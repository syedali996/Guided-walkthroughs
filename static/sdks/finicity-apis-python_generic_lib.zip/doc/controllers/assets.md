# Assets

Download asset files

```python
assets_controller = client.assets
```

## Class Name

`AssetsController`


# Get Asset by Customer ID

Retrieve a binary file for the given asset ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_asset_by_customer_id(self,
                            customer_id,
                            asset_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `asset_id` | `string` | Template, Required | The asset ID |

## Response Type

`binary`

## Example Usage

```python
customer_id = '1005061234'
asset_id = '097545c5-1c2a-4f20-a5ef-77f0820344c9-2018601178'

result = assets_controller.get_asset_by_customer_id(customer_id, asset_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

