# Portfolios

Generate portfolios of the most recent reports

```python
portfolios_controller = client.portfolios
```

## Class Name

`PortfoliosController`

## Methods

* [Get Portfolio by Customer](../../doc/controllers/portfolios.md#get-portfolio-by-customer)
* [Get Portfolio by Consumer](../../doc/controllers/portfolios.md#get-portfolio-by-consumer)


# Get Portfolio by Customer

Return a portfolio of most recently generated reports for each report type for the given customer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_portfolio_by_customer(self,
                             customer_id,
                             portfolio_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `portfolio_id` | `string` | Template, Required | A portfolio ID with the portfolio version number. Using the portfolio number without a version number will return the most recently generated reports. |

## Response Type

[`PortfolioSummary`](../../doc/models/portfolio-summary.md)

## Example Usage

```python
customer_id = '1005061234'
portfolio_id = 'y4zsgccj4xpw-6-port'

result = portfolios_controller.get_portfolio_by_customer(customer_id, portfolio_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Portfolio by Consumer

Return a portfolio of most recently generated reports for each report type for a given consumer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_portfolio_by_consumer(self,
                             consumer_id,
                             portfolio_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumer_id` | `string` | Template, Required | The consumer ID |
| `portfolio_id` | `string` | Template, Required | A portfolio ID with the portfolio version number. Using the portfolio number without a version number will return the most recently generated reports. |

## Response Type

[`PortfolioWithConsumerSummary`](../../doc/models/portfolio-with-consumer-summary.md)

## Example Usage

```python
consumer_id = '0bf46322c167b562e6cbed9d40e19a4c'
portfolio_id = 'y4zsgccj4xpw-6-port'

result = portfolios_controller.get_portfolio_by_consumer(consumer_id, portfolio_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

