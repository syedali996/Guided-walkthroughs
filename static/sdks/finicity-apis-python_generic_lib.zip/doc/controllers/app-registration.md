# App Registration

```python
app_registration_controller = client.app_registration
```

## Class Name

`AppRegistrationController`

## Methods

* [Register App](../../doc/controllers/app-registration.md#register-app)
* [Modify App Registration](../../doc/controllers/app-registration.md#modify-app-registration)
* [Get App Registration Status](../../doc/controllers/app-registration.md#get-app-registration-status)
* [Set Customer App ID](../../doc/controllers/app-registration.md#set-customer-app-id)
* [Migrate Institution Login Accounts](../../doc/controllers/app-registration.md#migrate-institution-login-accounts)


# Register App

Register a new application to access financial institutions using OAuth connections.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def register_app(self,
                body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```python
body = Application()
body.app_description = 'The app that makes your budgeting experience awesome'
body.app_name = 'Awesome Budget App'
body.app_url = 'https://www.finicity.com/'
body.owner_address_line_1 = '434 W Ascension Way'
body.owner_address_line_2 = 'Suite #200'
body.owner_city = 'Murray'
body.owner_country = 'USA'
body.owner_name = 'Finicity'
body.owner_postal_code = '84123'
body.owner_state = 'UT'
body.image = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K'

result = app_registration_controller.register_app(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify App Registration

Update a registered application.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def modify_app_registration(self,
                           pre_app_id,
                           body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pre_app_id` | `string` | Template, Required | The application registration tracking ID |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```python
pre_app_id = '2581'
body = Application()
body.app_description = 'The app that makes your budgeting experience awesome'
body.app_name = 'Awesome Budget App'
body.app_url = 'https://www.finicity.com/'
body.owner_address_line_1 = '434 W Ascension Way'
body.owner_address_line_2 = 'Suite #200'
body.owner_city = 'Murray'
body.owner_country = 'USA'
body.owner_name = 'Finicity'
body.owner_postal_code = '84123'
body.owner_state = 'UT'
body.image = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K'

result = app_registration_controller.modify_app_registration(pre_app_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get App Registration Status

Get the status of your application registration(s).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_app_registration_status(self,
                               pre_app_id=None,
                               application_id=None,
                               status=None,
                               app_name=None,
                               submitted_date=None,
                               modified_date=None,
                               page=1,
                               page_size=1)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pre_app_id` | `string` | Query, Optional | The application registration tracking ID |
| `application_id` | `string` | Query, Optional | The application ID |
| `status` | `string` | Query, Optional | Look up app registration requests by status |
| `app_name` | `string` | Query, Optional | Look up app registration requests by app name |
| `submitted_date` | `long\|int` | Query, Optional | Look up app registration requests by the date they were submitted |
| `modified_date` | `long\|int` | Query, Optional | Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R". |
| `page` | `int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `page_size` | `int` | Query, Optional | Maximum number of results per page<br>**Default**: `1` |

## Response Type

[`AppStatuses`](../../doc/models/app-statuses.md)

## Example Usage

```python
pre_app_id = '2581'
application_id = '123456789'
status = 'P'
app_name = 'Awesome Budget App'
submitted_date = 1607450357
modified_date = 1607450357
page = 1
page_size = 20

result = app_registration_controller.get_app_registration_status(pre_app_id, application_id, status, app_name, submitted_date, modified_date, page, page_size)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Set Customer App ID

If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def set_customer_app_id(self,
                       customer_id,
                       application_id,
                       body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `application_id` | `string` | Template, Required | The application ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

`void`

## Example Usage

```python
customer_id = '1005061234'
application_id = '123456789'

result = app_registration_controller.set_customer_app_id(customer_id, application_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Migrate Institution Login Accounts

The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.

This API returns a list of accounts for the given institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def migrate_institution_login_accounts(self,
                                      customer_id,
                                      institution_login_id,
                                      body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `institution_login_id` | `string` | Template, Required | The institution login ID |
| `body` | `object` | Body, Required | No payload expected |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```python
customer_id = '1005061234'
institution_login_id = '1007302745'
body = jsonpickle.decode('{"key1":"val1","key2":"val2"}')

result = app_registration_controller.migrate_institution_login_accounts(customer_id, institution_login_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

