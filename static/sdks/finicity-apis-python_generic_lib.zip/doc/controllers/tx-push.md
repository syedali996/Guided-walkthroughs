# Tx Push

Manage TxPush subscriptions

```python
tx_push_controller = client.tx_push
```

## Class Name

`TxPushController`

## Methods

* [Subscribe to Tx Push Notifications](../../doc/controllers/tx-push.md#subscribe-to-tx-push-notifications)
* [Disable Tx Push Notifications](../../doc/controllers/tx-push.md#disable-tx-push-notifications)
* [Create Tx Push Test Transaction](../../doc/controllers/tx-push.md#create-tx-push-test-transaction)
* [Delete Tx Push Subscription](../../doc/controllers/tx-push.md#delete-tx-push-subscription)


# Subscribe to Tx Push Notifications

Register a client app's TxPush Listener to receive TxPush notifications related to the given account.

Each call to this service will return two records, one with class account and one with class transaction. Account events are sent when values change in the account's fields (such as `balance` or `interestRate`). Transaction events are sent whenever a new transaction is posted for the account. For institutions that do not provide TxPush services, notifications are sent as soon as Finicity finds a new transaction or new account data through regular aggregation processes.

The listener's URL must be secure (HTTPS) for any real-world account. In addition, the client's TxPush Listener will need to be verified. HTTP and HTTPS connections are only allowed on the standard ports 80 (HTTP) and 443 (HTTPS). The use of other ports will result with the call failing.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def subscribe_to_tx_push_notifications(self,
                                      customer_id,
                                      account_id,
                                      body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |
| `body` | [`TxPushSubscriptionParameters`](../../doc/models/tx-push-subscription-parameters.md) | Body, Required | - |

## Response Type

[`TxPushSubscriptions`](../../doc/models/tx-push-subscriptions.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'
body = TxPushSubscriptionParameters()
body.callback_url = 'https://www.mydomain.com/txpush/listener'

result = tx_push_controller.subscribe_to_tx_push_notifications(customer_id, account_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Disable Tx Push Notifications

Delete all TxPush subscriptions with their notifications for the given account. No more notifications will be sent for account or transaction events.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def disable_tx_push_notifications(self,
                                 customer_id,
                                 account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

`void`

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = tx_push_controller.disable_tx_push_notifications(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Create Tx Push Test Transaction

Inject a transaction into the transaction list for a testing account. This allows an app to trigger TxPush notifications for the account in order to test the app's TxPush Listener service. This causes the platform to send one transaction event and one account event (showing that the account balance has changed). This service is only supported for testing accounts.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def create_tx_push_test_transaction(self,
                                   customer_id,
                                   account_id,
                                   body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |
| `body` | [`TestTxPushTransaction`](../../doc/models/test-tx-push-transaction.md) | Body, Required | - |

## Response Type

[`CreatedTestTxPushTransaction`](../../doc/models/created-test-tx-push-transaction.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'
body = TestTxPushTransaction()
body.amount = -4.25
body.description = 'a testing transaction description'
body.transaction_date = 1607450357

result = tx_push_controller.create_tx_push_test_transaction(customer_id, account_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Tx Push Subscription

Delete a specific subscription to TxPush notifications for the given account. This could be individual deleting the account or transactions events. No more events will be sent for that specific subscription.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def delete_tx_push_subscription(self,
                               customer_id,
                               subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `subscription_id` | `long\|int` | Template, Required | The subscription ID |

## Response Type

`void`

## Example Usage

```python
customer_id = '1005061234'
subscription_id = 17554874

result = tx_push_controller.delete_tx_push_subscription(customer_id, subscription_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

