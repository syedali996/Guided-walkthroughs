# Payments

Fetch ACH details and account balances

```python
payments_controller = client.payments
```

## Class Name

`PaymentsController`

## Methods

* [Get Account Owner](../../doc/controllers/payments.md#get-account-owner)
* [Get Loan Payment Details](../../doc/controllers/payments.md#get-loan-payment-details)
* [Get Account ACH Details](../../doc/controllers/payments.md#get-account-ach-details)
* [Get Available Balance Live](../../doc/controllers/payments.md#get-available-balance-live)
* [Get Available Balance](../../doc/controllers/payments.md#get-available-balance)


# Get Account Owner

Retrieve the names and addresses of the account owner from a financial institution.

Note: this is a premium service, billable per every successful API call.

This service retrieves account data from the institution. This usually returns quickly, but in some scenarios may take a few minutes to complete. In the event of a timeout condition, retry the call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_account_owner(self,
                     customer_id,
                     account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

[`AccountOwner`](../../doc/models/account-owner.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = payments_controller.get_account_owner(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Loan Payment Details

Return the loan payment details of the customer for a loan-type account.

Note: this is a premium service, billable per every successful API call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_loan_payment_details(self,
                            customer_id,
                            account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

[`LoanPaymentDetails`](../../doc/models/loan-payment-details.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = payments_controller.get_loan_payment_details(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Account ACH Details

Return the real account number and routing number details for an ACH payment.

Note: this is a premium service, billable per every successful API call.

_Supported account types_: "checking", "savings", "moneyMarket", "loan"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_account_ach_details(self,
                           customer_id,
                           account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

[`ACHDetails`](../../doc/models/ach-details.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = payments_controller.get_account_ach_details(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Available Balance Live

Retrieve the available and cleared account balances for a single account in real-time directly from a financial institution.

Note: this is a premium service, billable per every successful API call.

_Supported account types_: "checking", "savings", "moneyMarket", "cd"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_available_balance_live(self,
                              customer_id,
                              account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

[`AvailableBalance`](../../doc/models/available-balance.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = payments_controller.get_available_balance_live(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Available Balance

Retrieve the latest cached available and cleared account balances for a customer. Since we update and store balances throughout the day, this is the most accurate balance information available when a connection to a financial institution is unavailable or when a faster response is needed. Only deposit account types are supported: Checking, Savings, Money Market, and CD.

Note: this is a premium service, billable per every successful API call. Enrollment is required.

_Supported account types_: "checking", "savings", "moneyMarket", "cd"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_available_balance(self,
                         customer_id,
                         account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

[`AvailableBalance`](../../doc/models/available-balance.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = payments_controller.get_available_balance(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

