# Transactions

Fetch customer and account transactions and generate reports asynchronously

```python
transactions_controller = client.transactions
```

## Class Name

`TransactionsController`

## Methods

* [Load Historic Transactions for Customer Account](../../doc/controllers/transactions.md#load-historic-transactions-for-customer-account)
* [Get All Customer Transactions](../../doc/controllers/transactions.md#get-all-customer-transactions)
* [Get Customer Transaction](../../doc/controllers/transactions.md#get-customer-transaction)
* [Get Customer Account Transactions](../../doc/controllers/transactions.md#get-customer-account-transactions)
* [Generate Transactions Report](../../doc/controllers/transactions.md#generate-transactions-report)


# Load Historic Transactions for Customer Account

Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.

This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.)

The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.

In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:

* The institution's policy has changed, making more transactions available
* Finicity has now added a longer transaction history support for the institution
* The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team

In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def load_historic_transactions_for_customer_account(self,
                                                   customer_id,
                                                   account_id,
                                                   body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

`void`

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = transactions_controller.load_historic_transactions_for_customer_account(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get All Customer Transactions

Get all transactions available for this customer within the given date range, across all accounts. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.

Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the service Load Historic Transactions for Account.

There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_all_customer_transactions(self,
                                 customer_id,
                                 from_date,
                                 to_date,
                                 start=1,
                                 limit=25,
                                 sort='desc',
                                 include_pending=False)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `from_date` | `long\|int` | Query, Required | A start date |
| `to_date` | `long\|int` | Query, Required | A end date |
| `start` | `int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `sort` | `string` | Query, Optional | Date sort order: "asc" for ascending, "desc" for descending<br>**Default**: `'desc'` |
| `include_pending` | `bool` | Query, Optional | If pending transactions must be included<br>**Default**: `False` |

## Response Type

[`Transactions`](../../doc/models/transactions.md)

## Example Usage

```python
customer_id = '1005061234'
from_date = 1607450357
to_date = 1607450357
start = 1
limit = 25
sort = 'desc'
include_pending = False

result = transactions_controller.get_all_customer_transactions(customer_id, from_date, to_date, start, limit, sort, include_pending)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Transaction

Get details for the given transaction.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_customer_transaction(self,
                            customer_id,
                            transaction_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `transaction_id` | `long\|int` | Template, Required | A transaction ID |

## Response Type

[`Transaction`](../../doc/models/transaction.md)

## Example Usage

```python
customer_id = '1005061234'
transaction_id = 21284820852

result = transactions_controller.get_customer_transaction(customer_id, transaction_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Account Transactions

Get all transactions available for this customer account within the given date range. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.

Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the Cash Flow Verification service Load Historic Transactions for Account.

There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_customer_account_transactions(self,
                                     customer_id,
                                     account_id,
                                     from_date,
                                     to_date,
                                     start=1,
                                     limit=25,
                                     sort='desc',
                                     include_pending=False)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |
| `from_date` | `long\|int` | Query, Required | A start date |
| `to_date` | `long\|int` | Query, Required | A end date |
| `start` | `int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `sort` | `string` | Query, Optional | Date sort order: "asc" for ascending, "desc" for descending<br>**Default**: `'desc'` |
| `include_pending` | `bool` | Query, Optional | If pending transactions must be included<br>**Default**: `False` |

## Response Type

[`Transactions`](../../doc/models/transactions.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'
from_date = 1607450357
to_date = 1607450357
start = 1
limit = 25
sort = 'desc'
include_pending = False

result = transactions_controller.get_customer_account_transactions(customer_id, account_id, from_date, to_date, start, limit, sort, include_pending)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Transactions Report

Generate a Transaction Report for the given accounts under the given customer. This service retrieves up to 24 months of transaction history for the given customer. It then uses this information to generate the Transaction Report.

This is a premium service. A billable event will be created upon the successful generation of the Transactions Report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

There cannot be more than 24 months between `fromDate` and `toDate`.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_transactions_report(self,
                                customer_id,
                                to_date,
                                body,
                                callback_url=None,
                                include_pending=False)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `to_date` | `long\|int` | Query, Required | A end date |
| `body` | [`TransactionsReportConstraints`](../../doc/models/transactions-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |
| `include_pending` | `bool` | Query, Optional | If pending transactions must be included<br>**Default**: `False` |

## Response Type

[`TransactionsReportAck`](../../doc/models/transactions-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
to_date = 1607450357
body = TransactionsReportConstraints()
body.account_ids = '1027339038 1027339039'
body.from_date = 1580558400
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

callback_url = 'https://finicity-test/webhook'
include_pending = False

result = transactions_controller.generate_transactions_report(customer_id, to_date, body, callback_url, include_pending)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

