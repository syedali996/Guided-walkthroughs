# Pay Statements

```python
pay_statements_controller = client.pay_statements
```

## Class Name

`PayStatementsController`


# Store Customer Pay Statement

Upload pay statements for a customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def store_customer_pay_statement(self,
                                customer_id,
                                body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`PayStatement`](../../doc/models/pay-statement.md) | Body, Required | - |

## Response Type

[`Asset`](../../doc/models/asset.md)

## Example Usage

```python
customer_id = '1005061234'
body = PayStatement()
body.label = 'lastPayPeriod'
body.statement = 'VGhpcyBtdXN0IGJlIGFuIGltYWdl'

result = pay_statements_controller.store_customer_pay_statement(customer_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

