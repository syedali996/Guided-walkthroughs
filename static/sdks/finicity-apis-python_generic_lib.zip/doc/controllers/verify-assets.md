# Verify Assets

```python
verify_assets_controller = client.verify_assets
```

## Class Name

`VerifyAssetsController`

## Methods

* [Generate VOA Report](../../doc/controllers/verify-assets.md#generate-voa-report)
* [Generate VOA With Income Report](../../doc/controllers/verify-assets.md#generate-voa-with-income-report)
* [Generate Prequalification CRA Report](../../doc/controllers/verify-assets.md#generate-prequalification-cra-report)
* [Generate Prequalification Non CRA Report](../../doc/controllers/verify-assets.md#generate-prequalification-non-cra-report)


# Generate VOA Report

Generate a Verification of Assets (VOA) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to twelve months of transaction history for each account and uses this information to generate the VOA report.

This is a premium service. The billing rate is the variable rate for Verification of Assets under the current subscription plan. The billable event is the successful generation of a VOA report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_voa_report(self,
                       customer_id,
                       body,
                       callback_url=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`VOAReportConstraints`](../../doc/models/voa-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`VOAReportAck`](../../doc/models/voa-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
body = VOAReportConstraints()
body.account_ids = '1000535275'
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

body.show_nsf = False
body.from_date = 1580558400
callback_url = 'https://finicity-test/webhook'

result = verify_assets_controller.generate_voa_report(customer_id, body, callback_url)
```

## Example Response *(as JSON)*

```json
{
  "id": "u4hstnnak45g",
  "portfolioId": "dyr6qvqd2yhb-1-port",
  "customerType": "active",
  "customerId": 1000006677,
  "requestId": "sfb7xp439w",
  "requesterName": "Decisioning API",
  "createdDate": 1588350269,
  "title": "Finicity Verification of Assets",
  "consumerId": "ac39e237c7619a4ecf014b8d399c0696",
  "consumerSsn": "6789",
  "constraints": {
    "accountIds": [
      "1000535275",
      "1000535276"
    ],
    "fromDate": 1577986990,
    "showNsf": false,
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "voa",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate VOA With Income Report

Generate a Verification of Assets with Income (VOAI) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to 24 months of transaction history for each account and uses this information to generate the VOAI report. The report includes 1 - 6 months of all debit and credit transactions for asset verification. By default, the history is set to 61 days, however, you can change the transaction history in this section by setting the `fromDate` parameter. The report also includes up to 24 months of income credit transactions (ordered by account and confidence level) regardless of `fromDate` for income verification.

This is a premium service. The billable event is the successful generation of a VOAI report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_voa_with_income_report(self,
                                   customer_id,
                                   body,
                                   callback_url=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`VOAWithIncomeReportConstraints`](../../doc/models/voa-with-income-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`VOAWithIncomeReportAck`](../../doc/models/voa-with-income-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
body = VOAWithIncomeReportConstraints()
body.account_ids = '1000535275'
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

body.show_nsf = False
body.from_date = 1580558400
body.income_stream_confidence_minimum = 50
callback_url = 'https://finicity-test/webhook'

result = verify_assets_controller.generate_voa_with_income_report(customer_id, body, callback_url)
```

## Example Response *(as JSON)*

```json
{
  "id": "u4hstnyak45g",
  "portfolioId": "dyr6weqd2yhb-1-port",
  "customerType": "active",
  "customerId": 1000006677,
  "requestId": "sfb7x1we9w",
  "requesterName": "Decisioning API",
  "createdDate": 1588350269,
  "title": "Verification of Asset and Income - Transactions",
  "consumerId": "ac39e237c7619a4ecf014b8d399c0696",
  "consumerSsn": "6789",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "fromDate": 1580558400,
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ],
    "showNsf": false,
    "incomeStreamConfidenceMinimum": 50
  },
  "type": "voaHistory",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Prequalification CRA Report

Retrieve all checking, savings, money market, and investment accounts for a consumer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.

If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_prequalification_cra_report(self,
                                        customer_id,
                                        body,
                                        callback_url=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`PrequalificationReportConstraints`](../../doc/models/prequalification-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`PrequalificationReportAck`](../../doc/models/prequalification-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
body = PrequalificationReportConstraints()
body.account_ids = '1000535275'
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

body.show_nsf = False
body.from_date = 1580558400
callback_url = 'https://finicity-test/webhook'

result = verify_assets_controller.generate_prequalification_cra_report(customer_id, body, callback_url)
```

## Example Response *(as JSON)*

```json
{
  "id": "88w4fbssrbja-prequalvoa",
  "portfolioId": "0whcism47a34-5-port",
  "customerType": "active",
  "customerId": 1000006677,
  "requestId": "sfb7xacr9w",
  "requesterName": "Decisioning API",
  "createdDate": 1588350269,
  "title": "Asset Ready Report (CRA)",
  "consumerId": "cb619e10185177cd92271c4da2df3fa3",
  "consumerSsn": "6789",
  "constraints": {
    "accountIds": [
      "1000535275",
      "1000535276"
    ],
    "fromDate": 1577986990,
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ],
    "showNsf": false
  },
  "type": "preQualVoa",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Prequalification Non CRA Report

Retrieve all checking, savings, money market, and investment accounts for a customer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.

If no account type of checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_prequalification_non_cra_report(self,
                                            customer_id,
                                            body,
                                            callback_url=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`PrequalificationReportConstraints`](../../doc/models/prequalification-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`PrequalificationReportAck`](../../doc/models/prequalification-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
body = PrequalificationReportConstraints()
body.account_ids = '1000535275'
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

body.show_nsf = False
body.from_date = 1580558400
callback_url = 'https://finicity-test/webhook'

result = verify_assets_controller.generate_prequalification_non_cra_report(customer_id, body, callback_url)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

