# Institutions

Search and fetch financial institutions

```python
institutions_controller = client.institutions
```

## Class Name

`InstitutionsController`

## Methods

* [Get Certified Institutions With RSSD](../../doc/controllers/institutions.md#get-certified-institutions-with-rssd)
* [Get Institutions](../../doc/controllers/institutions.md#get-institutions)
* [Get Certified Institutions](../../doc/controllers/institutions.md#get-certified-institutions)
* [Get Institution](../../doc/controllers/institutions.md#get-institution)
* [Get Institution Branding](../../doc/controllers/institutions.md#get-institution-branding)


# Get Certified Institutions With RSSD

Search for certified financial institutions w/RSSD.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_certified_institutions_with_rssd(self,
                                        search=None,
                                        start=1,
                                        limit=25,
                                        mtype=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `mtype` | `string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`CertifiedInstitutions`](../../doc/models/certified-institutions.md)

## Example Usage

```python
search = 'finbank'
start = 1
limit = 25
mtype = 'voa'

result = institutions_controller.get_certified_institutions_with_rssd(search, start, limit, mtype)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institutions

Search for financial institutions.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_institutions(self,
                    search=None,
                    start=1,
                    limit=25,
                    mtype=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `mtype` | `string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`Institutions`](../../doc/models/institutions.md)

## Example Usage

```python
search = 'finbank'
start = 1
limit = 25
mtype = 'voa'

result = institutions_controller.get_institutions(search, start, limit, mtype)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Certified Institutions

Search for financial institutions by certified product.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_certified_institutions(self,
                              search=None,
                              start=1,
                              limit=25,
                              mtype=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `mtype` | `string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`CertifiedInstitutions`](../../doc/models/certified-institutions.md)

## Example Usage

```python
search = 'finbank'
start = 1
limit = 25
mtype = 'voa'

result = institutions_controller.get_certified_institutions(search, start, limit, mtype)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution

Get financial institution details by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_institution(self,
                   institution_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution_id` | `long\|int` | Template, Required | The institution ID |

## Response Type

[`InstitutionWrapper`](../../doc/models/institution-wrapper.md)

## Example Usage

```python
institution_id = 4222

result = institutions_controller.get_institution(institution_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution Branding

Return the branding information for a financial institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_institution_branding(self,
                            institution_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution_id` | `long\|int` | Template, Required | The institution ID |

## Response Type

[`BrandingWrapper`](../../doc/models/branding-wrapper.md)

## Example Usage

```python
institution_id = 4222

result = institutions_controller.get_institution_branding(institution_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

