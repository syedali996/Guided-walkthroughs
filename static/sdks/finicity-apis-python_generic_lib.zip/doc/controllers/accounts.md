# Accounts

Fetch or refresh customer accounts

```python
accounts_controller = client.accounts
```

## Class Name

`AccountsController`

## Methods

* [Get Customer Accounts by Institution Login](../../doc/controllers/accounts.md#get-customer-accounts-by-institution-login)
* [Refresh Customer Accounts by Institution Login](../../doc/controllers/accounts.md#refresh-customer-accounts-by-institution-login)
* [Delete Customer Accounts by Institution Login](../../doc/controllers/accounts.md#delete-customer-accounts-by-institution-login)
* [Get Customer Account](../../doc/controllers/accounts.md#get-customer-account)
* [Delete Customer Account](../../doc/controllers/accounts.md#delete-customer-account)
* [Get Customer Accounts](../../doc/controllers/accounts.md#get-customer-accounts)
* [Refresh Customer Accounts](../../doc/controllers/accounts.md#refresh-customer-accounts)
* [Get Customer Accounts by Institution](../../doc/controllers/accounts.md#get-customer-accounts-by-institution)


# Get Customer Accounts by Institution Login

Get all accounts associated with the given institution login. All accounts returned are accessible by a single set of credentials on a single institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_customer_accounts_by_institution_login(self,
                                              customer_id,
                                              institution_login_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `institution_login_id` | `string` | Template, Required | The institution login ID |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```python
customer_id = '1005061234'
institution_login_id = '1007302745'

result = accounts_controller.get_customer_accounts_by_institution_login(customer_id, institution_login_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Refresh Customer Accounts by Institution Login

Refresh account and transaction data for all accounts associated with a given `institutionLoginId` with a connection to the institution.

Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.

Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.

The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def refresh_customer_accounts_by_institution_login(self,
                                                  customer_id,
                                                  institution_login_id,
                                                  body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `institution_login_id` | `string` | Template, Required | The institution login ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```python
customer_id = '1005061234'
institution_login_id = '1007302745'

result = accounts_controller.refresh_customer_accounts_by_institution_login(customer_id, institution_login_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Customer Accounts by Institution Login

Remove from Finicity aggregation the set of accounts matching the institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def delete_customer_accounts_by_institution_login(self,
                                                 customer_id,
                                                 institution_login_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `institution_login_id` | `string` | Template, Required | The institution login ID |

## Response Type

`void`

## Example Usage

```python
customer_id = '1005061234'
institution_login_id = '1007302745'

result = accounts_controller.delete_customer_accounts_by_institution_login(customer_id, institution_login_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Account

Get a customer account by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_customer_account(self,
                        customer_id,
                        account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

[`CustomerAccount`](../../doc/models/customer-account.md)

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = accounts_controller.get_customer_account(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Customer Account

Remove the given account from Finicity aggregation.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def delete_customer_account(self,
                           customer_id,
                           account_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `account_id` | `string` | Template, Required | The account ID |

## Response Type

`void`

## Example Usage

```python
customer_id = '1005061234'
account_id = '5011648377'

result = accounts_controller.delete_customer_account(customer_id, account_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Accounts

Get all accounts owned by the given customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_customer_accounts(self,
                         customer_id,
                         status=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `status` | `string` | Query, Optional | A filter to fetch account in the given status |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```python
customer_id = '1005061234'
status = 'pending'

result = accounts_controller.get_customer_accounts(customer_id, status)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Refresh Customer Accounts

Refresh account and transaction data for all accounts associated with the  given `customerId` with a connection to the institution.

Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.

Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.

The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def refresh_customer_accounts(self,
                             customer_id,
                             body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```python
customer_id = '1005061234'

result = accounts_controller.refresh_customer_accounts(customer_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Accounts by Institution

Get all active accounts owned by the given customer at the given institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def get_customer_accounts_by_institution(self,
                                        customer_id,
                                        institution_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `institution_id` | `long\|int` | Template, Required | The institution ID |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```python
customer_id = '1005061234'
institution_id = 4222

result = accounts_controller.get_customer_accounts_by_institution(customer_id, institution_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

