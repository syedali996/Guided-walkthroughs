# Cash Flow

```python
cash_flow_controller = client.cash_flow
```

## Class Name

`CashFlowController`

## Methods

* [Generate Cash Flow Business Report](../../doc/controllers/cash-flow.md#generate-cash-flow-business-report)
* [Generate Cash Flow Personal Report](../../doc/controllers/cash-flow.md#generate-cash-flow-personal-report)


# Generate Cash Flow Business Report

Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.

This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_cash_flow_business_report(self,
                                      customer_id,
                                      body,
                                      callback_url=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`CashFlowReportAck`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
body = CashFlowReportConstraints()
body.account_ids = '1000535275'
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

body.show_nsf = False
body.from_date = 1580558400
body.income_stream_confidence_minimum = 50
callback_url = 'https://finicity-test/webhook'

result = cash_flow_controller.generate_cash_flow_business_report(customer_id, body, callback_url)
```

## Example Response *(as JSON)*

```json
{
  "id": "383z55zudewm-cfrb",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Business",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrb",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Cash Flow Personal Report

Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.

This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```python
def generate_cash_flow_personal_report(self,
                                      customer_id,
                                      body,
                                      callback_url=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Template, Required | A customer ID |
| `body` | [`CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callback_url` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`CashFlowReportAck`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```python
customer_id = '1005061234'
body = CashFlowReportConstraints()
body.account_ids = '1000535275'
body.report_custom_fields = []

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[0].label = 'loanID'
body.report_custom_fields[0].value = '12345'
body.report_custom_fields[0].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[1].label = 'trackingID'
body.report_custom_fields[1].value = '5555'
body.report_custom_fields[1].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[2].label = 'loanType'
body.report_custom_fields[2].value = 'car'
body.report_custom_fields[2].shown = False

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[3].label = 'vendorID'
body.report_custom_fields[3].value = '1613aa23'
body.report_custom_fields[3].shown = True

body.report_custom_fields.append(ReportCustomField())
body.report_custom_fields[4].label = 'vendorName'
body.report_custom_fields[4].value = 'PSC Finance'
body.report_custom_fields[4].shown = False

body.show_nsf = False
body.from_date = 1580558400
body.income_stream_confidence_minimum = 50
callback_url = 'https://finicity-test/webhook'

result = cash_flow_controller.generate_cash_flow_personal_report(customer_id, body, callback_url)
```

## Example Response *(as JSON)*

```json
{
  "id": "383z51zurqwo-cfrp",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Personal",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrp",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

