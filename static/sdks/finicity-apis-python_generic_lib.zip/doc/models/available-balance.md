
# Available Balance

## Structure

`AvailableBalance`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `real_account_number_last_4` | `string` | Required | The last 4 digits of the ACH account number |
| `available_balance` | `float` | Required | The available balance of the account |
| `available_balance_date` | `long\|int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `cleared_balance` | `float` | Required | The cleared balance of the account. Also referred as posted balance, current balance, ledger balance |
| `cleared_balance_date` | `long\|int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `aggregation_status_code` | `int` | Required | The status of the most recent aggregation attempt (see [Aggregation Status Codes](https://docs.finicity.com/aggregation-status-codes/)). Won't be present until you have run your first aggregation for the account. |
| `currency` | `string` | Required | A currency code |

## Example (as JSON)

```json
{
  "id": 1005061234,
  "realAccountNumberLast4": "5678",
  "availableBalance": 173.47,
  "availableBalanceDate": 1607450357,
  "clearedBalance": 222.25,
  "clearedBalanceDate": 1607450357,
  "aggregationStatusCode": null,
  "currency": "USD"
}
```

