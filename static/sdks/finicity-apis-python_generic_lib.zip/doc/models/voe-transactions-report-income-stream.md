
# VOE Transactions Report Income Stream

## Structure

`VOETransactionsReportIncomeStream`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | Income stream ID |
| `name` | `string` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream |
| `status` | `string` | Required | Possible values: "ACTIVE", "INACTIVE" |
| `estimate_inclusion` | `string` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" |
| `confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) |
| `cadence` | [`CadenceDetails`](../../doc/models/cadence-details.md) | Required | - |
| `days_since_last_transaction` | `int` | Required | The number of days since the last credit transaction for the particular income stream |
| `next_expected_transaction_date` | `long\|int` | Required | The next expected credit transaction date for the particular income stream, based on the cadence |
| `income_stream_months` | `int` | Required | The number of months the income transactions are observed |
| `transactions` | [`List of ReportTransaction`](../../doc/models/report-transaction.md) | Required | A list of transaction records |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voah",
  "name": "none",
  "status": null,
  "estimateInclusion": null,
  "confidence": 70,
  "cadence": null,
  "daysSinceLastTransaction": 15,
  "nextExpectedTransactionDate": 1572625469,
  "incomeStreamMonths": 18,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

