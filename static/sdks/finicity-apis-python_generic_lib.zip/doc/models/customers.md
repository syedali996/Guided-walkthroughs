
# Customers

A list of customers

## Structure

`Customers`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `found` | `int` | Required | The total number of results matching search criteria |
| `displaying` | `int` | Required | The number of results returned |
| `more_available` | `bool` | Required | If the value of `moreAvailable` is "true", you can retrieve the next page of results by increasing the value of the start parameter in your next request:"...&start=6&limit=5" |
| `customers` | [`List of Customer`](../../doc/models/customer.md) | Required | A list of customer records |

## Example (as JSON)

```json
{
  "found": 200,
  "displaying": 2,
  "moreAvailable": true,
  "customers": {
    "id": "1005061234",
    "username": "customerusername1",
    "type": "active",
    "createdDate": "1607450357"
  }
}
```

