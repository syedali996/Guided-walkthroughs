
# Cash Flow Outflow Attributes

## Structure

`CashFlowOutflowAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `average_withdrawal_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of withdrawals during periods in the report |
| `count_withdrawals_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndCount`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all withdrawals during periods in the report |
| `historic_count_of_withdrawal_transactions` | `int` | Required | Count of ALL withdrawals over entire known history of the account (may exceed requested length of report) |
| `historic_sum_of_withdrawals` | `float` | Optional | Sum of ALL withdrawals over entire known history of the account (may exceed requested length of report) |
| `maximum_withdrawal_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum withdrawal value for different periods in the report |
| `minimum_withdrawal_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum withdrawal value for different periods in the report |
| `sum_withdrawals_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all withdrawals during periods in the report |

## Example (as JSON)

```json
{
  "countWithdrawalsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfWithdrawalTransactions": 20,
  "maximumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumWithdrawalsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

