
# Obb Num Weeks Average Balance Increasing

## Structure

`ObbNumWeeksAverageBalanceIncreasing`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `historic_average_weekly_balances` | [`List of ObbAverageWeeklyBalance`](../../doc/models/obb-average-weekly-balance.md) | Required | Average weekly balances over the known history |
| `historic_number_of_weeks_average_balance_increasing` | `int` | Required | Number of weeks during the known history where the average balance of the account increased week over week |
| `historic_number_of_weeks_with_data_available` | `int` | Required | Number of weeks during the history in which data was available |

## Example (as JSON)

```json
{
  "historicAverageWeeklyBalances": {
    "amount": 679.07,
    "fromDate": "2020-01-01",
    "toDate": "2020-01-07",
    "week": 1
  },
  "historicNumberOfWeeksAverageBalanceIncreasing": 3,
  "historicNumberOfWeeksWithDataAvailable": 4
}
```

