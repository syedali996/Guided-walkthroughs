
# VOA With Income Report Account

## Structure

`VOAWithIncomeReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The ID of the account |
| `number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `owner_name` | `string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `owner_address` | `string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `name` | `string` | Optional | The account name from the institution |
| `mtype` | `string` | Optional | One of the values from account types |
| `available_balance` | `float` | Optional | The available balance for the account |
| `aggregation_status_code` | `int` | Optional | The status of the most recent aggregation attempt |
| `balance` | `float` | Optional | The cleared balance of the account as-of balanceDate |
| `balance_date` | `long\|int` | Optional | A timestamp showing when the balance was captured |
| `average_monthly_balance` | `float` | Optional | The average monthly balance of this account |
| `tot_number_insufficient_funds_fee_debit_tx_account` | `long\|int` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report. |
| `tot_number_insufficient_funds_fee_debit_tx_over_2_months_account` | `long\|int` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. |
| `tot_number_days_since_most_recent_insufficient_funds_fee_debit_tx_account` | `long\|int` | Optional | The number of days since the most recent insufficient funds transaction, based on the `fromDate` of the report. |
| `transactions` | [`List of ReportTransaction`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `details` | [`AccountDetails`](../../doc/models/account-details.md) | Optional | - |
| `asset` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `income_streams` | [`List of VOAIReportIncomeStream`](../../doc/models/voai-report-income-stream.md) | Optional | A list of income stream records |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "availableBalance": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "details": null,
  "asset": null,
  "incomeStreams": null
}
```

