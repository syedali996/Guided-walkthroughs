
# Consumer Update

## Structure

`ConsumerUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | First name(s) / given name(s) |
| `last_name` | `string` | Optional | Last name(s) / surname(s) |
| `address` | `string` | Optional | A street address |
| `city` | `string` | Optional | A city |
| `state` | `string` | Optional | A state |
| `zip` | `string` | Optional | A ZIP code |
| `phone` | `string` | Optional | A phone number |
| `ssn` | `string` | Optional | A full SSN with or without hyphens |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Optional | A birth date |
| `email` | `string` | Optional | An email address |
| `suffix` | `string` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "address": null,
  "city": null,
  "state": null,
  "zip": null,
  "phone": null,
  "ssn": null,
  "birthday": null,
  "email": null,
  "suffix": null
}
```

