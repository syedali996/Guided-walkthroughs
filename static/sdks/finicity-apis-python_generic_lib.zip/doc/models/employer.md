
# Employer

## Structure

`Employer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | The name of the employer |

## Example (as JSON)

```json
{
  "name": null
}
```

