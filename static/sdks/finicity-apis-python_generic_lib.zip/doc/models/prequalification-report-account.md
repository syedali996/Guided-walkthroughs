
# Prequalification Report Account

## Structure

`PrequalificationReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The ID of the account |
| `number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `owner_name` | `string` | Optional | The name of the account owner. If no owner information is available, this field won't appear in the report. |
| `owner_address` | `string` | Optional | The mailing address of the account owner. If no owner information is available, this field won't appear in the report. |
| `name` | `string` | Optional | The account name from the institution |
| `mtype` | `string` | Optional | One of the values from account types |
| `aggregation_status_code` | `int` | Optional | The status of the most recent aggregation attempt |
| `balance` | `float` | Optional | The cleared balance of the account as-of `balanceDate` |
| `balance_date` | `long\|int` | Optional | A timestamp of the balance |
| `available_balance` | `float` | Optional | Available balance |
| `average_monthly_balance` | `float` | Optional | The average monthly balance of the account |
| `tot_number_insufficient_funds_fee_debit_tx_account` | `int` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report |
| `tot_number_insufficient_funds_fee_debit_tx_over_6_months_account` | `int` | Optional | The total number of  insufficient funds fees for the account over six months |
| `tot_number_days_since_most_recent_insufficient_funds_fee_debit_tx_account` | `long\|int` | Optional | The total number of days since the most recent insufficient funds fee for the account |
| `transactions` | [`List of ReportTransaction`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `asset` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `details` | [`AccountDetails`](../../doc/models/account-details.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "availableBalance": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "asset": null,
  "details": null
}
```

