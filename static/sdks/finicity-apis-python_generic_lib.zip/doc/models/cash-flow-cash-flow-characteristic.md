
# Cash Flow Cash Flow Characteristic

## Structure

`CashFlowCashFlowCharacteristic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthly_cash_flow_characteristics` | [`List of CashFlowMonthlyCashFlowCharacteristics`](../../doc/models/cash-flow-monthly-cash-flow-characteristics.md) | Required | List of attributes for each month |
| `average_monthly_net` | `float` | Required | Average (Total Credits - Total Debits) for the account |
| `average_monthly_net_less_transfers` | `float` | Required | Average (Total Credits - Total Debits) without transfers for the account |
| `twelve_month_total_net` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) each month for the account |
| `twelve_month_total_net_less_transfers` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers for the account |
| `six_month_average_total_credits_less_total_debits` | `float` | Required | 6 Month Average (Total Credits - Total Debits) |
| `six_month_average_total_credits_less_total_debits_less_transfers` | `float` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) |
| `two_month_average_total_credits_less_total_debits` | `float` | Required | 2 Month Average (Total Credits - Total Debits) |
| `two_month_average_total_credits_less_total_debits_less_transfers` | `float` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristics": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 2350,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

