
# Borrower

## Structure

`Borrower`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `string` | Required | A customer ID. See Add Customer API for how to create a customer ID. |
| `consumer_id` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `mtype` | `string` | Required | "primary" or "jointBorrower" |
| `optional_consumer_info` | [`ConsumerInfo`](../../doc/models/consumer-info.md) | Optional | The SSN and date of birth of a consumer |

## Example (as JSON)

```json
{
  "customerId": "1005061234",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "type": "primary"
}
```

