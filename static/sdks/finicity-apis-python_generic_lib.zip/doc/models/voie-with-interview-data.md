
# VOIE With Interview Data

## Structure

`VOIEWithInterviewData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tx_verify_interview` | [`List of TxVerifyInterview`](../../doc/models/tx-verify-interview.md) | Required | An array of `TxVerifyInterview` objects |
| `extract_earnings` | `bool` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `True` |
| `extract_deductions` | `bool` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `False` |
| `extract_direct_deposit` | `bool` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `True` |

## Example (as JSON)

```json
{
  "txVerifyInterview": {
    "assetId": "097545c5-1c2a-4f20-a5ef-77f0820344c9-2018601178"
  }
}
```

