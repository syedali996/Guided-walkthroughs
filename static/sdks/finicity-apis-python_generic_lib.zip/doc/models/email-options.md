
# Email Options

Configuration for the Connect email's sent to customers

## Structure

`EmailOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `to` | `string` | Required | The email address for the customer receiving the Connect email |
| `mfrom` | `string` | Optional | The name of a person or business sending the Connect email |
| `support_phone` | `string` | Optional | The support phone number listed in the email |
| `subject` | `string` | Optional | The subject line of the email. The default is "Verify your Financial Information". |
| `first_name` | `string` | Optional | The first name of the customer or both names of the customers for joint borrowers. Example: "Marvin and Jenny". |
| `institution_name` | `string` | Optional | The name of your company |
| `institution_address` | `string` | Optional | The institution address to appear in the footer of the email |
| `signature` | `List of string` | Optional | A signature for the email |

## Example (as JSON)

```json
{
  "to": "alex.salido@finicity.com"
}
```

