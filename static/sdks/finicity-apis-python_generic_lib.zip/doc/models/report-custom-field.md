
# Report Custom Field

## Structure

`ReportCustomField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `string` | Optional | The name of the custom field |
| `value` | `string` | Optional | The value of the custom field |
| `shown` | `bool` | Optional | If the custom field will show on the PDF or not |

## Example (as JSON)

```json
{
  "label": null,
  "value": null,
  "shown": null
}
```

