
# Cash Flow Monthly Cash Flow Credits

## Structure

`CashFlowMonthlyCashFlowCredits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `month` | `long\|int` | Required | One instance for each complete calendar month in the report |
| `number_of_credits` | `string` | Required | Number of credits by month |
| `total_credits_amount` | `float` | Required | Total amount of credits by month |
| `largest_credit` | `float` | Required | Largest credit by month |
| `number_of_credits_less_transfers` | `string` | Required | Number of credits by month (less transfers) |
| `total_credits_amount_less_transfers` | `float` | Required | Total amount of credits by month (less transfers) |
| `average_credit_amount` | `float` | Required | The average credit amount |
| `estimated_number_of_loan_deposits` | `string` | Required | The estimated number of loan deposits |
| `estimated_loan_deposit_amount` | `float` | Required | The estimated loan deposit amount |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "3",
  "totalCreditsAmount": 5000,
  "largestCredit": 2000,
  "numberOfCreditsLessTransfers": "2",
  "totalCreditsAmountLessTransfers": 4000,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

