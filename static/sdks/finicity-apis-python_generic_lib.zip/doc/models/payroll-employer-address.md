
# Payroll Employer Address

## Structure

`PayrollEmployerAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `string` | Optional | Employer address as stated by the employer in the payroll system |
| `city` | `string` | Optional | Employer city as stated by the employer in the payroll system |
| `state` | `string` | Optional | Employer state as stated by the employer in the payroll system |
| `zip` | `string` | Optional | Employer zip code as stated by the employer in the payroll system |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

