
# Obb Week of Year

## Structure

`ObbWeekOfYear`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `from_date` | `string` | Required | Begin date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `to_date` | `string` | Required | End date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `week` | `int` | Required | Week number, where the first week of each year begins on January 1st and ends on January 7th. May be in the range [1, 53] |

## Example (as JSON)

```json
{
  "fromDate": "2020-01-01",
  "toDate": "2020-01-07",
  "week": 1
}
```

