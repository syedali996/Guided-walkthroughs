
# Cash Flow Monthly Cash Flow Credit Summaries

## Structure

`CashFlowMonthlyCashFlowCreditSummaries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `month` | `long\|int` | Required | One instance for each complete calendar month in the report |
| `number_of_credits` | `string` | Required | Number of credits by month across all accounts |
| `total_credits_amount` | `float` | Required | Total amount of credits by month across all accounts |
| `largest_credit` | `float` | Required | Largest credit by month across all accounts |
| `number_of_credits_less_transfers` | `string` | Required | Number of credits by month (less transfers) across all accounts |
| `total_credits_amount_less_transfers` | `float` | Required | Total amount of credits by month (less transfers) across all accounts |
| `average_credit_amount` | `float` | Required | The average credit amount |
| `estimated_number_of_loan_deposits` | `string` | Required | The estimated number of loan deposits by month |
| `estimated_loan_deposit_amount` | `float` | Required | The estimated loan deposit amount by month |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "57",
  "totalCreditsAmount": 3479.39,
  "largestCredit": 3000.49,
  "numberOfCreditsLessTransfers": "5",
  "totalCreditsAmountLessTransfers": 25.46,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

