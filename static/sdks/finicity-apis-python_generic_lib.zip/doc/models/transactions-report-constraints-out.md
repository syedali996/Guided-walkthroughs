
# Transactions Report Constraints Out

## Structure

`TransactionsReportConstraintsOut`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_ids` | `List of string` | Optional | An array of account IDs to be included in the report (all accounts will be included if not set) |
| `from_date` | `long\|int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `to_date` | `long\|int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `include_pending` | `bool` | Optional | If pending transactions must be included<br>**Default**: `False` |
| `report_custom_fields` | [`List of ReportCustomField`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. |

## Example (as JSON)

```json
{
  "accountIds": null,
  "fromDate": null,
  "toDate": null,
  "includePending": null,
  "reportCustomFields": null
}
```

