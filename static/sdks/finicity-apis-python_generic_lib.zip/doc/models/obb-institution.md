
# Obb Institution

## Structure

`ObbInstitution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution_icon_url` | `string` | Optional | URL of the institution logo icon for reporting<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `institution_id` | `int` | Required | ID of the financial institution |
| `institution_name` | `string` | Optional | Name of the financial institution<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `institution_primary_color` | `string` | Optional | Primary branding color of the institution, in hex color format<br>**Constraints**: *Minimum Length*: `7`, *Maximum Length*: `7` |

## Example (as JSON)

```json
{
  "institutionId": 12345
}
```

