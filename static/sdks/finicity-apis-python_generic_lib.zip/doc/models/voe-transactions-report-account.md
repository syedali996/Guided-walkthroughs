
# VOE Transactions Report Account

## Structure

`VOETransactionsReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The ID of the account |
| `number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `owner_name` | `string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `owner_address` | `string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `name` | `string` | Optional | The account name from the institution |
| `mtype` | `string` | Optional | One of the values from account types |
| `aggregation_status_code` | `int` | Optional | The status of the most recent aggregation attempt |
| `income_streams` | [`List of VOETransactionsReportIncomeStream`](../../doc/models/voe-transactions-report-income-stream.md) | Optional | A list of income stream records |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null
}
```

