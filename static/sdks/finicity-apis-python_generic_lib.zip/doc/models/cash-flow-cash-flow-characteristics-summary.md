
# Cash Flow Cash Flow Characteristics Summary

## Structure

`CashFlowCashFlowCharacteristicsSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthly_cash_flow_characteristic_summaries` | [`List of CashFlowMonthlyCashFlowCharacteristicSummaries`](../../doc/models/cash-flow-monthly-cash-flow-characteristic-summaries.md) | Required | List of attributes for each month |
| `average_monthly_net` | `float` | Required | Average monthly net amount |
| `average_monthly_net_less_transfers` | `float` | Required | Average monthly net less transfers |
| `twelve_month_total_net` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) each month by the account |
| `twelve_month_total_net_less_transfers` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers by the account |
| `six_month_average_total_credits_less_total_debits` | `float` | Required | 6 Month Average (Total Credits - Total Debits) across all accounts |
| `six_month_average_total_credits_less_total_debits_less_transfers` | `float` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts |
| `two_month_average_total_credits_less_total_debits` | `float` | Required | 2 Month Average (Total Credits - Total Debits) across all accounts |
| `two_month_average_total_credits_less_total_debits_less_transfers` | `float` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristicSummaries": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 1250,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

