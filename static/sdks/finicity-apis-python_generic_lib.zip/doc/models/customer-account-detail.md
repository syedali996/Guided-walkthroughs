
# Customer Account Detail

Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution.

## Structure

`CustomerAccountDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date_as_of` | `long\|int` | Optional | (All Account Types) Most recent date of the following information. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `available_balance_amount` | `float` | Required | (Checking/Savings/CD/MoneyMarket) and (Mortgage/Loan) The available balance (typically the current balance with adjustments for any pending transactions) |
| `open_date` | `long\|int` | Optional | (Checking/Savings/CD/MoneyMarket) Date when account was opened. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `period_start_date` | `long\|int` | Optional | (Checking/Savings/CD/MoneyMarket) Start date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `period_end_date` | `long\|int` | Optional | End date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `period_interest_rate` | `float` | Optional | (Checking/Savings/CD/MoneyMarket) The APY for the current period interest rate |
| `period_deposit_amount` | `float` | Optional | (Checking/Savings/CD/MoneyMarket) Amount deposited in period |
| `period_interest_amount` | `float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued during the current period |
| `interest_ytd_amount` | `float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued year-to-date |
| `interest_prior_ytd_amount` | `float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest earned in prior year |
| `maturity_date` | `long\|int` | Optional | (Checking/Savings/CD/MoneyMarket) Maturity date of account type. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `interest_rate` | `string` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The account's current interest rate |
| `credit_available_amount` | `float` | Optional | (Credit Card/Line Of Credit) The available credit (typically the credit limit minus the current balance) |
| `credit_max_amount` | `float` | Optional | (Credit Card/Line Of Credit) The account's credit limit |
| `cash_advance_available_amount` | `float` | Optional | (Credit Card/Line Of Credit) Currently available cash advance |
| `cash_advance_max_amount` | `float` | Optional | (Credit Card/Line Of Credit) Maximum cash advance amount |
| `cash_advance_balance` | `float` | Optional | (Credit Card/Line Of Credit) Balance of current cash advance |
| `cash_advance_interest_rate` | `float` | Optional | (Credit Card/Line Of Credit) Interest rate for cash advances |
| `current_balance` | `float` | Optional | (Credit Card/Line Of Credit) and (Investment) Current balance |
| `payment_min_amount` | `float` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) Minimum payment due |
| `payment_due_date` | `long\|int` | Optional | (Credit Card/Line Of Credit) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `previous_balance` | `float` | Optional | (Credit Card/Line Of Credit) Prior balance in last statement |
| `statement_start_date` | `long\|int` | Optional | (Credit Card/Line Of Credit) Start date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `statement_end_date` | `long\|int` | Optional | (Credit Card/Line Of Credit) End date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `statement_purchase_amount` | `float` | Optional | (Credit Card/Line Of Credit) Purchase amount of statement period |
| `statement_finance_amount` | `float` | Optional | (Credit Card/Line Of Credit) Finance amount of statement period |
| `statement_credit_amount` | `float` | Optional | (Credit Card/Line Of Credit) Credit amount applied in statement period |
| `reward_earned_balance` | `int` | Optional | (Credit Card/Line Of Credit) Earned reward balance |
| `past_due_amount` | `float` | Optional | (Credit Card/Line Of Credit) Balance past due |
| `last_payment_amount` | `float` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The amount received in the last payment |
| `last_payment_date` | `long\|int` | Optional | (Credit Card/Line Of Credit) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `statement_close_balance` | `float` | Optional | (Credit Card/Line Of Credit) Balance of statement at close |
| `term_of_ml` | `string` | Optional | (Mortgage/Loan) Length of loan in months |
| `ml_holder_name` | `string` | Optional | (Mortgage/Loan) Holder of the mortgage or loan |
| `description` | `string` | Optional | (Mortgage/Loan) Description of loan |
| `late_fee_amount` | `float` | Optional | (Mortgage/Loan) Late fee charged |
| `payoff_amount` | `float` | Optional | (Mortgage/Loan) The amount required to payoff the loan |
| `payoff_amount_date` | `long\|int` | Optional | (Mortgage/Loan) Date of final payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `original_maturity_date` | `long\|int` | Optional | (Mortgage/Loan) Original date of loan maturity. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `principal_balance` | `float` | Optional | (Mortgage/Loan) The principal balance |
| `escrow_balance` | `float` | Optional | (Mortgage/Loan) The escrow balance |
| `interest_period` | `string` | Optional | (Mortgage/Loan) Period of interest |
| `initial_ml_amount` | `float` | Optional | (Mortgage/Loan) Original loan amount |
| `initial_ml_date` | `long\|int` | Optional | (Mortgage/Loan) Original date of loan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `next_payment_principal_amount` | `float` | Optional | (Mortgage/Loan) Amount towards principal in next payment |
| `next_payment_interest_amount` | `float` | Optional | (Mortgage/Loan) Amount of interest in next payment |
| `next_payment` | `float` | Optional | (Mortgage/Loan) Minimum payment due |
| `next_payment_date` | `long\|int` | Optional | (Mortgage/Loan) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_payment_due_date` | `long\|int` | Optional | (Mortgage/Loan) Due date of last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_payment_receive_date` | `long\|int` | Optional | (Mortgage/Loan) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_payment_principal_amount` | `float` | Optional | (Mortgage/Loan) Amount towards principal in last payment |
| `last_payment_interest_amount` | `float` | Optional | (Mortgage/Loan) Amount of interest in last payment |
| `last_payment_escrow_amount` | `float` | Optional | (Mortgage/Loan) Amount towards escrow in last payment |
| `last_payment_last_fee_amount` | `float` | Optional | (Mortgage/Loan) Amount of last fee in last payment |
| `last_payment_late_charge` | `float` | Optional | (Mortgage/Loan) Amount of late charge in last payment |
| `ytd_principal_paid` | `float` | Optional | (Mortgage/Loan) Principal paid year-to-date |
| `ytd_interest_paid` | `float` | Optional | (Mortgage/Loan) Interest paid year-to-date |
| `ytd_insurance_paid` | `float` | Optional | (Mortgage/Loan) Insurance paid year-to-date |
| `ytd_tax_paid` | `float` | Optional | (Mortgage/Loan) Tax paid year-to-date |
| `auto_pay_enrolled` | `bool` | Optional | (Mortgage/Loan) Enrolled in autopay (F/Y) |
| `collateral` | `string` | Optional | (Mortgage/Loan) Collateral on loan |
| `current_school` | `string` | Optional | (Mortgage/Loan) Current school |
| `first_payment_date` | `long\|int` | Optional | (Mortgage/Loan) First payment due date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `first_mortgage` | `bool` | Optional | (Mortgage/Loan) First mortgage (F/Y) |
| `loan_payment_freq` | `string` | Optional | (Mortgage/Loan) Frequency of payments (monthly, etc.) |
| `original_school` | `string` | Optional | (Mortgage/Loan) Original school |
| `recurring_payment_amount` | `float` | Optional | (Mortgage/Loan) Recurring payment amount |
| `lender` | `string` | Optional | (Mortgage/Loan) Owner of loan |
| `ending_balance_amount` | `float` | Optional | (Mortgage/Loan) Ending balance |
| `loan_term_type` | `string` | Optional | (Mortgage/Loan) Type of loan term |
| `payments_made` | `int` | Optional | (Mortgage/Loan) Number of payments made |
| `balloon_amount` | `float` | Optional | (Mortgage/Loan) Balloon payment amount |
| `projected_interest` | `float` | Optional | (Mortgage/Loan) Projected interest on the loan |
| `interest_paid_ltd` | `float` | Optional | (Mortgage/Loan) Interest paid since inception of loan (life to date) |
| `interest_rate_type` | `string` | Optional | (Mortgage/Loan) Type of interest rate |
| `loan_payment_type` | `string` | Optional | (Mortgage/Loan) Type of loan payment |
| `repayment_plan` | `string` | Optional | (Mortgage/Loan) Type of repayment plan for the student loan |
| `payments_remaining` | `int` | Optional | (Mortgage/Loan) Number of payments remaining before loan is paid off |
| `margin_balance` | `float` | Optional | (Investment) Net interest earned after deducting interest paid out |
| `short_balance` | `float` | Optional | (Investment) Sum of short balance |
| `available_cash_balance` | `float` | Optional | (Investment) Amount available for cash withdrawal |
| `maturity_value_amount` | `float` | Optional | (Investment) amount payable to an investor at maturity |
| `vested_balance` | `float` | Optional | (Investment) Vested amount in account |
| `emp_match_amount` | `float` | Optional | (Investment) Employer matched contributions |
| `emp_pretax_contrib_amount` | `float` | Optional | (Investment) Employer pretax contribution amount |
| `emp_pretax_contrib_amount_ytd` | `float` | Optional | (Investment) Employer pretax contribution amount year to date |
| `contrib_total_ytd` | `float` | Optional | (Investment) Total year to date contributions |
| `cash_balance_amount` | `float` | Optional | (Investment) Cash balance of account |
| `pre_tax_amount` | `float` | Optional | (Investment) Pre tax amount of total balance |
| `after_tax_amount` | `float` | Optional | (Investment) Post tax amount of total balance |
| `match_amount` | `float` | Optional | (Investment) Amount matched |
| `profit_sharing_amount` | `float` | Optional | (Investment) Amount of balance for profit sharing |
| `rollover_amount` | `float` | Optional | (Investment) Amount of balance rolled over from original account (401k, etc.) |
| `other_vest_amount` | `float` | Optional | (Investment) Other vested amount |
| `other_nonvest_amount` | `float` | Optional | (Investment) Other nonvested amount |
| `current_loan_balance` | `float` | Optional | (Investment) Current loan balance |
| `loan_rate` | `float` | Optional | (Investment) Interest rate of loan |
| `buy_power` | `float` | Optional | (Investment) Money available to buy securities |
| `rollover_ltd` | `float` | Optional | (Investment) Life to date of money rolled over |
| `loan_award_id` | `string` | Optional | (Student Loan) The federal unique loan identifying number |
| `original_interest_rate` | `float` | Optional | (Student Loan) The original interest rate to which the loan was disbursed, in APY |
| `guarantor` | `string` | Optional | (Student Loan) The financial institution guarantor of the loan (who will pay the loan amount to the owner if the borrower defaults) |
| `owner` | `string` | Optional | (Student Loan) Owner of the loan |
| `interest_subsidy_type` | `string` | Optional | (Student Loan) The indication of the presence of an interest subsidy (i.e. subsidized) |
| `interest_balance` | `float` | Optional | (Student Loan) The total outstanding interest balance |
| `remaining_term_of_ml` | `float` | Optional | (Student Loan) The number of months still outstanding on a loan |
| `initial_interest_rate` | `float` | Optional | (Student Loan) Initial interest rate of loan |
| `fees_balance` | `float` | Optional | (Student Loan) The total outstanding fees balance |
| `loan_ytd_interest_paid` | `float` | Optional | (Student Loan) Loan interest paid year-to-date |
| `loan_ytd_fees_paid` | `float` | Optional | (Student Loan) Loan fees paid year-to-date |
| `loan_ytd_principal_paid` | `float` | Optional | (Student Loan) Loan principal paid year-to-date |
| `loan_status` | `string` | Optional | (Student Loan) The repayment status phase (i.e. In School, Grace, Repayment, Deferment, Forbearance) |
| `loan_status_start_date` | `long\|int` | Optional | (Student Loan) The start date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `loan_status_end_date` | `long\|int` | Optional | (Student Loan) The end date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `weighted_interest_rate` | `float` | Optional | (Student Loan) The interest rate of multiple interest rates and balances at the group level, in APY |
| `repayment_plan_start_date` | `long\|int` | Optional | (Student Loan) The start date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `repayment_plan_end_date` | `long\|int` | Optional | (Student Loan) The end date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `expected_payoff_date` | `long\|int` | Optional | (Student Loan) The expected date of the payoff date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `out_of_school_date` | `long\|int` | Optional | (Student Loan) The date the borrower graduated or dropped below half-time enrollment in school. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `convert_to_repayment` | `long\|int` | Optional | (Student Loan) The date the loan enters into repayment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `days_delinquent` | `int` | Optional | (Student Loan) The number of days past a due date that a payment should have been made |
| `total_principal_paid` | `float` | Optional | (Student Loan) The total amount paid towards the principal balance |
| `total_interest_paid` | `float` | Optional | (Student Loan) The total amount paid towards interest |
| `total_amount_paid` | `float` | Optional | (Student Loan) The total amount paid |

## Example (as JSON)

```json
{
  "availableBalanceAmount": 5678.78
}
```

