
# Obb Daily Balance

## Structure

`ObbDailyBalance`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `string` | Required | Date of balance information<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `day_of_week` | `string` | Required | Day of the week for which balance information available<br>**Constraints**: *Minimum Length*: `6`, *Maximum Length*: `9` |
| `ending_balance` | `float` | Required | End of day balance |

## Example (as JSON)

```json
{
  "date": "2021-10-11",
  "dayOfWeek": "Monday",
  "endingBalance": 21527.3
}
```

