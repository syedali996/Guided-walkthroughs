
# Institution Address

The address of a financial institution

## Structure

`InstitutionAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `city` | `string` | Optional | A city |
| `state` | `string` | Optional | A state |
| `country` | `string` | Optional | A country code |
| `postal_code` | `string` | Optional | A ZIP code |
| `address_line_1` | `string` | Optional | An address line 1 |
| `address_line_2` | `string` | Optional | An address line 2 |

## Example (as JSON)

```json
{
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "addressLine1": null,
  "addressLine2": null
}
```

