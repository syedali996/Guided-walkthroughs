
# Direct Deposit

## Structure

`DirectDeposit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount_current` | `float` | Optional | The amount of the deposit |
| `account_last_four` | `string` | Optional | The last four numbers of the account the deposit went into |

## Example (as JSON)

```json
{
  "amountCurrent": null,
  "accountLastFour": null
}
```

