
# Customer With App Data

A finicity customer record with application info

## Structure

`CustomerWithAppData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | A customer ID. See Add Customer API for how to create a customer ID. |
| `username` | `string` | Required | The customer's username, assigned by the partner (a unique identifier), following these rules: minimum 6 characters maximum 255 characters any mix of uppercase, lowercase, numeric, and non-alphabet special characters ! @ . # $ % & * _ – + the use of email in this field is discouraged it is recommended to use a unique non-email identifier. Use of special characters may result in an error (e.g. í, ü, etc.). Usernames are unique. A username used in [Test Drive](https://signup.finicity.com/) can't be reused in other plans. |
| `first_name` | `string` | Required | First name(s) / given name(s) |
| `last_name` | `string` | Required | Last name(s) / surname(s) |
| `mtype` | `string` | Required | The type of customer ("active" or "testing" or "" for all types) |
| `created_date` | `string` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_modified_date` | `string` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `application_id` | `string` | Required | `applicationId` value returned from the Get App Registration Status API and the partner assign the customers to. This cannot be changed once set. Only applicable in cases of partners with multiple registered applications. If the partner only has one app, this can usually be omitted. This field is populated after the app is in a status approved. |
| `application_name` | `string` | Required | The name of the application assigned to the customer |

## Example (as JSON)

```json
{
  "id": "1005061234",
  "username": "customerusername1",
  "firstName": "John",
  "lastName": "Smith",
  "type": "active",
  "createdDate": "1607450357",
  "applicationId": "123456789",
  "applicationName": "Awesome Budget App"
}
```

