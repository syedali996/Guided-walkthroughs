
# Obb Error Message Exception

OBB Error response message

## Structure

`ObbErrorMessageException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_code` | `int` | Required | Error code |
| `message` | `string` | Required | Detailed reason about the source of the error<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "errorCode": 4,
  "message": "message0"
}
```

