
# Institution

A financial institution

## Structure

`Institution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Required | The ID of a financial institution, represented as a number |
| `name` | `string` | Optional | The name of the institution |
| `trans_agg` | `bool` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product |
| `ach` | `bool` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product |
| `state_agg` | `bool` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product |
| `voi` | `bool` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product |
| `voa` | `bool` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product |
| `aha` | `bool` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product |
| `avail_balance` | `bool` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product |
| `account_owner` | `bool` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product |
| `student_loan_data` | `bool` | Optional | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product |
| `loan_payment_details` | `bool` | Optional | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product |
| `account_type_description` | `string` | Optional | Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance |
| `phone` | `string` | Optional | A phone number |
| `url_home_app` | `string` | Optional | The URL of the institution's primary home page |
| `url_logon_app` | `string` | Optional | The URL of the institution's login page |
| `oauth_enabled` | `bool` | Required | "true": The institution is an OAuth connection<br><br>"false": The institution isn't an OAuth connection |
| `url_forgot_password` | `string` | Optional | Institution's forgot password page |
| `url_online_registration` | `string` | Optional | Institution's signup page |
| `mclass` | `string` | Optional | Institution's class |
| `special_text` | `string` | Optional | Special instructions given to customers for login |
| `time_zone` | `string` | Optional | The time zone of the institution. |
| `special_instructions` | `List of string` | Optional | Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.<br><br>Note: this helps the customer to provide the proper permission for data needed for the application. |
| `special_instutions_title` | `string` | Optional | The title of the special instructions, if one exists or is required. |
| `address` | [`InstitutionAddress`](../../doc/models/institution-address.md) | Optional | The address of a financial institution |
| `currency` | `string` | Required | A currency code |
| `email` | `string` | Optional | An email address |
| `status` | `string` | Required | Status for the institution: "online", "offline", "maintenance", "testing" |
| `new_institution_id` | `long\|int` | Optional | The ID of a financial institution, represented as a number |
| `branding` | [`Branding`](../../doc/models/branding.md) | Optional | All assets are SVGs so can be slightly resized without any issues. |
| `oauth_institution_id` | `long\|int` | Optional | The ID of a financial institution, represented as a number |

## Example (as JSON)

```json
{
  "id": 4222,
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "oauthEnabled": true,
  "currency": "USD",
  "status": "online"
}
```

