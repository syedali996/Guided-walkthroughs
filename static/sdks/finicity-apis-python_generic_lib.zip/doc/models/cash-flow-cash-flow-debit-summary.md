
# Cash Flow Cash Flow Debit Summary

## Structure

`CashFlowCashFlowDebitSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthly_cash_flow_debit_summaries` | [`List of CashFlowMonthlyCashFlowDebitSummaries`](../../doc/models/cash-flow-monthly-cash-flow-debit-summaries.md) | Required | List of attributes for each month |
| `twelve_month_debit_total` | `float` | Required | Sum of all monthly debit transactions for each month by account |
| `twelve_month_debit_total_less_transfers` | `float` | Required | Sum of all monthly debit transactions without transfers for the account |
| `six_month_debit_total` | `float` | Required | Six month sum of all debit transactions by account |
| `six_month_debit_total_less_transfers` | `float` | Required | Six month sum of all debit transactions without transfers for the account |
| `two_month_debit_total` | `float` | Required | Two month sum of all debit transactions by account |
| `two_month_debit_total_less_transfers` | `float` | Required | Two month sum of all debit transactions without transfers for the account |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebitSummaries": {
    "month": 1512111600,
    "numberOfDebits": "1500",
    "totalDebitsAmount": -12345.46,
    "largestDebit": -20000,
    "numberOfDebitsLessTransfers": "5",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": -1200,
  "twelveMonthDebitTotalLessTransfers": -1000,
  "sixMonthDebitTotal": -750,
  "sixMonthDebitTotalLessTransfers": -500,
  "twoMonthDebitTotal": -150,
  "twoMonthDebitTotalLessTransfers": -100
}
```

