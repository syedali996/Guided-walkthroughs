
# Report Transaction

## Structure

`ReportTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Required | A transaction ID |
| `amount` | `float` | Optional | The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values. |
| `posted_date` | `long\|int` | Required | A timestamp showing when the transaction was posted or cleared by the institution |
| `description` | `string` | Required | The description of the transaction, as provided by the institution (often known as `payee`). In the event that this field is left blank by the institution, Finicity will pass a value of "No description provided by institution". All other values are provided by the institution. |
| `memo` | `string` | Optional | The memo field of the transaction, as provided by the institution. The institution must provide either a description, a memo, or both. It is recommended to concatenate the two fields into a single value. |
| `normalized_payee` | `string` | Required | A normalized payee, derived from the transaction's `description` and `memo` fields |
| `institution_transaction_id` | `string` | Required | The unique identifier given by the FI for each transaction |
| `category` | `string` | Required | One of the values from Categories (assigned based on the payee name) |
| `mtype` | `string` | Optional | One of the values from transaction types |
| `security_type` | `string` | Optional | The type of investment security (VOA only) |
| `symbol` | `string` | Optional | Investment symbol (VOA only) |
| `commission` | `float` | Optional | - |

## Example (as JSON)

```json
{
  "id": 21284820852,
  "postedDate": 1571313600,
  "description": "ATM CHECK DEPOSIT mm/dd",
  "normalizedPayee": "T-Mobile",
  "institutionTransactionId": "0000000000",
  "category": "Income"
}
```

