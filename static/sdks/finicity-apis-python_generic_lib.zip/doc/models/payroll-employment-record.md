
# Payroll Employment Record

## Structure

`PayrollEmploymentRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `employer_name` | `string` | Required | Name of the employer as stated by the employer in the payroll system |
| `legal_entity_id` | `string` | Optional | Employer identification number (EIN) |
| `original_hire_date` | `long\|int` | Optional | The original hired date of an employee at the company |
| `latest_hire_date` | `long\|int` | Optional | If an employee leaves the company and returns later, then the employer states the latest hire date at the company |
| `latest_pay_date` | `long\|int` | Required | The most recent pay date from an employer |
| `days_since_last_pay` | `int` | Required | The number of days since an employee was last paid |
| `number_pay_cadence_without_pay` | `int` | Required | The number of pay cadences an employee has not been paid; determined by the pay frequency |
| `employment_end_date` | `long\|int` | Optional | The date an employee ended their employment at the company |
| `employment_duration` | `string` | Optional | The length of time an employee has been employed with that employer in ISO 8601 format (eg P1Y6M0D) |
| `employer_address` | [`List of PayrollEmployerAddress`](../../doc/models/payroll-employer-address.md) | Optional | Array of addresses |
| `employment_status_code` | `string` | Required | Status codes: `A` - Active, `NLE` - No Longer Employed, `L` - Leave |
| `employment_status_name` | `string` | Required | Status name: `Active`, `No Longer Employed`, or `Leave` |
| `work_level_code` | `string` | Optional | The abbreviate code for the employment level names (workLevelName) that we receive from the employer |
| `work_level_name` | `string` | Optional | The employment level name is whatever we receive from the employer, such as full time, part time, temp, contractor, and more |
| `work_level_status` | `string` | Required | The categorized work level status. Enumerations are: <br> * `Temporary` <br> * `Seasonal` <br> * `Retired` <br> * `Student` <br> * `Full Time` <br> * `Part Time` <br> * `Unspecified` <br> This is a new field, currently enabled only for testing reports. It will be added for all reports in August 2021. |
| `position_title` | `string` | Optional | Employee job title |
| `position_duration` | `string` | Optional | The length of time an employee has been employed at their current or latest position for this employment in ISO 8601 format (eg P1Y6M0D) |

## Example (as JSON)

```json
{
  "employerName": "ACME INC",
  "latestPayDate": 1596175200,
  "daysSinceLastPay": 10,
  "numberPayCadenceWithoutPay": 1,
  "employmentStatusCode": "A",
  "employmentStatusName": "Active",
  "workLevelStatus": "Full Time"
}
```

