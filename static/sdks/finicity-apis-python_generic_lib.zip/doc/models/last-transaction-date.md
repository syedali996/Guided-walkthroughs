
# Last Transaction Date

## Structure

`LastTransactionDate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `string` | Required | Date the deposit transaction was posted |
| `deposits_credits` | `float` | Optional | Amount of transaction if deposit, otherwise null |
| `withdrawals_debits` | `float` | Optional | Amount of transaction if withdrawal, otherwise null |
| `zero_amount_transaction` | `float` | Optional | Amount of transaction if zero, otherwise null |
| `transaction_description` | `string` | Optional | Description of transaction |

## Example (as JSON)

```json
{
  "date": "2020-03-25"
}
```

