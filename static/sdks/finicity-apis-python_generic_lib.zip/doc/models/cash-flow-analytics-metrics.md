
# Cash Flow Analytics Metrics

## Structure

`CashFlowAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `inflow` | [`CashFlowInflowAttributes`](../../doc/models/cash-flow-inflow-attributes.md) | Optional | Inflow Attributes |
| `negative_triggers` | [`CashFlowNegativeTriggers`](../../doc/models/cash-flow-negative-triggers.md) | Optional | Details of transactions that may be warning signs of bad creditworthiness |
| `outflow` | [`CashFlowOutflowAttributes`](../../doc/models/cash-flow-outflow-attributes.md) | Optional | Outflow attributes |
| `revenue_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Optional | Sum of all transactions categorized as revenue, split by months |
| `revenue_for_the_report_time_period` | `float` | Optional | Sum of all transactions categorized as revenue |
| `transaction_analytics` | [`CashFlowTransactionAnalyticsAttributes`](../../doc/models/cash-flow-transaction-analytics-attributes.md) | Optional | Transaction Analytics Attributes |

## Example (as JSON)

```json
{
  "inflow": null,
  "negativeTriggers": null,
  "outflow": null,
  "revenueByMonthForTheReportTimePeriod": null,
  "revenueForTheReportTimePeriod": null,
  "transactionAnalytics": null
}
```

