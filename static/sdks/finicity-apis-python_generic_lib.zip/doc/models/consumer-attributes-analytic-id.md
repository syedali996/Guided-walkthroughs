
# Consumer Attributes Analytic Id

An analytic ID and a date

## Structure

`ConsumerAttributesAnalyticId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `analytic_id` | `string` | Required | An ID for a Consumer Attributes report |
| `created_date` | `string` | Required | A date-time without time zone |

## Example (as JSON)

```json
{
  "analytic_id": "CA-5dfbaa3ac-5321",
  "created_date": "04/12/2022 11:51:23"
}
```

