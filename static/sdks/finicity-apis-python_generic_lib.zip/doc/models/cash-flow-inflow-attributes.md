
# Cash Flow Inflow Attributes

## Structure

`CashFlowInflowAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `average_deposit_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of deposits during periods in the report |
| `count_deposits_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndCount`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all deposits during periods in the report |
| `historic_count_of_deposit_transactions` | `int` | Required | Count of ALL deposits over entire known history of the account (may exceed requested length of report) |
| `historic_sum_of_deposits` | `float` | Optional | Sum of ALL deposits over entire known history of the account (may exceed requested length of report) |
| `maximum_deposit_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum deposit value for different periods in the report |
| `minimum_deposit_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum deposit value for different periods in the report |
| `sum_deposits_by_month_for_the_report_time_period` | [`List of ObbDateRangeAndAmount`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all deposits during periods in the report |

## Example (as JSON)

```json
{
  "countDepositsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfDepositTransactions": 20,
  "maximumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumDepositsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

