
# VOAI Report Income Stream 2

A report income stream record

## Structure

`VOAIReportIncomeStream2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | Income stream ID |
| `name` | `string` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream |
| `status` | `string` | Required | Possible values: "ACTIVE", "INACTIVE" |
| `estimate_inclusion` | `string` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" |
| `confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) |
| `cadence` | [`CadenceDetails`](../../doc/models/cadence-details.md) | Required | - |
| `net_monthly` | [`List of NetMonthly`](../../doc/models/net-monthly.md) | Required | A list of net monthly records. One instance for each complete calendar month in the report. |
| `net_annual` | `float` | Required | Sum of all values in `netMonthlyIncome` over the previous 12 months |
| `projected_net_annual` | `float` | Required | Projected net income over the next 12 months, across all income streams, based on `netAnnualIncome` |
| `estimated_gross_annual` | `float` | Required | Before-tax gross annual income (estimated from `netAnnual`) across all income stream in the past 12 months |
| `projected_gross_annual` | `float` | Required | Projected gross income over the next 12 months, across all active income streams, based on `projectedNetAnnual` |
| `average_monthly_income_net` | `float` | Required | Monthly average amount over the previous 24 months |
| `income_stream_months` | `int` | Required | The number of months the income transactions are observed |
| `transactions` | [`List of ReportTransaction`](../../doc/models/report-transaction.md) | Required | A list of transaction records |
| `days_since_last_transaction` | `int` | Required | The number of days since the last credit transaction for the particular income stream |
| `next_expected_transaction_date` | `long\|int` | Required | The next expected credit transaction date for the particular income stream, based on the cadence |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voah",
  "name": "none",
  "status": null,
  "estimateInclusion": null,
  "confidence": 70,
  "cadence": null,
  "netMonthly": [
    {
      "month": 1522562400,
      "net": 2004.77
    }
  ],
  "netAnnual": 110475.7,
  "projectedNetAnnual": 0,
  "estimatedGrossAnnual": 12321.1,
  "projectedGrossAnnual": 151609,
  "averageMonthlyIncomeNet": 9206.31,
  "incomeStreamMonths": 18,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "daysSinceLastTransaction": 15,
  "nextExpectedTransactionDate": 1572625469
}
```

