
# Transactions

A list of transactions

## Structure

`Transactions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `found` | `int` | Required | The total number of results matching search criteria |
| `displaying` | `int` | Required | The number of results returned |
| `more_available` | `bool` | Required | If the value of `moreAvailable` is "true", you can retrieve the next page of results by increasing the value of the start parameter in your next request:"...&start=6&limit=5" |
| `from_date` | `long\|int` | Required | Value of the `fromDate` request parameter that generated this response |
| `to_date` | `long\|int` | Required | Value of the `toDate` request parameter that generated this response |
| `sort` | `string` | Required | Value of the sort request parameter that generated this response |
| `transactions` | [`List of Transaction`](../../doc/models/transaction.md) | Required | The array of transactions |

## Example (as JSON)

```json
{
  "found": 200,
  "displaying": 2,
  "moreAvailable": true,
  "fromDate": 1607450357,
  "toDate": 1607450357,
  "sort": "desc",
  "transactions": {
    "id": 21284820852,
    "amount": -828.9,
    "accountId": 5011648377,
    "customerId": 1005061234,
    "status": "active",
    "description": "Buy Stock",
    "createdDate": 1607450357,
    "categorization": {
      "normalizedPayeeName": "Mad Science Research",
      "category": "ATM Fee",
      "country": "USA"
    }
  }
}
```

