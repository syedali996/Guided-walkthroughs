
# Payroll Employee Record

## Structure

`PayrollEmployeeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | Full name of the employee: first, middle (if stated), and last name |
| `given_name` | `string` | Required | First name of employee |
| `middle_name` | `string` | Optional | Middle name of employee, if stated |
| `family_name` | `string` | Required | Last name of employee |
| `address` | [`List of PayrollEmployeeAddress`](../../doc/models/payroll-employee-address.md) | Optional | Array of addresses |

## Example (as JSON)

```json
{
  "name": "John Doe Smith",
  "givenName": "John",
  "familyName": "Smith"
}
```

