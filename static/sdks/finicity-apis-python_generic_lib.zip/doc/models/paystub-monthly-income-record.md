
# Paystub Monthly Income Record

## Structure

`PaystubMonthlyIncomeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `estimated_monthly_base_pay` | `float` | Optional | The estimated monthly base pay amount for the employment from the paystub, calculated by Finicity |
| `estimated_monthly_overtime_pay` | `float` | Optional | The estimated monthly overtime pay amount for the employment from the paystub, calculated by Finicity |
| `estimated_monthly_bonus_pay` | `float` | Optional | The estimated monthly bonus pay amount for the employment from the paystub, calculated by Finicity |
| `estimated_monthly_commission_pay` | `float` | Optional | The estimated commission bonus pay amount for the employment from the paystub, calculated by Finicity |

## Example (as JSON)

```json
{
  "estimatedMonthlyBasePay": null,
  "estimatedMonthlyOvertimePay": null,
  "estimatedMonthlyBonusPay": null,
  "estimatedMonthlyCommissionPay": null
}
```

