
# VOIE With Statement Data

## Structure

`VOIEWithStatementData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_ids` | `List of string` | Required | A list of pay statement asset IDs |
| `extract_earnings` | `bool` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `True` |
| `extract_deductions` | `bool` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `False` |
| `extract_direct_deposit` | `bool` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `True` |

## Example (as JSON)

```json
{
  "assetIds": [
    "assetIds3"
  ],
  "extractEarnings": null,
  "extractDeductions": null,
  "extractDirectDeposit": null
}
```

