
# Cash Flow Cash Flow Credit Summary

## Structure

`CashFlowCashFlowCreditSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthly_cash_flow_credit_summaries` | [`List of CashFlowMonthlyCashFlowCreditSummaries`](../../doc/models/cash-flow-monthly-cash-flow-credit-summaries.md) | Required | List of attributes for each month |
| `twelve_month_credit_total` | `float` | Required | Sum of all credit transactions for each month for all accounts |
| `twelve_month_credit_total_less_transfers` | `float` | Required | Sum of all monthly credit transactions without transfers for all accounts |
| `six_month_credit_total` | `float` | Required | Six month sum of all credit transactions |
| `six_month_credit_total_less_transfers` | `float` | Required | Six month sum of all monthly credit transactions without transfers for all accounts |
| `two_month_credit_total` | `float` | Required | Two month sum of all credit transactions |
| `two_month_credit_total_less_transfers` | `float` | Required | Two month sum of all monthly credit transactions without transfers for all accounts |

## Example (as JSON)

```json
{
  "monthlyCashFlowCreditSummaries": {
    "month": 1512111600,
    "numberOfCredits": "57",
    "totalCreditsAmount": 3479.39,
    "largestCredit": 3000.49,
    "numberOfCreditsLessTransfers": "5",
    "totalCreditsAmountLessTransfers": 25.46,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

