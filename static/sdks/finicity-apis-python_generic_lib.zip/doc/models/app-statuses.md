
# App Statuses

The response for the Get App Registration Status API which returns an array of status objects

## Structure

`AppStatuses`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total_records` | `long\|int` | Required | The total number of results |
| `total_pages` | `long\|int` | Required | The total number of pages |
| `page_number` | `long\|int` | Required | The current page number |
| `number_of_records_per_page` | `long\|int` | Required | The number of results per page |
| `applications` | [`List of AppStatus`](../../doc/models/app-status.md) | Required | A list of applications with their statuses |

## Example (as JSON)

```json
{
  "totalRecords": 50,
  "totalPages": 5,
  "pageNumber": 2,
  "numberOfRecordsPerPage": 10,
  "applications": {
    "partnerId": "1234583871234",
    "preAppId": "2581",
    "appName": "Awesome Budget App",
    "submittedDate": 1607450357,
    "modifiedDate": 1607450357,
    "status": "P"
  }
}
```

