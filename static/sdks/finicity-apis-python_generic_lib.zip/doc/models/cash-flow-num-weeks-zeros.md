
# Cash Flow Num Weeks Zeros

## Structure

`CashFlowNumWeeksZeros`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `historic_number_of_weeks_with_data_available` | `int` | Required | Number of weeks during known history of account in which data was available |
| `historic_number_of_weeks_zero_transactions` | `int` | Required | Number of weeks during known history of account where zero transactions were posted |
| `historic_weeks_with_zero_transactions` | [`List of ObbWeekOfYear`](../../doc/models/obb-week-of-year.md) | Required | List of weeks with zero reported transactions |

## Example (as JSON)

```json
{
  "historicNumberOfWeeksWithDataAvailable": 10,
  "historicNumberOfWeeksZeroTransactions": 5,
  "historicWeeksWithZeroTransactions": {
    "fromDate": "2020-01-01",
    "toDate": "2020-01-07",
    "week": 1
  }
}
```

