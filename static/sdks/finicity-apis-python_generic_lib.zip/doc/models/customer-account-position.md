
# Customer Account Position

Details for investment account holdings

## Structure

`CustomerAccountPosition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The id of the investment position |
| `description` | `string` | Optional | The description of the holding |
| `symbol` | `string` | Optional | The investment position's market ticker symbol |
| `units` | `float` | Optional | The number of units of the holding |
| `current_price` | `float` | Optional | The current price of the investment holding |
| `security_name` | `string` | Optional | The security name for the investment holding |
| `transaction_type` | `string` | Optional | The transaction type of the holding, such as cash, margin, and more |
| `market_value` | `float` | Optional | Market value of an investment position at the time of retrieval |
| `cost_basis` | `float` | Optional | The total cost of acquiring the security |
| `status` | `string` | Optional | The status of the holding |
| `current_price_date` | `long\|int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `security_type` | `string` | Optional | Type of security for the investment position |
| `mf_type` | `string` | Optional | Type of mutual fund, such as open ended |
| `pos_type` | `string` | Optional | Fund type assigned by the FI (long or short) |
| `total_gl_dollar` | `float` | Optional | Total gain and loss of the position at the time of aggregation in dollars |
| `total_gl_percent` | `float` | Optional | Total gain and loss of the position at the time of aggregation in percentage |
| `option_strike_price` | `float` | Optional | The strike price of the option contract |
| `option_type` | `string` | Optional | The type of option contract (PUT or CALL) |
| `option_shares_per_contract` | `float` | Optional | The number of shares per option contract |
| `option_expire_date` | `date` | Optional | Expiration date of option |
| `fi_asset_class` | `string` | Optional | Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS) |
| `asset_class` | `string` | Optional | An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER) |
| `currency_rate` | `float` | Optional | Currency rate, ratio of currency to original currency |
| `security_id` | `string` | Optional | The security ID of the transaction |
| `security_id_type` | `string` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" |
| `cost_basis_per_share` | `float` | Optional | The per share cost of acquiring the security |
| `sub_account_type` | `string` | Optional | The subaccount's type, such as cash |
| `security_currency` | `string` | Optional | Symbol for the currency that the account is being converted into |
| `today_gl_dollar` | `float` | Optional | The current day's gain and loss of the position at the time of aggregation in dollars |
| `today_gl_percent` | `float` | Optional | The current day's gain and loss of the position at the time of aggregation in percentage |

## Example (as JSON)

```json
{
  "id": null,
  "description": null,
  "symbol": null,
  "units": null,
  "currentPrice": null,
  "securityName": null,
  "transactionType": null,
  "marketValue": null,
  "costBasis": null,
  "status": null,
  "currentPriceDate": null,
  "securityType": null,
  "mfType": null,
  "posType": null,
  "totalGLDollar": null,
  "totalGLPercent": null,
  "optionStrikePrice": null,
  "optionType": null,
  "optionSharesPerContract": null,
  "optionExpireDate": null,
  "fiAssetClass": null,
  "assetClass": null,
  "currencyRate": null,
  "securityId": null,
  "securityIdType": null,
  "costBasisPerShare": null,
  "subAccountType": null,
  "securityCurrency": null,
  "todayGLDollar": null,
  "todayGLPercent": null
}
```

