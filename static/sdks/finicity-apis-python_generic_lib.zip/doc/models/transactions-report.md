
# Transactions Report

A Transactions report

## Structure

`TransactionsReport`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Optional | A report ID |
| `customer_type` | `string` | Optional | The type of customer ("active" or "testing" or "" for all types) |
| `customer_id` | `long\|int` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `request_id` | `string` | Optional | Finicity indicator to track all activity associated with this report |
| `requester_name` | `string` | Optional | Name of a Finicity partner |
| `created_date` | `long\|int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `title` | `string` | Optional | Title of the report |
| `consumer_id` | `string` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `consumer_ssn` | `string` | Optional | Last 4 digits of a SSN |
| `mtype` | `string` | Optional | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" |
| `status` | `string` | Optional | A report generation status. Possible values: "inProgress", "success", "failure". |
| `errors` | [`List of ErrorMessage`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation |
| `portfolio_id` | `string` | Optional | A unique identifier that will be consistent across all reports created for the same customer |
| `start_date` | `long\|int` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `end_date` | `long\|int` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `days` | `long\|int` | Optional | Number of days covered by the report |
| `seasoned` | `bool` | Optional | "true" if the report covers more than 365 days |
| `institutions` | [`List of ReportInstitution`](../../doc/models/report-institution.md) | Optional | A list of institution records |

## Example (as JSON)

```json
{
  "id": null,
  "customerType": null,
  "customerId": null,
  "requestId": null,
  "requesterName": null,
  "createdDate": null,
  "title": null,
  "consumerId": null,
  "consumerSsn": null,
  "type": null,
  "status": null,
  "errors": null,
  "portfolioId": null,
  "startDate": null,
  "endDate": null,
  "days": null,
  "seasoned": null,
  "institutions": null
}
```

