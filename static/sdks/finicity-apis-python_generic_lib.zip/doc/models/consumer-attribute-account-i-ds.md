
# Consumer Attribute Account I Ds

A list of account IDs

## Structure

`ConsumerAttributeAccountIDs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_ids` | `List of string` | Required | The list of account IDs |

## Example (as JSON)

```json
{
  "accountIds": [
    "accountIds5",
    "accountIds6"
  ]
}
```

