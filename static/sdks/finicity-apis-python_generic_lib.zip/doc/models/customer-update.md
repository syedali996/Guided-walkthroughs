
# Customer Update

Represent an update to customer fields

## Structure

`CustomerUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `string` | Optional | First name(s) / given name(s) |
| `last_name` | `string` | Optional | Last name(s) / surname(s) |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

