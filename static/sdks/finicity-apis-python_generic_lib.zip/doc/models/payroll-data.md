
# Payroll Data

## Structure

`PayrollData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ssn` | `string` | Required | A full SSN without hyphens |
| `dob` | `long\|int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `report_id` | `string` | Optional | A report ID |

## Example (as JSON)

```json
{
  "ssn": "999999999",
  "dob": 1607450357
}
```

