
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `http_client_instance` | `HttpClient` | The Http Client passed from the sdk user for making requests |
| `override_http_client_configuration` | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| `http_call_back` | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| `timeout` | `float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `backoff_factor` | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| `retry_statuses` | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT', 'GET', 'PUT']** |
| `finicity_app_key` | `string` | The "Finicity-App-Key" from the developer dashboard |
| `finicity_app_token` | `string` | A token returned by the `/authentication` API |

The API client can be initialized as follows:

```python
from finicityapis.finicityapis_client import FinicityapisClient
from finicityapis.configuration import Environment

client = FinicityapisClient(
    finicity_app_key='Finicity-App-Key',
    finicity_app_token='Finicity-App-Token',
    environment=Environment.PRODUCTION,)
```

## Finicity APIs Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| accounts | Gets AccountsController |
| analytics_and_attributes | Gets AnalyticsAndAttributesController |
| app_registration | Gets AppRegistrationController |
| assets | Gets AssetsController |
| authentication | Gets AuthenticationController |
| balance_analytics | Gets BalanceAnalyticsController |
| bank_statements | Gets BankStatementsController |
| cash_flow | Gets CashFlowController |
| cash_flow_analytics | Gets CashFlowAnalyticsController |
| connect | Gets ConnectController |
| consumers | Gets ConsumersController |
| customers | Gets CustomersController |
| institutions | Gets InstitutionsController |
| pay_statements | Gets PayStatementsController |
| payments | Gets PaymentsController |
| portfolios | Gets PortfoliosController |
| reports | Gets ReportsController |
| transactions | Gets TransactionsController |
| tx_push | Gets TxPushController |
| verify_assets | Gets VerifyAssetsController |
| verify_income_and_employment | Gets VerifyIncomeAndEmploymentController |

