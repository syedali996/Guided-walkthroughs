
# VOI Report Ack

## Structure

`VOIReportAck`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | A report ID |
| `customer_type` | `String` | Required | The type of customer ("active" or "testing" or "" for all types) |
| `customer_id` | `Integer` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `request_id` | `String` | Required | Finicity indicator to track all activity associated with this report |
| `requester_name` | `String` | Required | Name of a Finicity partner |
| `created_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `title` | `String` | Required | Title of the report |
| `consumer_id` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `consumer_ssn` | `String` | Required | Last 4 digits of a SSN |
| `type` | `String` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" |
| `status` | `String` | Required | A report generation status. Possible values: "inProgress", "success", "failure". |
| `errors` | [`Array<ErrorMessage>`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation |
| `portfolio_id` | `String` | Required | A unique identifier that will be consistent across all reports created for the same customer |
| `constraints` | [`VOIReportConstraintsOut`](../../doc/models/voi-report-constraints-out.md) | Required | - |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "customerType": "active",
  "customerId": 1005061234,
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "title": "Finicity Asset Ready Report (CRA)",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress",
  "portfolioId": "y4zsgccj4xpw-6-port",
  "constraints": null
}
```

