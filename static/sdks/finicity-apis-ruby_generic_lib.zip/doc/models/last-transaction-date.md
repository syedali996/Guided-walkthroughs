
# Last Transaction Date

## Structure

`LastTransactionDate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `String` | Required | Date the deposit transaction was posted |
| `deposits_credits` | `Float` | Optional | Amount of transaction if deposit, otherwise null |
| `withdrawals_debits` | `Float` | Optional | Amount of transaction if withdrawal, otherwise null |
| `zero_amount_transaction` | `Float` | Optional | Amount of transaction if zero, otherwise null |
| `transaction_description` | `String` | Optional | Description of transaction |

## Example (as JSON)

```json
{
  "date": "2020-03-25"
}
```

