
# Institution

A financial institution

## Structure

`Institution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | The ID of a financial institution, represented as a number |
| `name` | `String` | Optional | The name of the institution |
| `trans_agg` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product |
| `ach` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product |
| `state_agg` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product |
| `voi` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product |
| `voa` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product |
| `aha` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product |
| `avail_balance` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product |
| `account_owner` | `TrueClass\|FalseClass` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product |
| `student_loan_data` | `TrueClass\|FalseClass` | Optional | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product |
| `loan_payment_details` | `TrueClass\|FalseClass` | Optional | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product |
| `account_type_description` | `String` | Optional | Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance |
| `phone` | `String` | Optional | A phone number |
| `url_home_app` | `String` | Optional | The URL of the institution's primary home page |
| `url_logon_app` | `String` | Optional | The URL of the institution's login page |
| `oauth_enabled` | `TrueClass\|FalseClass` | Required | "true": The institution is an OAuth connection<br><br>"false": The institution isn't an OAuth connection |
| `url_forgot_password` | `String` | Optional | Institution's forgot password page |
| `url_online_registration` | `String` | Optional | Institution's signup page |
| `mclass` | `String` | Optional | Institution's class |
| `special_text` | `String` | Optional | Special instructions given to customers for login |
| `time_zone` | `String` | Optional | The time zone of the institution. |
| `special_instructions` | `Array<String>` | Optional | Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.<br><br>Note: this helps the customer to provide the proper permission for data needed for the application. |
| `special_instutions_title` | `String` | Optional | The title of the special instructions, if one exists or is required. |
| `address` | [`InstitutionAddress`](../../doc/models/institution-address.md) | Optional | The address of a financial institution |
| `currency` | `String` | Required | A currency code |
| `email` | `String` | Optional | An email address |
| `status` | `String` | Required | Status for the institution: "online", "offline", "maintenance", "testing" |
| `new_institution_id` | `Integer` | Optional | The ID of a financial institution, represented as a number |
| `branding` | [`Branding`](../../doc/models/branding.md) | Optional | All assets are SVGs so can be slightly resized without any issues. |
| `oauth_institution_id` | `Integer` | Optional | The ID of a financial institution, represented as a number |

## Example (as JSON)

```json
{
  "id": 4222,
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "oauthEnabled": true,
  "currency": "USD",
  "status": "online"
}
```

