
# Statement Data

## Structure

`StatementData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_id` | `Integer` | Required | An account ID represented as a number |
| `index` | `Integer` | Optional | Index of the statement to retrieve<br>**Default**: `1`<br>**Constraints**: `<= 6` |

## Example (as JSON)

```json
{
  "accountId": 5011648377
}
```

