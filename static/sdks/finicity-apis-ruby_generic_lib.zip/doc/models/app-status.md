
# App Status

Registration status details for the application

## Structure

`AppStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `partner_id` | `String` | Required | Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin) |
| `pre_app_id` | `String` | Required | Identifier to track the application registration from the App Registration and Get App Registration Status APIs |
| `note` | `String` | Optional | A note on the registration. Typically used to indicate reasons for rejected apps. |
| `application_id` | `String` | Optional | `applicationId` value returned from the Get App Registration Status API and the partner assign the customers to. This cannot be changed once set. Only applicable in cases of partners with multiple registered applications. If the partner only has one app, this can usually be omitted. This field is populated after the app is in a status approved. |
| `app_name` | `String` | Required | The name of the application assigned to the customer |
| `submitted_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `modified_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `status` | `String` | Required | The status of an app registration request. "A" means approved. "P" means pending which is the status when initially submitted or when the app is modified and awaiting approval. "R" means rejected. If it is rejected there will be a note with the rejected reason. |
| `scopes` | `String` | Optional | Indicates scopes of data accessible to the app |
| `institution_details` | [`Array<AppFinancialInstitutionStatus>`](../../doc/models/app-financial-institution-status.md) | Optional | A list of the registration status for each FI for the application |

## Example (as JSON)

```json
{
  "partnerId": "1234583871234",
  "preAppId": "2581",
  "appName": "Awesome Budget App",
  "submittedDate": 1607450357,
  "modifiedDate": 1607450357,
  "status": "P"
}
```

