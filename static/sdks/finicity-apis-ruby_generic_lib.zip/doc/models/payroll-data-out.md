
# Payroll Data Out

## Structure

`PayrollDataOut`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payroll_data_retrieval_id` | `String` | Required | An id to identify the data retrieved from the payroll providers for the report. |
| `employer_names` | `Array<String>` | Required | An array of employer names that the consumer submitted after completing the Connect application. |
| `report_id` | `String` | Optional | A report ID |

## Example (as JSON)

```json
{
  "payrollDataRetrievalId": "hahvhe2k0000",
  "employerNames": null
}
```

