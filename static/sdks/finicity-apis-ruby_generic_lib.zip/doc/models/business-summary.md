
# Business Summary

## Structure

`BusinessSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `cashflow_analytics_metrics` | [`CashFlowAnalyticsMetrics`](../../doc/models/cash-flow-analytics-metrics.md) | Optional | Cash flow analytics metrics and calculations across all accounts in the report |
| `current_report_request` | [`ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Required | - |
| `historic_data_availability` | [`ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Required | - |
| `balance_analytics_metrics` | [`BalanceAnalyticsMetrics`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations across all accounts in the report |

## Example (as JSON)

```json
{
  "currentReportRequest": {
    "reportBeginDate": "2022-03-01",
    "reportEndDate": "2022-03-30",
    "reportRequestDate": "03/30/2022 21:47:19",
    "requestedDaysForReport": 90,
    "requestedReportBeginDate": "2022-01-01"
  },
  "historicDataAvailability": {
    "historicAvailabilityBeginDate": "2022-03-01",
    "historicAvailabilityEndDate": "2022-03-30",
    "historicAvailableDays": 30,
    "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
  }
}
```

