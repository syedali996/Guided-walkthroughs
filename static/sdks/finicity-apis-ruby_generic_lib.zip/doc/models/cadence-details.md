
# Cadence Details

## Structure

`CadenceDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `start_date` | `Integer` | Optional | `postedDate` of the first deposit transaction |
| `stop_date` | `Integer` | Optional | `postedDate` of the final deposit transaction (omitted if status is active) |
| `days` | `Integer` | Optional | Number of days between the recurring deposits |

## Example (as JSON)

```json
{
  "startDate": null,
  "stopDate": null,
  "days": null
}
```

