
# Cash Flow Report Account

## Structure

`CashFlowReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | Finicity account ID |
| `owner_name` | `String` | Optional | The name(s) of the account owner(s), retrieved from the institution. |
| `owner_address` | `String` | Optional | The mailing address of the account owner, retrieved from the institution. |
| `name` | `String` | Optional | The account name from the institution |
| `number` | `String` | Optional | The account number from the institution (obfuscated) |
| `type` | `String` | Optional | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) |
| `aggregation_status_code` | `String` | Optional | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) |
| `current_balance` | `Float` | Optional | The cleared balance of the account as-of `balanceDate` |
| `available_balance` | `Float` | Optional | Available balance |
| `balance_date` | `Integer` | Optional | A timestamp showing when the `balance` was captured |
| `transactions` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `cash_flow_balance` | [`CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - |
| `cash_flow_credit` | [`CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - |
| `cash_flow_debit` | [`CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - |
| `cash_flow_characteristic` | [`CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "number": null,
  "type": null,
  "aggregationStatusCode": null,
  "currentBalance": null,
  "availableBalance": null,
  "balanceDate": null,
  "transactions": null,
  "cashFlowBalance": null,
  "cashFlowCredit": null,
  "cashFlowDebit": null,
  "cashFlowCharacteristic": null
}
```

