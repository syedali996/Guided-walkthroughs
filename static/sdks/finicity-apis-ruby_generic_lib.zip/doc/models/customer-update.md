
# Customer Update

Represent an update to customer fields

## Structure

`CustomerUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `String` | Optional | First name(s) / given name(s) |
| `last_name` | `String` | Optional | Last name(s) / surname(s) |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

