
# Balance and Cash Flow Analytics Report Ack

Response given when analtyics were generated successfully, providing the caller with a report ID which can be used to retrieve the report as JSON or a PDF.

## Structure

`BalanceAndCashFlowAnalyticsReportAck`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_ids` | `Array<Integer>` | Required | List of account IDs included in the report |
| `business_id` | `Integer` | Optional | Business ID associated with the requested customer |
| `created_date` | `String` | Required | Created date of balance analytics request<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `customer_id` | `Integer` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `report_id` | `String` | Required | A report ID |
| `report_pin` | `String` | Required | PIN that may be used to access the report<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` |
| `requester_name` | `String` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `title` | `String` | Required | Title of the report |

## Example (as JSON)

```json
{
  "accountIds": null,
  "createdDate": null,
  "customerId": 1005061234,
  "reportId": "u4hstnnak45g",
  "reportPin": null,
  "title": "Finicity Asset Ready Report (CRA)"
}
```

