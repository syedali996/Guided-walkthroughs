
# VOIE Pay Statement

## Structure

`VOIEPayStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pay_period` | `String` | Optional | The pay period of the pay statement |
| `billable` | `TrueClass\|FalseClass` | Optional | Designates whether the pay statement is billable |
| `asset_id` | `String` | Optional | The asset ID of the stored pay statement |
| `pay_date` | `Integer` | Optional | The listed pay date for the pay statement |
| `start_date` | `Integer` | Optional | The beginning of the pay period |
| `end_date` | `Integer` | Optional | The end of the pay period |
| `net_pay_current` | `Float` | Optional | The total pay after deductions for the employee for the current pay period |
| `net_pay_ytd` | `Float` | Optional | The total accumulation of pay after deductions for the employee for the current pay year |
| `gross_pay_current` | `Float` | Optional | The total pay before deductions for the employee for the current pay period |
| `gross_pay_ytd` | `Float` | Optional | The total accumulation of pay before deductions for the employee for the current pay year |
| `payroll_provider` | `String` | Optional | The company that provides the pay stub. |
| `employer` | [`Employer`](../../doc/models/employer.md) | Optional | - |
| `employee` | [`Employee`](../../doc/models/employee.md) | Optional | - |
| `pay_stat` | [`Array<PayStat>`](../../doc/models/pay-stat.md) | Optional | Information pertaining to the earnings on the pay statement |
| `deductions` | [`Array<Deduction>`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement |
| `direct_deposits` | [`Array<DirectDeposit>`](../../doc/models/direct-deposit.md) | Optional | Information pertaining to direct deposits on the pay statement |

## Example (as JSON)

```json
{
  "payPeriod": null,
  "billable": null,
  "assetId": null,
  "payDate": null,
  "startDate": null,
  "endDate": null,
  "netPayCurrent": null,
  "netPayYTD": null,
  "grossPayCurrent": null,
  "grossPayYTD": null,
  "payrollProvider": null,
  "employer": null,
  "employee": null,
  "payStat": null,
  "deductions": null,
  "directDeposits": null
}
```

