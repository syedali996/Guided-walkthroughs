
# Report Header

## Structure

`ReportHeader`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_address` | `String` | Optional | Business address line 1<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `business_city` | `String` | Optional | Business address city<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `business_name` | `String` | Optional | Name of the business<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `business_state` | `String` | Optional | Business address state<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `business_zip` | `String` | Optional | Business address zip<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `reference_number` | `String` | Optional | Partner-provided reference number<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `report_date` | `String` | Required | Date the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `report_id` | `String` | Required | Generated unique report ID<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "reportDate": "03/17/2022 04:28:38",
  "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
}
```

