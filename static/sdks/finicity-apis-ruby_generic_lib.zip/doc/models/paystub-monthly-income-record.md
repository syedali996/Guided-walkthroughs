
# Paystub Monthly Income Record

## Structure

`PaystubMonthlyIncomeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `estimated_monthly_base_pay` | `Float` | Optional | The estimated monthly base pay amount for the employment from the paystub, calculated by Finicity |
| `estimated_monthly_overtime_pay` | `Float` | Optional | The estimated monthly overtime pay amount for the employment from the paystub, calculated by Finicity |
| `estimated_monthly_bonus_pay` | `Float` | Optional | The estimated monthly bonus pay amount for the employment from the paystub, calculated by Finicity |
| `estimated_monthly_commission_pay` | `Float` | Optional | The estimated commission bonus pay amount for the employment from the paystub, calculated by Finicity |

## Example (as JSON)

```json
{
  "estimatedMonthlyBasePay": null,
  "estimatedMonthlyOvertimePay": null,
  "estimatedMonthlyBonusPay": null,
  "estimatedMonthlyCommissionPay": null
}
```

