
# Cash Flow Monthly Cash Flow Balance Summaries

## Structure

`CashFlowMonthlyCashFlowBalanceSummaries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `month` | `Integer` | Required | One instance for each complete calendar month in the report |
| `min_daily_balance` | `Float` | Required | Min Daily Balance for each month for all accounts |
| `max_daily_balance` | `Float` | Required | Max Daily Balance for each month for all accounts |
| `average_daily_balance` | `Float` | Required | Average Daily Balance for each month for all accounts |
| `standard_deviation_of_daily_balance` | `String` | Required | Standard Deviation of Daily Balance for each month for all accounts |
| `number_of_days_negative_balance` | `String` | Required | Number of Days Negative Balance for each month for all accounts |
| `number_of_days_positive_balance` | `String` | Required | Number of Days Positive Balance for each month for all accounts |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "minDailyBalance": 3479.39,
  "maxDailyBalance": 3479.39,
  "averageDailyBalance": 3479.39,
  "standardDeviationOfDailyBalance": "20.45454545",
  "numberOfDaysNegativeBalance": "6",
  "numberOfDaysPositiveBalance": "0"
}
```

