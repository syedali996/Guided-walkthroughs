
# Consumer

A finicity consumer record

## Structure

`Consumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `first_name` | `String` | Required | First name(s) / given name(s) |
| `last_name` | `String` | Required | Last name(s) / surname(s) |
| `customer_id` | `Integer` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `address` | `String` | Required | A street address |
| `city` | `String` | Required | A city |
| `state` | `String` | Required | A state |
| `zip` | `String` | Required | A ZIP code |
| `phone` | `String` | Required | A phone number |
| `ssn` | `String` | Required | Last 4 digits of a SSN |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `email` | `String` | Required | An email address |
| `created_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `suffix` | `String` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "9999",
  "birthday": null,
  "email": "finicity@test.com",
  "createdDate": 1607450357
}
```

