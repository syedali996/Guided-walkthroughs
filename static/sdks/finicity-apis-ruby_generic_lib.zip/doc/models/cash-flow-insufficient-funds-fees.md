
# Cash Flow Insufficient Funds Fees

## Structure

`CashFlowInsufficientFundsFees`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count_of_transactions_for_the_report_time_period` | `Integer` | Optional | Count of all NSF transactions during the report |
| `sum_of_transactions_for_the_report_time_period` | `Float` | Optional | Sum of all NSF transactions during the report |
| `transactions` | [`Array<InsufficientFundsTransaction>`](../../doc/models/insufficient-funds-transaction.md) | Optional | Transactions categorized as NSF |

## Example (as JSON)

```json
{
  "countOfTransactionsForTheReportTimePeriod": null,
  "sumOfTransactionsForTheReportTimePeriod": null,
  "transactions": null
}
```

