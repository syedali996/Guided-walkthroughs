
# Get Obb Analytics Report Response

## Structure

`GetObbAnalyticsReportResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_results` | [`Array<CashFlowAnalyticsAccountResult1>`](../../doc/models/cash-flow-analytics-account-result-1.md) | Optional | Cash flow results per account |
| `business_id` | `Integer` | Optional | Business ID |
| `business_summary` | [`BusinessSummary`](../../doc/models/business-summary.md) | Optional | - |
| `customer_id` | `Integer` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `report_header` | [`ReportHeader`](../../doc/models/report-header.md) | Required | - |
| `requester_name` | `String` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `title` | `String` | Required | Title of the report |
| `total_revenue` | `Float` | Optional | The total revenue |

## Example (as JSON)

```json
{
  "customerId": 1005061234,
  "reportHeader": {
    "reportDate": "03/17/2022 04:28:38",
    "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
  },
  "title": "Finicity Asset Ready Report (CRA)"
}
```

