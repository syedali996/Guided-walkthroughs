
# VOIETX Verify Report Income Stream

## Structure

`VOIETXVerifyReportIncomeStream`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | Finicity’s income stream ID |
| `name` | `String` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream |
| `status` | `String` | Required | Possible values: "ACTIVE", "INACTIVE" |
| `confidence` | `Integer` | Required | Level of confidence that the deposit stream represents income (example: 85%) |
| `cadence` | [`CadenceDetails`](../../doc/models/cadence-details.md) | Required | - |
| `net_monthly` | [`Array<NetMonthly>`](../../doc/models/net-monthly.md) | Required | A list of net monthly records. One instance for each complete calendar month in the report. |
| `net_annual` | `Float` | Required | Sum of all values in `netMonthlyIncome` over the previous 12 months |
| `projected_net_annual` | `Float` | Required | Projected net income over the next 12 months, across all income streams, based on `netAnnualIncome` |
| `estimated_gross_annual` | `Float` | Required | Before-tax gross annual income (estimated from `netAnnual`) across all income stream in the past 12 months |
| `projected_gross_annual` | `Float` | Required | Projected gross income over the next 12 months, across all active income streams, based on `projectedNetAnnual` |
| `average_monthly_income_net` | `Float` | Required | Monthly average amount over the previous 24 months |
| `income_stream_months` | `Integer` | Required | The number of months the income transactions are observed |
| `transactions` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | A list of transaction records |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voietxverify",
  "name": "none",
  "status": null,
  "confidence": 70,
  "cadence": null,
  "netMonthly": {
    "month": 1522562400,
    "net": 2004.77
  },
  "netAnnual": 110475.7,
  "projectedNetAnnual": 0,
  "estimatedGrossAnnual": 12321.1,
  "projectedGrossAnnual": 151609,
  "averageMonthlyIncomeNet": 9206.31,
  "incomeStreamMonths": 24,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

