
# Cash Flow Activity Withdrawals Debits

## Structure

`CashFlowActivityWithdrawalsDebits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `String` | Required | Date the withdrawal transaction was posted<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `transaction_description` | `String` | Optional | Description of transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `withdrawals_debits` | `Float` | Required | Amount of the withdrawal |

## Example (as JSON)

```json
{
  "date": "2020-03-25",
  "withdrawalsDebits": 15.69
}
```

