
# Cash Flow Monthly Cash Flow Credits

## Structure

`CashFlowMonthlyCashFlowCredits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `month` | `Integer` | Required | One instance for each complete calendar month in the report |
| `number_of_credits` | `String` | Required | Number of credits by month |
| `total_credits_amount` | `Float` | Required | Total amount of credits by month |
| `largest_credit` | `Float` | Required | Largest credit by month |
| `number_of_credits_less_transfers` | `String` | Required | Number of credits by month (less transfers) |
| `total_credits_amount_less_transfers` | `Float` | Required | Total amount of credits by month (less transfers) |
| `average_credit_amount` | `Float` | Required | The average credit amount |
| `estimated_number_of_loan_deposits` | `String` | Required | The estimated number of loan deposits |
| `estimated_loan_deposit_amount` | `Float` | Required | The estimated loan deposit amount |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "3",
  "totalCreditsAmount": 5000,
  "largestCredit": 2000,
  "numberOfCreditsLessTransfers": "2",
  "totalCreditsAmountLessTransfers": 4000,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

