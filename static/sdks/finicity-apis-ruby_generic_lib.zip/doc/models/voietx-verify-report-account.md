
# VOIETX Verify Report Account

## Structure

`VOIETXVerifyReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | The ID of the account |
| `number` | `String` | Required | The account number from the institution (all digits except the last four are obfuscated) |
| `owner_name` | `String` | Required | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `owner_address` | `String` | Required | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `name` | `String` | Required | The account name from the institution |
| `type` | `String` | Required | One of the values from account types |
| `aggregation_status_code` | `Integer` | Required | The status of the most recent aggregation attempt |
| `income_streams` | [`Array<VOIETXVerifyReportIncomeStream>`](../../doc/models/voietx-verify-report-income-stream.md) | Required | A list of income stream records |
| `balance` | `Float` | Required | The cleared balance of the account as-of `balanceDate` |
| `average_monthly_balance` | `Float` | Required | The average monthly balance of this account |
| `transactions` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | a list of transaction records |
| `available_balance` | `Float` | Required | The available balance for the account |

## Example (as JSON)

```json
{
  "id": 1000023996,
  "number": "1111",
  "ownerName": "JOHN DOE",
  "ownerAddress": "924 GAINSVILLE HIGHWAY SUITE 130 BUFORD, GA 30518",
  "name": "Checking",
  "type": "checking",
  "aggregationStatusCode": null,
  "incomeStreams": {
    "id": "dens28i3vsch-voietxverify",
    "name": "none",
    "status": null,
    "confidence": 70,
    "cadence": null,
    "netMonthly": {
      "month": 1522562400,
      "net": 2004.77
    },
    "netAnnual": 110475.7,
    "projectedNetAnnual": 0,
    "estimatedGrossAnnual": 12321.1,
    "projectedGrossAnnual": 151609,
    "averageMonthlyIncomeNet": 9206.31,
    "incomeStreamMonths": 24,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    }
  },
  "balance": 123.45,
  "averageMonthlyBalance": 301.45,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "availableBalance": 123.45
}
```

