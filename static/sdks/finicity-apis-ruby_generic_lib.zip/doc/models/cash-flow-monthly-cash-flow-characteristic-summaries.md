
# Cash Flow Monthly Cash Flow Characteristic Summaries

## Structure

`CashFlowMonthlyCashFlowCharacteristicSummaries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `month` | `Integer` | Required | One instance for each complete calendar month in the report |
| `total_credits_less_total_debits` | `Float` | Required | Total Credits - Total Debits by month across all accounts |
| `total_credits_less_total_debits_less_transfers` | `Float` | Required | Total Credits - Total Debits by month (Without Transfers) across all accounts |
| `average_transaction_amount` | `Float` | Required | Average transaction amount across all accounts |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "totalCreditsLessTotalDebits": 15000,
  "totalCreditsLessTotalDebitsLessTransfers": 11000,
  "averageTransactionAmount": 10
}
```

