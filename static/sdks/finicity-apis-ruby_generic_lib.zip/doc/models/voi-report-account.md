
# VOI Report Account

## Structure

`VOIReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the account |
| `number` | `String` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `owner_name` | `String` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `owner_address` | `String` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `name` | `String` | Optional | The account name from the institution |
| `type` | `String` | Optional | One of the values from account types |
| `aggregation_status_code` | `Integer` | Optional | The status of the most recent aggregation attempt |
| `income_streams` | [`Array<VOIReportIncomeStream>`](../../doc/models/voi-report-income-stream.md) | Optional | A list of income stream records |
| `balance` | `Float` | Optional | The cleared balance of the account as-of `balanceDate` |
| `average_monthly_balance` | `Float` | Optional | The average monthly balance of this account |
| `transactions` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `available_balance` | `Float` | Optional | The available balance for the account |
| `current_balance` | `Float` | Optional | Current balance of the account |
| `beginning_balance` | `Float` | Optional | Beginning balance of account per the time period in the report |
| `misc_deposits` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null,
  "balance": null,
  "averageMonthlyBalance": null,
  "transactions": null,
  "availableBalance": null,
  "currentBalance": null,
  "beginningBalance": null,
  "miscDeposits": null
}
```

