
# Application

## Structure

`Application`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `app_description` | `String` | Required | A short description of the app. This will be visible to end users in the FI interface. |
| `app_name` | `String` | Required | The name of the application assigned to the customer |
| `app_url` | `String` | Required | An URL for the app. This will be visible to end users in the FI interface. |
| `owner_address_line_1` | `String` | Required | An address line 1 |
| `owner_address_line_2` | `String` | Required | An address line 2 |
| `owner_city` | `String` | Required | City for the business entity that owns the app. Information for registration purposes only and not given to the end user. |
| `owner_country` | `String` | Required | Country for the  business entity that owns the app. Information for registration purposes only and not given to the end user. |
| `owner_name` | `String` | Required | Business name for the business entity that owns the app. Information for registration purposes only and not given to the end user. |
| `owner_postal_code` | `String` | Required | Zip code for the business entity that owns the app. Information for registration purposes only and not given to the end user. |
| `owner_state` | `String` | Required | State for the business entity that owns the app. Information for registration purposes only and not given to the end user. |
| `image` | `String` | Required | An app logo passed as a Base64 encoded image (1:1 SVG file, must be less than 50KB) |

## Example (as JSON)

```json
{
  "appDescription": "The app that makes your budgeting experience awesome",
  "appName": "Awesome Budget App",
  "appUrl": "https://www.finicity.com/",
  "ownerAddressLine1": "434 W Ascension Way",
  "ownerAddressLine2": "Suite #200",
  "ownerCity": "Murray",
  "ownerCountry": "USA",
  "ownerName": "Finicity",
  "ownerPostalCode": "84123",
  "ownerState": "UT",
  "image": "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K"
}
```

