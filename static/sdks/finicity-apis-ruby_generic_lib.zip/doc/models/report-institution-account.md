
# Report Institution Account

An account record

## Structure

`ReportInstitutionAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | Finicity account ID |
| `owner_name` | `String` | Required | The name(s) of the account owner(s), retrieved from the institution. |
| `owner_address` | `String` | Required | The mailing address of the account owner, retrieved from the institution. |
| `name` | `String` | Required | The account name from the institution |
| `number` | `String` | Required | The account number from the institution (obfuscated) |
| `type` | `String` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) |
| `aggregation_status_code` | `String` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) |
| `current_balance` | `Float` | Optional | The cleared balance of the account as-of `balanceDate` |
| `available_balance` | `Float` | Required | Available balance |
| `balance_date` | `Integer` | Optional | A timestamp showing when the `balance` was captured |
| `transactions` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | a list of transaction records |
| `cash_flow_balance` | [`CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - |
| `cash_flow_credit` | [`CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - |
| `cash_flow_debit` | [`CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - |
| `cash_flow_characteristic` | [`CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - |
| `balance` | `Float` | Required | The cleared balance of the account as-of `balanceDate` |
| `average_monthly_balance` | `Float` | Required | The average monthly balance of the account |
| `tot_number_insufficient_funds_fee_debit_tx_account` | `Integer` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report |
| `tot_number_insufficient_funds_fee_debit_tx_over_6_months_account` | `Integer` | Optional | The total number of  insufficient funds fees for the account over six months |
| `tot_number_days_since_most_recent_insufficient_funds_fee_debit_tx_account` | `Integer` | Optional | The total number of days since the most recent insufficient funds fee for the account |
| `asset` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `details` | [`AccountDetails`](../../doc/models/account-details.md) | Optional | - |
| `tot_number_insufficient_funds_fee_debit_tx_over_2_months_account` | `Integer` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. |
| `income_streams` | [`Array<VOAIReportIncomeStream2>`](../../doc/models/voai-report-income-stream-2.md) | Required | A list of income stream records |
| `beginning_balance` | `Float` | Optional | Beginning balance of account per the time period in the report |
| `misc_deposits` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "availableBalance": 1000,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "balance": 501.24,
  "averageMonthlyBalance": 501.02,
  "incomeStreams": {
    "id": "dens28i3vsch-voah",
    "name": "none",
    "status": null,
    "estimateInclusion": null,
    "confidence": 70,
    "cadence": null,
    "netMonthly": [
      {
        "month": 1522562400,
        "net": 2004.77
      }
    ],
    "netAnnual": 110475.7,
    "projectedNetAnnual": 0,
    "estimatedGrossAnnual": 12321.1,
    "projectedGrossAnnual": 151609,
    "averageMonthlyIncomeNet": 9206.31,
    "incomeStreamMonths": 18,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    },
    "daysSinceLastTransaction": 15,
    "nextExpectedTransactionDate": 1572625469
  }
}
```

