
# App Financial Institution Status

The registration status fields for each specific OAuth financial institution

## Structure

`AppFinancialInstitutionStatus`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Required | The ID of a financial institution, represented as a number |
| `abbrv_name` | `String` | Optional | The application's abbreviated name |
| `logo_url` | `String` | Optional | An URL to a logo file |
| `decryption_key_activated` | `TrueClass\|FalseClass` | Required | Status of decryption keys for financial institution app registration |
| `created_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_modified_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `status` | `TrueClass\|FalseClass` | Required | "false" indicates registration is still pending |

## Example (as JSON)

```json
{
  "id": 4222,
  "decryptionKeyActivated": false,
  "createdDate": 1607450357,
  "lastModifiedDate": 1607450357,
  "status": true
}
```

