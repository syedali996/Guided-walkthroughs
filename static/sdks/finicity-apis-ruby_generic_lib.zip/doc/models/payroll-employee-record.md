
# Payroll Employee Record

## Structure

`PayrollEmployeeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | Full name of the employee: first, middle (if stated), and last name |
| `given_name` | `String` | Required | First name of employee |
| `middle_name` | `String` | Optional | Middle name of employee, if stated |
| `family_name` | `String` | Required | Last name of employee |
| `address` | [`Array<PayrollEmployeeAddress>`](../../doc/models/payroll-employee-address.md) | Optional | Array of addresses |

## Example (as JSON)

```json
{
  "name": "John Doe Smith",
  "givenName": "John",
  "familyName": "Smith"
}
```

