
# Cash Flow Possible Loan Deposits Account

## Structure

`CashFlowPossibleLoanDepositsAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | Finicity account ID |
| `owner_name` | `String` | Required | The name(s) of the account owner(s), retrieved from the institution. |
| `owner_address` | `String` | Required | The mailing address of the account owner, retrieved from the institution. |
| `name` | `String` | Required | The account name from the institution |
| `number` | `String` | Required | The account number from the institution (obfuscated) |
| `type` | `String` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) |
| `aggregation_status_code` | `String` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) |
| `current_balance` | `Float` | Required | The cleared balance of the account as-of `balanceDate` |
| `available_balance` | `Float` | Required | Available balance |
| `balance_date` | `Integer` | Required | A timestamp showing when the `balance` was captured |
| `transactions` | [`Array<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | a list of transaction records |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "currentBalance": 100000,
  "availableBalance": 1000,
  "balanceDate": 1614880526,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

