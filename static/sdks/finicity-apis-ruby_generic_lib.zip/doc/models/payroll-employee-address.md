
# Payroll Employee Address

## Structure

`PayrollEmployeeAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address_1` | `String` | Optional | Employee address as stated by the employer in the payroll system |
| `city` | `String` | Optional | Employee city as stated by the employer in the payroll system |
| `state` | `String` | Optional | Employee state as stated by the employer in the payroll system |
| `zip` | `String` | Optional | Employee zip code as stated by the employer in the payroll system |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

