
# Cash Flow Monthlycashflow Debits

## Structure

`CashFlowMonthlycashflowDebits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `month` | `Integer` | Required | One instance for each complete calendar month in the report |
| `number_of_debits` | `String` | Required | Number of Debits by month |
| `total_debits_amount` | `Float` | Required | Total Amount of Debits by month |
| `largest_debit` | `Float` | Required | Largest Debit by month |
| `number_of_debits_less_transfers` | `String` | Required | Number of Debits by month (less transfers) |
| `total_debits_amount_less_transfers` | `Float` | Required | Total amount of debits by month (less transfers) |
| `average_debit_amount` | `Float` | Required | The average debit amount |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfDebits": "5",
  "totalDebitsAmount": -12345,
  "largestDebit": -2000,
  "numberOfDebitsLessTransfers": "3",
  "totalDebitsAmountLessTransfers": -2000,
  "averageDebitAmount": 500
}
```

