
# Balance Analytics Metrics

## Structure

`BalanceAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available_balance` | `Float` | Optional | Available Balance |
| `available_balance_date` | `String` | Optional | Available Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `average_daily_balance_by_month_for_the_report_time_period` | [`Array<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average daily ending balance each month over the report time period |
| `average_daily_balance_for_the_report_time_period` | `Float` | Optional | Average Daily Balance |
| `average_weekday_balance_for_the_report_time_period` | `Float` | Optional | Average Weekday Balance |
| `count_daily_negative_balances_by_month_for_the_report_time_period` | [`Array<ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Optional | Number of negative daily ending balances each month over the report time period |
| `current_running_balance` | `Float` | Optional | Current Running Balance Date |
| `current_running_balance_date` | `String` | Optional | Current Running Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `daily_balances_by_weekday_for_the_report_time_period` | [`Array<ObbDailyBalance>`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account during weekdays over the length of the report |
| `daily_balances_for_the_report_time_period` | [`Array<ObbDailyBalance>`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account over the length of the report |
| `historic_number_of_weeks_average_balance_increasing` | [`ObbNumWeeksAverageBalanceIncreasing`](../../doc/models/obb-num-weeks-average-balance-increasing.md) | Optional | Report of average account balance week over week and count of weeks where the average balance increased |
| `maximum_daily_balance_by_month_for_the_report_time_period` | [`Array<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Maximum daily ending balance each month over the report time period |
| `maximum_running_balance_for_the_report_time_period` | `Float` | Optional | Maximum Running Balance |
| `minimum_daily_balance_by_month_for_the_report_time_period` | [`Array<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Minimum daily ending balance each month over the report time period |
| `minimum_running_balance_for_the_report_time_period` | `Float` | Optional | Minimum Running Balance |

## Example (as JSON)

```json
{
  "availableBalance": null,
  "availableBalanceDate": null,
  "averageDailyBalanceByMonthForTheReportTimePeriod": null,
  "averageDailyBalanceForTheReportTimePeriod": null,
  "averageWeekdayBalanceForTheReportTimePeriod": null,
  "countDailyNegativeBalancesByMonthForTheReportTimePeriod": null,
  "currentRunningBalance": null,
  "currentRunningBalanceDate": null,
  "dailyBalancesByWeekdayForTheReportTimePeriod": null,
  "dailyBalancesForTheReportTimePeriod": null,
  "historicNumberOfWeeksAverageBalanceIncreasing": null,
  "maximumDailyBalanceByMonthForTheReportTimePeriod": null,
  "maximumRunningBalanceForTheReportTimePeriod": null,
  "minimumDailyBalanceByMonthForTheReportTimePeriod": null,
  "minimumRunningBalanceForTheReportTimePeriod": null
}
```

