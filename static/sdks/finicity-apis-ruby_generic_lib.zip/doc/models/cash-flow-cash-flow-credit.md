
# Cash Flow Cash Flow Credit

## Structure

`CashFlowCashFlowCredit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthly_cash_flow_credits` | [`Array<CashFlowMonthlyCashFlowCredits>`](../../doc/models/cash-flow-monthly-cash-flow-credits.md) | Required | List of attributes for each month |
| `twelve_month_credit_total` | `Float` | Required | Sum of all credit transactions for each month by account |
| `twelve_month_credit_total_less_transfers` | `Float` | Required | Sum of all monthly credit transactions without transfers for the account |
| `six_month_credit_total` | `Float` | Required | Sum of six month credit transactions |
| `six_month_credit_total_less_transfers` | `Float` | Required | Sum of six month credit transactions without transfers |
| `two_month_credit_total` | `Float` | Required | Sum of two month credit transactions |
| `two_month_credit_total_less_transfers` | `Float` | Required | Sum of two month credit transactions without transfers |

## Example (as JSON)

```json
{
  "monthlyCashFlowCredits": {
    "month": 1512111600,
    "numberOfCredits": "3",
    "totalCreditsAmount": 5000,
    "largestCredit": 2000,
    "numberOfCreditsLessTransfers": "2",
    "totalCreditsAmountLessTransfers": 4000,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

