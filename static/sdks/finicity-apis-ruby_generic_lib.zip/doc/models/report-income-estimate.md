
# Report Income Estimate

## Structure

`ReportIncomeEstimate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `net_annual` | `Float` | Required | - |
| `projected_net_annual` | `Float` | Required | - |
| `estimated_gross_annual` | `Float` | Required | - |
| `projected_gross_annual` | `Float` | Required | - |

## Example (as JSON)

```json
{
  "netAnnual": 1000.12,
  "projectedNetAnnual": 1500.23,
  "estimatedGrossAnnual": 2000.12,
  "projectedGrossAnnual": 2500.23
}
```

