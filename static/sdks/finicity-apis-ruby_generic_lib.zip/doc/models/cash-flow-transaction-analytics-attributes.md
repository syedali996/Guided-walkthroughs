
# Cash Flow Transaction Analytics Attributes

## Structure

`CashFlowTransactionAnalyticsAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `activity_deposits_credits_for_the_report_time_period` | [`Array<CashFlowActivityDepositsCredits>`](../../doc/models/cash-flow-activity-deposits-credits.md) | Required | List of all deposit transactions posted to the account during the report period |
| `activity_withdrawals_debits_for_the_report_time_period` | [`Array<CashFlowActivityWithdrawalsDebits>`](../../doc/models/cash-flow-activity-withdrawals-debits.md) | Required | List of all withdrawal transactions posted to the account during the report period |
| `average_transaction_value_by_month_for_the_report_time_period` | [`Array<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Average value of transactions during periods in the report. Values may be positive or negative |
| `historic_weeks_with_zero_transactions` | [`CashFlowNumWeeksZeros`](../../doc/models/cash-flow-num-weeks-zeros.md) | Optional | Details of weeks with zero transactions during the known history of the account |
| `last_transaction_date` | [`Array<LastTransactionDate>`](../../doc/models/last-transaction-date.md) | Optional | Latest posted transaction(s) to the account. May be more than one if they share the same timestamp |
| `net_cash_flow_by_month_for_the_report_time_period` | [`Array<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Net cash flow for each month during the report period |
| `net_cash_flow_for_the_report_time_period` | `Float` | Optional | Net cash flow during the report period (may be positive or negative) |

## Example (as JSON)

```json
{
  "activityDepositsCreditsForTheReportTimePeriod": {
    "date": "2020-03-25",
    "depositsCredits": 500
  },
  "activityWithdrawalsDebitsForTheReportTimePeriod": {
    "date": "2020-03-25",
    "withdrawalsDebits": 15.69
  },
  "averageTransactionValueByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

