
# Customer Account Position

Details for investment account holdings

## Structure

`CustomerAccountPosition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The id of the investment position |
| `description` | `String` | Optional | The description of the holding |
| `symbol` | `String` | Optional | The investment position's market ticker symbol |
| `units` | `Float` | Optional | The number of units of the holding |
| `current_price` | `Float` | Optional | The current price of the investment holding |
| `security_name` | `String` | Optional | The security name for the investment holding |
| `transaction_type` | `String` | Optional | The transaction type of the holding, such as cash, margin, and more |
| `market_value` | `Float` | Optional | Market value of an investment position at the time of retrieval |
| `cost_basis` | `Float` | Optional | The total cost of acquiring the security |
| `status` | `String` | Optional | The status of the holding |
| `current_price_date` | `Integer` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `security_type` | `String` | Optional | Type of security for the investment position |
| `mf_type` | `String` | Optional | Type of mutual fund, such as open ended |
| `pos_type` | `String` | Optional | Fund type assigned by the FI (long or short) |
| `total_gl_dollar` | `Float` | Optional | Total gain and loss of the position at the time of aggregation in dollars |
| `total_gl_percent` | `Float` | Optional | Total gain and loss of the position at the time of aggregation in percentage |
| `option_strike_price` | `Float` | Optional | The strike price of the option contract |
| `option_type` | `String` | Optional | The type of option contract (PUT or CALL) |
| `option_shares_per_contract` | `Float` | Optional | The number of shares per option contract |
| `option_expire_date` | `Date` | Optional | Expiration date of option |
| `fi_asset_class` | `String` | Optional | Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS) |
| `asset_class` | `String` | Optional | An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER) |
| `currency_rate` | `Float` | Optional | Currency rate, ratio of currency to original currency |
| `security_id` | `String` | Optional | The security ID of the transaction |
| `security_id_type` | `String` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" |
| `cost_basis_per_share` | `Float` | Optional | The per share cost of acquiring the security |
| `sub_account_type` | `String` | Optional | The subaccount's type, such as cash |
| `security_currency` | `String` | Optional | Symbol for the currency that the account is being converted into |
| `today_gl_dollar` | `Float` | Optional | The current day's gain and loss of the position at the time of aggregation in dollars |
| `today_gl_percent` | `Float` | Optional | The current day's gain and loss of the position at the time of aggregation in percentage |

## Example (as JSON)

```json
{
  "id": null,
  "description": null,
  "symbol": null,
  "units": null,
  "currentPrice": null,
  "securityName": null,
  "transactionType": null,
  "marketValue": null,
  "costBasis": null,
  "status": null,
  "currentPriceDate": null,
  "securityType": null,
  "mfType": null,
  "posType": null,
  "totalGLDollar": null,
  "totalGLPercent": null,
  "optionStrikePrice": null,
  "optionType": null,
  "optionSharesPerContract": null,
  "optionExpireDate": null,
  "fiAssetClass": null,
  "assetClass": null,
  "currencyRate": null,
  "securityId": null,
  "securityIdType": null,
  "costBasisPerShare": null,
  "subAccountType": null,
  "securityCurrency": null,
  "todayGLDollar": null,
  "todayGLPercent": null
}
```

