
# Deduction

## Structure

`Deduction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | The normalized category of the deductions in the format [type][number]. The number is the will be the iterating number of the type's occurrence starting at one. |
| `description` | `String` | Optional | The deduction line's deduction type description |
| `amount_current` | `Float` | Optional | The amount for the deduction line deducted from employee's pay for the specified pay period |
| `amount_ytd` | `Float` | Optional | The amount for the deduction line being deducted from the employee's pay for the current pay year |
| `type` | `String` | Optional | Categorization based on the deduction line's description |

## Example (as JSON)

```json
{
  "name": null,
  "description": null,
  "amountCurrent": null,
  "amountYTD": null,
  "type": null
}
```

