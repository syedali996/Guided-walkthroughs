
# Report Income Stream Summary

## Structure

`ReportIncomeStreamSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `confidence_type` | `String` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" |
| `net_monthly` | [`Array<NetMonthly>`](../../doc/models/net-monthly.md) | Required | - |
| `income_estimate` | [`ReportIncomeEstimate`](../../doc/models/report-income-estimate.md) | Required | - |

## Example (as JSON)

```json
{
  "confidenceType": null,
  "netMonthly": {
    "month": 1522562400,
    "net": 2004.77
  },
  "incomeEstimate": {
    "netAnnual": 1000.12,
    "projectedNetAnnual": 1500.23,
    "estimatedGrossAnnual": 2000.12,
    "projectedGrossAnnual": 2500.23
  }
}
```

