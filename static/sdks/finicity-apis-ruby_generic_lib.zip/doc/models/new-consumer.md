
# New Consumer

A new consumer to be created

## Structure

`NewConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `String` | Required | First name(s) / given name(s) |
| `last_name` | `String` | Required | Last name(s) / surname(s) |
| `address` | `String` | Required | A street address |
| `city` | `String` | Required | A city |
| `state` | `String` | Required | A state |
| `zip` | `String` | Required | A ZIP code |
| `phone` | `String` | Required | A phone number |
| `ssn` | `String` | Required | A full SSN with or without hyphens |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `email` | `String` | Optional | An email address |
| `suffix` | `String` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "firstName": "John",
  "lastName": "Smith",
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "999-99-9999",
  "birthday": null
}
```

