
# Portfolio Consumer

## Structure

`PortfolioConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `first_name` | `String` | Required | First name(s) / given name(s) |
| `last_name` | `String` | Required | Last name(s) / surname(s) |
| `customer_id` | `Integer` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `ssn` | `String` | Required | A full SSN with or without hyphens |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `suffix` | `String` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "ssn": "999-99-9999",
  "birthday": null
}
```

