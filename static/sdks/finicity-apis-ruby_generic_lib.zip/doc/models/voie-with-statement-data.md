
# VOIE With Statement Data

## Structure

`VOIEWithStatementData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_ids` | `Array<String>` | Required | A list of pay statement asset IDs |
| `extract_earnings` | `TrueClass\|FalseClass` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `true` |
| `extract_deductions` | `TrueClass\|FalseClass` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `false` |
| `extract_direct_deposit` | `TrueClass\|FalseClass` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `true` |

## Example (as JSON)

```json
{
  "assetIds": [
    "assetIds3"
  ],
  "extractEarnings": null,
  "extractDeductions": null,
  "extractDirectDeposit": null
}
```

