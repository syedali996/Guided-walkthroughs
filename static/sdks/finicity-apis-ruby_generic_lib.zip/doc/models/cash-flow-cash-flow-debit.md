
# Cash Flow Cash Flow Debit

## Structure

`CashFlowCashFlowDebit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthly_cash_flow_debits` | [`Array<CashFlowMonthlycashflowDebits>`](../../doc/models/cash-flow-monthlycashflow-debits.md) | Required | List of attributes for each month |
| `twelve_month_debit_total` | `Float` | Required | Sum of all monthly debit transactions for each month by account |
| `twelve_month_debit_total_less_transfers` | `Float` | Required | Sum of all monthly debit transactions without transfers for the account |
| `six_month_debit_total` | `Float` | Required | Six month sum of all debit transactions |
| `six_month_debit_total_less_transfers` | `Float` | Required | Six month sum of all debit transactions without transfers for the account |
| `two_month_debit_total` | `Float` | Required | Two month sum of all debit transactions |
| `two_month_debit_total_less_transfers` | `Float` | Required | Two month sum of all debit transactions without transfers for the account |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebits": {
    "month": 1512111600,
    "numberOfDebits": "5",
    "totalDebitsAmount": -12345,
    "largestDebit": -2000,
    "numberOfDebitsLessTransfers": "3",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": 1200,
  "twelveMonthDebitTotalLessTransfers": 1000,
  "sixMonthDebitTotal": 750,
  "sixMonthDebitTotalLessTransfers": 500,
  "twoMonthDebitTotal": 150,
  "twoMonthDebitTotalLessTransfers": 100
}
```

