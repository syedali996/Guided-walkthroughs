
# Obb Average Weekly Balance

## Structure

`ObbAverageWeeklyBalance`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `Float` | Required | Average daily ending balance during the week |
| `from_date` | `String` | Required | Begin date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `to_date` | `String` | Required | End date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `week` | `Integer` | Required | Week number, where the first week of each year begins on January 1st and ends on January 7th. May be in the range [1, 53] |

## Example (as JSON)

```json
{
  "amount": 679.07,
  "fromDate": "2020-01-01",
  "toDate": "2020-01-07",
  "week": 1
}
```

