
# VOIE Paystub With Statement Pay Statement

## Structure

`VOIEPaystubWithStatementPayStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pay_period` | `String` | Required | The pay period of the pay statement |
| `billable` | `TrueClass\|FalseClass` | Required | This will display true if the pay statement is billable. If a pay statement has been digitized previously, this will display as false as it will not be billable. |
| `asset_id` | `String` | Required | The asset ID of the stored pay statement |
| `pay_date` | `Integer` | Required | The listed pay date for the pay statement |
| `start_date` | `Integer` | Required | The beginning of the pay period |
| `end_date` | `Integer` | Required | The end of the pay period |
| `net_pay_current` | `Float` | Required | The total pay after deductions for the employee for the current pay period |
| `net_pay_ytd` | `Float` | Required | The total accumulation of pay after deductions for the employee for the current pay year |
| `gross_pay_current` | `Float` | Required | The total pay before deductions for the employee for the current pay period |
| `gross_pay_ytd` | `Float` | Required | The total accumulation of pay before deductions for the employee for the current pay year |
| `payroll_provider` | `String` | Optional | The payroll provider extracted from the pay statement |
| `employer` | [`Employer`](../../doc/models/employer.md) | Required | - |
| `employee` | [`Employee`](../../doc/models/employee.md) | Required | - |
| `pay_stat` | [`Array<PayStat>`](../../doc/models/pay-stat.md) | Required | Information pertaining to the earnings on the pay statement |
| `direct_deposits` | [`Array<DirectDeposit>`](../../doc/models/direct-deposit.md) | Required | Information pertaining to the direct deposits on the pay statement |
| `monthly_income` | [`PaystubMonthlyIncomeRecord`](../../doc/models/paystub-monthly-income-record.md) | Required | - |
| `institutions` | `Array<String>` | Required | Not populated for the voieWithStatement style of paystub report. For the VOIE - Paystub (with TXVerify) reports this would include details of the financial institution accounts and income streams with matching transactions to the pay statement. |
| `error_code` | `Integer` | Optional | Error code for the asset |
| `error_message` | `String` | Optional | Error message for the asset |

## Example (as JSON)

```json
{
  "payPeriod": "LastPayPeriod",
  "billable": true,
  "assetId": "6f8fb0a0-e882-4f57-b672-cf53f1397581",
  "payDate": 1559241000,
  "startDate": 1557513000,
  "endDate": 1558722600,
  "netPayCurrent": 1802.22,
  "netPayYTD": 36000,
  "grossPayCurrent": 24200,
  "grossPayYTD": 72600,
  "employer": null,
  "employee": null,
  "payStat": null,
  "directDeposits": null,
  "monthlyIncome": null,
  "institutions": []
}
```

