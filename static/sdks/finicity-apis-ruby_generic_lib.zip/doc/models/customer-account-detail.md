
# Customer Account Detail

Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution.

## Structure

`CustomerAccountDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date_as_of` | `Integer` | Optional | (All Account Types) Most recent date of the following information. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `available_balance_amount` | `Float` | Required | (Checking/Savings/CD/MoneyMarket) and (Mortgage/Loan) The available balance (typically the current balance with adjustments for any pending transactions) |
| `open_date` | `Integer` | Optional | (Checking/Savings/CD/MoneyMarket) Date when account was opened. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `period_start_date` | `Integer` | Optional | (Checking/Savings/CD/MoneyMarket) Start date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `period_end_date` | `Integer` | Optional | End date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `period_interest_rate` | `Float` | Optional | (Checking/Savings/CD/MoneyMarket) The APY for the current period interest rate |
| `period_deposit_amount` | `Float` | Optional | (Checking/Savings/CD/MoneyMarket) Amount deposited in period |
| `period_interest_amount` | `Float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued during the current period |
| `interest_ytd_amount` | `Float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued year-to-date |
| `interest_prior_ytd_amount` | `Float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest earned in prior year |
| `maturity_date` | `Integer` | Optional | (Checking/Savings/CD/MoneyMarket) Maturity date of account type. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `interest_rate` | `String` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The account's current interest rate |
| `credit_available_amount` | `Float` | Optional | (Credit Card/Line Of Credit) The available credit (typically the credit limit minus the current balance) |
| `credit_max_amount` | `Float` | Optional | (Credit Card/Line Of Credit) The account's credit limit |
| `cash_advance_available_amount` | `Float` | Optional | (Credit Card/Line Of Credit) Currently available cash advance |
| `cash_advance_max_amount` | `Float` | Optional | (Credit Card/Line Of Credit) Maximum cash advance amount |
| `cash_advance_balance` | `Float` | Optional | (Credit Card/Line Of Credit) Balance of current cash advance |
| `cash_advance_interest_rate` | `Float` | Optional | (Credit Card/Line Of Credit) Interest rate for cash advances |
| `current_balance` | `Float` | Optional | (Credit Card/Line Of Credit) and (Investment) Current balance |
| `payment_min_amount` | `Float` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) Minimum payment due |
| `payment_due_date` | `Integer` | Optional | (Credit Card/Line Of Credit) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `previous_balance` | `Float` | Optional | (Credit Card/Line Of Credit) Prior balance in last statement |
| `statement_start_date` | `Integer` | Optional | (Credit Card/Line Of Credit) Start date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `statement_end_date` | `Integer` | Optional | (Credit Card/Line Of Credit) End date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `statement_purchase_amount` | `Float` | Optional | (Credit Card/Line Of Credit) Purchase amount of statement period |
| `statement_finance_amount` | `Float` | Optional | (Credit Card/Line Of Credit) Finance amount of statement period |
| `statement_credit_amount` | `Float` | Optional | (Credit Card/Line Of Credit) Credit amount applied in statement period |
| `reward_earned_balance` | `Integer` | Optional | (Credit Card/Line Of Credit) Earned reward balance |
| `past_due_amount` | `Float` | Optional | (Credit Card/Line Of Credit) Balance past due |
| `last_payment_amount` | `Float` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The amount received in the last payment |
| `last_payment_date` | `Integer` | Optional | (Credit Card/Line Of Credit) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `statement_close_balance` | `Float` | Optional | (Credit Card/Line Of Credit) Balance of statement at close |
| `term_of_ml` | `String` | Optional | (Mortgage/Loan) Length of loan in months |
| `ml_holder_name` | `String` | Optional | (Mortgage/Loan) Holder of the mortgage or loan |
| `description` | `String` | Optional | (Mortgage/Loan) Description of loan |
| `late_fee_amount` | `Float` | Optional | (Mortgage/Loan) Late fee charged |
| `payoff_amount` | `Float` | Optional | (Mortgage/Loan) The amount required to payoff the loan |
| `payoff_amount_date` | `Integer` | Optional | (Mortgage/Loan) Date of final payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `original_maturity_date` | `Integer` | Optional | (Mortgage/Loan) Original date of loan maturity. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `principal_balance` | `Float` | Optional | (Mortgage/Loan) The principal balance |
| `escrow_balance` | `Float` | Optional | (Mortgage/Loan) The escrow balance |
| `interest_period` | `String` | Optional | (Mortgage/Loan) Period of interest |
| `initial_ml_amount` | `Float` | Optional | (Mortgage/Loan) Original loan amount |
| `initial_ml_date` | `Integer` | Optional | (Mortgage/Loan) Original date of loan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `next_payment_principal_amount` | `Float` | Optional | (Mortgage/Loan) Amount towards principal in next payment |
| `next_payment_interest_amount` | `Float` | Optional | (Mortgage/Loan) Amount of interest in next payment |
| `next_payment` | `Float` | Optional | (Mortgage/Loan) Minimum payment due |
| `next_payment_date` | `Integer` | Optional | (Mortgage/Loan) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_payment_due_date` | `Integer` | Optional | (Mortgage/Loan) Due date of last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_payment_receive_date` | `Integer` | Optional | (Mortgage/Loan) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `last_payment_principal_amount` | `Float` | Optional | (Mortgage/Loan) Amount towards principal in last payment |
| `last_payment_interest_amount` | `Float` | Optional | (Mortgage/Loan) Amount of interest in last payment |
| `last_payment_escrow_amount` | `Float` | Optional | (Mortgage/Loan) Amount towards escrow in last payment |
| `last_payment_last_fee_amount` | `Float` | Optional | (Mortgage/Loan) Amount of last fee in last payment |
| `last_payment_late_charge` | `Float` | Optional | (Mortgage/Loan) Amount of late charge in last payment |
| `ytd_principal_paid` | `Float` | Optional | (Mortgage/Loan) Principal paid year-to-date |
| `ytd_interest_paid` | `Float` | Optional | (Mortgage/Loan) Interest paid year-to-date |
| `ytd_insurance_paid` | `Float` | Optional | (Mortgage/Loan) Insurance paid year-to-date |
| `ytd_tax_paid` | `Float` | Optional | (Mortgage/Loan) Tax paid year-to-date |
| `auto_pay_enrolled` | `TrueClass\|FalseClass` | Optional | (Mortgage/Loan) Enrolled in autopay (F/Y) |
| `collateral` | `String` | Optional | (Mortgage/Loan) Collateral on loan |
| `current_school` | `String` | Optional | (Mortgage/Loan) Current school |
| `first_payment_date` | `Integer` | Optional | (Mortgage/Loan) First payment due date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `first_mortgage` | `TrueClass\|FalseClass` | Optional | (Mortgage/Loan) First mortgage (F/Y) |
| `loan_payment_freq` | `String` | Optional | (Mortgage/Loan) Frequency of payments (monthly, etc.) |
| `original_school` | `String` | Optional | (Mortgage/Loan) Original school |
| `recurring_payment_amount` | `Float` | Optional | (Mortgage/Loan) Recurring payment amount |
| `lender` | `String` | Optional | (Mortgage/Loan) Owner of loan |
| `ending_balance_amount` | `Float` | Optional | (Mortgage/Loan) Ending balance |
| `loan_term_type` | `String` | Optional | (Mortgage/Loan) Type of loan term |
| `payments_made` | `Integer` | Optional | (Mortgage/Loan) Number of payments made |
| `balloon_amount` | `Float` | Optional | (Mortgage/Loan) Balloon payment amount |
| `projected_interest` | `Float` | Optional | (Mortgage/Loan) Projected interest on the loan |
| `interest_paid_ltd` | `Float` | Optional | (Mortgage/Loan) Interest paid since inception of loan (life to date) |
| `interest_rate_type` | `String` | Optional | (Mortgage/Loan) Type of interest rate |
| `loan_payment_type` | `String` | Optional | (Mortgage/Loan) Type of loan payment |
| `repayment_plan` | `String` | Optional | (Mortgage/Loan) Type of repayment plan for the student loan |
| `payments_remaining` | `Integer` | Optional | (Mortgage/Loan) Number of payments remaining before loan is paid off |
| `margin_balance` | `Float` | Optional | (Investment) Net interest earned after deducting interest paid out |
| `short_balance` | `Float` | Optional | (Investment) Sum of short balance |
| `available_cash_balance` | `Float` | Optional | (Investment) Amount available for cash withdrawal |
| `maturity_value_amount` | `Float` | Optional | (Investment) amount payable to an investor at maturity |
| `vested_balance` | `Float` | Optional | (Investment) Vested amount in account |
| `emp_match_amount` | `Float` | Optional | (Investment) Employer matched contributions |
| `emp_pretax_contrib_amount` | `Float` | Optional | (Investment) Employer pretax contribution amount |
| `emp_pretax_contrib_amount_ytd` | `Float` | Optional | (Investment) Employer pretax contribution amount year to date |
| `contrib_total_ytd` | `Float` | Optional | (Investment) Total year to date contributions |
| `cash_balance_amount` | `Float` | Optional | (Investment) Cash balance of account |
| `pre_tax_amount` | `Float` | Optional | (Investment) Pre tax amount of total balance |
| `after_tax_amount` | `Float` | Optional | (Investment) Post tax amount of total balance |
| `match_amount` | `Float` | Optional | (Investment) Amount matched |
| `profit_sharing_amount` | `Float` | Optional | (Investment) Amount of balance for profit sharing |
| `rollover_amount` | `Float` | Optional | (Investment) Amount of balance rolled over from original account (401k, etc.) |
| `other_vest_amount` | `Float` | Optional | (Investment) Other vested amount |
| `other_nonvest_amount` | `Float` | Optional | (Investment) Other nonvested amount |
| `current_loan_balance` | `Float` | Optional | (Investment) Current loan balance |
| `loan_rate` | `Float` | Optional | (Investment) Interest rate of loan |
| `buy_power` | `Float` | Optional | (Investment) Money available to buy securities |
| `rollover_ltd` | `Float` | Optional | (Investment) Life to date of money rolled over |
| `loan_award_id` | `String` | Optional | (Student Loan) The federal unique loan identifying number |
| `original_interest_rate` | `Float` | Optional | (Student Loan) The original interest rate to which the loan was disbursed, in APY |
| `guarantor` | `String` | Optional | (Student Loan) The financial institution guarantor of the loan (who will pay the loan amount to the owner if the borrower defaults) |
| `owner` | `String` | Optional | (Student Loan) Owner of the loan |
| `interest_subsidy_type` | `String` | Optional | (Student Loan) The indication of the presence of an interest subsidy (i.e. subsidized) |
| `interest_balance` | `Float` | Optional | (Student Loan) The total outstanding interest balance |
| `remaining_term_of_ml` | `Float` | Optional | (Student Loan) The number of months still outstanding on a loan |
| `initial_interest_rate` | `Float` | Optional | (Student Loan) Initial interest rate of loan |
| `fees_balance` | `Float` | Optional | (Student Loan) The total outstanding fees balance |
| `loan_ytd_interest_paid` | `Float` | Optional | (Student Loan) Loan interest paid year-to-date |
| `loan_ytd_fees_paid` | `Float` | Optional | (Student Loan) Loan fees paid year-to-date |
| `loan_ytd_principal_paid` | `Float` | Optional | (Student Loan) Loan principal paid year-to-date |
| `loan_status` | `String` | Optional | (Student Loan) The repayment status phase (i.e. In School, Grace, Repayment, Deferment, Forbearance) |
| `loan_status_start_date` | `Integer` | Optional | (Student Loan) The start date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `loan_status_end_date` | `Integer` | Optional | (Student Loan) The end date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `weighted_interest_rate` | `Float` | Optional | (Student Loan) The interest rate of multiple interest rates and balances at the group level, in APY |
| `repayment_plan_start_date` | `Integer` | Optional | (Student Loan) The start date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `repayment_plan_end_date` | `Integer` | Optional | (Student Loan) The end date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `expected_payoff_date` | `Integer` | Optional | (Student Loan) The expected date of the payoff date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `out_of_school_date` | `Integer` | Optional | (Student Loan) The date the borrower graduated or dropped below half-time enrollment in school. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `convert_to_repayment` | `Integer` | Optional | (Student Loan) The date the loan enters into repayment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `days_delinquent` | `Integer` | Optional | (Student Loan) The number of days past a due date that a payment should have been made |
| `total_principal_paid` | `Float` | Optional | (Student Loan) The total amount paid towards the principal balance |
| `total_interest_paid` | `Float` | Optional | (Student Loan) The total amount paid towards interest |
| `total_amount_paid` | `Float` | Optional | (Student Loan) The total amount paid |

## Example (as JSON)

```json
{
  "availableBalanceAmount": 5678.78
}
```

