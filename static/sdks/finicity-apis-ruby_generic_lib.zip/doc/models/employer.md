
# Employer

## Structure

`Employer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | The name of the employer |

## Example (as JSON)

```json
{
  "name": null
}
```

