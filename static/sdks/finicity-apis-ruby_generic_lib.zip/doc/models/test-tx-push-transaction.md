
# Test Tx Push Transaction

A fake transaction for TxPush testing

## Structure

`TestTxPushTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `Float` | Required | The amount of the transaction |
| `description` | `String` | Required | The description of the transaction |
| `status` | `String` | Optional | "active" or "pending" (optional)<br>**Default**: `'active'` |
| `posted_date` | `Integer` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `transaction_date` | `Integer` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |

## Example (as JSON)

```json
{
  "amount": -4.25,
  "description": "a testing transaction description",
  "transactionDate": 1607450357
}
```

