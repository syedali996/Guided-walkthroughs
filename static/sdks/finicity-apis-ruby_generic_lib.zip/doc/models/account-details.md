
# Account Details

## Structure

`AccountDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `interest_margin_balance` | `Float` | Optional | Only available for investment accounts. Net interest earned after deducting interest paid out. |
| `available_cash_balance` | `Float` | Optional | Only available for investment accounts. Amount available for cash withdrawal. |
| `vested_balance` | `Float` | Optional | Only available for investment accounts. Vested amount in account. |
| `current_loan_balance` | `Float` | Optional | Only available for investment accounts. Current loan balance. |
| `available_balance_amount` | `Float` | Optional | The available balance for the account |

## Example (as JSON)

```json
{
  "interestMarginBalance": null,
  "availableCashBalance": null,
  "vestedBalance": null,
  "currentLoanBalance": null,
  "availableBalanceAmount": null
}
```

