
# Loan Payment Details Account

## Structure

`LoanPaymentDetailsAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_id` | `String` | Required | An account ID |
| `account_number` | `String` | Required | Institution's ID of the Student Loan Account |
| `account_payment_number` | `String` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. |
| `account_payment_address` | `String` | Required | The payment address to which send manual payments should be sent |
| `account_future_payoff_amount` | `Float` | Optional | The payoff amount for the account |
| `account_future_payoff_date` | `DateTime` | Optional | The date to which the "Future Payoff Amount" applies |
| `group_detail` | [`Array<LoanPaymentDetailsGroup>`](../../doc/models/loan-payment-details-group.md) | Optional | Group details |
| `loan_detail` | [`Array<LoanPaymentDetailsLoan>`](../../doc/models/loan-payment-details-loan.md) | Optional | Loan details |

## Example (as JSON)

```json
{
  "accountId": "5011648377",
  "accountNumber": "9876543210",
  "accountPaymentNumber": "00001234895413",
  "accountPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054"
}
```

