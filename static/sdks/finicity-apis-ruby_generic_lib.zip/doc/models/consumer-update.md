
# Consumer Update

## Structure

`ConsumerUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `String` | Optional | First name(s) / given name(s) |
| `last_name` | `String` | Optional | Last name(s) / surname(s) |
| `address` | `String` | Optional | A street address |
| `city` | `String` | Optional | A city |
| `state` | `String` | Optional | A state |
| `zip` | `String` | Optional | A ZIP code |
| `phone` | `String` | Optional | A phone number |
| `ssn` | `String` | Optional | A full SSN with or without hyphens |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Optional | A birth date |
| `email` | `String` | Optional | An email address |
| `suffix` | `String` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "address": null,
  "city": null,
  "state": null,
  "zip": null,
  "phone": null,
  "ssn": null,
  "birthday": null,
  "email": null,
  "suffix": null
}
```

