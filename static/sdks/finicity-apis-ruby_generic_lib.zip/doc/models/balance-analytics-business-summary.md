
# Balance Analytics Business Summary

## Structure

`BalanceAnalyticsBusinessSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `balance_analytics_metrics` | [`BalanceAnalyticsMetrics`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations across all accounts in the report |
| `current_report_request` | [`ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Optional | Describes the requested attributes of the report |
| `historic_data_availability` | [`ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Optional | Describes the availability of historical data for all accounts owned by the business |

## Example (as JSON)

```json
{
  "balanceAnalyticsMetrics": null,
  "currentReportRequest": null,
  "historicDataAvailability": null
}
```

