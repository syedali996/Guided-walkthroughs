
# Balance Analytics Account Result 1

## Structure

`BalanceAnalyticsAccountResult1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_details` | [`AccountDetails1`](../../doc/models/account-details-1.md) | Required | - |
| `account_id` | `Integer` | Required | An account ID represented as a number |
| `balance_analytics_metrics` | [`BalanceAnalyticsMetrics`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations |
| `current_report_request` | [`ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Required | - |
| `historic_data_availability` | [`ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Required | - |
| `cashflow_analytics_metrics` | [`CashFlowAnalyticsMetrics`](../../doc/models/cash-flow-analytics-metrics.md) | Optional | Generated cashflow calculations/metrics |

## Example (as JSON)

```json
{
  "accountDetails": {
    "accountOwner": {
      "address": "123 Main St, Portland, OR 12345",
      "name": "Johnny Appleseed"
    },
    "id": 5011648377,
    "institution": {
      "institutionId": 12345
    }
  },
  "accountId": 5011648377,
  "currentReportRequest": {
    "reportBeginDate": "2022-03-01",
    "reportEndDate": "2022-03-30",
    "reportRequestDate": "03/30/2022 21:47:19",
    "requestedDaysForReport": 90,
    "requestedReportBeginDate": "2022-01-01"
  },
  "historicDataAvailability": {
    "historicAvailabilityBeginDate": "2022-03-01",
    "historicAvailabilityEndDate": "2022-03-30",
    "historicAvailableDays": 30,
    "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
  }
}
```

