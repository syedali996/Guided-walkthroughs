
# Institution Address

The address of a financial institution

## Structure

`InstitutionAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `city` | `String` | Optional | A city |
| `state` | `String` | Optional | A state |
| `country` | `String` | Optional | A country code |
| `postal_code` | `String` | Optional | A ZIP code |
| `address_line_1` | `String` | Optional | An address line 1 |
| `address_line_2` | `String` | Optional | An address line 2 |

## Example (as JSON)

```json
{
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "addressLine1": null,
  "addressLine2": null
}
```

