# Analyticsand Attributes

```ruby
analyticsand_attributes_controller = client.analyticsand_attributes
```

## Class Name

`AnalyticsandAttributesController`

## Methods

* [Generate Consumer Attributes](../../doc/controllers/analyticsand-attributes.md#generate-consumer-attributes)
* [List Consumer Attributes](../../doc/controllers/analyticsand-attributes.md#list-consumer-attributes)
* [Generate FCRA Consumer Attributes](../../doc/controllers/analyticsand-attributes.md#generate-fcra-consumer-attributes)
* [Get Consumer Attributes by ID](../../doc/controllers/analyticsand-attributes.md#get-consumer-attributes-by-id)
* [Get FCRA Consumer Attributes by ID](../../doc/controllers/analyticsand-attributes.md#get-fcra-consumer-attributes-by-id)


# Generate Consumer Attributes

Generate a Consumer Attributes report for the given customer. The "to" and "from" date range is the last 12 months of consumer data, based on the date at which the report was generated.

An analytic ID is created and associated with the customer's ID. If you generate multiple Consumer Attributes reports for the same customer, then each report will have its own analytic ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def generate_consumer_attributes(customer_id,
                                 body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |
| `body` | [`ConsumerAttributeAccountIDs`](../../doc/models/consumer-attribute-account-i-ds.md) | Body, Optional | - |

## Response Type

[`ConsumerAttributesAnalyticId`](../../doc/models/consumer-attributes-analytic-id.md)

## Example Usage

```ruby
customer_id = '1005061234'

result = analytics_and_attributes_controller.generate_consumer_attributes(customer_id, )
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# List Consumer Attributes

Retrieve a list of all analytic IDs previously created for a customer using the Generate Consumer Attributes APIs.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def list_consumer_attributes(customer_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |

## Response Type

[`ConsumerAttributeList`](../../doc/models/consumer-attribute-list.md)

## Example Usage

```ruby
customer_id = '1005061234'

result = analytics_and_attributes_controller.list_consumer_attributes(customer_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate FCRA Consumer Attributes

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def generate_fcra_consumer_attributes(customer_id,
                                      body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |
| `body` | [`ConsumerAttributeAccountIDs`](../../doc/models/consumer-attribute-account-i-ds.md) | Body, Optional | - |

## Response Type

[`ConsumerAttributesAnalyticId`](../../doc/models/consumer-attributes-analytic-id.md)

## Example Usage

```ruby
customer_id = '1005061234'

result = analytics_and_attributes_controller.generate_fcra_consumer_attributes(customer_id, )
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer Attributes by ID

Retrieve a Consumer Attributes report for a customer.

Use the analytic and customer IDs to retrieve 12 months of data attributes according to the "to" and "from" date range of the report at the time it was created.

If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def get_consumer_attributes_by_id(analytics_id,
                                  customer_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `analytics_id` | `String` | Template, Required | The analytic ID |
| `customer_id` | `String` | Template, Required | A customer ID |

## Response Type

[`ConsumerAttributes`](../../doc/models/consumer-attributes.md)

## Example Usage

```ruby
analytics_id = 'CA-5dfbaa3ac-5321'
customer_id = '1005061234'

result = analytics_and_attributes_controller.get_consumer_attributes_by_id(analytics_id, customer_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get FCRA Consumer Attributes by ID

Retrieve a FCRA Consumer Attributes report for a customer.

Use the analytic and customer IDs to retrieve 12 months of FCRA data attributes according to the `To` and `From` date range of the report at the time it was created.

If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def get_fcra_consumer_attributes_by_id(analytics_id,
                                       customer_id,
                                       purpose: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `analytics_id` | `String` | Template, Required | The analytic ID |
| `customer_id` | `String` | Template, Required | A customer ID |
| `purpose` | `String` | Query, Optional | 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports. |

## Response Type

[`ConsumerAttributes`](../../doc/models/consumer-attributes.md)

## Example Usage

```ruby
analytics_id = 'CA-5dfbaa3ac-5321'
customer_id = '1005061234'
purpose = '99'

result = analytics_and_attributes_controller.get_fcra_consumer_attributes_by_id(analytics_id, customer_id, purpose: purpose)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

