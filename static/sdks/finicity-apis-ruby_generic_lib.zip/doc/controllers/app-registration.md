# App Registration

```ruby
app_registration_controller = client.app_registration
```

## Class Name

`AppRegistrationController`

## Methods

* [Register App](../../doc/controllers/app-registration.md#register-app)
* [Modify App Registration](../../doc/controllers/app-registration.md#modify-app-registration)
* [Get App Registration Status](../../doc/controllers/app-registration.md#get-app-registration-status)
* [Set Customer App ID](../../doc/controllers/app-registration.md#set-customer-app-id)
* [Migrate Institution Login Accounts](../../doc/controllers/app-registration.md#migrate-institution-login-accounts)


# Register App

Register a new application to access financial institutions using OAuth connections.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def register_app(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```ruby
body = Application.new
body.app_description = 'The app that makes your budgeting experience awesome'
body.app_name = 'Awesome Budget App'
body.app_url = 'https://www.finicity.com/'
body.owner_address_line1 = '434 W Ascension Way'
body.owner_address_line2 = 'Suite #200'
body.owner_city = 'Murray'
body.owner_country = 'USA'
body.owner_name = 'Finicity'
body.owner_postal_code = '84123'
body.owner_state = 'UT'
body.image = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K'

result = app_registration_controller.register_app(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify App Registration

Update a registered application.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def modify_app_registration(pre_app_id,
                            body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pre_app_id` | `String` | Template, Required | The application registration tracking ID |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```ruby
pre_app_id = '2581'
body = Application.new
body.app_description = 'The app that makes your budgeting experience awesome'
body.app_name = 'Awesome Budget App'
body.app_url = 'https://www.finicity.com/'
body.owner_address_line1 = '434 W Ascension Way'
body.owner_address_line2 = 'Suite #200'
body.owner_city = 'Murray'
body.owner_country = 'USA'
body.owner_name = 'Finicity'
body.owner_postal_code = '84123'
body.owner_state = 'UT'
body.image = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K'

result = app_registration_controller.modify_app_registration(pre_app_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get App Registration Status

Get the status of your application registration(s).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def get_app_registration_status(pre_app_id: nil,
                                application_id: nil,
                                status: nil,
                                app_name: nil,
                                submitted_date: nil,
                                modified_date: nil,
                                page: 1,
                                page_size: 1)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pre_app_id` | `String` | Query, Optional | The application registration tracking ID |
| `application_id` | `String` | Query, Optional | The application ID |
| `status` | `String` | Query, Optional | Look up app registration requests by status |
| `app_name` | `String` | Query, Optional | Look up app registration requests by app name |
| `submitted_date` | `Integer` | Query, Optional | Look up app registration requests by the date they were submitted |
| `modified_date` | `Integer` | Query, Optional | Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R". |
| `page` | `Integer` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `page_size` | `Integer` | Query, Optional | Maximum number of results per page<br>**Default**: `1` |

## Response Type

[`AppStatuses`](../../doc/models/app-statuses.md)

## Example Usage

```ruby
pre_app_id = '2581'
application_id = '123456789'
status = 'P'
app_name = 'Awesome Budget App'
submitted_date = 1607450357
modified_date = 1607450357
page = 1
page_size = 20

result = app_registration_controller.get_app_registration_status(pre_app_id: pre_app_id, application_id: application_id, status: status, app_name: app_name, submitted_date: submitted_date, modified_date: modified_date, page: page, page_size: page_size)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Set Customer App ID

If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def set_customer_app_id(customer_id,
                        application_id,
                        body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |
| `application_id` | `String` | Template, Required | The application ID |
| `body` | `Object` | Body, Optional | No payload expected |

## Response Type

`void`

## Example Usage

```ruby
customer_id = '1005061234'
application_id = '123456789'

result = app_registration_controller.set_customer_app_id(customer_id, application_id, )
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Migrate Institution Login Accounts

The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.

This API returns a list of accounts for the given institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def migrate_institution_login_accounts(customer_id,
                                       institution_login_id,
                                       body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |
| `institution_login_id` | `String` | Template, Required | The institution login ID |
| `body` | `Object` | Body, Required | No payload expected |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```ruby
customer_id = '1005061234'
institution_login_id = '1007302745'
body = JSON.parse('{"key1":"val1","key2":"val2"}')

result = app_registration_controller.migrate_institution_login_accounts(customer_id, institution_login_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

