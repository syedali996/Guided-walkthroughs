# Connect

```ruby
connect_controller = client.connect
```

## Class Name

`ConnectController`

## Methods

* [Generate Connect Url](../../doc/controllers/connect.md#generate-connect-url)
* [Generate Lite Connect Url](../../doc/controllers/connect.md#generate-lite-connect-url)
* [Generate Fix Connect Url](../../doc/controllers/connect.md#generate-fix-connect-url)
* [Send Connect Email](../../doc/controllers/connect.md#send-connect-email)
* [Generate Joint Borrower Connect Url](../../doc/controllers/connect.md#generate-joint-borrower-connect-url)
* [Send Joint Borrower Connect Email](../../doc/controllers/connect.md#send-joint-borrower-connect-email)


# Generate Connect Url

Generate a Connect 2.0 URL link to add within your own applications.

In option, use the `experience` parameter to call Connect (per session) in the body of the request. Configure the `experience` parameter to change the brand color, logo, icon, which credit decisioning report to generate when the Connect application completes, and more.

Note: contact your Sales Account Team to set up the `experience` parameter.

MVS Developers: You can pre-populate the consumer's SSN on the "Find employment records" page at the beginning of the MVS payroll app. Pass the SSN value for the consumer in the body of the request call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def generate_connect_url(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectParameters`](../../doc/models/connect-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```ruby
body = ConnectParameters.new
body.partner_id = '1234583871234'
body.customer_id = '1005061234'

result = connect_controller.generate_connect_url(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Lite Connect Url

Connect Lite is a variation of Connect Full (`POST /connect/v2/generate`), which has a limited set of features.

* Sign in, user's credentials, and Multi-Factor Authentication (MFA)
* No user account management

The Connect Web SDK isn't a requirement when using Connect lite. However, if you want to use the SDK events, routes, and user events, then you must integrate with the Connect Web SDK.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def generate_lite_connect_url(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`LiteConnectParameters`](../../doc/models/lite-connect-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```ruby
body = LiteConnectParameters.new
body.partner_id = '1234583871234'
body.customer_id = '1005061234'
body.institution_id = 4222

result = connect_controller.generate_lite_connect_url(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Fix Connect Url

Use the Connect Fix API when the following conditions occur:

* The connection to the user's financial institution is lost
* The user's credentials were updated (for any number of reasons)
* The user's MFA challenge has expired

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def generate_fix_connect_url(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FixConnectParameters`](../../doc/models/fix-connect-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```ruby
body = FixConnectParameters.new
body.partner_id = '1234583871234'
body.customer_id = '1005061234'
body.institution_login_id = '1007302745'

result = connect_controller.generate_fix_connect_url(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Send Connect Email

Same as Connect Full (`POST /connect/v2/generate`) but send a Connect email to a consumer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def send_connect_email(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectEmailParameters`](../../doc/models/connect-email-parameters.md) | Body, Required | - |

## Response Type

[`ConnectEmailUrl`](../../doc/models/connect-email-url.md)

## Example Usage

```ruby
body = ConnectEmailParameters.new
body.partner_id = '1234583871234'
body.customer_id = '1005061234'
body.consumer_id = '0bf46322c167b562e6cbed9d40e19a4c'
body.email = EmailOptions.new
body.email.to = 'alex.salido@finicity.com'

result = connect_controller.send_connect_email(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Joint Borrower Connect Url

Same as Connect Full (`POST /connect/v2/generate`) but for joint borrowers.

MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def generate_joint_borrower_connect_url(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectJointBorrowerParameters`](../../doc/models/connect-joint-borrower-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```ruby
body = ConnectJointBorrowerParameters.new
body.partner_id = '1234583871234'
body.borrowers = []


body.borrowers[0] = Borrower.new
body.borrowers[0].customer_id = 'customerId8'
body.borrowers[0].consumer_id = 'consumerId8'
body.borrowers[0].type = 'type4'

body.borrowers[1] = Borrower.new
body.borrowers[1].customer_id = 'customerId9'
body.borrowers[1].consumer_id = 'consumerId9'
body.borrowers[1].type = 'type5'


result = connect_controller.generate_joint_borrower_connect_url(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Send Joint Borrower Connect Email

Same as Connect Joint Borrower (`POST /connect/v2/generate/jointBorrower`) but send a Connect email  to at least one of the joint borrower's email addresses.

When the consumer opens the email, MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def send_joint_borrower_connect_email(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectJointBorrowerEmailParameters`](../../doc/models/connect-joint-borrower-email-parameters.md) | Body, Required | - |

## Response Type

[`ConnectEmailUrl`](../../doc/models/connect-email-url.md)

## Example Usage

```ruby
body = ConnectJointBorrowerEmailParameters.new
body.partner_id = '1234583871234'
body.borrowers = []


body.borrowers[0] = Borrower.new
body.borrowers[0].customer_id = 'customerId8'
body.borrowers[0].consumer_id = 'consumerId8'
body.borrowers[0].type = 'type4'

body.borrowers[1] = Borrower.new
body.borrowers[1].customer_id = 'customerId9'
body.borrowers[1].consumer_id = 'consumerId9'
body.borrowers[1].type = 'type5'

body.email = EmailOptions.new
body.email.to = 'alex.salido@finicity.com'
body.experience = 'default'

result = connect_controller.send_joint_borrower_connect_email(body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

