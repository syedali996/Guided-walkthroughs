# Consumers

Create and manage consumers associated with customers in order to use report services

```ruby
consumers_controller = client.consumers
```

## Class Name

`ConsumersController`

## Methods

* [Create Consumer](../../doc/controllers/consumers.md#create-consumer)
* [Get Consumer for Customer](../../doc/controllers/consumers.md#get-consumer-for-customer)
* [Get Consumer](../../doc/controllers/consumers.md#get-consumer)
* [Modify Consumer](../../doc/controllers/consumers.md#modify-consumer)


# Create Consumer

Create a consumer record associated with the given customer. A consumer persists as the owner of any reports that are generated, even after the original customer is deleted from the system.

A consumer must be created for the given customer before calling any of the Generate Report services.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def create_consumer(customer_id,
                    body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |
| `body` | [`NewConsumer`](../../doc/models/new-consumer.md) | Body, Required | - |

## Response Type

[`CreatedConsumer`](../../doc/models/created-consumer.md)

## Example Usage

```ruby
customer_id = '1005061234'
body = NewConsumer.new
body.first_name = 'John'
body.last_name = 'Smith'
body.address = '434 W Ascension Way'
body.city = 'Murray'
body.state = 'UT'
body.zip = '84123'
body.phone = '1-800-986-3343'
body.ssn = '999-99-9999'
body.birthday = Birthday.new

result = consumers_controller.create_consumer(customer_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 409 | The resource already exists | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer for Customer

Get the details of a consumer record by customer ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def get_consumer_for_customer(customer_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customer_id` | `String` | Template, Required | A customer ID |

## Response Type

[`Consumer`](../../doc/models/consumer.md)

## Example Usage

```ruby
customer_id = '1005061234'

result = consumers_controller.get_consumer_for_customer(customer_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer

Get the details of a consumer record by consumer ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def get_consumer(consumer_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumer_id` | `String` | Template, Required | The consumer ID |

## Response Type

[`Consumer`](../../doc/models/consumer.md)

## Example Usage

```ruby
consumer_id = '0bf46322c167b562e6cbed9d40e19a4c'

result = consumers_controller.get_consumer(consumer_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify Consumer

Modify an existing consumer. All fields are required for a consumer record, but individual fields for this call are optional because fields that are not specified will be left unchanged.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ruby
def modify_consumer(consumer_id,
                    body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumer_id` | `String` | Template, Required | The consumer ID |
| `body` | [`ConsumerUpdate`](../../doc/models/consumer-update.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```ruby
consumer_id = '0bf46322c167b562e6cbed9d40e19a4c'
body = ConsumerUpdate.new

result = consumers_controller.modify_consumer(consumer_id, body)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

