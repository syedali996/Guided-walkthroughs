# Consumers

Create and manage consumers associated with customers in order to use report services

```java
ConsumersController consumersController = client.getConsumersController();
```

## Class Name

`ConsumersController`

## Methods

* [Create Consumer](../../doc/controllers/consumers.md#create-consumer)
* [Get Consumer for Customer](../../doc/controllers/consumers.md#get-consumer-for-customer)
* [Get Consumer](../../doc/controllers/consumers.md#get-consumer)
* [Modify Consumer](../../doc/controllers/consumers.md#modify-consumer)


# Create Consumer

Create a consumer record associated with the given customer. A consumer persists as the owner of any reports that are generated, even after the original customer is deleted from the system.

A consumer must be created for the given customer before calling any of the Generate Report services.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CreatedConsumer> createConsumerAsync(
    final String customerId,
    final NewConsumer body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `body` | [`NewConsumer`](../../doc/models/new-consumer.md) | Body, Required | - |

## Response Type

[`CreatedConsumer`](../../doc/models/created-consumer.md)

## Example Usage

```java
String customerId = "1005061234";
NewConsumer body = new NewConsumer();
body.setFirstName("John");
body.setLastName("Smith");
body.setAddress("434 W Ascension Way");
body.setCity("Murray");
body.setState("UT");
body.setZip("84123");
body.setPhone("1-800-986-3343");
body.setSsn("999-99-9999");
Birthday birthday = new Birthday();

body.setBirthday(birthday);

consumersController.createConsumerAsync(customerId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 409 | The resource already exists | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer for Customer

Get the details of a consumer record by customer ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Consumer> getConsumerForCustomerAsync(
    final String customerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |

## Response Type

[`Consumer`](../../doc/models/consumer.md)

## Example Usage

```java
String customerId = "1005061234";

consumersController.getConsumerForCustomerAsync(customerId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer

Get the details of a consumer record by consumer ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Consumer> getConsumerAsync(
    final String consumerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumerId` | `String` | Template, Required | The consumer ID |

## Response Type

[`Consumer`](../../doc/models/consumer.md)

## Example Usage

```java
String consumerId = "0bf46322c167b562e6cbed9d40e19a4c";

consumersController.getConsumerAsync(consumerId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify Consumer

Modify an existing consumer. All fields are required for a consumer record, but individual fields for this call are optional because fields that are not specified will be left unchanged.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Void> modifyConsumerAsync(
    final String consumerId,
    final ConsumerUpdate body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumerId` | `String` | Template, Required | The consumer ID |
| `body` | [`ConsumerUpdate`](../../doc/models/consumer-update.md) | Body, Required | - |

## Response Type

`void`

## Example Usage

```java
String consumerId = "0bf46322c167b562e6cbed9d40e19a4c";
ConsumerUpdate body = new ConsumerUpdate();

consumersController.modifyConsumerAsync(consumerId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

