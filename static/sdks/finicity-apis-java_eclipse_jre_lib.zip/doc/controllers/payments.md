# Payments

Fetch ACH details and account balances

```java
PaymentsController paymentsController = client.getPaymentsController();
```

## Class Name

`PaymentsController`

## Methods

* [Get Account Owner](../../doc/controllers/payments.md#get-account-owner)
* [Get Loan Payment Details](../../doc/controllers/payments.md#get-loan-payment-details)
* [Get Account ACH Details](../../doc/controllers/payments.md#get-account-ach-details)
* [Get Available Balance Live](../../doc/controllers/payments.md#get-available-balance-live)
* [Get Available Balance](../../doc/controllers/payments.md#get-available-balance)


# Get Account Owner

Retrieve the names and addresses of the account owner from a financial institution.

Note: this is a premium service, billable per every successful API call.

This service retrieves account data from the institution. This usually returns quickly, but in some scenarios may take a few minutes to complete. In the event of a timeout condition, retry the call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<AccountOwner> getAccountOwnerAsync(
    final String customerId,
    final String accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |

## Response Type

[`AccountOwner`](../../doc/models/account-owner.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";

paymentsController.getAccountOwnerAsync(customerId, accountId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Loan Payment Details

Return the loan payment details of the customer for a loan-type account.

Note: this is a premium service, billable per every successful API call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<LoanPaymentDetails> getLoanPaymentDetailsAsync(
    final String customerId,
    final String accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |

## Response Type

[`LoanPaymentDetails`](../../doc/models/loan-payment-details.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";

paymentsController.getLoanPaymentDetailsAsync(customerId, accountId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Account ACH Details

Return the real account number and routing number details for an ACH payment.

Note: this is a premium service, billable per every successful API call.

_Supported account types_: "checking", "savings", "moneyMarket", "loan"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ACHDetails> getAccountACHDetailsAsync(
    final String customerId,
    final String accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |

## Response Type

[`ACHDetails`](../../doc/models/ach-details.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";

paymentsController.getAccountACHDetailsAsync(customerId, accountId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Available Balance Live

Retrieve the available and cleared account balances for a single account in real-time directly from a financial institution.

Note: this is a premium service, billable per every successful API call.

_Supported account types_: "checking", "savings", "moneyMarket", "cd"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<AvailableBalance> getAvailableBalanceLiveAsync(
    final String customerId,
    final String accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |

## Response Type

[`AvailableBalance`](../../doc/models/available-balance.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";

paymentsController.getAvailableBalanceLiveAsync(customerId, accountId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Available Balance

Retrieve the latest cached available and cleared account balances for a customer. Since we update and store balances throughout the day, this is the most accurate balance information available when a connection to a financial institution is unavailable or when a faster response is needed. Only deposit account types are supported: Checking, Savings, Money Market, and CD.

Note: this is a premium service, billable per every successful API call. Enrollment is required.

_Supported account types_: "checking", "savings", "moneyMarket", "cd"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<AvailableBalance> getAvailableBalanceAsync(
    final String customerId,
    final String accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |

## Response Type

[`AvailableBalance`](../../doc/models/available-balance.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";

paymentsController.getAvailableBalanceAsync(customerId, accountId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

