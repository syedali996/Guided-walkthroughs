# Cash Flow

```java
CashFlowController cashFlowController = client.getCashFlowController();
```

## Class Name

`CashFlowController`

## Methods

* [Generate Cash Flow Business Report](../../doc/controllers/cash-flow.md#generate-cash-flow-business-report)
* [Generate Cash Flow Personal Report](../../doc/controllers/cash-flow.md#generate-cash-flow-personal-report)


# Generate Cash Flow Business Report

Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.

This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CashFlowReportAck> generateCashFlowBusinessReportAsync(
    final String customerId,
    final CashFlowReportConstraints body,
    final String callbackUrl)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `body` | [`CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `String` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`CashFlowReportAck`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```java
String customerId = "1005061234";
CashFlowReportConstraints body = new CashFlowReportConstraints();
body.setAccountIds("1000535275");
List<ReportCustomField> reportCustomFields = new LinkedList<>();
ReportCustomField reportCustomFields0 = new ReportCustomField();
reportCustomFields0.setLabel("loanID");
reportCustomFields0.setValue("12345");
reportCustomFields0.setShown(true);

reportCustomFields.add(reportCustomFields0);
ReportCustomField reportCustomFields1 = new ReportCustomField();
reportCustomFields1.setLabel("trackingID");
reportCustomFields1.setValue("5555");
reportCustomFields1.setShown(true);

reportCustomFields.add(reportCustomFields1);
ReportCustomField reportCustomFields2 = new ReportCustomField();
reportCustomFields2.setLabel("loanType");
reportCustomFields2.setValue("car");
reportCustomFields2.setShown(false);

reportCustomFields.add(reportCustomFields2);
ReportCustomField reportCustomFields3 = new ReportCustomField();
reportCustomFields3.setLabel("vendorID");
reportCustomFields3.setValue("1613aa23");
reportCustomFields3.setShown(true);

reportCustomFields.add(reportCustomFields3);
ReportCustomField reportCustomFields4 = new ReportCustomField();
reportCustomFields4.setLabel("vendorName");
reportCustomFields4.setValue("PSC Finance");
reportCustomFields4.setShown(false);

reportCustomFields.add(reportCustomFields4);

body.setReportCustomFields(reportCustomFields);
body.setShowNsf(false);
body.setFromDate(1580558400L);
body.setIncomeStreamConfidenceMinimum(50);

String callbackUrl = "https://finicity-test/webhook";

cashFlowController.generateCashFlowBusinessReportAsync(customerId, body, callbackUrl).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "id": "383z55zudewm-cfrb",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Business",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrb",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Cash Flow Personal Report

Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.

This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CashFlowReportAck> generateCashFlowPersonalReportAsync(
    final String customerId,
    final CashFlowReportConstraints body,
    final String callbackUrl)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `body` | [`CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `String` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`CashFlowReportAck`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```java
String customerId = "1005061234";
CashFlowReportConstraints body = new CashFlowReportConstraints();
body.setAccountIds("1000535275");
List<ReportCustomField> reportCustomFields = new LinkedList<>();
ReportCustomField reportCustomFields0 = new ReportCustomField();
reportCustomFields0.setLabel("loanID");
reportCustomFields0.setValue("12345");
reportCustomFields0.setShown(true);

reportCustomFields.add(reportCustomFields0);
ReportCustomField reportCustomFields1 = new ReportCustomField();
reportCustomFields1.setLabel("trackingID");
reportCustomFields1.setValue("5555");
reportCustomFields1.setShown(true);

reportCustomFields.add(reportCustomFields1);
ReportCustomField reportCustomFields2 = new ReportCustomField();
reportCustomFields2.setLabel("loanType");
reportCustomFields2.setValue("car");
reportCustomFields2.setShown(false);

reportCustomFields.add(reportCustomFields2);
ReportCustomField reportCustomFields3 = new ReportCustomField();
reportCustomFields3.setLabel("vendorID");
reportCustomFields3.setValue("1613aa23");
reportCustomFields3.setShown(true);

reportCustomFields.add(reportCustomFields3);
ReportCustomField reportCustomFields4 = new ReportCustomField();
reportCustomFields4.setLabel("vendorName");
reportCustomFields4.setValue("PSC Finance");
reportCustomFields4.setShown(false);

reportCustomFields.add(reportCustomFields4);

body.setReportCustomFields(reportCustomFields);
body.setShowNsf(false);
body.setFromDate(1580558400L);
body.setIncomeStreamConfidenceMinimum(50);

String callbackUrl = "https://finicity-test/webhook";

cashFlowController.generateCashFlowPersonalReportAsync(customerId, body, callbackUrl).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "id": "383z51zurqwo-cfrp",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Personal",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrp",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

