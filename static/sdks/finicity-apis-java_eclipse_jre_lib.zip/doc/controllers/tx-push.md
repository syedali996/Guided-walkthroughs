# Tx Push

Manage TxPush subscriptions

```java
TxPushController txPushController = client.getTxPushController();
```

## Class Name

`TxPushController`

## Methods

* [Subscribe to Tx Push Notifications](../../doc/controllers/tx-push.md#subscribe-to-tx-push-notifications)
* [Disable Tx Push Notifications](../../doc/controllers/tx-push.md#disable-tx-push-notifications)
* [Create Tx Push Test Transaction](../../doc/controllers/tx-push.md#create-tx-push-test-transaction)
* [Delete Tx Push Subscription](../../doc/controllers/tx-push.md#delete-tx-push-subscription)


# Subscribe to Tx Push Notifications

Register a client app's TxPush Listener to receive TxPush notifications related to the given account.

Each call to this service will return two records, one with class account and one with class transaction. Account events are sent when values change in the account's fields (such as `balance` or `interestRate`). Transaction events are sent whenever a new transaction is posted for the account. For institutions that do not provide TxPush services, notifications are sent as soon as Finicity finds a new transaction or new account data through regular aggregation processes.

The listener's URL must be secure (HTTPS) for any real-world account. In addition, the client's TxPush Listener will need to be verified. HTTP and HTTPS connections are only allowed on the standard ports 80 (HTTP) and 443 (HTTPS). The use of other ports will result with the call failing.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<TxPushSubscriptions> subscribeToTxPushNotificationsAsync(
    final String customerId,
    final String accountId,
    final TxPushSubscriptionParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |
| `body` | [`TxPushSubscriptionParameters`](../../doc/models/tx-push-subscription-parameters.md) | Body, Required | - |

## Response Type

[`TxPushSubscriptions`](../../doc/models/tx-push-subscriptions.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";
TxPushSubscriptionParameters body = new TxPushSubscriptionParameters();
body.setCallbackUrl("https://www.mydomain.com/txpush/listener");

txPushController.subscribeToTxPushNotificationsAsync(customerId, accountId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Disable Tx Push Notifications

Delete all TxPush subscriptions with their notifications for the given account. No more notifications will be sent for account or transaction events.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Void> disableTxPushNotificationsAsync(
    final String customerId,
    final String accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |

## Response Type

`void`

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";

txPushController.disableTxPushNotificationsAsync(customerId, accountId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Create Tx Push Test Transaction

Inject a transaction into the transaction list for a testing account. This allows an app to trigger TxPush notifications for the account in order to test the app's TxPush Listener service. This causes the platform to send one transaction event and one account event (showing that the account balance has changed). This service is only supported for testing accounts.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CreatedTestTxPushTransaction> createTxPushTestTransactionAsync(
    final String customerId,
    final String accountId,
    final TestTxPushTransaction body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `accountId` | `String` | Template, Required | The account ID |
| `body` | [`TestTxPushTransaction`](../../doc/models/test-tx-push-transaction.md) | Body, Required | - |

## Response Type

[`CreatedTestTxPushTransaction`](../../doc/models/created-test-tx-push-transaction.md)

## Example Usage

```java
String customerId = "1005061234";
String accountId = "5011648377";
TestTxPushTransaction body = new TestTxPushTransaction();
body.setAmount(-4.25);
body.setDescription("a testing transaction description");
body.setTransactionDate(1607450357L);

txPushController.createTxPushTestTransactionAsync(customerId, accountId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Tx Push Subscription

Delete a specific subscription to TxPush notifications for the given account. This could be individual deleting the account or transactions events. No more events will be sent for that specific subscription.

For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Void> deleteTxPushSubscriptionAsync(
    final String customerId,
    final long subscriptionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `subscriptionId` | `long` | Template, Required | The subscription ID |

## Response Type

`void`

## Example Usage

```java
String customerId = "1005061234";
long subscriptionId = 17554874L;

txPushController.deleteTxPushSubscriptionAsync(customerId, subscriptionId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

