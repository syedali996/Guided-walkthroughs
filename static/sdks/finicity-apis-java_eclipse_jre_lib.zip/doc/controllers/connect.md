# Connect

```java
ConnectController connectController = client.getConnectController();
```

## Class Name

`ConnectController`

## Methods

* [Generate Connect Url](../../doc/controllers/connect.md#generate-connect-url)
* [Generate Lite Connect Url](../../doc/controllers/connect.md#generate-lite-connect-url)
* [Generate Fix Connect Url](../../doc/controllers/connect.md#generate-fix-connect-url)
* [Send Connect Email](../../doc/controllers/connect.md#send-connect-email)
* [Generate Joint Borrower Connect Url](../../doc/controllers/connect.md#generate-joint-borrower-connect-url)
* [Send Joint Borrower Connect Email](../../doc/controllers/connect.md#send-joint-borrower-connect-email)


# Generate Connect Url

Generate a Connect 2.0 URL link to add within your own applications.

In option, use the `experience` parameter to call Connect (per session) in the body of the request. Configure the `experience` parameter to change the brand color, logo, icon, which credit decisioning report to generate when the Connect application completes, and more.

Note: contact your Sales Account Team to set up the `experience` parameter.

MVS Developers: You can pre-populate the consumer's SSN on the "Find employment records" page at the beginning of the MVS payroll app. Pass the SSN value for the consumer in the body of the request call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ConnectUrl> generateConnectUrlAsync(
    final ConnectParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectParameters`](../../doc/models/connect-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```java
ConnectParameters body = new ConnectParameters();
body.setPartnerId("1234583871234");
body.setCustomerId("1005061234");

connectController.generateConnectUrlAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Lite Connect Url

Connect Lite is a variation of Connect Full (`POST /connect/v2/generate`), which has a limited set of features.

* Sign in, user's credentials, and Multi-Factor Authentication (MFA)
* No user account management

The Connect Web SDK isn't a requirement when using Connect lite. However, if you want to use the SDK events, routes, and user events, then you must integrate with the Connect Web SDK.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ConnectUrl> generateLiteConnectUrlAsync(
    final LiteConnectParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`LiteConnectParameters`](../../doc/models/lite-connect-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```java
LiteConnectParameters body = new LiteConnectParameters();
body.setPartnerId("1234583871234");
body.setCustomerId("1005061234");
body.setInstitutionId(4222L);

connectController.generateLiteConnectUrlAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Fix Connect Url

Use the Connect Fix API when the following conditions occur:

* The connection to the user's financial institution is lost
* The user's credentials were updated (for any number of reasons)
* The user's MFA challenge has expired

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ConnectUrl> generateFixConnectUrlAsync(
    final FixConnectParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FixConnectParameters`](../../doc/models/fix-connect-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```java
FixConnectParameters body = new FixConnectParameters();
body.setPartnerId("1234583871234");
body.setCustomerId("1005061234");
body.setInstitutionLoginId("1007302745");

connectController.generateFixConnectUrlAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Send Connect Email

Same as Connect Full (`POST /connect/v2/generate`) but send a Connect email to a consumer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ConnectEmailUrl> sendConnectEmailAsync(
    final ConnectEmailParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectEmailParameters`](../../doc/models/connect-email-parameters.md) | Body, Required | - |

## Response Type

[`ConnectEmailUrl`](../../doc/models/connect-email-url.md)

## Example Usage

```java
ConnectEmailParameters body = new ConnectEmailParameters();
body.setPartnerId("1234583871234");
body.setCustomerId("1005061234");
body.setConsumerId("0bf46322c167b562e6cbed9d40e19a4c");
EmailOptions email = new EmailOptions();
email.setTo("alex.salido@finicity.com");

body.setEmail(email);

connectController.sendConnectEmailAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Joint Borrower Connect Url

Same as Connect Full (`POST /connect/v2/generate`) but for joint borrowers.

MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ConnectUrl> generateJointBorrowerConnectUrlAsync(
    final ConnectJointBorrowerParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectJointBorrowerParameters`](../../doc/models/connect-joint-borrower-parameters.md) | Body, Required | - |

## Response Type

[`ConnectUrl`](../../doc/models/connect-url.md)

## Example Usage

```java
ConnectJointBorrowerParameters body = new ConnectJointBorrowerParameters();
body.setPartnerId("1234583871234");
List<Borrower> borrowers = new LinkedList<>();
Borrower borrowers0 = new Borrower();
borrowers0.setCustomerId("customerId8");
borrowers0.setConsumerId("consumerId8");
borrowers0.setType("type4");

borrowers.add(borrowers0);
Borrower borrowers1 = new Borrower();
borrowers1.setCustomerId("customerId9");
borrowers1.setConsumerId("consumerId9");
borrowers1.setType("type5");

borrowers.add(borrowers1);

body.setBorrowers(borrowers);

connectController.generateJointBorrowerConnectUrlAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Send Joint Borrower Connect Email

Same as Connect Joint Borrower (`POST /connect/v2/generate/jointBorrower`) but send a Connect email  to at least one of the joint borrower's email addresses.

When the consumer opens the email, MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<ConnectEmailUrl> sendJointBorrowerConnectEmailAsync(
    final ConnectJointBorrowerEmailParameters body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ConnectJointBorrowerEmailParameters`](../../doc/models/connect-joint-borrower-email-parameters.md) | Body, Required | - |

## Response Type

[`ConnectEmailUrl`](../../doc/models/connect-email-url.md)

## Example Usage

```java
ConnectJointBorrowerEmailParameters body = new ConnectJointBorrowerEmailParameters();
body.setPartnerId("1234583871234");
List<Borrower> borrowers = new LinkedList<>();
Borrower borrowers0 = new Borrower();
borrowers0.setCustomerId("customerId8");
borrowers0.setConsumerId("consumerId8");
borrowers0.setType("type4");

borrowers.add(borrowers0);
Borrower borrowers1 = new Borrower();
borrowers1.setCustomerId("customerId9");
borrowers1.setConsumerId("consumerId9");
borrowers1.setType("type5");

borrowers.add(borrowers1);

body.setBorrowers(borrowers);
EmailOptions email = new EmailOptions();
email.setTo("alex.salido@finicity.com");

body.setEmail(email);
body.setExperience("default");

connectController.sendJointBorrowerConnectEmailAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

