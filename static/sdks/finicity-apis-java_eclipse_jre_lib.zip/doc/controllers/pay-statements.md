# Pay Statements

```java
PayStatementsController payStatementsController = client.getPayStatementsController();
```

## Class Name

`PayStatementsController`


# Store Customer Pay Statement

Upload pay statements for a customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Asset> storeCustomerPayStatementAsync(
    final String customerId,
    final PayStatement body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `body` | [`PayStatement`](../../doc/models/pay-statement.md) | Body, Required | - |

## Response Type

[`Asset`](../../doc/models/asset.md)

## Example Usage

```java
String customerId = "1005061234";
PayStatement body = new PayStatement();
body.setLabel("lastPayPeriod");
body.setStatement("VGhpcyBtdXN0IGJlIGFuIGltYWdl");

payStatementsController.storeCustomerPayStatementAsync(customerId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

