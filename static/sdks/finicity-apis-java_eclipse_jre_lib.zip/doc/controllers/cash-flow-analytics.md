# Cash Flow Analytics

```java
CashFlowAnalyticsController cashFlowAnalyticsController = client.getCashFlowAnalyticsController();
```

## Class Name

`CashFlowAnalyticsController`

## Methods

* [Generate Cash Flow Analytics](../../doc/controllers/cash-flow-analytics.md#generate-cash-flow-analytics)
* [Generate Cash Flow Analytics Fcra](../../doc/controllers/cash-flow-analytics.md#generate-cash-flow-analytics-fcra)


# Generate Cash Flow Analytics

Cash Flow Analytics for Business analyzes cash flow over time to report metrics and identify behavior that may indicate risk.

Calculated metrics include:

* Average transaction value by month over the requested time period

* Net cash flow over the requested time period and broken down by month

* Count and report of weeks in the requested time period where there
  were zero transactions posted to the customer's accounts

* Minimum/maximum/average/sum/count of deposits by month

* Minimum/maximum/average/sum/count of withdrawals by month

* Estimated amount of deposits that can be classified as business
  revenue

* Number of transactions posted incurring a non-sufficient funds (NSF)
  fee, and net amount charged in NSF fees

This version of the API is intended for piloting and integration testing your application with the Cash Flow Analytics product. It does not adhere to FCRA requirements, and should not be used for production/lending purposes. See _Generate Cash Flow Analytics - FCRA_ for the FCRA compliant version of this API.

A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Cash Flow Analytics Report_ (operation: _GetCashFlowAnalyticsReport_).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<BalanceAndCashFlowAnalyticsReportAck> generateCashFlowAnalyticsAsync(
    final String customerId,
    final BalanceAndCashFlowAnalyticsReportConstraints body,
    final String referenceNumber)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `body` | [`BalanceAndCashFlowAnalyticsReportConstraints`](../../doc/models/balance-and-cash-flow-analytics-report-constraints.md) | Body, Required | - |
| `referenceNumber` | `String` | Query, Optional | Partner-provided reference number to correlate reports. |

## Response Type

[`BalanceAndCashFlowAnalyticsReportAck`](../../doc/models/balance-and-cash-flow-analytics-report-ack.md)

## Example Usage

```java
String customerId = "1005061234";
BalanceAndCashFlowAnalyticsReportConstraints body = new BalanceAndCashFlowAnalyticsReportConstraints();

String referenceNumber = "abc123";

cashFlowAnalyticsController.generateCashFlowAnalyticsAsync(customerId, body, referenceNumber).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "accountIds": [
    10001,
    10002,
    10003
  ],
  "businessId": 123,
  "createdDate": "2022-02-10T05:00:00-07:00",
  "customerId": 10001,
  "reportId": "145cabe0-2b38-4175-9b7e-115431359839",
  "reportPin": "qert",
  "requesterName": "Mortage ABC LLC",
  "title": "Finicity Cashflow Analytics"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A bad request was provided | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 401 | Unauthorized request | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 403 | Access forbidden | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 404 | Resource not found | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 409 | Resource conflict | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |


# Generate Cash Flow Analytics Fcra

Cash Flow Analytics for Business analyzes cash flow over time to report metrics and identify behavior that may indicate risk.

Calculated metrics include:

* Average transaction value by month over the requested time period

* Net cash flow over the requested time period and broken down by month

* Count and report of weeks in the requested time period where there
  were zero transactions posted to the customer's accounts

* Minimum/maximum/average/sum/count of deposits by month

* Minimum/maximum/average/sum/count of withdrawals by month

* Estimated amount of deposits that can be classified as business
  revenue

* Number of transactions posted incurring a non-sufficient funds (NSF)
  fee, and net amount charged in NSF fees

This version of the API is intended for production use. It maintains and enforces all compliance with FCRA rules and requirements.

*Note:* this is a premium service, billable per every successful API call for non-testing customers.

A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Cash Flow Analytics Report - FCRA_ (operation: _GetCashFlowAnalyticsReportFCRA_).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<BalanceAndCashFlowAnalyticsReportAck> generateCashFlowAnalyticsFcraAsync(
    final String customerId,
    final BalanceAndCashFlowAnalyticsReportConstraints body,
    final String referenceNumber)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `body` | [`BalanceAndCashFlowAnalyticsReportConstraints`](../../doc/models/balance-and-cash-flow-analytics-report-constraints.md) | Body, Required | - |
| `referenceNumber` | `String` | Query, Optional | Partner-provided reference number to correlate reports. |

## Response Type

[`BalanceAndCashFlowAnalyticsReportAck`](../../doc/models/balance-and-cash-flow-analytics-report-ack.md)

## Example Usage

```java
String customerId = "1005061234";
BalanceAndCashFlowAnalyticsReportConstraints body = new BalanceAndCashFlowAnalyticsReportConstraints();

String referenceNumber = "abc123";

cashFlowAnalyticsController.generateCashFlowAnalyticsFcraAsync(customerId, body, referenceNumber).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "accountIds": [
    10001,
    10002,
    10003
  ],
  "businessId": 123,
  "createdDate": "2022-02-10T05:00:00-07:00",
  "customerId": 10001,
  "reportId": "145cabe0-2b38-4175-9b7e-115431359839",
  "reportPin": "qert",
  "requesterName": "Mortage ABC LLC",
  "title": "Finicity Cashflow Analytics"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A bad request was provided | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 401 | Unauthorized request | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 403 | Access forbidden | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 404 | Resource not found | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 409 | Resource conflict | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |

