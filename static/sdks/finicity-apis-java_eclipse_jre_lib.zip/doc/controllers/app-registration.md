# App Registration

```java
AppRegistrationController appRegistrationController = client.getAppRegistrationController();
```

## Class Name

`AppRegistrationController`

## Methods

* [Register App](../../doc/controllers/app-registration.md#register-app)
* [Modify App Registration](../../doc/controllers/app-registration.md#modify-app-registration)
* [Get App Registration Status](../../doc/controllers/app-registration.md#get-app-registration-status)
* [Set Customer App ID](../../doc/controllers/app-registration.md#set-customer-app-id)
* [Migrate Institution Login Accounts](../../doc/controllers/app-registration.md#migrate-institution-login-accounts)


# Register App

Register a new application to access financial institutions using OAuth connections.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<RegisteredApplication> registerAppAsync(
    final Application body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```java
Application body = new Application();
body.setAppDescription("The app that makes your budgeting experience awesome");
body.setAppName("Awesome Budget App");
body.setAppUrl("https://www.finicity.com/");
body.setOwnerAddressLine1("434 W Ascension Way");
body.setOwnerAddressLine2("Suite #200");
body.setOwnerCity("Murray");
body.setOwnerCountry("USA");
body.setOwnerName("Finicity");
body.setOwnerPostalCode("84123");
body.setOwnerState("UT");
body.setImage("PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K");

appRegistrationController.registerAppAsync(body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify App Registration

Update a registered application.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<RegisteredApplication> modifyAppRegistrationAsync(
    final String preAppId,
    final Application body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preAppId` | `String` | Template, Required | The application registration tracking ID |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```java
String preAppId = "2581";
Application body = new Application();
body.setAppDescription("The app that makes your budgeting experience awesome");
body.setAppName("Awesome Budget App");
body.setAppUrl("https://www.finicity.com/");
body.setOwnerAddressLine1("434 W Ascension Way");
body.setOwnerAddressLine2("Suite #200");
body.setOwnerCity("Murray");
body.setOwnerCountry("USA");
body.setOwnerName("Finicity");
body.setOwnerPostalCode("84123");
body.setOwnerState("UT");
body.setImage("PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K");

appRegistrationController.modifyAppRegistrationAsync(preAppId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get App Registration Status

Get the status of your application registration(s).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<AppStatuses> getAppRegistrationStatusAsync(
    final String preAppId,
    final String applicationId,
    final String status,
    final String appName,
    final Long submittedDate,
    final Long modifiedDate,
    final Integer page,
    final Integer pageSize)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preAppId` | `String` | Query, Optional | The application registration tracking ID |
| `applicationId` | `String` | Query, Optional | The application ID |
| `status` | `String` | Query, Optional | Look up app registration requests by status |
| `appName` | `String` | Query, Optional | Look up app registration requests by app name |
| `submittedDate` | `Long` | Query, Optional | Look up app registration requests by the date they were submitted |
| `modifiedDate` | `Long` | Query, Optional | Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R". |
| `page` | `Integer` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `pageSize` | `Integer` | Query, Optional | Maximum number of results per page<br>**Default**: `1` |

## Response Type

[`AppStatuses`](../../doc/models/app-statuses.md)

## Example Usage

```java
String preAppId = "2581";
String applicationId = "123456789";
String status = "P";
String appName = "Awesome Budget App";
Long submittedDate = 1607450357L;
Long modifiedDate = 1607450357L;
Integer page = 1;
Integer pageSize = 20;

appRegistrationController.getAppRegistrationStatusAsync(preAppId, applicationId, status, appName, submittedDate, modifiedDate, page, pageSize).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Set Customer App ID

If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Void> setCustomerAppIDAsync(
    final String customerId,
    final String applicationId,
    final Object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `applicationId` | `String` | Template, Required | The application ID |
| `body` | `Object` | Body, Optional | No payload expected |

## Response Type

`void`

## Example Usage

```java
String customerId = "1005061234";
String applicationId = "123456789";

appRegistrationController.setCustomerAppIDAsync(customerId, applicationId, null).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Migrate Institution Login Accounts

The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.

This API returns a list of accounts for the given institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CustomerAccounts> migrateInstitutionLoginAccountsAsync(
    final String customerId,
    final String institutionLoginId,
    final Object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `institutionLoginId` | `String` | Template, Required | The institution login ID |
| `body` | `Object` | Body, Required | No payload expected |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```java
String customerId = "1005061234";
String institutionLoginId = "1007302745";
Object body = com.finicity.api.ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}");

appRegistrationController.migrateInstitutionLoginAccountsAsync(customerId, institutionLoginId, body).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

