# Institutions

Search and fetch financial institutions

```java
InstitutionsController institutionsController = client.getInstitutionsController();
```

## Class Name

`InstitutionsController`

## Methods

* [Get Certified Institutions With RSSD](../../doc/controllers/institutions.md#get-certified-institutions-with-rssd)
* [Get Institutions](../../doc/controllers/institutions.md#get-institutions)
* [Get Certified Institutions](../../doc/controllers/institutions.md#get-certified-institutions)
* [Get Institution](../../doc/controllers/institutions.md#get-institution)
* [Get Institution Branding](../../doc/controllers/institutions.md#get-institution-branding)


# Get Certified Institutions With RSSD

Search for certified financial institutions w/RSSD.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CertifiedInstitutions> getCertifiedInstitutionsWithRSSDAsync(
    final String search,
    final Integer start,
    final Integer limit,
    final String type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `String` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `Integer` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `Integer` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `String` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`CertifiedInstitutions`](../../doc/models/certified-institutions.md)

## Example Usage

```java
String search = "finbank";
Integer start = 1;
Integer limit = 25;
String type = "voa";

institutionsController.getCertifiedInstitutionsWithRSSDAsync(search, start, limit, type).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institutions

Search for financial institutions.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<Institutions> getInstitutionsAsync(
    final String search,
    final Integer start,
    final Integer limit,
    final String type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `String` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `Integer` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `Integer` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `String` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`Institutions`](../../doc/models/institutions.md)

## Example Usage

```java
String search = "finbank";
Integer start = 1;
Integer limit = 25;
String type = "voa";

institutionsController.getInstitutionsAsync(search, start, limit, type).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Certified Institutions

Search for financial institutions by certified product.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<CertifiedInstitutions> getCertifiedInstitutionsAsync(
    final String search,
    final Integer start,
    final Integer limit,
    final String type)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `String` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `Integer` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `Integer` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `String` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`CertifiedInstitutions`](../../doc/models/certified-institutions.md)

## Example Usage

```java
String search = "finbank";
Integer start = 1;
Integer limit = 25;
String type = "voa";

institutionsController.getCertifiedInstitutionsAsync(search, start, limit, type).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution

Get financial institution details by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<InstitutionWrapper> getInstitutionAsync(
    final long institutionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institutionId` | `long` | Template, Required | The institution ID |

## Response Type

[`InstitutionWrapper`](../../doc/models/institution-wrapper.md)

## Example Usage

```java
long institutionId = 4222L;

institutionsController.getInstitutionAsync(institutionId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution Branding

Return the branding information for a financial institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<BrandingWrapper> getInstitutionBrandingAsync(
    final long institutionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institutionId` | `long` | Template, Required | The institution ID |

## Response Type

[`BrandingWrapper`](../../doc/models/branding-wrapper.md)

## Example Usage

```java
long institutionId = 4222L;

institutionsController.getInstitutionBrandingAsync(institutionId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

