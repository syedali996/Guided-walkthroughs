# Assets

Download asset files

```java
AssetsController assetsController = client.getAssetsController();
```

## Class Name

`AssetsController`


# Get Asset by Customer ID

Retrieve a binary file for the given asset ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```java
CompletableFuture<InputStream> getAssetByCustomerIDAsync(
    final String customerId,
    final String assetId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `String` | Template, Required | A customer ID |
| `assetId` | `String` | Template, Required | The asset ID |

## Response Type

`InputStream`

## Example Usage

```java
String customerId = "1005061234";
String assetId = "097545c5-1c2a-4f20-a5ef-77f0820344c9-2018601178";

assetsController.getAssetByCustomerIDAsync(customerId, assetId).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

