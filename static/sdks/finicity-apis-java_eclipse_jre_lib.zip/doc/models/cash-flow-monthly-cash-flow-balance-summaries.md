
# Cash Flow Monthly Cash Flow Balance Summaries

## Structure

`CashFlowMonthlyCashFlowBalanceSummaries`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report | long getMonth() | setMonth(long month) |
| `MinDailyBalance` | `double` | Required | Min Daily Balance for each month for all accounts | double getMinDailyBalance() | setMinDailyBalance(double minDailyBalance) |
| `MaxDailyBalance` | `double` | Required | Max Daily Balance for each month for all accounts | double getMaxDailyBalance() | setMaxDailyBalance(double maxDailyBalance) |
| `AverageDailyBalance` | `double` | Required | Average Daily Balance for each month for all accounts | double getAverageDailyBalance() | setAverageDailyBalance(double averageDailyBalance) |
| `StandardDeviationOfDailyBalance` | `String` | Required | Standard Deviation of Daily Balance for each month for all accounts | String getStandardDeviationOfDailyBalance() | setStandardDeviationOfDailyBalance(String standardDeviationOfDailyBalance) |
| `NumberOfDaysNegativeBalance` | `String` | Required | Number of Days Negative Balance for each month for all accounts | String getNumberOfDaysNegativeBalance() | setNumberOfDaysNegativeBalance(String numberOfDaysNegativeBalance) |
| `NumberOfDaysPositiveBalance` | `String` | Required | Number of Days Positive Balance for each month for all accounts | String getNumberOfDaysPositiveBalance() | setNumberOfDaysPositiveBalance(String numberOfDaysPositiveBalance) |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "minDailyBalance": 3479.39,
  "maxDailyBalance": 3479.39,
  "averageDailyBalance": 3479.39,
  "standardDeviationOfDailyBalance": "20.45454545",
  "numberOfDaysNegativeBalance": "6",
  "numberOfDaysPositiveBalance": "0"
}
```

