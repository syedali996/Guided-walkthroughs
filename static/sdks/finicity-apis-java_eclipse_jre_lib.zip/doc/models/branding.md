
# Branding

All assets are SVGs so can be slightly resized without any issues.

## Structure

`Branding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Logo` | `String` | Optional | File path of the institution's logo. For white backgrounds designed at 375 x 72, has built in spacing around it to normalize brand sizing. | String getLogo() | setLogo(String logo) |
| `AlternateLogo` | `String` | Optional | File path of the institution's alternate logo. For colored backgrounds designed at 375 x 72 has built in spacing around it to normalize brand sizing. | String getAlternateLogo() | setAlternateLogo(String alternateLogo) |
| `Icon` | `String` | Optional | File path of the institution's icon. For search results designed at 40 x 40. | String getIcon() | setIcon(String icon) |
| `PrimaryColor` | `String` | Optional | Hex code for the institution's primary color | String getPrimaryColor() | setPrimaryColor(String primaryColor) |
| `Tile` | `String` | Optional | File path of institution name logo. For popular banks designed at 160 x 72. | String getTile() | setTile(String tile) |

## Example (as JSON)

```json
{
  "logo": null,
  "alternateLogo": null,
  "icon": null,
  "primaryColor": null,
  "tile": null
}
```

