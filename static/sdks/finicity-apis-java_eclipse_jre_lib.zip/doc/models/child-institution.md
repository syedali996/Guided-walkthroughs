
# Child Institution

## Structure

`ChildInstitution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rssd` | `long` | Required | The RSSD ID is a unique identifier assigned to financial institutions by the Federal Reserve. While the length of the RSSD ID varies by institution, it cannot exceed 10 numerical digits. | long getRssd() | setRssd(long rssd) |
| `ParentRSSD` | `long` | Required | The RSSD ID is a unique identifier assigned to financial institutions by the Federal Reserve. While the length of the RSSD ID varies by institution, it cannot exceed 10 numerical digits. | long getParentRSSD() | setParentRSSD(long parentRSSD) |
| `Name` | `String` | Required | The name of the institution | String getName() | setName(String name) |
| `InstitutionId` | `long` | Required | The ID of a financial institution, represented as a number | long getInstitutionId() | setInstitutionId(long institutionId) |

## Example (as JSON)

```json
{
  "rssd": 490535,
  "parentRSSD": 490535,
  "name": "FinBank",
  "institutionId": 4222
}
```

