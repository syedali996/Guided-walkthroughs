
# VOIE Pay Statement

## Structure

`VOIEPayStatement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PayPeriod` | `String` | Optional | The pay period of the pay statement | String getPayPeriod() | setPayPeriod(String payPeriod) |
| `Billable` | `Boolean` | Optional | Designates whether the pay statement is billable | Boolean getBillable() | setBillable(Boolean billable) |
| `AssetId` | `String` | Optional | The asset ID of the stored pay statement | String getAssetId() | setAssetId(String assetId) |
| `PayDate` | `Long` | Optional | The listed pay date for the pay statement | Long getPayDate() | setPayDate(Long payDate) |
| `StartDate` | `Long` | Optional | The beginning of the pay period | Long getStartDate() | setStartDate(Long startDate) |
| `EndDate` | `Long` | Optional | The end of the pay period | Long getEndDate() | setEndDate(Long endDate) |
| `NetPayCurrent` | `Double` | Optional | The total pay after deductions for the employee for the current pay period | Double getNetPayCurrent() | setNetPayCurrent(Double netPayCurrent) |
| `NetPayYTD` | `Double` | Optional | The total accumulation of pay after deductions for the employee for the current pay year | Double getNetPayYTD() | setNetPayYTD(Double netPayYTD) |
| `GrossPayCurrent` | `Double` | Optional | The total pay before deductions for the employee for the current pay period | Double getGrossPayCurrent() | setGrossPayCurrent(Double grossPayCurrent) |
| `GrossPayYTD` | `Double` | Optional | The total accumulation of pay before deductions for the employee for the current pay year | Double getGrossPayYTD() | setGrossPayYTD(Double grossPayYTD) |
| `PayrollProvider` | `String` | Optional | The company that provides the pay stub. | String getPayrollProvider() | setPayrollProvider(String payrollProvider) |
| `Employer` | [`Employer`](../../doc/models/employer.md) | Optional | - | Employer getEmployer() | setEmployer(Employer employer) |
| `Employee` | [`Employee`](../../doc/models/employee.md) | Optional | - | Employee getEmployee() | setEmployee(Employee employee) |
| `PayStat` | [`List<PayStat>`](../../doc/models/pay-stat.md) | Optional | Information pertaining to the earnings on the pay statement | List<PayStat> getPayStat() | setPayStat(List<PayStat> payStat) |
| `Deductions` | [`List<Deduction>`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement | List<Deduction> getDeductions() | setDeductions(List<Deduction> deductions) |
| `DirectDeposits` | [`List<DirectDeposit>`](../../doc/models/direct-deposit.md) | Optional | Information pertaining to direct deposits on the pay statement | List<DirectDeposit> getDirectDeposits() | setDirectDeposits(List<DirectDeposit> directDeposits) |

## Example (as JSON)

```json
{
  "payPeriod": null,
  "billable": null,
  "assetId": null,
  "payDate": null,
  "startDate": null,
  "endDate": null,
  "netPayCurrent": null,
  "netPayYTD": null,
  "grossPayCurrent": null,
  "grossPayYTD": null,
  "payrollProvider": null,
  "employer": null,
  "employee": null,
  "payStat": null,
  "deductions": null,
  "directDeposits": null
}
```

