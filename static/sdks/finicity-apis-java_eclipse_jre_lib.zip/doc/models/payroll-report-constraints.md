
# Payroll Report Constraints

## Structure

`PayrollReportConstraints`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PayrollData` | [`PayrollData`](../../doc/models/payroll-data.md) | Required | - | PayrollData getPayrollData() | setPayrollData(PayrollData payrollData) |
| `ReportCustomFields` | [`List<ReportCustomField>`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. | List<ReportCustomField> getReportCustomFields() | setReportCustomFields(List<ReportCustomField> reportCustomFields) |
| `PayStatementsFromDate` | `Long` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPayStatementsFromDate() | setPayStatementsFromDate(Long payStatementsFromDate) |
| `MarketSegment` | `String` | Optional | Filter consumer’s data based on the market segment. Currently supported values are; "Mortgage", "KYC", and "Identity". | String getMarketSegment() | setMarketSegment(String marketSegment) |
| `ExcludeEmpInfo` | `Boolean` | Optional | If true is passed, Employment information data will not be searched or returned. | Boolean getExcludeEmpInfo() | setExcludeEmpInfo(Boolean excludeEmpInfo) |
| `Purpose` | `String` | Optional | 2-digit code from [Permissible Purpose Codes] (https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. | String getPurpose() | setPurpose(String purpose) |

## Example (as JSON)

```json
{
  "payrollData": {
    "ssn": "999999999",
    "dob": 1607450357
  }
}
```

