
# Obb Error Message Exception

OBB Error response message

## Structure

`ObbErrorMessageException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ErrorCode` | `int` | Required | Error code | int getErrorCode() | setErrorCode(int errorCode) |
| `Message` | `String` | Required | Detailed reason about the source of the error<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getMessageField() | setMessageField(String messageField) |

## Example (as JSON)

```json
{
  "errorCode": 4,
  "message": "message0"
}
```

