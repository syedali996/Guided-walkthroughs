
# Cash Flow Report Account

## Structure

`CashFlowReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | Finicity account ID | String getId() | setId(String id) |
| `OwnerName` | `String` | Optional | The name(s) of the account owner(s), retrieved from the institution. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Optional | The mailing address of the account owner, retrieved from the institution. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Optional | The account name from the institution | String getName() | setName(String name) |
| `Number` | `String` | Optional | The account number from the institution (obfuscated) | String getNumber() | setNumber(String number) |
| `Type` | `String` | Optional | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) | String getType() | setType(String type) |
| `AggregationStatusCode` | `String` | Optional | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) | String getAggregationStatusCode() | setAggregationStatusCode(String aggregationStatusCode) |
| `CurrentBalance` | `Double` | Optional | The cleared balance of the account as-of `balanceDate` | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `AvailableBalance` | `Double` | Optional | Available balance | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `BalanceDate` | `Long` | Optional | A timestamp showing when the `balance` was captured | Long getBalanceDate() | setBalanceDate(Long balanceDate) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |
| `CashFlowBalance` | [`CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - | CashFlowCashFlowBalance getCashFlowBalance() | setCashFlowBalance(CashFlowCashFlowBalance cashFlowBalance) |
| `CashFlowCredit` | [`CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - | CashFlowCashFlowCredit getCashFlowCredit() | setCashFlowCredit(CashFlowCashFlowCredit cashFlowCredit) |
| `CashFlowDebit` | [`CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - | CashFlowCashFlowDebit getCashFlowDebit() | setCashFlowDebit(CashFlowCashFlowDebit cashFlowDebit) |
| `CashFlowCharacteristic` | [`CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - | CashFlowCashFlowCharacteristic getCashFlowCharacteristic() | setCashFlowCharacteristic(CashFlowCashFlowCharacteristic cashFlowCharacteristic) |

## Example (as JSON)

```json
{
  "id": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "number": null,
  "type": null,
  "aggregationStatusCode": null,
  "currentBalance": null,
  "availableBalance": null,
  "balanceDate": null,
  "transactions": null,
  "cashFlowBalance": null,
  "cashFlowCredit": null,
  "cashFlowDebit": null,
  "cashFlowCharacteristic": null
}
```

