
# Insufficient Funds Transaction

## Structure

`InsufficientFundsTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the NSF transaction | double getAmount() | setAmount(double amount) |
| `Description` | `String` | Optional | Description of the transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getDescription() | setDescription(String description) |
| `Memo` | `String` | Optional | Transaction memo<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getMemo() | setMemo(String memo) |
| `PostedDate` | `String` | Required | Posted date of the NSF transaction<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getPostedDate() | setPostedDate(String postedDate) |
| `TransactionId` | `long` | Required | Finicity transaction ID | long getTransactionId() | setTransactionId(long transactionId) |

## Example (as JSON)

```json
{
  "amount": -1.65,
  "postedDate": "2022-12-19",
  "transactionId": 23092384290
}
```

