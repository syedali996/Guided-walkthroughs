
# Cash Flow Cash Flow Characteristics Summary

## Structure

`CashFlowCashFlowCharacteristicsSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyCashFlowCharacteristicSummaries` | [`List<CashFlowMonthlyCashFlowCharacteristicSummaries>`](../../doc/models/cash-flow-monthly-cash-flow-characteristic-summaries.md) | Required | List of attributes for each month | List<CashFlowMonthlyCashFlowCharacteristicSummaries> getMonthlyCashFlowCharacteristicSummaries() | setMonthlyCashFlowCharacteristicSummaries(List<CashFlowMonthlyCashFlowCharacteristicSummaries> monthlyCashFlowCharacteristicSummaries) |
| `AverageMonthlyNet` | `double` | Required | Average monthly net amount | double getAverageMonthlyNet() | setAverageMonthlyNet(double averageMonthlyNet) |
| `AverageMonthlyNetLessTransfers` | `double` | Required | Average monthly net less transfers | double getAverageMonthlyNetLessTransfers() | setAverageMonthlyNetLessTransfers(double averageMonthlyNetLessTransfers) |
| `TwelveMonthTotalNet` | `double` | Required | Sum of all monthly (Total Credits - Total Debits) each month by the account | double getTwelveMonthTotalNet() | setTwelveMonthTotalNet(double twelveMonthTotalNet) |
| `TwelveMonthTotalNetLessTransfers` | `double` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers by the account | double getTwelveMonthTotalNetLessTransfers() | setTwelveMonthTotalNetLessTransfers(double twelveMonthTotalNetLessTransfers) |
| `SixMonthAverageTotalCreditsLessTotalDebits` | `double` | Required | 6 Month Average (Total Credits - Total Debits) across all accounts | double getSixMonthAverageTotalCreditsLessTotalDebits() | setSixMonthAverageTotalCreditsLessTotalDebits(double sixMonthAverageTotalCreditsLessTotalDebits) |
| `SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts | double getSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers() | setSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers(double sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers) |
| `TwoMonthAverageTotalCreditsLessTotalDebits` | `double` | Required | 2 Month Average (Total Credits - Total Debits) across all accounts | double getTwoMonthAverageTotalCreditsLessTotalDebits() | setTwoMonthAverageTotalCreditsLessTotalDebits(double twoMonthAverageTotalCreditsLessTotalDebits) |
| `TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts | double getTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers() | setTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers(double twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristicSummaries": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 1250,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

