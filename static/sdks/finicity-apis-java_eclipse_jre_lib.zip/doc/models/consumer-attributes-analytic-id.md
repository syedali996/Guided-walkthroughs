
# Consumer Attributes Analytic Id

An analytic ID and a date

## Structure

`ConsumerAttributesAnalyticId`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AnalyticId` | `String` | Required | An ID for a Consumer Attributes report | String getAnalyticId() | setAnalyticId(String analyticId) |
| `CreatedDate` | `String` | Required | A date-time without time zone | String getCreatedDate() | setCreatedDate(String createdDate) |

## Example (as JSON)

```json
{
  "analytic_id": "CA-5dfbaa3ac-5321",
  "created_date": "04/12/2022 11:51:23"
}
```

