
# Certified Institution

## Structure

`CertifiedInstitution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `long` | Required | The ID of a financial institution, represented as a number | long getId() | setId(long id) |
| `Rssd` | `Long` | Optional | The RSSD ID is a unique identifier assigned to financial institutions by the Federal Reserve. While the length of the RSSD ID varies by institution, it cannot exceed 10 numerical digits. | Long getRssd() | setRssd(Long rssd) |
| `Name` | `String` | Required | The name of the institution | String getName() | setName(String name) |
| `TransAgg` | `boolean` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product | boolean getTransAgg() | setTransAgg(boolean transAgg) |
| `Ach` | `boolean` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product | boolean getAch() | setAch(boolean ach) |
| `StateAgg` | `boolean` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product | boolean getStateAgg() | setStateAgg(boolean stateAgg) |
| `Voi` | `boolean` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product | boolean getVoi() | setVoi(boolean voi) |
| `Voa` | `boolean` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product | boolean getVoa() | setVoa(boolean voa) |
| `Aha` | `boolean` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product | boolean getAha() | setAha(boolean aha) |
| `AvailBalance` | `boolean` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product | boolean getAvailBalance() | setAvailBalance(boolean availBalance) |
| `AccountOwner` | `boolean` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product | boolean getAccountOwner() | setAccountOwner(boolean accountOwner) |
| `StudentLoanData` | `boolean` | Required | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product | boolean getStudentLoanData() | setStudentLoanData(boolean studentLoanData) |
| `LoanPaymentDetails` | `boolean` | Required | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product | boolean getLoanPaymentDetails() | setLoanPaymentDetails(boolean loanPaymentDetails) |
| `ChildInstitutions` | [`List<ChildInstitution>`](../../doc/models/child-institution.md) | Optional | An array of child financial institutions<br>**Constraints**: *Minimum Items*: `0` | List<ChildInstitution> getChildInstitutions() | setChildInstitutions(List<ChildInstitution> childInstitutions) |

## Example (as JSON)

```json
{
  "id": 4222,
  "name": "FinBank",
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "studentLoanData": true,
  "loanPaymentDetails": true
}
```

