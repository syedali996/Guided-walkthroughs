
# Created Consumer

A consumer that was just created

## Structure

`CreatedConsumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getId() | setId(String id) |
| `CreatedDate` | `Long` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getCreatedDate() | setCreatedDate(Long createdDate) |
| `CustomerId` | `Long` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | Long getCustomerId() | setCustomerId(Long customerId) |

## Example (as JSON)

```json
{
  "id": null,
  "createdDate": null,
  "customerId": null
}
```

