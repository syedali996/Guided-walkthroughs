
# Obb Date Range and Amount

## Structure

`ObbDateRangeAndAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `Double` | Optional | Metric value for the given period | Double getAmount() | setAmount(Double amount) |
| `Period` | `String` | Required | Period represented by this metric<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `12` | String getPeriod() | setPeriod(String period) |
| `PeriodBeginDate` | `String` | Required | Begin date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getPeriodBeginDate() | setPeriodBeginDate(String periodBeginDate) |
| `PeriodEndDate` | `String` | Required | End date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getPeriodEndDate() | setPeriodEndDate(String periodEndDate) |

## Example (as JSON)

```json
{
  "period": "last30to1",
  "periodBeginDate": "2022-03-01",
  "periodEndDate": "2022-03-30"
}
```

