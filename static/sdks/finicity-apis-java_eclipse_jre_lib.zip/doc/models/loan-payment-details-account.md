
# Loan Payment Details Account

## Structure

`LoanPaymentDetailsAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Required | An account ID | String getAccountId() | setAccountId(String accountId) |
| `AccountNumber` | `String` | Required | Institution's ID of the Student Loan Account | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `AccountPaymentNumber` | `String` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. | String getAccountPaymentNumber() | setAccountPaymentNumber(String accountPaymentNumber) |
| `AccountPaymentAddress` | `String` | Required | The payment address to which send manual payments should be sent | String getAccountPaymentAddress() | setAccountPaymentAddress(String accountPaymentAddress) |
| `AccountFuturePayoffAmount` | `Double` | Optional | The payoff amount for the account | Double getAccountFuturePayoffAmount() | setAccountFuturePayoffAmount(Double accountFuturePayoffAmount) |
| `AccountFuturePayoffDate` | `LocalDateTime` | Optional | The date to which the "Future Payoff Amount" applies | LocalDateTime getAccountFuturePayoffDate() | setAccountFuturePayoffDate(LocalDateTime accountFuturePayoffDate) |
| `GroupDetail` | [`List<LoanPaymentDetailsGroup>`](../../doc/models/loan-payment-details-group.md) | Optional | Group details | List<LoanPaymentDetailsGroup> getGroupDetail() | setGroupDetail(List<LoanPaymentDetailsGroup> groupDetail) |
| `LoanDetail` | [`List<LoanPaymentDetailsLoan>`](../../doc/models/loan-payment-details-loan.md) | Optional | Loan details | List<LoanPaymentDetailsLoan> getLoanDetail() | setLoanDetail(List<LoanPaymentDetailsLoan> loanDetail) |

## Example (as JSON)

```json
{
  "accountId": "5011648377",
  "accountNumber": "9876543210",
  "accountPaymentNumber": "00001234895413",
  "accountPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054"
}
```

