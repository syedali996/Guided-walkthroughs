
# Customer Update

Represent an update to customer fields

## Structure

`CustomerUpdate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | First name(s) / given name(s) | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Optional | Last name(s) / surname(s) | String getLastName() | setLastName(String lastName) |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

