
# Cash Flow Insufficient Funds Fees

## Structure

`CashFlowInsufficientFundsFees`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CountOfTransactionsForTheReportTimePeriod` | `Integer` | Optional | Count of all NSF transactions during the report | Integer getCountOfTransactionsForTheReportTimePeriod() | setCountOfTransactionsForTheReportTimePeriod(Integer countOfTransactionsForTheReportTimePeriod) |
| `SumOfTransactionsForTheReportTimePeriod` | `Double` | Optional | Sum of all NSF transactions during the report | Double getSumOfTransactionsForTheReportTimePeriod() | setSumOfTransactionsForTheReportTimePeriod(Double sumOfTransactionsForTheReportTimePeriod) |
| `Transactions` | [`List<InsufficientFundsTransaction>`](../../doc/models/insufficient-funds-transaction.md) | Optional | Transactions categorized as NSF | List<InsufficientFundsTransaction> getTransactions() | setTransactions(List<InsufficientFundsTransaction> transactions) |

## Example (as JSON)

```json
{
  "countOfTransactionsForTheReportTimePeriod": null,
  "sumOfTransactionsForTheReportTimePeriod": null,
  "transactions": null
}
```

