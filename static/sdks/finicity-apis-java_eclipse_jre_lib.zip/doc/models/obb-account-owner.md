
# Obb Account Owner

## Structure

`ObbAccountOwner`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Address` | `String` | Required | Address of the owner on record for the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getAddress() | setAddress(String address) |
| `Name` | `String` | Required | Name of the owner on record for the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getName() | setName(String name) |

## Example (as JSON)

```json
{
  "address": "123 Main St, Portland, OR 12345",
  "name": "Johnny Appleseed"
}
```

