
# Cash Flow Cash Flow Characteristic

## Structure

`CashFlowCashFlowCharacteristic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyCashFlowCharacteristics` | [`List<CashFlowMonthlyCashFlowCharacteristics>`](../../doc/models/cash-flow-monthly-cash-flow-characteristics.md) | Required | List of attributes for each month | List<CashFlowMonthlyCashFlowCharacteristics> getMonthlyCashFlowCharacteristics() | setMonthlyCashFlowCharacteristics(List<CashFlowMonthlyCashFlowCharacteristics> monthlyCashFlowCharacteristics) |
| `AverageMonthlyNet` | `double` | Required | Average (Total Credits - Total Debits) for the account | double getAverageMonthlyNet() | setAverageMonthlyNet(double averageMonthlyNet) |
| `AverageMonthlyNetLessTransfers` | `double` | Required | Average (Total Credits - Total Debits) without transfers for the account | double getAverageMonthlyNetLessTransfers() | setAverageMonthlyNetLessTransfers(double averageMonthlyNetLessTransfers) |
| `TwelveMonthTotalNet` | `double` | Required | Sum of all monthly (Total Credits - Total Debits) each month for the account | double getTwelveMonthTotalNet() | setTwelveMonthTotalNet(double twelveMonthTotalNet) |
| `TwelveMonthTotalNetLessTransfers` | `double` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers for the account | double getTwelveMonthTotalNetLessTransfers() | setTwelveMonthTotalNetLessTransfers(double twelveMonthTotalNetLessTransfers) |
| `SixMonthAverageTotalCreditsLessTotalDebits` | `double` | Required | 6 Month Average (Total Credits - Total Debits) | double getSixMonthAverageTotalCreditsLessTotalDebits() | setSixMonthAverageTotalCreditsLessTotalDebits(double sixMonthAverageTotalCreditsLessTotalDebits) |
| `SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) | double getSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers() | setSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers(double sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers) |
| `TwoMonthAverageTotalCreditsLessTotalDebits` | `double` | Required | 2 Month Average (Total Credits - Total Debits) | double getTwoMonthAverageTotalCreditsLessTotalDebits() | setTwoMonthAverageTotalCreditsLessTotalDebits(double twoMonthAverageTotalCreditsLessTotalDebits) |
| `TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) | double getTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers() | setTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers(double twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristics": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 2350,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

