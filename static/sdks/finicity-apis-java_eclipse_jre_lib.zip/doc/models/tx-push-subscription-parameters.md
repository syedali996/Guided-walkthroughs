
# Tx Push Subscription Parameters

## Structure

`TxPushSubscriptionParameters`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CallbackUrl` | `String` | Required | A callback URL where to receive TxPush notifications | String getCallbackUrl() | setCallbackUrl(String callbackUrl) |

## Example (as JSON)

```json
{
  "callbackUrl": "https://www.mydomain.com/txpush/listener"
}
```

