
# Balance Analytics Report

Balance analytics report data as JSON

## Structure

`BalanceAnalyticsReport`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountResults` | [`List<BalanceAnalyticsAccountResult>`](../../doc/models/balance-analytics-account-result.md) | Optional | Balance results per account | List<BalanceAnalyticsAccountResult> getAccountResults() | setAccountResults(List<BalanceAnalyticsAccountResult> accountResults) |
| `BusinessId` | `Integer` | Optional | Business ID | Integer getBusinessId() | setBusinessId(Integer businessId) |
| `BusinessSummary` | [`BalanceAnalyticsBusinessSummary`](../../doc/models/balance-analytics-business-summary.md) | Optional | Balance analytics summarized across all accounts in the report | BalanceAnalyticsBusinessSummary getBusinessSummary() | setBusinessSummary(BalanceAnalyticsBusinessSummary businessSummary) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `ReportHeader` | [`ObbReportHeader`](../../doc/models/obb-report-header.md) | Required | Customer and report metadata | ObbReportHeader getReportHeader() | setReportHeader(ObbReportHeader reportHeader) |
| `RequesterName` | `String` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getRequesterName() | setRequesterName(String requesterName) |
| `Title` | `String` | Required | Title of the report | String getTitle() | setTitle(String title) |

## Example (as JSON)

```json
{
  "customerId": 1005061234,
  "reportHeader": {
    "reportDate": "03/17/2022 04:28:38",
    "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
  },
  "title": "Finicity Asset Ready Report (CRA)"
}
```

