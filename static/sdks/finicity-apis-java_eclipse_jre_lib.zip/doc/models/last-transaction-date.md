
# Last Transaction Date

## Structure

`LastTransactionDate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Date` | `String` | Required | Date the deposit transaction was posted | String getDate() | setDate(String date) |
| `DepositsCredits` | `Double` | Optional | Amount of transaction if deposit, otherwise null | Double getDepositsCredits() | setDepositsCredits(Double depositsCredits) |
| `WithdrawalsDebits` | `Double` | Optional | Amount of transaction if withdrawal, otherwise null | Double getWithdrawalsDebits() | setWithdrawalsDebits(Double withdrawalsDebits) |
| `ZeroAmountTransaction` | `Double` | Optional | Amount of transaction if zero, otherwise null | Double getZeroAmountTransaction() | setZeroAmountTransaction(Double zeroAmountTransaction) |
| `TransactionDescription` | `String` | Optional | Description of transaction | String getTransactionDescription() | setTransactionDescription(String transactionDescription) |

## Example (as JSON)

```json
{
  "date": "2020-03-25"
}
```

