
# Cash Flow Activity Withdrawals Debits

## Structure

`CashFlowActivityWithdrawalsDebits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Date` | `String` | Required | Date the withdrawal transaction was posted<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getDate() | setDate(String date) |
| `TransactionDescription` | `String` | Optional | Description of transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getTransactionDescription() | setTransactionDescription(String transactionDescription) |
| `WithdrawalsDebits` | `double` | Required | Amount of the withdrawal | double getWithdrawalsDebits() | setWithdrawalsDebits(double withdrawalsDebits) |

## Example (as JSON)

```json
{
  "date": "2020-03-25",
  "withdrawalsDebits": 15.69
}
```

