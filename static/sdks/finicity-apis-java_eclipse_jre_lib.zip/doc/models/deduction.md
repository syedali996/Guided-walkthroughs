
# Deduction

## Structure

`Deduction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | The normalized category of the deductions in the format [type][number]. The number is the will be the iterating number of the type's occurrence starting at one. | String getName() | setName(String name) |
| `Description` | `String` | Optional | The deduction line's deduction type description | String getDescription() | setDescription(String description) |
| `AmountCurrent` | `Double` | Optional | The amount for the deduction line deducted from employee's pay for the specified pay period | Double getAmountCurrent() | setAmountCurrent(Double amountCurrent) |
| `AmountYTD` | `Double` | Optional | The amount for the deduction line being deducted from the employee's pay for the current pay year | Double getAmountYTD() | setAmountYTD(Double amountYTD) |
| `Type` | `String` | Optional | Categorization based on the deduction line's description | String getType() | setType(String type) |

## Example (as JSON)

```json
{
  "name": null,
  "description": null,
  "amountCurrent": null,
  "amountYTD": null,
  "type": null
}
```

