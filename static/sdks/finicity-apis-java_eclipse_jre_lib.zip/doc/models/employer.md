
# Employer

## Structure

`Employer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | The name of the employer | String getName() | setName(String name) |

## Example (as JSON)

```json
{
  "name": null
}
```

