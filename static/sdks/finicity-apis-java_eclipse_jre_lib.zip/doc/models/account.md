
# Account

## Structure

`Account`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | Finicity account ID | String getId() | setId(String id) |
| `OwnerName` | `String` | Required | The name(s) of the account owner(s), retrieved from the institution. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Required | The mailing address of the account owner, retrieved from the institution. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Required | The account name from the institution | String getName() | setName(String name) |
| `Number` | `String` | Required | The account number from the institution (obfuscated) | String getNumber() | setNumber(String number) |
| `Type` | `String` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) | String getType() | setType(String type) |
| `AggregationStatusCode` | `String` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) | String getAggregationStatusCode() | setAggregationStatusCode(String aggregationStatusCode) |
| `CurrentBalance` | `Double` | Optional | The cleared balance of the account as-of `balanceDate` | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `AvailableBalance` | `double` | Required | Available balance | double getAvailableBalance() | setAvailableBalance(double availableBalance) |
| `BalanceDate` | `Long` | Optional | A timestamp showing when the `balance` was captured | Long getBalanceDate() | setBalanceDate(Long balanceDate) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | a list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |
| `CashFlowBalance` | [`CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - | CashFlowCashFlowBalance getCashFlowBalance() | setCashFlowBalance(CashFlowCashFlowBalance cashFlowBalance) |
| `CashFlowCredit` | [`CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - | CashFlowCashFlowCredit getCashFlowCredit() | setCashFlowCredit(CashFlowCashFlowCredit cashFlowCredit) |
| `CashFlowDebit` | [`CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - | CashFlowCashFlowDebit getCashFlowDebit() | setCashFlowDebit(CashFlowCashFlowDebit cashFlowDebit) |
| `CashFlowCharacteristic` | [`CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - | CashFlowCashFlowCharacteristic getCashFlowCharacteristic() | setCashFlowCharacteristic(CashFlowCashFlowCharacteristic cashFlowCharacteristic) |
| `Balance` | `double` | Required | The cleared balance of the account as-of `balanceDate` | double getBalance() | setBalance(double balance) |
| `AverageMonthlyBalance` | `double` | Required | The average monthly balance of the account | double getAverageMonthlyBalance() | setAverageMonthlyBalance(double averageMonthlyBalance) |
| `TotNumberInsufficientFundsFeeDebitTxAccount` | `Integer` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report | Integer getTotNumberInsufficientFundsFeeDebitTxAccount() | setTotNumberInsufficientFundsFeeDebitTxAccount(Integer totNumberInsufficientFundsFeeDebitTxAccount) |
| `TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `Integer` | Optional | The total number of  insufficient funds fees for the account over six months | Integer getTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount() | setTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount(Integer totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount) |
| `TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `Long` | Optional | The total number of days since the most recent insufficient funds fee for the account | Long getTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount() | setTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(Long totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount) |
| `Asset` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | PrequalificationReportAssetSummary getAsset() | setAsset(PrequalificationReportAssetSummary asset) |
| `Details` | [`AccountDetails`](../../doc/models/account-details.md) | Optional | - | AccountDetails getDetails() | setDetails(AccountDetails details) |
| `TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `Long` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. | Long getTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount() | setTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount(Long totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount) |
| `IncomeStreams` | [`List<VOAIReportIncomeStream2>`](../../doc/models/voai-report-income-stream-2.md) | Required | A list of income stream records | List<VOAIReportIncomeStream2> getIncomeStreams() | setIncomeStreams(List<VOAIReportIncomeStream2> incomeStreams) |
| `BeginningBalance` | `Double` | Optional | Beginning balance of account per the time period in the report | Double getBeginningBalance() | setBeginningBalance(Double beginningBalance) |
| `MiscDeposits` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` | List<ReportTransaction> getMiscDeposits() | setMiscDeposits(List<ReportTransaction> miscDeposits) |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "availableBalance": 1000,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "balance": 501.24,
  "averageMonthlyBalance": 501.02,
  "incomeStreams": {
    "id": "dens28i3vsch-voah",
    "name": "none",
    "status": null,
    "estimateInclusion": null,
    "confidence": 70,
    "cadence": null,
    "netMonthly": [
      {
        "month": 1522562400,
        "net": 2004.77
      }
    ],
    "netAnnual": 110475.7,
    "projectedNetAnnual": 0,
    "estimatedGrossAnnual": 12321.1,
    "projectedGrossAnnual": 151609,
    "averageMonthlyIncomeNet": 9206.31,
    "incomeStreamMonths": 18,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    },
    "daysSinceLastTransaction": 15,
    "nextExpectedTransactionDate": 1572625469
  }
}
```

