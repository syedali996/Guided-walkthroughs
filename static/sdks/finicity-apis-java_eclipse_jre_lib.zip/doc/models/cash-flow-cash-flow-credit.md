
# Cash Flow Cash Flow Credit

## Structure

`CashFlowCashFlowCredit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyCashFlowCredits` | [`List<CashFlowMonthlyCashFlowCredits>`](../../doc/models/cash-flow-monthly-cash-flow-credits.md) | Required | List of attributes for each month | List<CashFlowMonthlyCashFlowCredits> getMonthlyCashFlowCredits() | setMonthlyCashFlowCredits(List<CashFlowMonthlyCashFlowCredits> monthlyCashFlowCredits) |
| `TwelveMonthCreditTotal` | `double` | Required | Sum of all credit transactions for each month by account | double getTwelveMonthCreditTotal() | setTwelveMonthCreditTotal(double twelveMonthCreditTotal) |
| `TwelveMonthCreditTotalLessTransfers` | `double` | Required | Sum of all monthly credit transactions without transfers for the account | double getTwelveMonthCreditTotalLessTransfers() | setTwelveMonthCreditTotalLessTransfers(double twelveMonthCreditTotalLessTransfers) |
| `SixMonthCreditTotal` | `double` | Required | Sum of six month credit transactions | double getSixMonthCreditTotal() | setSixMonthCreditTotal(double sixMonthCreditTotal) |
| `SixMonthCreditTotalLessTransfers` | `double` | Required | Sum of six month credit transactions without transfers | double getSixMonthCreditTotalLessTransfers() | setSixMonthCreditTotalLessTransfers(double sixMonthCreditTotalLessTransfers) |
| `TwoMonthCreditTotal` | `double` | Required | Sum of two month credit transactions | double getTwoMonthCreditTotal() | setTwoMonthCreditTotal(double twoMonthCreditTotal) |
| `TwoMonthCreditTotalLessTransfers` | `double` | Required | Sum of two month credit transactions without transfers | double getTwoMonthCreditTotalLessTransfers() | setTwoMonthCreditTotalLessTransfers(double twoMonthCreditTotalLessTransfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCredits": {
    "month": 1512111600,
    "numberOfCredits": "3",
    "totalCreditsAmount": 5000,
    "largestCredit": 2000,
    "numberOfCreditsLessTransfers": "2",
    "totalCreditsAmountLessTransfers": 4000,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

