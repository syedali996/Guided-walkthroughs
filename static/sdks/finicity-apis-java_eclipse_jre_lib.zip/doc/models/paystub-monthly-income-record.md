
# Paystub Monthly Income Record

## Structure

`PaystubMonthlyIncomeRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EstimatedMonthlyBasePay` | `Double` | Optional | The estimated monthly base pay amount for the employment from the paystub, calculated by Finicity | Double getEstimatedMonthlyBasePay() | setEstimatedMonthlyBasePay(Double estimatedMonthlyBasePay) |
| `EstimatedMonthlyOvertimePay` | `Double` | Optional | The estimated monthly overtime pay amount for the employment from the paystub, calculated by Finicity | Double getEstimatedMonthlyOvertimePay() | setEstimatedMonthlyOvertimePay(Double estimatedMonthlyOvertimePay) |
| `EstimatedMonthlyBonusPay` | `Double` | Optional | The estimated monthly bonus pay amount for the employment from the paystub, calculated by Finicity | Double getEstimatedMonthlyBonusPay() | setEstimatedMonthlyBonusPay(Double estimatedMonthlyBonusPay) |
| `EstimatedMonthlyCommissionPay` | `Double` | Optional | The estimated commission bonus pay amount for the employment from the paystub, calculated by Finicity | Double getEstimatedMonthlyCommissionPay() | setEstimatedMonthlyCommissionPay(Double estimatedMonthlyCommissionPay) |

## Example (as JSON)

```json
{
  "estimatedMonthlyBasePay": null,
  "estimatedMonthlyOvertimePay": null,
  "estimatedMonthlyBonusPay": null,
  "estimatedMonthlyCommissionPay": null
}
```

