
# Balance and Cash Flow Analytics Report Ack

Response given when analtyics were generated successfully, providing the caller with a report ID which can be used to retrieve the report as JSON or a PDF.

## Structure

`BalanceAndCashFlowAnalyticsReportAck`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountIds` | `List<Long>` | Required | List of account IDs included in the report | List<Long> getAccountIds() | setAccountIds(List<Long> accountIds) |
| `BusinessId` | `Integer` | Optional | Business ID associated with the requested customer | Integer getBusinessId() | setBusinessId(Integer businessId) |
| `CreatedDate` | `String` | Required | Created date of balance analytics request<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getCreatedDate() | setCreatedDate(String createdDate) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `ReportId` | `String` | Required | A report ID | String getReportId() | setReportId(String reportId) |
| `ReportPin` | `String` | Required | PIN that may be used to access the report<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | String getReportPin() | setReportPin(String reportPin) |
| `RequesterName` | `String` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getRequesterName() | setRequesterName(String requesterName) |
| `Title` | `String` | Required | Title of the report | String getTitle() | setTitle(String title) |

## Example (as JSON)

```json
{
  "accountIds": null,
  "createdDate": null,
  "customerId": 1005061234,
  "reportId": "u4hstnnak45g",
  "reportPin": null,
  "title": "Finicity Asset Ready Report (CRA)"
}
```

