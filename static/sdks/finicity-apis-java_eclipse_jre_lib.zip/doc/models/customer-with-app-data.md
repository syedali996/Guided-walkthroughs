
# Customer With App Data

A finicity customer record with application info

## Structure

`CustomerWithAppData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | A customer ID. See Add Customer API for how to create a customer ID. | String getId() | setId(String id) |
| `Username` | `String` | Required | The customer's username, assigned by the partner (a unique identifier), following these rules: minimum 6 characters maximum 255 characters any mix of uppercase, lowercase, numeric, and non-alphabet special characters ! @ . # $ % & * _ – + the use of email in this field is discouraged it is recommended to use a unique non-email identifier. Use of special characters may result in an error (e.g. í, ü, etc.). Usernames are unique. A username used in [Test Drive](https://signup.finicity.com/) can't be reused in other plans. | String getUsername() | setUsername(String username) |
| `FirstName` | `String` | Required | First name(s) / given name(s) | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | Last name(s) / surname(s) | String getLastName() | setLastName(String lastName) |
| `Type` | `String` | Required | The type of customer ("active" or "testing" or "" for all types) | String getType() | setType(String type) |
| `CreatedDate` | `String` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | String getCreatedDate() | setCreatedDate(String createdDate) |
| `LastModifiedDate` | `String` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | String getLastModifiedDate() | setLastModifiedDate(String lastModifiedDate) |
| `ApplicationId` | `String` | Required | `applicationId` value returned from the Get App Registration Status API and the partner assign the customers to. This cannot be changed once set. Only applicable in cases of partners with multiple registered applications. If the partner only has one app, this can usually be omitted. This field is populated after the app is in a status approved. | String getApplicationId() | setApplicationId(String applicationId) |
| `ApplicationName` | `String` | Required | The name of the application assigned to the customer | String getApplicationName() | setApplicationName(String applicationName) |

## Example (as JSON)

```json
{
  "id": "1005061234",
  "username": "customerusername1",
  "firstName": "John",
  "lastName": "Smith",
  "type": "active",
  "createdDate": "1607450357",
  "applicationId": "123456789",
  "applicationName": "Awesome Budget App"
}
```

