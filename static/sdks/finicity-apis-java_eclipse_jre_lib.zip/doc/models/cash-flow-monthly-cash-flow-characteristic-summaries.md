
# Cash Flow Monthly Cash Flow Characteristic Summaries

## Structure

`CashFlowMonthlyCashFlowCharacteristicSummaries`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report | long getMonth() | setMonth(long month) |
| `TotalCreditsLessTotalDebits` | `double` | Required | Total Credits - Total Debits by month across all accounts | double getTotalCreditsLessTotalDebits() | setTotalCreditsLessTotalDebits(double totalCreditsLessTotalDebits) |
| `TotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | Total Credits - Total Debits by month (Without Transfers) across all accounts | double getTotalCreditsLessTotalDebitsLessTransfers() | setTotalCreditsLessTotalDebitsLessTransfers(double totalCreditsLessTotalDebitsLessTransfers) |
| `AverageTransactionAmount` | `double` | Required | Average transaction amount across all accounts | double getAverageTransactionAmount() | setAverageTransactionAmount(double averageTransactionAmount) |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "totalCreditsLessTotalDebits": 15000,
  "totalCreditsLessTotalDebitsLessTransfers": 11000,
  "averageTransactionAmount": 10
}
```

