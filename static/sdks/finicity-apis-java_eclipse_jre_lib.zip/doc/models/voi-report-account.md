
# VOI Report Account

## Structure

`VOIReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Long` | Optional | The ID of the account | Long getId() | setId(Long id) |
| `Number` | `String` | Optional | The account number from the institution (all digits except the last four are obfuscated) | String getNumber() | setNumber(String number) |
| `OwnerName` | `String` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Optional | The account name from the institution | String getName() | setName(String name) |
| `Type` | `String` | Optional | One of the values from account types | String getType() | setType(String type) |
| `AggregationStatusCode` | `Integer` | Optional | The status of the most recent aggregation attempt | Integer getAggregationStatusCode() | setAggregationStatusCode(Integer aggregationStatusCode) |
| `IncomeStreams` | [`List<VOIReportIncomeStream>`](../../doc/models/voi-report-income-stream.md) | Optional | A list of income stream records | List<VOIReportIncomeStream> getIncomeStreams() | setIncomeStreams(List<VOIReportIncomeStream> incomeStreams) |
| `Balance` | `Double` | Optional | The cleared balance of the account as-of `balanceDate` | Double getBalance() | setBalance(Double balance) |
| `AverageMonthlyBalance` | `Double` | Optional | The average monthly balance of this account | Double getAverageMonthlyBalance() | setAverageMonthlyBalance(Double averageMonthlyBalance) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |
| `AvailableBalance` | `Double` | Optional | The available balance for the account | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `CurrentBalance` | `Double` | Optional | Current balance of the account | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `BeginningBalance` | `Double` | Optional | Beginning balance of account per the time period in the report | Double getBeginningBalance() | setBeginningBalance(Double beginningBalance) |
| `MiscDeposits` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` | List<ReportTransaction> getMiscDeposits() | setMiscDeposits(List<ReportTransaction> miscDeposits) |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null,
  "balance": null,
  "averageMonthlyBalance": null,
  "transactions": null,
  "availableBalance": null,
  "currentBalance": null,
  "beginningBalance": null,
  "miscDeposits": null
}
```

