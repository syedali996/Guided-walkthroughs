
# App Statuses

The response for the Get App Registration Status API which returns an array of status objects

## Structure

`AppStatuses`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TotalRecords` | `long` | Required | The total number of results | long getTotalRecords() | setTotalRecords(long totalRecords) |
| `TotalPages` | `long` | Required | The total number of pages | long getTotalPages() | setTotalPages(long totalPages) |
| `PageNumber` | `long` | Required | The current page number | long getPageNumber() | setPageNumber(long pageNumber) |
| `NumberOfRecordsPerPage` | `long` | Required | The number of results per page | long getNumberOfRecordsPerPage() | setNumberOfRecordsPerPage(long numberOfRecordsPerPage) |
| `Applications` | [`List<AppStatus>`](../../doc/models/app-status.md) | Required | A list of applications with their statuses | List<AppStatus> getApplications() | setApplications(List<AppStatus> applications) |

## Example (as JSON)

```json
{
  "totalRecords": 50,
  "totalPages": 5,
  "pageNumber": 2,
  "numberOfRecordsPerPage": 10,
  "applications": {
    "partnerId": "1234583871234",
    "preAppId": "2581",
    "appName": "Awesome Budget App",
    "submittedDate": 1607450357,
    "modifiedDate": 1607450357,
    "status": "P"
  }
}
```

