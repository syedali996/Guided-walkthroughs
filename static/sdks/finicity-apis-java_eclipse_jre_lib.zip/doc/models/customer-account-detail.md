
# Customer Account Detail

Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution.

## Structure

`CustomerAccountDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DateAsOf` | `Long` | Optional | (All Account Types) Most recent date of the following information. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getDateAsOf() | setDateAsOf(Long dateAsOf) |
| `AvailableBalanceAmount` | `double` | Required | (Checking/Savings/CD/MoneyMarket) and (Mortgage/Loan) The available balance (typically the current balance with adjustments for any pending transactions) | double getAvailableBalanceAmount() | setAvailableBalanceAmount(double availableBalanceAmount) |
| `OpenDate` | `Long` | Optional | (Checking/Savings/CD/MoneyMarket) Date when account was opened. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getOpenDate() | setOpenDate(Long openDate) |
| `PeriodStartDate` | `Long` | Optional | (Checking/Savings/CD/MoneyMarket) Start date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPeriodStartDate() | setPeriodStartDate(Long periodStartDate) |
| `PeriodEndDate` | `Long` | Optional | End date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPeriodEndDate() | setPeriodEndDate(Long periodEndDate) |
| `PeriodInterestRate` | `Double` | Optional | (Checking/Savings/CD/MoneyMarket) The APY for the current period interest rate | Double getPeriodInterestRate() | setPeriodInterestRate(Double periodInterestRate) |
| `PeriodDepositAmount` | `Double` | Optional | (Checking/Savings/CD/MoneyMarket) Amount deposited in period | Double getPeriodDepositAmount() | setPeriodDepositAmount(Double periodDepositAmount) |
| `PeriodInterestAmount` | `Double` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued during the current period | Double getPeriodInterestAmount() | setPeriodInterestAmount(Double periodInterestAmount) |
| `InterestYtdAmount` | `Double` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued year-to-date | Double getInterestYtdAmount() | setInterestYtdAmount(Double interestYtdAmount) |
| `InterestPriorYtdAmount` | `Double` | Optional | (Checking/Savings/CD/MoneyMarket) Interest earned in prior year | Double getInterestPriorYtdAmount() | setInterestPriorYtdAmount(Double interestPriorYtdAmount) |
| `MaturityDate` | `Long` | Optional | (Checking/Savings/CD/MoneyMarket) Maturity date of account type. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getMaturityDate() | setMaturityDate(Long maturityDate) |
| `InterestRate` | `String` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The account's current interest rate | String getInterestRate() | setInterestRate(String interestRate) |
| `CreditAvailableAmount` | `Double` | Optional | (Credit Card/Line Of Credit) The available credit (typically the credit limit minus the current balance) | Double getCreditAvailableAmount() | setCreditAvailableAmount(Double creditAvailableAmount) |
| `CreditMaxAmount` | `Double` | Optional | (Credit Card/Line Of Credit) The account's credit limit | Double getCreditMaxAmount() | setCreditMaxAmount(Double creditMaxAmount) |
| `CashAdvanceAvailableAmount` | `Double` | Optional | (Credit Card/Line Of Credit) Currently available cash advance | Double getCashAdvanceAvailableAmount() | setCashAdvanceAvailableAmount(Double cashAdvanceAvailableAmount) |
| `CashAdvanceMaxAmount` | `Double` | Optional | (Credit Card/Line Of Credit) Maximum cash advance amount | Double getCashAdvanceMaxAmount() | setCashAdvanceMaxAmount(Double cashAdvanceMaxAmount) |
| `CashAdvanceBalance` | `Double` | Optional | (Credit Card/Line Of Credit) Balance of current cash advance | Double getCashAdvanceBalance() | setCashAdvanceBalance(Double cashAdvanceBalance) |
| `CashAdvanceInterestRate` | `Double` | Optional | (Credit Card/Line Of Credit) Interest rate for cash advances | Double getCashAdvanceInterestRate() | setCashAdvanceInterestRate(Double cashAdvanceInterestRate) |
| `CurrentBalance` | `Double` | Optional | (Credit Card/Line Of Credit) and (Investment) Current balance | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `PaymentMinAmount` | `Double` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) Minimum payment due | Double getPaymentMinAmount() | setPaymentMinAmount(Double paymentMinAmount) |
| `PaymentDueDate` | `Long` | Optional | (Credit Card/Line Of Credit) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPaymentDueDate() | setPaymentDueDate(Long paymentDueDate) |
| `PreviousBalance` | `Double` | Optional | (Credit Card/Line Of Credit) Prior balance in last statement | Double getPreviousBalance() | setPreviousBalance(Double previousBalance) |
| `StatementStartDate` | `Long` | Optional | (Credit Card/Line Of Credit) Start date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getStatementStartDate() | setStatementStartDate(Long statementStartDate) |
| `StatementEndDate` | `Long` | Optional | (Credit Card/Line Of Credit) End date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getStatementEndDate() | setStatementEndDate(Long statementEndDate) |
| `StatementPurchaseAmount` | `Double` | Optional | (Credit Card/Line Of Credit) Purchase amount of statement period | Double getStatementPurchaseAmount() | setStatementPurchaseAmount(Double statementPurchaseAmount) |
| `StatementFinanceAmount` | `Double` | Optional | (Credit Card/Line Of Credit) Finance amount of statement period | Double getStatementFinanceAmount() | setStatementFinanceAmount(Double statementFinanceAmount) |
| `StatementCreditAmount` | `Double` | Optional | (Credit Card/Line Of Credit) Credit amount applied in statement period | Double getStatementCreditAmount() | setStatementCreditAmount(Double statementCreditAmount) |
| `RewardEarnedBalance` | `Integer` | Optional | (Credit Card/Line Of Credit) Earned reward balance | Integer getRewardEarnedBalance() | setRewardEarnedBalance(Integer rewardEarnedBalance) |
| `PastDueAmount` | `Double` | Optional | (Credit Card/Line Of Credit) Balance past due | Double getPastDueAmount() | setPastDueAmount(Double pastDueAmount) |
| `LastPaymentAmount` | `Double` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The amount received in the last payment | Double getLastPaymentAmount() | setLastPaymentAmount(Double lastPaymentAmount) |
| `LastPaymentDate` | `Long` | Optional | (Credit Card/Line Of Credit) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getLastPaymentDate() | setLastPaymentDate(Long lastPaymentDate) |
| `StatementCloseBalance` | `Double` | Optional | (Credit Card/Line Of Credit) Balance of statement at close | Double getStatementCloseBalance() | setStatementCloseBalance(Double statementCloseBalance) |
| `TermOfMl` | `String` | Optional | (Mortgage/Loan) Length of loan in months | String getTermOfMl() | setTermOfMl(String termOfMl) |
| `MlHolderName` | `String` | Optional | (Mortgage/Loan) Holder of the mortgage or loan | String getMlHolderName() | setMlHolderName(String mlHolderName) |
| `Description` | `String` | Optional | (Mortgage/Loan) Description of loan | String getDescription() | setDescription(String description) |
| `LateFeeAmount` | `Double` | Optional | (Mortgage/Loan) Late fee charged | Double getLateFeeAmount() | setLateFeeAmount(Double lateFeeAmount) |
| `PayoffAmount` | `Double` | Optional | (Mortgage/Loan) The amount required to payoff the loan | Double getPayoffAmount() | setPayoffAmount(Double payoffAmount) |
| `PayoffAmountDate` | `Long` | Optional | (Mortgage/Loan) Date of final payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPayoffAmountDate() | setPayoffAmountDate(Long payoffAmountDate) |
| `OriginalMaturityDate` | `Long` | Optional | (Mortgage/Loan) Original date of loan maturity. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getOriginalMaturityDate() | setOriginalMaturityDate(Long originalMaturityDate) |
| `PrincipalBalance` | `Double` | Optional | (Mortgage/Loan) The principal balance | Double getPrincipalBalance() | setPrincipalBalance(Double principalBalance) |
| `EscrowBalance` | `Double` | Optional | (Mortgage/Loan) The escrow balance | Double getEscrowBalance() | setEscrowBalance(Double escrowBalance) |
| `InterestPeriod` | `String` | Optional | (Mortgage/Loan) Period of interest | String getInterestPeriod() | setInterestPeriod(String interestPeriod) |
| `InitialMlAmount` | `Double` | Optional | (Mortgage/Loan) Original loan amount | Double getInitialMlAmount() | setInitialMlAmount(Double initialMlAmount) |
| `InitialMlDate` | `Long` | Optional | (Mortgage/Loan) Original date of loan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getInitialMlDate() | setInitialMlDate(Long initialMlDate) |
| `NextPaymentPrincipalAmount` | `Double` | Optional | (Mortgage/Loan) Amount towards principal in next payment | Double getNextPaymentPrincipalAmount() | setNextPaymentPrincipalAmount(Double nextPaymentPrincipalAmount) |
| `NextPaymentInterestAmount` | `Double` | Optional | (Mortgage/Loan) Amount of interest in next payment | Double getNextPaymentInterestAmount() | setNextPaymentInterestAmount(Double nextPaymentInterestAmount) |
| `NextPayment` | `Double` | Optional | (Mortgage/Loan) Minimum payment due | Double getNextPayment() | setNextPayment(Double nextPayment) |
| `NextPaymentDate` | `Long` | Optional | (Mortgage/Loan) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getNextPaymentDate() | setNextPaymentDate(Long nextPaymentDate) |
| `LastPaymentDueDate` | `Long` | Optional | (Mortgage/Loan) Due date of last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getLastPaymentDueDate() | setLastPaymentDueDate(Long lastPaymentDueDate) |
| `LastPaymentReceiveDate` | `Long` | Optional | (Mortgage/Loan) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getLastPaymentReceiveDate() | setLastPaymentReceiveDate(Long lastPaymentReceiveDate) |
| `LastPaymentPrincipalAmount` | `Double` | Optional | (Mortgage/Loan) Amount towards principal in last payment | Double getLastPaymentPrincipalAmount() | setLastPaymentPrincipalAmount(Double lastPaymentPrincipalAmount) |
| `LastPaymentInterestAmount` | `Double` | Optional | (Mortgage/Loan) Amount of interest in last payment | Double getLastPaymentInterestAmount() | setLastPaymentInterestAmount(Double lastPaymentInterestAmount) |
| `LastPaymentEscrowAmount` | `Double` | Optional | (Mortgage/Loan) Amount towards escrow in last payment | Double getLastPaymentEscrowAmount() | setLastPaymentEscrowAmount(Double lastPaymentEscrowAmount) |
| `LastPaymentLastFeeAmount` | `Double` | Optional | (Mortgage/Loan) Amount of last fee in last payment | Double getLastPaymentLastFeeAmount() | setLastPaymentLastFeeAmount(Double lastPaymentLastFeeAmount) |
| `LastPaymentLateCharge` | `Double` | Optional | (Mortgage/Loan) Amount of late charge in last payment | Double getLastPaymentLateCharge() | setLastPaymentLateCharge(Double lastPaymentLateCharge) |
| `YtdPrincipalPaid` | `Double` | Optional | (Mortgage/Loan) Principal paid year-to-date | Double getYtdPrincipalPaid() | setYtdPrincipalPaid(Double ytdPrincipalPaid) |
| `YtdInterestPaid` | `Double` | Optional | (Mortgage/Loan) Interest paid year-to-date | Double getYtdInterestPaid() | setYtdInterestPaid(Double ytdInterestPaid) |
| `YtdInsurancePaid` | `Double` | Optional | (Mortgage/Loan) Insurance paid year-to-date | Double getYtdInsurancePaid() | setYtdInsurancePaid(Double ytdInsurancePaid) |
| `YtdTaxPaid` | `Double` | Optional | (Mortgage/Loan) Tax paid year-to-date | Double getYtdTaxPaid() | setYtdTaxPaid(Double ytdTaxPaid) |
| `AutoPayEnrolled` | `Boolean` | Optional | (Mortgage/Loan) Enrolled in autopay (F/Y) | Boolean getAutoPayEnrolled() | setAutoPayEnrolled(Boolean autoPayEnrolled) |
| `Collateral` | `String` | Optional | (Mortgage/Loan) Collateral on loan | String getCollateral() | setCollateral(String collateral) |
| `CurrentSchool` | `String` | Optional | (Mortgage/Loan) Current school | String getCurrentSchool() | setCurrentSchool(String currentSchool) |
| `FirstPaymentDate` | `Long` | Optional | (Mortgage/Loan) First payment due date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getFirstPaymentDate() | setFirstPaymentDate(Long firstPaymentDate) |
| `FirstMortgage` | `Boolean` | Optional | (Mortgage/Loan) First mortgage (F/Y) | Boolean getFirstMortgage() | setFirstMortgage(Boolean firstMortgage) |
| `LoanPaymentFreq` | `String` | Optional | (Mortgage/Loan) Frequency of payments (monthly, etc.) | String getLoanPaymentFreq() | setLoanPaymentFreq(String loanPaymentFreq) |
| `OriginalSchool` | `String` | Optional | (Mortgage/Loan) Original school | String getOriginalSchool() | setOriginalSchool(String originalSchool) |
| `RecurringPaymentAmount` | `Double` | Optional | (Mortgage/Loan) Recurring payment amount | Double getRecurringPaymentAmount() | setRecurringPaymentAmount(Double recurringPaymentAmount) |
| `Lender` | `String` | Optional | (Mortgage/Loan) Owner of loan | String getLender() | setLender(String lender) |
| `EndingBalanceAmount` | `Double` | Optional | (Mortgage/Loan) Ending balance | Double getEndingBalanceAmount() | setEndingBalanceAmount(Double endingBalanceAmount) |
| `LoanTermType` | `String` | Optional | (Mortgage/Loan) Type of loan term | String getLoanTermType() | setLoanTermType(String loanTermType) |
| `PaymentsMade` | `Integer` | Optional | (Mortgage/Loan) Number of payments made | Integer getPaymentsMade() | setPaymentsMade(Integer paymentsMade) |
| `BalloonAmount` | `Double` | Optional | (Mortgage/Loan) Balloon payment amount | Double getBalloonAmount() | setBalloonAmount(Double balloonAmount) |
| `ProjectedInterest` | `Double` | Optional | (Mortgage/Loan) Projected interest on the loan | Double getProjectedInterest() | setProjectedInterest(Double projectedInterest) |
| `InterestPaidLtd` | `Double` | Optional | (Mortgage/Loan) Interest paid since inception of loan (life to date) | Double getInterestPaidLtd() | setInterestPaidLtd(Double interestPaidLtd) |
| `InterestRateType` | `String` | Optional | (Mortgage/Loan) Type of interest rate | String getInterestRateType() | setInterestRateType(String interestRateType) |
| `LoanPaymentType` | `String` | Optional | (Mortgage/Loan) Type of loan payment | String getLoanPaymentType() | setLoanPaymentType(String loanPaymentType) |
| `RepaymentPlan` | `String` | Optional | (Mortgage/Loan) Type of repayment plan for the student loan | String getRepaymentPlan() | setRepaymentPlan(String repaymentPlan) |
| `PaymentsRemaining` | `Integer` | Optional | (Mortgage/Loan) Number of payments remaining before loan is paid off | Integer getPaymentsRemaining() | setPaymentsRemaining(Integer paymentsRemaining) |
| `MarginBalance` | `Double` | Optional | (Investment) Net interest earned after deducting interest paid out | Double getMarginBalance() | setMarginBalance(Double marginBalance) |
| `ShortBalance` | `Double` | Optional | (Investment) Sum of short balance | Double getShortBalance() | setShortBalance(Double shortBalance) |
| `AvailableCashBalance` | `Double` | Optional | (Investment) Amount available for cash withdrawal | Double getAvailableCashBalance() | setAvailableCashBalance(Double availableCashBalance) |
| `MaturityValueAmount` | `Double` | Optional | (Investment) amount payable to an investor at maturity | Double getMaturityValueAmount() | setMaturityValueAmount(Double maturityValueAmount) |
| `VestedBalance` | `Double` | Optional | (Investment) Vested amount in account | Double getVestedBalance() | setVestedBalance(Double vestedBalance) |
| `EmpMatchAmount` | `Double` | Optional | (Investment) Employer matched contributions | Double getEmpMatchAmount() | setEmpMatchAmount(Double empMatchAmount) |
| `EmpPretaxContribAmount` | `Double` | Optional | (Investment) Employer pretax contribution amount | Double getEmpPretaxContribAmount() | setEmpPretaxContribAmount(Double empPretaxContribAmount) |
| `EmpPretaxContribAmountYtd` | `Double` | Optional | (Investment) Employer pretax contribution amount year to date | Double getEmpPretaxContribAmountYtd() | setEmpPretaxContribAmountYtd(Double empPretaxContribAmountYtd) |
| `ContribTotalYtd` | `Double` | Optional | (Investment) Total year to date contributions | Double getContribTotalYtd() | setContribTotalYtd(Double contribTotalYtd) |
| `CashBalanceAmount` | `Double` | Optional | (Investment) Cash balance of account | Double getCashBalanceAmount() | setCashBalanceAmount(Double cashBalanceAmount) |
| `PreTaxAmount` | `Double` | Optional | (Investment) Pre tax amount of total balance | Double getPreTaxAmount() | setPreTaxAmount(Double preTaxAmount) |
| `AfterTaxAmount` | `Double` | Optional | (Investment) Post tax amount of total balance | Double getAfterTaxAmount() | setAfterTaxAmount(Double afterTaxAmount) |
| `MatchAmount` | `Double` | Optional | (Investment) Amount matched | Double getMatchAmount() | setMatchAmount(Double matchAmount) |
| `ProfitSharingAmount` | `Double` | Optional | (Investment) Amount of balance for profit sharing | Double getProfitSharingAmount() | setProfitSharingAmount(Double profitSharingAmount) |
| `RolloverAmount` | `Double` | Optional | (Investment) Amount of balance rolled over from original account (401k, etc.) | Double getRolloverAmount() | setRolloverAmount(Double rolloverAmount) |
| `OtherVestAmount` | `Double` | Optional | (Investment) Other vested amount | Double getOtherVestAmount() | setOtherVestAmount(Double otherVestAmount) |
| `OtherNonvestAmount` | `Double` | Optional | (Investment) Other nonvested amount | Double getOtherNonvestAmount() | setOtherNonvestAmount(Double otherNonvestAmount) |
| `CurrentLoanBalance` | `Double` | Optional | (Investment) Current loan balance | Double getCurrentLoanBalance() | setCurrentLoanBalance(Double currentLoanBalance) |
| `LoanRate` | `Double` | Optional | (Investment) Interest rate of loan | Double getLoanRate() | setLoanRate(Double loanRate) |
| `BuyPower` | `Double` | Optional | (Investment) Money available to buy securities | Double getBuyPower() | setBuyPower(Double buyPower) |
| `RolloverLtd` | `Double` | Optional | (Investment) Life to date of money rolled over | Double getRolloverLtd() | setRolloverLtd(Double rolloverLtd) |
| `LoanAwardId` | `String` | Optional | (Student Loan) The federal unique loan identifying number | String getLoanAwardId() | setLoanAwardId(String loanAwardId) |
| `OriginalInterestRate` | `Double` | Optional | (Student Loan) The original interest rate to which the loan was disbursed, in APY | Double getOriginalInterestRate() | setOriginalInterestRate(Double originalInterestRate) |
| `Guarantor` | `String` | Optional | (Student Loan) The financial institution guarantor of the loan (who will pay the loan amount to the owner if the borrower defaults) | String getGuarantor() | setGuarantor(String guarantor) |
| `Owner` | `String` | Optional | (Student Loan) Owner of the loan | String getOwner() | setOwner(String owner) |
| `InterestSubsidyType` | `String` | Optional | (Student Loan) The indication of the presence of an interest subsidy (i.e. subsidized) | String getInterestSubsidyType() | setInterestSubsidyType(String interestSubsidyType) |
| `InterestBalance` | `Double` | Optional | (Student Loan) The total outstanding interest balance | Double getInterestBalance() | setInterestBalance(Double interestBalance) |
| `RemainingTermOfMl` | `Double` | Optional | (Student Loan) The number of months still outstanding on a loan | Double getRemainingTermOfMl() | setRemainingTermOfMl(Double remainingTermOfMl) |
| `InitialInterestRate` | `Double` | Optional | (Student Loan) Initial interest rate of loan | Double getInitialInterestRate() | setInitialInterestRate(Double initialInterestRate) |
| `FeesBalance` | `Double` | Optional | (Student Loan) The total outstanding fees balance | Double getFeesBalance() | setFeesBalance(Double feesBalance) |
| `LoanYtdInterestPaid` | `Double` | Optional | (Student Loan) Loan interest paid year-to-date | Double getLoanYtdInterestPaid() | setLoanYtdInterestPaid(Double loanYtdInterestPaid) |
| `LoanYtdFeesPaid` | `Double` | Optional | (Student Loan) Loan fees paid year-to-date | Double getLoanYtdFeesPaid() | setLoanYtdFeesPaid(Double loanYtdFeesPaid) |
| `LoanYtdPrincipalPaid` | `Double` | Optional | (Student Loan) Loan principal paid year-to-date | Double getLoanYtdPrincipalPaid() | setLoanYtdPrincipalPaid(Double loanYtdPrincipalPaid) |
| `LoanStatus` | `String` | Optional | (Student Loan) The repayment status phase (i.e. In School, Grace, Repayment, Deferment, Forbearance) | String getLoanStatus() | setLoanStatus(String loanStatus) |
| `LoanStatusStartDate` | `Long` | Optional | (Student Loan) The start date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getLoanStatusStartDate() | setLoanStatusStartDate(Long loanStatusStartDate) |
| `LoanStatusEndDate` | `Long` | Optional | (Student Loan) The end date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getLoanStatusEndDate() | setLoanStatusEndDate(Long loanStatusEndDate) |
| `WeightedInterestRate` | `Double` | Optional | (Student Loan) The interest rate of multiple interest rates and balances at the group level, in APY | Double getWeightedInterestRate() | setWeightedInterestRate(Double weightedInterestRate) |
| `RepaymentPlanStartDate` | `Long` | Optional | (Student Loan) The start date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getRepaymentPlanStartDate() | setRepaymentPlanStartDate(Long repaymentPlanStartDate) |
| `RepaymentPlanEndDate` | `Long` | Optional | (Student Loan) The end date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getRepaymentPlanEndDate() | setRepaymentPlanEndDate(Long repaymentPlanEndDate) |
| `ExpectedPayoffDate` | `Long` | Optional | (Student Loan) The expected date of the payoff date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getExpectedPayoffDate() | setExpectedPayoffDate(Long expectedPayoffDate) |
| `OutOfSchoolDate` | `Long` | Optional | (Student Loan) The date the borrower graduated or dropped below half-time enrollment in school. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getOutOfSchoolDate() | setOutOfSchoolDate(Long outOfSchoolDate) |
| `ConvertToRepayment` | `Long` | Optional | (Student Loan) The date the loan enters into repayment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getConvertToRepayment() | setConvertToRepayment(Long convertToRepayment) |
| `DaysDelinquent` | `Integer` | Optional | (Student Loan) The number of days past a due date that a payment should have been made | Integer getDaysDelinquent() | setDaysDelinquent(Integer daysDelinquent) |
| `TotalPrincipalPaid` | `Double` | Optional | (Student Loan) The total amount paid towards the principal balance | Double getTotalPrincipalPaid() | setTotalPrincipalPaid(Double totalPrincipalPaid) |
| `TotalInterestPaid` | `Double` | Optional | (Student Loan) The total amount paid towards interest | Double getTotalInterestPaid() | setTotalInterestPaid(Double totalInterestPaid) |
| `TotalAmountPaid` | `Double` | Optional | (Student Loan) The total amount paid | Double getTotalAmountPaid() | setTotalAmountPaid(Double totalAmountPaid) |

## Example (as JSON)

```json
{
  "availableBalanceAmount": 5678.78
}
```

