
# Institution

A financial institution

## Structure

`Institution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `long` | Required | The ID of a financial institution, represented as a number | long getId() | setId(long id) |
| `Name` | `String` | Optional | The name of the institution | String getName() | setName(String name) |
| `TransAgg` | `boolean` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product | boolean getTransAgg() | setTransAgg(boolean transAgg) |
| `Ach` | `boolean` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product | boolean getAch() | setAch(boolean ach) |
| `StateAgg` | `boolean` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product | boolean getStateAgg() | setStateAgg(boolean stateAgg) |
| `Voi` | `boolean` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product | boolean getVoi() | setVoi(boolean voi) |
| `Voa` | `boolean` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product | boolean getVoa() | setVoa(boolean voa) |
| `Aha` | `boolean` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product | boolean getAha() | setAha(boolean aha) |
| `AvailBalance` | `boolean` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product | boolean getAvailBalance() | setAvailBalance(boolean availBalance) |
| `AccountOwner` | `boolean` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product | boolean getAccountOwner() | setAccountOwner(boolean accountOwner) |
| `StudentLoanData` | `Boolean` | Optional | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product | Boolean getStudentLoanData() | setStudentLoanData(Boolean studentLoanData) |
| `LoanPaymentDetails` | `Boolean` | Optional | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product | Boolean getLoanPaymentDetails() | setLoanPaymentDetails(Boolean loanPaymentDetails) |
| `AccountTypeDescription` | `String` | Optional | Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance | String getAccountTypeDescription() | setAccountTypeDescription(String accountTypeDescription) |
| `Phone` | `String` | Optional | A phone number | String getPhone() | setPhone(String phone) |
| `UrlHomeApp` | `String` | Optional | The URL of the institution's primary home page | String getUrlHomeApp() | setUrlHomeApp(String urlHomeApp) |
| `UrlLogonApp` | `String` | Optional | The URL of the institution's login page | String getUrlLogonApp() | setUrlLogonApp(String urlLogonApp) |
| `OauthEnabled` | `boolean` | Required | "true": The institution is an OAuth connection<br><br>"false": The institution isn't an OAuth connection | boolean getOauthEnabled() | setOauthEnabled(boolean oauthEnabled) |
| `UrlForgotPassword` | `String` | Optional | Institution's forgot password page | String getUrlForgotPassword() | setUrlForgotPassword(String urlForgotPassword) |
| `UrlOnlineRegistration` | `String` | Optional | Institution's signup page | String getUrlOnlineRegistration() | setUrlOnlineRegistration(String urlOnlineRegistration) |
| `Class` | `String` | Optional | Institution's class | String getClassField() | setClassField(String classField) |
| `SpecialText` | `String` | Optional | Special instructions given to customers for login | String getSpecialText() | setSpecialText(String specialText) |
| `TimeZone` | `String` | Optional | The time zone of the institution. | String getTimeZone() | setTimeZone(String timeZone) |
| `SpecialInstructions` | `List<String>` | Optional | Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.<br><br>Note: this helps the customer to provide the proper permission for data needed for the application. | List<String> getSpecialInstructions() | setSpecialInstructions(List<String> specialInstructions) |
| `SpecialInstutionsTitle` | `String` | Optional | The title of the special instructions, if one exists or is required. | String getSpecialInstutionsTitle() | setSpecialInstutionsTitle(String specialInstutionsTitle) |
| `Address` | [`InstitutionAddress`](../../doc/models/institution-address.md) | Optional | The address of a financial institution | InstitutionAddress getAddress() | setAddress(InstitutionAddress address) |
| `Currency` | `String` | Required | A currency code | String getCurrency() | setCurrency(String currency) |
| `Email` | `String` | Optional | An email address | String getEmail() | setEmail(String email) |
| `Status` | `String` | Required | Status for the institution: "online", "offline", "maintenance", "testing" | String getStatus() | setStatus(String status) |
| `NewInstitutionId` | `Long` | Optional | The ID of a financial institution, represented as a number | Long getNewInstitutionId() | setNewInstitutionId(Long newInstitutionId) |
| `Branding` | [`Branding`](../../doc/models/branding.md) | Optional | All assets are SVGs so can be slightly resized without any issues. | Branding getBranding() | setBranding(Branding branding) |
| `OauthInstitutionId` | `Long` | Optional | The ID of a financial institution, represented as a number | Long getOauthInstitutionId() | setOauthInstitutionId(Long oauthInstitutionId) |

## Example (as JSON)

```json
{
  "id": 4222,
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "oauthEnabled": true,
  "currency": "USD",
  "status": "online"
}
```

