
# Cash Flow Monthly Cash Flow Credits

## Structure

`CashFlowMonthlyCashFlowCredits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report | long getMonth() | setMonth(long month) |
| `NumberOfCredits` | `String` | Required | Number of credits by month | String getNumberOfCredits() | setNumberOfCredits(String numberOfCredits) |
| `TotalCreditsAmount` | `double` | Required | Total amount of credits by month | double getTotalCreditsAmount() | setTotalCreditsAmount(double totalCreditsAmount) |
| `LargestCredit` | `double` | Required | Largest credit by month | double getLargestCredit() | setLargestCredit(double largestCredit) |
| `NumberOfCreditsLessTransfers` | `String` | Required | Number of credits by month (less transfers) | String getNumberOfCreditsLessTransfers() | setNumberOfCreditsLessTransfers(String numberOfCreditsLessTransfers) |
| `TotalCreditsAmountLessTransfers` | `double` | Required | Total amount of credits by month (less transfers) | double getTotalCreditsAmountLessTransfers() | setTotalCreditsAmountLessTransfers(double totalCreditsAmountLessTransfers) |
| `AverageCreditAmount` | `double` | Required | The average credit amount | double getAverageCreditAmount() | setAverageCreditAmount(double averageCreditAmount) |
| `EstimatedNumberOfLoanDeposits` | `String` | Required | The estimated number of loan deposits | String getEstimatedNumberOfLoanDeposits() | setEstimatedNumberOfLoanDeposits(String estimatedNumberOfLoanDeposits) |
| `EstimatedLoanDepositAmount` | `double` | Required | The estimated loan deposit amount | double getEstimatedLoanDepositAmount() | setEstimatedLoanDepositAmount(double estimatedLoanDepositAmount) |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "3",
  "totalCreditsAmount": 5000,
  "largestCredit": 2000,
  "numberOfCreditsLessTransfers": "2",
  "totalCreditsAmountLessTransfers": 4000,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

