
# Obb Data Availability

## Structure

`ObbDataAvailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `HistoricAvailabilityBeginDate` | `String` | Required | Begin date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getHistoricAvailabilityBeginDate() | setHistoricAvailabilityBeginDate(String historicAvailabilityBeginDate) |
| `HistoricAvailabilityEndDate` | `String` | Required | End date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getHistoricAvailabilityEndDate() | setHistoricAvailabilityEndDate(String historicAvailabilityEndDate) |
| `HistoricAvailableDays` | `int` | Required | Days for which transaction details are available | int getHistoricAvailableDays() | setHistoricAvailableDays(int historicAvailableDays) |
| `HistoricDataAvailability` | `String` | Required | Description of historic data availability<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getHistoricDataAvailability() | setHistoricDataAvailability(String historicDataAvailability) |

## Example (as JSON)

```json
{
  "historicAvailabilityBeginDate": "2022-03-01",
  "historicAvailabilityEndDate": "2022-03-30",
  "historicAvailableDays": 30,
  "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
}
```

