
# Direct Deposit

## Structure

`DirectDeposit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AmountCurrent` | `Double` | Optional | The amount of the deposit | Double getAmountCurrent() | setAmountCurrent(Double amountCurrent) |
| `AccountLastFour` | `String` | Optional | The last four numbers of the account the deposit went into | String getAccountLastFour() | setAccountLastFour(String accountLastFour) |

## Example (as JSON)

```json
{
  "amountCurrent": null,
  "accountLastFour": null
}
```

