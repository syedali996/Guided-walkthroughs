
# Get Obb Analytics Report Fcra Response

## Structure

`GetObbAnalyticsReportFcraResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountResults` | [`List<BalanceAnalyticsAccountResult1>`](../../doc/models/balance-analytics-account-result-1.md) | Optional | Balance results per account | List<BalanceAnalyticsAccountResult1> getAccountResults() | setAccountResults(List<BalanceAnalyticsAccountResult1> accountResults) |
| `BusinessId` | `Integer` | Optional | Business ID | Integer getBusinessId() | setBusinessId(Integer businessId) |
| `BusinessSummary` | [`BusinessSummary`](../../doc/models/business-summary.md) | Optional | - | BusinessSummary getBusinessSummary() | setBusinessSummary(BusinessSummary businessSummary) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `ReportHeader` | [`ReportHeader`](../../doc/models/report-header.md) | Required | - | ReportHeader getReportHeader() | setReportHeader(ReportHeader reportHeader) |
| `RequesterName` | `String` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getRequesterName() | setRequesterName(String requesterName) |
| `Title` | `String` | Required | Title of the report | String getTitle() | setTitle(String title) |
| `TotalRevenue` | `Double` | Optional | The total revenue | Double getTotalRevenue() | setTotalRevenue(Double totalRevenue) |

## Example (as JSON)

```json
{
  "customerId": 1005061234,
  "reportHeader": {
    "reportDate": "03/17/2022 04:28:38",
    "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
  },
  "title": "Finicity Asset Ready Report (CRA)"
}
```

