
# Payroll Employee Address

## Structure

`PayrollEmployeeAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Address1` | `String` | Optional | Employee address as stated by the employer in the payroll system | String getAddress1() | setAddress1(String address1) |
| `City` | `String` | Optional | Employee city as stated by the employer in the payroll system | String getCity() | setCity(String city) |
| `State` | `String` | Optional | Employee state as stated by the employer in the payroll system | String getState() | setState(String state) |
| `Zip` | `String` | Optional | Employee zip code as stated by the employer in the payroll system | String getZip() | setZip(String zip) |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

