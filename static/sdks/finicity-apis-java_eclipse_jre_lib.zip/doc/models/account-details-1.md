
# Account Details 1

## Structure

`AccountDetails1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountNumberDisplay` | `String` | Optional | The account number from a financial institution in truncated format<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | String getAccountNumberDisplay() | setAccountNumberDisplay(String accountNumberDisplay) |
| `AccountOwner` | [`ObbAccountOwner`](../../doc/models/obb-account-owner.md) | Required | - | ObbAccountOwner getAccountOwner() | setAccountOwner(ObbAccountOwner accountOwner) |
| `AggregationAttemptDate` | `String` | Optional | A timestamp showing the last aggregation attempt. This will not be present until you have run your first aggregation for the account.<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getAggregationAttemptDate() | setAggregationAttemptDate(String aggregationAttemptDate) |
| `AggregationStatusCode` | `Integer` | Optional | The status of the most recent aggregation attempt. This will not be present until you have run your first aggregation for the account | Integer getAggregationStatusCode() | setAggregationStatusCode(Integer aggregationStatusCode) |
| `AggregationSuccessDate` | `String` | Optional | A timestamp showing the last successful aggregation of the account. This will not be present until you have run your first aggregation for the account.<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getAggregationSuccessDate() | setAggregationSuccessDate(String aggregationSuccessDate) |
| `Currency` | `String` | Optional | The currency of the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `5` | String getCurrency() | setCurrency(String currency) |
| `CurrentBalance` | `Double` | Optional | Current reported balance of the account | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `Id` | `long` | Required | An account ID represented as a number | long getId() | setId(long id) |
| `Institution` | [`ObbInstitution`](../../doc/models/obb-institution.md) | Required | - | ObbInstitution getInstitution() | setInstitution(ObbInstitution institution) |
| `InstitutionLoginId` | `Long` | Optional | An institution login ID (from the account record), represented as a number | Long getInstitutionLoginId() | setInstitutionLoginId(Long institutionLoginId) |
| `Name` | `String` | Optional | The account name from the institution<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | String getName() | setName(String name) |
| `RealAccountNumberLast4` | `Integer` | Optional | The last 4 digits of the ACH account number | Integer getRealAccountNumberLast4() | setRealAccountNumberLast4(Integer realAccountNumberLast4) |
| `Status` | `String` | Optional | pending during account discovery, always active following successful account activation<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | String getStatus() | setStatus(String status) |
| `Type` | `String` | Optional | Account type, e.g. checking/saving<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | String getType() | setType(String type) |

## Example (as JSON)

```json
{
  "accountOwner": {
    "address": "123 Main St, Portland, OR 12345",
    "name": "Johnny Appleseed"
  },
  "id": 5011648377,
  "institution": {
    "institutionId": 12345
  }
}
```

