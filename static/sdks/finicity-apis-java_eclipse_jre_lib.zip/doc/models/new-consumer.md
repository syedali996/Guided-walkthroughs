
# New Consumer

A new consumer to be created

## Structure

`NewConsumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Required | First name(s) / given name(s) | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | Last name(s) / surname(s) | String getLastName() | setLastName(String lastName) |
| `Address` | `String` | Required | A street address | String getAddress() | setAddress(String address) |
| `City` | `String` | Required | A city | String getCity() | setCity(String city) |
| `State` | `String` | Required | A state | String getState() | setState(String state) |
| `Zip` | `String` | Required | A ZIP code | String getZip() | setZip(String zip) |
| `Phone` | `String` | Required | A phone number | String getPhone() | setPhone(String phone) |
| `Ssn` | `String` | Required | A full SSN with or without hyphens | String getSsn() | setSsn(String ssn) |
| `Birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date | Birthday getBirthday() | setBirthday(Birthday birthday) |
| `Email` | `String` | Optional | An email address | String getEmail() | setEmail(String email) |
| `Suffix` | `String` | Optional | A person suffix | String getSuffix() | setSuffix(String suffix) |

## Example (as JSON)

```json
{
  "firstName": "John",
  "lastName": "Smith",
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "999-99-9999",
  "birthday": null
}
```

