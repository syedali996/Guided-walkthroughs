
# VOIETX Verify Report Income Stream

## Structure

`VOIETXVerifyReportIncomeStream`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | Finicity’s income stream ID | String getId() | setId(String id) |
| `Name` | `String` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream | String getName() | setName(String name) |
| `Status` | `String` | Required | Possible values: "ACTIVE", "INACTIVE" | String getStatus() | setStatus(String status) |
| `Confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) | int getConfidence() | setConfidence(int confidence) |
| `Cadence` | [`CadenceDetails`](../../doc/models/cadence-details.md) | Required | - | CadenceDetails getCadence() | setCadence(CadenceDetails cadence) |
| `NetMonthly` | [`List<NetMonthly>`](../../doc/models/net-monthly.md) | Required | A list of net monthly records. One instance for each complete calendar month in the report. | List<NetMonthly> getNetMonthly() | setNetMonthly(List<NetMonthly> netMonthly) |
| `NetAnnual` | `double` | Required | Sum of all values in `netMonthlyIncome` over the previous 12 months | double getNetAnnual() | setNetAnnual(double netAnnual) |
| `ProjectedNetAnnual` | `double` | Required | Projected net income over the next 12 months, across all income streams, based on `netAnnualIncome` | double getProjectedNetAnnual() | setProjectedNetAnnual(double projectedNetAnnual) |
| `EstimatedGrossAnnual` | `double` | Required | Before-tax gross annual income (estimated from `netAnnual`) across all income stream in the past 12 months | double getEstimatedGrossAnnual() | setEstimatedGrossAnnual(double estimatedGrossAnnual) |
| `ProjectedGrossAnnual` | `double` | Required | Projected gross income over the next 12 months, across all active income streams, based on `projectedNetAnnual` | double getProjectedGrossAnnual() | setProjectedGrossAnnual(double projectedGrossAnnual) |
| `AverageMonthlyIncomeNet` | `double` | Required | Monthly average amount over the previous 24 months | double getAverageMonthlyIncomeNet() | setAverageMonthlyIncomeNet(double averageMonthlyIncomeNet) |
| `IncomeStreamMonths` | `int` | Required | The number of months the income transactions are observed | int getIncomeStreamMonths() | setIncomeStreamMonths(int incomeStreamMonths) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | A list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voietxverify",
  "name": "none",
  "status": null,
  "confidence": 70,
  "cadence": null,
  "netMonthly": {
    "month": 1522562400,
    "net": 2004.77
  },
  "netAnnual": 110475.7,
  "projectedNetAnnual": 0,
  "estimatedGrossAnnual": 12321.1,
  "projectedGrossAnnual": 151609,
  "averageMonthlyIncomeNet": 9206.31,
  "incomeStreamMonths": 24,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

