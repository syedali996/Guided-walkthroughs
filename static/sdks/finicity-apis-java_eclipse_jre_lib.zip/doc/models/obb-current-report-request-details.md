
# Obb Current Report Request Details

## Structure

`ObbCurrentReportRequestDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReportBeginDate` | `String` | Required | Date from when the requested data is available<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getReportBeginDate() | setReportBeginDate(String reportBeginDate) |
| `ReportEndDate` | `String` | Required | Date to which the requested data is available<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getReportEndDate() | setReportEndDate(String reportEndDate) |
| `ReportRequestDate` | `String` | Required | The date and time the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getReportRequestDate() | setReportRequestDate(String reportRequestDate) |
| `RequestedDaysForReport` | `int` | Required | Number of days requested for the report | int getRequestedDaysForReport() | setRequestedDaysForReport(int requestedDaysForReport) |
| `RequestedReportBeginDate` | `String` | Required | Date the report would have began on if enough data was available for which the partner requested<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getRequestedReportBeginDate() | setRequestedReportBeginDate(String requestedReportBeginDate) |

## Example (as JSON)

```json
{
  "reportBeginDate": "2022-03-01",
  "reportEndDate": "2022-03-30",
  "reportRequestDate": "03/30/2022 21:47:19",
  "requestedDaysForReport": 90,
  "requestedReportBeginDate": "2022-01-01"
}
```

