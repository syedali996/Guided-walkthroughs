
# Net Monthly

## Structure

`NetMonthly`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | `long` | Required | Timestamp for the first day of this month | long getMonth() | setMonth(long month) |
| `Net` | `double` | Required | Total income during the given month, across all income streams | double getNet() | setNet(double net) |

## Example (as JSON)

```json
{
  "month": 1522562400,
  "net": 2004.77
}
```

