
# Consumer

A finicity consumer record

## Structure

`Consumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getId() | setId(String id) |
| `FirstName` | `String` | Required | First name(s) / given name(s) | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | Last name(s) / surname(s) | String getLastName() | setLastName(String lastName) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `Address` | `String` | Required | A street address | String getAddress() | setAddress(String address) |
| `City` | `String` | Required | A city | String getCity() | setCity(String city) |
| `State` | `String` | Required | A state | String getState() | setState(String state) |
| `Zip` | `String` | Required | A ZIP code | String getZip() | setZip(String zip) |
| `Phone` | `String` | Required | A phone number | String getPhone() | setPhone(String phone) |
| `Ssn` | `String` | Required | Last 4 digits of a SSN | String getSsn() | setSsn(String ssn) |
| `Birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date | Birthday getBirthday() | setBirthday(Birthday birthday) |
| `Email` | `String` | Required | An email address | String getEmail() | setEmail(String email) |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getCreatedDate() | setCreatedDate(long createdDate) |
| `Suffix` | `String` | Optional | A person suffix | String getSuffix() | setSuffix(String suffix) |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "9999",
  "birthday": null,
  "email": "finicity@test.com",
  "createdDate": 1607450357
}
```

