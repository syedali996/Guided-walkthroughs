
# VOE Transactions Report Account

## Structure

`VOETransactionsReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Long` | Optional | The ID of the account | Long getId() | setId(Long id) |
| `Number` | `String` | Optional | The account number from the institution (all digits except the last four are obfuscated) | String getNumber() | setNumber(String number) |
| `OwnerName` | `String` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Optional | The account name from the institution | String getName() | setName(String name) |
| `Type` | `String` | Optional | One of the values from account types | String getType() | setType(String type) |
| `AggregationStatusCode` | `Integer` | Optional | The status of the most recent aggregation attempt | Integer getAggregationStatusCode() | setAggregationStatusCode(Integer aggregationStatusCode) |
| `IncomeStreams` | [`List<VOETransactionsReportIncomeStream>`](../../doc/models/voe-transactions-report-income-stream.md) | Optional | A list of income stream records | List<VOETransactionsReportIncomeStream> getIncomeStreams() | setIncomeStreams(List<VOETransactionsReportIncomeStream> incomeStreams) |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null
}
```

