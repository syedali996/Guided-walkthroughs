
# Consumer Update

## Structure

`ConsumerUpdate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | First name(s) / given name(s) | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Optional | Last name(s) / surname(s) | String getLastName() | setLastName(String lastName) |
| `Address` | `String` | Optional | A street address | String getAddress() | setAddress(String address) |
| `City` | `String` | Optional | A city | String getCity() | setCity(String city) |
| `State` | `String` | Optional | A state | String getState() | setState(String state) |
| `Zip` | `String` | Optional | A ZIP code | String getZip() | setZip(String zip) |
| `Phone` | `String` | Optional | A phone number | String getPhone() | setPhone(String phone) |
| `Ssn` | `String` | Optional | A full SSN with or without hyphens | String getSsn() | setSsn(String ssn) |
| `Birthday` | [`Birthday`](../../doc/models/birthday.md) | Optional | A birth date | Birthday getBirthday() | setBirthday(Birthday birthday) |
| `Email` | `String` | Optional | An email address | String getEmail() | setEmail(String email) |
| `Suffix` | `String` | Optional | A person suffix | String getSuffix() | setSuffix(String suffix) |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "address": null,
  "city": null,
  "state": null,
  "zip": null,
  "phone": null,
  "ssn": null,
  "birthday": null,
  "email": null,
  "suffix": null
}
```

