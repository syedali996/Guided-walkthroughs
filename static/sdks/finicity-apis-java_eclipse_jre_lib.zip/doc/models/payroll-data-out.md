
# Payroll Data Out

## Structure

`PayrollDataOut`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PayrollDataRetrievalId` | `String` | Required | An id to identify the data retrieved from the payroll providers for the report. | String getPayrollDataRetrievalId() | setPayrollDataRetrievalId(String payrollDataRetrievalId) |
| `EmployerNames` | `List<String>` | Required | An array of employer names that the consumer submitted after completing the Connect application. | List<String> getEmployerNames() | setEmployerNames(List<String> employerNames) |
| `ReportId` | `String` | Optional | A report ID | String getReportId() | setReportId(String reportId) |

## Example (as JSON)

```json
{
  "payrollDataRetrievalId": "hahvhe2k0000",
  "employerNames": null
}
```

