
# Transactions Report

A Transactions report

## Structure

`TransactionsReport`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | A report ID | String getId() | setId(String id) |
| `CustomerType` | `String` | Optional | The type of customer ("active" or "testing" or "" for all types) | String getCustomerType() | setCustomerType(String customerType) |
| `CustomerId` | `Long` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | Long getCustomerId() | setCustomerId(Long customerId) |
| `RequestId` | `String` | Optional | Finicity indicator to track all activity associated with this report | String getRequestId() | setRequestId(String requestId) |
| `RequesterName` | `String` | Optional | Name of a Finicity partner | String getRequesterName() | setRequesterName(String requesterName) |
| `CreatedDate` | `Long` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getCreatedDate() | setCreatedDate(Long createdDate) |
| `Title` | `String` | Optional | Title of the report | String getTitle() | setTitle(String title) |
| `ConsumerId` | `String` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getConsumerId() | setConsumerId(String consumerId) |
| `ConsumerSsn` | `String` | Optional | Last 4 digits of a SSN | String getConsumerSsn() | setConsumerSsn(String consumerSsn) |
| `Type` | `String` | Optional | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | String getType() | setType(String type) |
| `Status` | `String` | Optional | A report generation status. Possible values: "inProgress", "success", "failure". | String getStatus() | setStatus(String status) |
| `Errors` | [`List<ErrorMessage>`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | List<ErrorMessage> getErrors() | setErrors(List<ErrorMessage> errors) |
| `PortfolioId` | `String` | Optional | A unique identifier that will be consistent across all reports created for the same customer | String getPortfolioId() | setPortfolioId(String portfolioId) |
| `StartDate` | `Long` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getStartDate() | setStartDate(Long startDate) |
| `EndDate` | `Long` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getEndDate() | setEndDate(Long endDate) |
| `Days` | `Long` | Optional | Number of days covered by the report | Long getDays() | setDays(Long days) |
| `Seasoned` | `Boolean` | Optional | "true" if the report covers more than 365 days | Boolean getSeasoned() | setSeasoned(Boolean seasoned) |
| `Institutions` | [`List<ReportInstitution>`](../../doc/models/report-institution.md) | Optional | A list of institution records | List<ReportInstitution> getInstitutions() | setInstitutions(List<ReportInstitution> institutions) |

## Example (as JSON)

```json
{
  "id": null,
  "customerType": null,
  "customerId": null,
  "requestId": null,
  "requesterName": null,
  "createdDate": null,
  "title": null,
  "consumerId": null,
  "consumerSsn": null,
  "type": null,
  "status": null,
  "errors": null,
  "portfolioId": null,
  "startDate": null,
  "endDate": null,
  "days": null,
  "seasoned": null,
  "institutions": null
}
```

