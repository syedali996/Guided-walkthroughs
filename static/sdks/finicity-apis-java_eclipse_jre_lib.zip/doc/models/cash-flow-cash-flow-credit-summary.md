
# Cash Flow Cash Flow Credit Summary

## Structure

`CashFlowCashFlowCreditSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyCashFlowCreditSummaries` | [`List<CashFlowMonthlyCashFlowCreditSummaries>`](../../doc/models/cash-flow-monthly-cash-flow-credit-summaries.md) | Required | List of attributes for each month | List<CashFlowMonthlyCashFlowCreditSummaries> getMonthlyCashFlowCreditSummaries() | setMonthlyCashFlowCreditSummaries(List<CashFlowMonthlyCashFlowCreditSummaries> monthlyCashFlowCreditSummaries) |
| `TwelveMonthCreditTotal` | `double` | Required | Sum of all credit transactions for each month for all accounts | double getTwelveMonthCreditTotal() | setTwelveMonthCreditTotal(double twelveMonthCreditTotal) |
| `TwelveMonthCreditTotalLessTransfers` | `double` | Required | Sum of all monthly credit transactions without transfers for all accounts | double getTwelveMonthCreditTotalLessTransfers() | setTwelveMonthCreditTotalLessTransfers(double twelveMonthCreditTotalLessTransfers) |
| `SixMonthCreditTotal` | `double` | Required | Six month sum of all credit transactions | double getSixMonthCreditTotal() | setSixMonthCreditTotal(double sixMonthCreditTotal) |
| `SixMonthCreditTotalLessTransfers` | `double` | Required | Six month sum of all monthly credit transactions without transfers for all accounts | double getSixMonthCreditTotalLessTransfers() | setSixMonthCreditTotalLessTransfers(double sixMonthCreditTotalLessTransfers) |
| `TwoMonthCreditTotal` | `double` | Required | Two month sum of all credit transactions | double getTwoMonthCreditTotal() | setTwoMonthCreditTotal(double twoMonthCreditTotal) |
| `TwoMonthCreditTotalLessTransfers` | `double` | Required | Two month sum of all monthly credit transactions without transfers for all accounts | double getTwoMonthCreditTotalLessTransfers() | setTwoMonthCreditTotalLessTransfers(double twoMonthCreditTotalLessTransfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCreditSummaries": {
    "month": 1512111600,
    "numberOfCredits": "57",
    "totalCreditsAmount": 3479.39,
    "largestCredit": 3000.49,
    "numberOfCreditsLessTransfers": "5",
    "totalCreditsAmountLessTransfers": 25.46,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

