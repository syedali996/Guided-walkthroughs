
# Consumer Attribute Account I Ds

A list of account IDs

## Structure

`ConsumerAttributeAccountIDs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountIds` | `List<String>` | Required | The list of account IDs | List<String> getAccountIds() | setAccountIds(List<String> accountIds) |

## Example (as JSON)

```json
{
  "accountIds": [
    "accountIds5",
    "accountIds6"
  ]
}
```

