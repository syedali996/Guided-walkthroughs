
# Partner Credentials

## Structure

`PartnerCredentials`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PartnerId` | `String` | Required | Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin) | String getPartnerId() | setPartnerId(String partnerId) |
| `PartnerSecret` | `String` | Required | Your Partner Secret displayed in the [Developer Dashboard](https://developer.finicity.com/admin) | String getPartnerSecret() | setPartnerSecret(String partnerSecret) |

## Example (as JSON)

```json
{
  "partnerId": "1234583871234",
  "partnerSecret": "aqJ5Ic4SEVx2IgDQ6oR4"
}
```

