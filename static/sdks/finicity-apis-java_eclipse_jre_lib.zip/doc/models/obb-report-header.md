
# Obb Report Header

Includes details about the business the report is generated for and metadata about the report

## Structure

`ObbReportHeader`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BusinessAddress` | `String` | Optional | Business address line 1<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getBusinessAddress() | setBusinessAddress(String businessAddress) |
| `BusinessCity` | `String` | Optional | Business address city<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getBusinessCity() | setBusinessCity(String businessCity) |
| `BusinessName` | `String` | Optional | Name of the business<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getBusinessName() | setBusinessName(String businessName) |
| `BusinessState` | `String` | Optional | Business address state<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getBusinessState() | setBusinessState(String businessState) |
| `BusinessZip` | `String` | Optional | Business address zip<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getBusinessZip() | setBusinessZip(String businessZip) |
| `ReferenceNumber` | `String` | Optional | Partner-provided reference number<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getReferenceNumber() | setReferenceNumber(String referenceNumber) |
| `ReportDate` | `String` | Required | Date the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getReportDate() | setReportDate(String reportDate) |
| `ReportId` | `String` | Required | Generated unique report ID<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getReportId() | setReportId(String reportId) |

## Example (as JSON)

```json
{
  "reportDate": "03/17/2022 04:28:38",
  "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
}
```

