
# Obb Week of Year

## Structure

`ObbWeekOfYear`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FromDate` | `String` | Required | Begin date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getFromDate() | setFromDate(String fromDate) |
| `ToDate` | `String` | Required | End date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getToDate() | setToDate(String toDate) |
| `Week` | `int` | Required | Week number, where the first week of each year begins on January 1st and ends on January 7th. May be in the range [1, 53] | int getWeek() | setWeek(int week) |

## Example (as JSON)

```json
{
  "fromDate": "2020-01-01",
  "toDate": "2020-01-07",
  "week": 1
}
```

