
# App Financial Institution Status

The registration status fields for each specific OAuth financial institution

## Structure

`AppFinancialInstitutionStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `long` | Required | The ID of a financial institution, represented as a number | long getId() | setId(long id) |
| `AbbrvName` | `String` | Optional | The application's abbreviated name | String getAbbrvName() | setAbbrvName(String abbrvName) |
| `LogoUrl` | `String` | Optional | An URL to a logo file | String getLogoUrl() | setLogoUrl(String logoUrl) |
| `DecryptionKeyActivated` | `boolean` | Required | Status of decryption keys for financial institution app registration | boolean getDecryptionKeyActivated() | setDecryptionKeyActivated(boolean decryptionKeyActivated) |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getCreatedDate() | setCreatedDate(long createdDate) |
| `LastModifiedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getLastModifiedDate() | setLastModifiedDate(long lastModifiedDate) |
| `Status` | `boolean` | Required | "false" indicates registration is still pending | boolean getStatus() | setStatus(boolean status) |

## Example (as JSON)

```json
{
  "id": 4222,
  "decryptionKeyActivated": false,
  "createdDate": 1607450357,
  "lastModifiedDate": 1607450357,
  "status": true
}
```

