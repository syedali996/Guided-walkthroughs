
# ACH Details

The routing and account number information to initiate ACH transfers

## Structure

`ACHDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RoutingNumber` | `String` | Required | The routing number of the financial institution for this specific customers account | String getRoutingNumber() | setRoutingNumber(String routingNumber) |
| `RealAccountNumber` | `String` | Required | The account number for initiating ACH transfers for this account | String getRealAccountNumber() | setRealAccountNumber(String realAccountNumber) |

## Example (as JSON)

```json
{
  "routingNumber": "123456789",
  "realAccountNumber": "002345678901"
}
```

