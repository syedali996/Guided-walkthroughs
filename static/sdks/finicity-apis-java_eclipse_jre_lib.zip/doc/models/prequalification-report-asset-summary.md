
# Prequalification Report Asset Summary

## Structure

`PrequalificationReportAssetSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `String` | Optional | The asset type: "checking", "savings", "moneyMarket", "cd", "investment" | String getType() | setType(String type) |
| `AvailableBalance` | `Double` | Optional | The available balance for the account | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `CurrentBalance` | `double` | Required | The current balance of the account | double getCurrentBalance() | setCurrentBalance(double currentBalance) |
| `TwoMonthAverage` | `double` | Required | The two month average daily balance of the account | double getTwoMonthAverage() | setTwoMonthAverage(double twoMonthAverage) |
| `SixMonthAverage` | `double` | Required | The six month average daily balance of the account | double getSixMonthAverage() | setSixMonthAverage(double sixMonthAverage) |
| `BeginningBalance` | `double` | Required | The beginning balance of the account per the time period of the report | double getBeginningBalance() | setBeginningBalance(double beginningBalance) |

## Example (as JSON)

```json
{
  "currentBalance": 1000,
  "twoMonthAverage": -1865.96,
  "sixMonthAverage": -7616.01,
  "beginningBalance": -17795.6
}
```

