
# Payroll Employment Record

## Structure

`PayrollEmploymentRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EmployerName` | `String` | Required | Name of the employer as stated by the employer in the payroll system | String getEmployerName() | setEmployerName(String employerName) |
| `LegalEntityId` | `String` | Optional | Employer identification number (EIN) | String getLegalEntityId() | setLegalEntityId(String legalEntityId) |
| `OriginalHireDate` | `Long` | Optional | The original hired date of an employee at the company | Long getOriginalHireDate() | setOriginalHireDate(Long originalHireDate) |
| `LatestHireDate` | `Long` | Optional | If an employee leaves the company and returns later, then the employer states the latest hire date at the company | Long getLatestHireDate() | setLatestHireDate(Long latestHireDate) |
| `LatestPayDate` | `long` | Required | The most recent pay date from an employer | long getLatestPayDate() | setLatestPayDate(long latestPayDate) |
| `DaysSinceLastPay` | `int` | Required | The number of days since an employee was last paid | int getDaysSinceLastPay() | setDaysSinceLastPay(int daysSinceLastPay) |
| `NumberPayCadenceWithoutPay` | `int` | Required | The number of pay cadences an employee has not been paid; determined by the pay frequency | int getNumberPayCadenceWithoutPay() | setNumberPayCadenceWithoutPay(int numberPayCadenceWithoutPay) |
| `EmploymentEndDate` | `Long` | Optional | The date an employee ended their employment at the company | Long getEmploymentEndDate() | setEmploymentEndDate(Long employmentEndDate) |
| `EmploymentDuration` | `String` | Optional | The length of time an employee has been employed with that employer in ISO 8601 format (eg P1Y6M0D) | String getEmploymentDuration() | setEmploymentDuration(String employmentDuration) |
| `EmployerAddress` | [`List<PayrollEmployerAddress>`](../../doc/models/payroll-employer-address.md) | Optional | Array of addresses | List<PayrollEmployerAddress> getEmployerAddress() | setEmployerAddress(List<PayrollEmployerAddress> employerAddress) |
| `EmploymentStatusCode` | `String` | Required | Status codes: `A` - Active, `NLE` - No Longer Employed, `L` - Leave | String getEmploymentStatusCode() | setEmploymentStatusCode(String employmentStatusCode) |
| `EmploymentStatusName` | `String` | Required | Status name: `Active`, `No Longer Employed`, or `Leave` | String getEmploymentStatusName() | setEmploymentStatusName(String employmentStatusName) |
| `WorkLevelCode` | `String` | Optional | The abbreviate code for the employment level names (workLevelName) that we receive from the employer | String getWorkLevelCode() | setWorkLevelCode(String workLevelCode) |
| `WorkLevelName` | `String` | Optional | The employment level name is whatever we receive from the employer, such as full time, part time, temp, contractor, and more | String getWorkLevelName() | setWorkLevelName(String workLevelName) |
| `WorkLevelStatus` | `String` | Required | The categorized work level status. Enumerations are: <br> * `Temporary` <br> * `Seasonal` <br> * `Retired` <br> * `Student` <br> * `Full Time` <br> * `Part Time` <br> * `Unspecified` <br> This is a new field, currently enabled only for testing reports. It will be added for all reports in August 2021. | String getWorkLevelStatus() | setWorkLevelStatus(String workLevelStatus) |
| `PositionTitle` | `String` | Optional | Employee job title | String getPositionTitle() | setPositionTitle(String positionTitle) |
| `PositionDuration` | `String` | Optional | The length of time an employee has been employed at their current or latest position for this employment in ISO 8601 format (eg P1Y6M0D) | String getPositionDuration() | setPositionDuration(String positionDuration) |

## Example (as JSON)

```json
{
  "employerName": "ACME INC",
  "latestPayDate": 1596175200,
  "daysSinceLastPay": 10,
  "numberPayCadenceWithoutPay": 1,
  "employmentStatusCode": "A",
  "employmentStatusName": "Active",
  "workLevelStatus": "Full Time"
}
```

