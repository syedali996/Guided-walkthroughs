
# Branding Wrapper

## Structure

`BrandingWrapper`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Branding` | [`Branding`](../../doc/models/branding.md) | Required | All assets are SVGs so can be slightly resized without any issues. | Branding getBranding() | setBranding(Branding branding) |

## Example (as JSON)

```json
{
  "branding": {
    "logo": null,
    "alternateLogo": null,
    "icon": null,
    "primaryColor": null,
    "tile": null
  }
}
```

