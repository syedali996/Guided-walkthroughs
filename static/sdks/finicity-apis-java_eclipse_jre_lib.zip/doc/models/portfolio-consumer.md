
# Portfolio Consumer

## Structure

`PortfolioConsumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getId() | setId(String id) |
| `FirstName` | `String` | Required | First name(s) / given name(s) | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | Last name(s) / surname(s) | String getLastName() | setLastName(String lastName) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `Ssn` | `String` | Required | A full SSN with or without hyphens | String getSsn() | setSsn(String ssn) |
| `Birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date | Birthday getBirthday() | setBirthday(Birthday birthday) |
| `Suffix` | `String` | Optional | A person suffix | String getSuffix() | setSuffix(String suffix) |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "ssn": "999-99-9999",
  "birthday": null
}
```

