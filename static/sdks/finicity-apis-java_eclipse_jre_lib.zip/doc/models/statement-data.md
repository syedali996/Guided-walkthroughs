
# Statement Data

## Structure

`StatementData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `long` | Required | An account ID represented as a number | long getAccountId() | setAccountId(long accountId) |
| `Index` | `Integer` | Optional | Index of the statement to retrieve<br>**Default**: `1`<br>**Constraints**: `<= 6` | Integer getIndex() | setIndex(Integer index) |

## Example (as JSON)

```json
{
  "accountId": 5011648377
}
```

