
# Cadence Details

## Structure

`CadenceDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StartDate` | `Long` | Optional | `postedDate` of the first deposit transaction | Long getStartDate() | setStartDate(Long startDate) |
| `StopDate` | `Long` | Optional | `postedDate` of the final deposit transaction (omitted if status is active) | Long getStopDate() | setStopDate(Long stopDate) |
| `Days` | `Integer` | Optional | Number of days between the recurring deposits | Integer getDays() | setDays(Integer days) |

## Example (as JSON)

```json
{
  "startDate": null,
  "stopDate": null,
  "days": null
}
```

