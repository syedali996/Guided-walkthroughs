
# Email Options

Configuration for the Connect email's sent to customers

## Structure

`EmailOptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `To` | `String` | Required | The email address for the customer receiving the Connect email | String getTo() | setTo(String to) |
| `From` | `String` | Optional | The name of a person or business sending the Connect email | String getFrom() | setFrom(String from) |
| `SupportPhone` | `String` | Optional | The support phone number listed in the email | String getSupportPhone() | setSupportPhone(String supportPhone) |
| `Subject` | `String` | Optional | The subject line of the email. The default is "Verify your Financial Information". | String getSubject() | setSubject(String subject) |
| `FirstName` | `String` | Optional | The first name of the customer or both names of the customers for joint borrowers. Example: "Marvin and Jenny". | String getFirstName() | setFirstName(String firstName) |
| `InstitutionName` | `String` | Optional | The name of your company | String getInstitutionName() | setInstitutionName(String institutionName) |
| `InstitutionAddress` | `String` | Optional | The institution address to appear in the footer of the email | String getInstitutionAddress() | setInstitutionAddress(String institutionAddress) |
| `Signature` | `List<String>` | Optional | A signature for the email | List<String> getSignature() | setSignature(List<String> signature) |

## Example (as JSON)

```json
{
  "to": "alex.salido@finicity.com"
}
```

