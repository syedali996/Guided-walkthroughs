
# Payroll Employee Record

## Structure

`PayrollEmployeeRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | Full name of the employee: first, middle (if stated), and last name | String getName() | setName(String name) |
| `GivenName` | `String` | Required | First name of employee | String getGivenName() | setGivenName(String givenName) |
| `MiddleName` | `String` | Optional | Middle name of employee, if stated | String getMiddleName() | setMiddleName(String middleName) |
| `FamilyName` | `String` | Required | Last name of employee | String getFamilyName() | setFamilyName(String familyName) |
| `Address` | [`List<PayrollEmployeeAddress>`](../../doc/models/payroll-employee-address.md) | Optional | Array of addresses | List<PayrollEmployeeAddress> getAddress() | setAddress(List<PayrollEmployeeAddress> address) |

## Example (as JSON)

```json
{
  "name": "John Doe Smith",
  "givenName": "John",
  "familyName": "Smith"
}
```

