
# Pay Statement Data

Data to be included within the pay statement report

## Structure

`PayStatementData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetIds` | `List<String>` | Required | A list of pay statement asset IDs | List<String> getAssetIds() | setAssetIds(List<String> assetIds) |
| `ExtractEarnings` | `Boolean` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `true` | Boolean getExtractEarnings() | setExtractEarnings(Boolean extractEarnings) |
| `ExtractDeductions` | `Boolean` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `false` | Boolean getExtractDeductions() | setExtractDeductions(Boolean extractDeductions) |
| `ExtractDirectDeposit` | `Boolean` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `true` | Boolean getExtractDirectDeposit() | setExtractDirectDeposit(Boolean extractDirectDeposit) |

## Example (as JSON)

```json
{
  "assetIds": [
    "assetIds3"
  ],
  "extractEarnings": null,
  "extractDeductions": null,
  "extractDirectDeposit": null
}
```

