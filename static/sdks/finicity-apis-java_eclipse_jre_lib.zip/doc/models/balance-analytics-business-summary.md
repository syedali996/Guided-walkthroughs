
# Balance Analytics Business Summary

## Structure

`BalanceAnalyticsBusinessSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BalanceAnalyticsMetrics` | [`BalanceAnalyticsMetrics`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations across all accounts in the report | BalanceAnalyticsMetrics getBalanceAnalyticsMetrics() | setBalanceAnalyticsMetrics(BalanceAnalyticsMetrics balanceAnalyticsMetrics) |
| `CurrentReportRequest` | [`ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Optional | Describes the requested attributes of the report | ObbCurrentReportRequestDetails getCurrentReportRequest() | setCurrentReportRequest(ObbCurrentReportRequestDetails currentReportRequest) |
| `HistoricDataAvailability` | [`ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Optional | Describes the availability of historical data for all accounts owned by the business | ObbDataAvailability getHistoricDataAvailability() | setHistoricDataAvailability(ObbDataAvailability historicDataAvailability) |

## Example (as JSON)

```json
{
  "balanceAnalyticsMetrics": null,
  "currentReportRequest": null,
  "historicDataAvailability": null
}
```

