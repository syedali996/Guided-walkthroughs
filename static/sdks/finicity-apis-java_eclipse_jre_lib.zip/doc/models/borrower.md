
# Borrower

## Structure

`Borrower`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CustomerId` | `String` | Required | A customer ID. See Add Customer API for how to create a customer ID. | String getCustomerId() | setCustomerId(String customerId) |
| `ConsumerId` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getConsumerId() | setConsumerId(String consumerId) |
| `Type` | `String` | Required | "primary" or "jointBorrower" | String getType() | setType(String type) |
| `OptionalConsumerInfo` | [`ConsumerInfo`](../../doc/models/consumer-info.md) | Optional | The SSN and date of birth of a consumer | ConsumerInfo getOptionalConsumerInfo() | setOptionalConsumerInfo(ConsumerInfo optionalConsumerInfo) |

## Example (as JSON)

```json
{
  "customerId": "1005061234",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "type": "primary"
}
```

