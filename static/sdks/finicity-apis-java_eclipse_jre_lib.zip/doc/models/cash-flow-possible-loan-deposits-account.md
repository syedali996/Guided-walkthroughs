
# Cash Flow Possible Loan Deposits Account

## Structure

`CashFlowPossibleLoanDepositsAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | Finicity account ID | String getId() | setId(String id) |
| `OwnerName` | `String` | Required | The name(s) of the account owner(s), retrieved from the institution. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Required | The mailing address of the account owner, retrieved from the institution. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Required | The account name from the institution | String getName() | setName(String name) |
| `Number` | `String` | Required | The account number from the institution (obfuscated) | String getNumber() | setNumber(String number) |
| `Type` | `String` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) | String getType() | setType(String type) |
| `AggregationStatusCode` | `String` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) | String getAggregationStatusCode() | setAggregationStatusCode(String aggregationStatusCode) |
| `CurrentBalance` | `double` | Required | The cleared balance of the account as-of `balanceDate` | double getCurrentBalance() | setCurrentBalance(double currentBalance) |
| `AvailableBalance` | `double` | Required | Available balance | double getAvailableBalance() | setAvailableBalance(double availableBalance) |
| `BalanceDate` | `long` | Required | A timestamp showing when the `balance` was captured | long getBalanceDate() | setBalanceDate(long balanceDate) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Required | a list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "currentBalance": 100000,
  "availableBalance": 1000,
  "balanceDate": 1614880526,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

