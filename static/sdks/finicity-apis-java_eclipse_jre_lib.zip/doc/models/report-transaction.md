
# Report Transaction

## Structure

`ReportTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `long` | Required | A transaction ID | long getId() | setId(long id) |
| `Amount` | `Double` | Optional | The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values. | Double getAmount() | setAmount(Double amount) |
| `PostedDate` | `long` | Required | A timestamp showing when the transaction was posted or cleared by the institution | long getPostedDate() | setPostedDate(long postedDate) |
| `Description` | `String` | Required | The description of the transaction, as provided by the institution (often known as `payee`). In the event that this field is left blank by the institution, Finicity will pass a value of "No description provided by institution". All other values are provided by the institution. | String getDescription() | setDescription(String description) |
| `Memo` | `String` | Optional | The memo field of the transaction, as provided by the institution. The institution must provide either a description, a memo, or both. It is recommended to concatenate the two fields into a single value. | String getMemo() | setMemo(String memo) |
| `NormalizedPayee` | `String` | Required | A normalized payee, derived from the transaction's `description` and `memo` fields | String getNormalizedPayee() | setNormalizedPayee(String normalizedPayee) |
| `InstitutionTransactionId` | `String` | Required | The unique identifier given by the FI for each transaction | String getInstitutionTransactionId() | setInstitutionTransactionId(String institutionTransactionId) |
| `Category` | `String` | Required | One of the values from Categories (assigned based on the payee name) | String getCategory() | setCategory(String category) |
| `Type` | `String` | Optional | One of the values from transaction types | String getType() | setType(String type) |
| `SecurityType` | `String` | Optional | The type of investment security (VOA only) | String getSecurityType() | setSecurityType(String securityType) |
| `Symbol` | `String` | Optional | Investment symbol (VOA only) | String getSymbol() | setSymbol(String symbol) |
| `Commission` | `Double` | Optional | - | Double getCommission() | setCommission(Double commission) |

## Example (as JSON)

```json
{
  "id": 21284820852,
  "postedDate": 1571313600,
  "description": "ATM CHECK DEPOSIT mm/dd",
  "normalizedPayee": "T-Mobile",
  "institutionTransactionId": "0000000000",
  "category": "Income"
}
```

