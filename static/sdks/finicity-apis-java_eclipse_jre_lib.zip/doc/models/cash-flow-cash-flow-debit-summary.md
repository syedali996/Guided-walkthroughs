
# Cash Flow Cash Flow Debit Summary

## Structure

`CashFlowCashFlowDebitSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyCashFlowDebitSummaries` | [`List<CashFlowMonthlyCashFlowDebitSummaries>`](../../doc/models/cash-flow-monthly-cash-flow-debit-summaries.md) | Required | List of attributes for each month | List<CashFlowMonthlyCashFlowDebitSummaries> getMonthlyCashFlowDebitSummaries() | setMonthlyCashFlowDebitSummaries(List<CashFlowMonthlyCashFlowDebitSummaries> monthlyCashFlowDebitSummaries) |
| `TwelveMonthDebitTotal` | `double` | Required | Sum of all monthly debit transactions for each month by account | double getTwelveMonthDebitTotal() | setTwelveMonthDebitTotal(double twelveMonthDebitTotal) |
| `TwelveMonthDebitTotalLessTransfers` | `double` | Required | Sum of all monthly debit transactions without transfers for the account | double getTwelveMonthDebitTotalLessTransfers() | setTwelveMonthDebitTotalLessTransfers(double twelveMonthDebitTotalLessTransfers) |
| `SixMonthDebitTotal` | `double` | Required | Six month sum of all debit transactions by account | double getSixMonthDebitTotal() | setSixMonthDebitTotal(double sixMonthDebitTotal) |
| `SixMonthDebitTotalLessTransfers` | `double` | Required | Six month sum of all debit transactions without transfers for the account | double getSixMonthDebitTotalLessTransfers() | setSixMonthDebitTotalLessTransfers(double sixMonthDebitTotalLessTransfers) |
| `TwoMonthDebitTotal` | `double` | Required | Two month sum of all debit transactions by account | double getTwoMonthDebitTotal() | setTwoMonthDebitTotal(double twoMonthDebitTotal) |
| `TwoMonthDebitTotalLessTransfers` | `double` | Required | Two month sum of all debit transactions without transfers for the account | double getTwoMonthDebitTotalLessTransfers() | setTwoMonthDebitTotalLessTransfers(double twoMonthDebitTotalLessTransfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebitSummaries": {
    "month": 1512111600,
    "numberOfDebits": "1500",
    "totalDebitsAmount": -12345.46,
    "largestDebit": -20000,
    "numberOfDebitsLessTransfers": "5",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": -1200,
  "twelveMonthDebitTotalLessTransfers": -1000,
  "sixMonthDebitTotal": -750,
  "sixMonthDebitTotalLessTransfers": -500,
  "twoMonthDebitTotal": -150,
  "twoMonthDebitTotalLessTransfers": -100
}
```

