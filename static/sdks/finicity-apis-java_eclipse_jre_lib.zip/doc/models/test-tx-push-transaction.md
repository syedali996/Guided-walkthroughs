
# Test Tx Push Transaction

A fake transaction for TxPush testing

## Structure

`TestTxPushTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | The amount of the transaction | double getAmount() | setAmount(double amount) |
| `Description` | `String` | Required | The description of the transaction | String getDescription() | setDescription(String description) |
| `Status` | `String` | Optional | "active" or "pending" (optional)<br>**Default**: `"active"` | String getStatus() | setStatus(String status) |
| `PostedDate` | `Long` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPostedDate() | setPostedDate(Long postedDate) |
| `TransactionDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getTransactionDate() | setTransactionDate(long transactionDate) |

## Example (as JSON)

```json
{
  "amount": -4.25,
  "description": "a testing transaction description",
  "transactionDate": 1607450357
}
```

