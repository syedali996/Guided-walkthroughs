
# Birthday

A birth date

## Structure

`Birthday`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Year` | `Integer` | Optional | The birthday 4-digit year | Integer getYear() | setYear(Integer year) |
| `Month` | `Integer` | Optional | The birthday 2-digit month (1 is January) | Integer getMonth() | setMonth(Integer month) |
| `DayOfMonth` | `Integer` | Optional | The birthday 2-digit day-of-month | Integer getDayOfMonth() | setDayOfMonth(Integer dayOfMonth) |

## Example (as JSON)

```json
{
  "year": null,
  "month": null,
  "dayOfMonth": null
}
```

