
# Payroll Data

## Structure

`PayrollData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Ssn` | `String` | Required | A full SSN without hyphens | String getSsn() | setSsn(String ssn) |
| `Dob` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getDob() | setDob(long dob) |
| `ReportId` | `String` | Optional | A report ID | String getReportId() | setReportId(String reportId) |

## Example (as JSON)

```json
{
  "ssn": "999999999",
  "dob": 1607450357
}
```

