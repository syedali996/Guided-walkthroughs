
# Report Summary

## Structure

`ReportSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | A report ID | String getId() | setId(String id) |
| `RequestId` | `String` | Required | Finicity indicator to track all activity associated with this report | String getRequestId() | setRequestId(String requestId) |
| `RequesterName` | `String` | Required | Name of a Finicity partner | String getRequesterName() | setRequesterName(String requesterName) |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getCreatedDate() | setCreatedDate(long createdDate) |
| `ConsumerId` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getConsumerId() | setConsumerId(String consumerId) |
| `ConsumerSsn` | `String` | Required | Last 4 digits of a SSN | String getConsumerSsn() | setConsumerSsn(String consumerSsn) |
| `Type` | `String` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | String getType() | setType(String type) |
| `Status` | `String` | Required | A report generation status. Possible values: "inProgress", "success", "failure". | String getStatus() | setStatus(String status) |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress"
}
```

