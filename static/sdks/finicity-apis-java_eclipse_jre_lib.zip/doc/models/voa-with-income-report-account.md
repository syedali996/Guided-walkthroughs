
# VOA With Income Report Account

## Structure

`VOAWithIncomeReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Long` | Optional | The ID of the account | Long getId() | setId(Long id) |
| `Number` | `String` | Optional | The account number from the institution (all digits except the last four are obfuscated) | String getNumber() | setNumber(String number) |
| `OwnerName` | `String` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Optional | The account name from the institution | String getName() | setName(String name) |
| `Type` | `String` | Optional | One of the values from account types | String getType() | setType(String type) |
| `AvailableBalance` | `Double` | Optional | The available balance for the account | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `AggregationStatusCode` | `Integer` | Optional | The status of the most recent aggregation attempt | Integer getAggregationStatusCode() | setAggregationStatusCode(Integer aggregationStatusCode) |
| `Balance` | `Double` | Optional | The cleared balance of the account as-of balanceDate | Double getBalance() | setBalance(Double balance) |
| `BalanceDate` | `Long` | Optional | A timestamp showing when the balance was captured | Long getBalanceDate() | setBalanceDate(Long balanceDate) |
| `AverageMonthlyBalance` | `Double` | Optional | The average monthly balance of this account | Double getAverageMonthlyBalance() | setAverageMonthlyBalance(Double averageMonthlyBalance) |
| `TotNumberInsufficientFundsFeeDebitTxAccount` | `Long` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report. | Long getTotNumberInsufficientFundsFeeDebitTxAccount() | setTotNumberInsufficientFundsFeeDebitTxAccount(Long totNumberInsufficientFundsFeeDebitTxAccount) |
| `TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `Long` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. | Long getTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount() | setTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount(Long totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount) |
| `TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `Long` | Optional | The number of days since the most recent insufficient funds transaction, based on the `fromDate` of the report. | Long getTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount() | setTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(Long totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |
| `Details` | [`AccountDetails`](../../doc/models/account-details.md) | Optional | - | AccountDetails getDetails() | setDetails(AccountDetails details) |
| `Asset` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | PrequalificationReportAssetSummary getAsset() | setAsset(PrequalificationReportAssetSummary asset) |
| `IncomeStreams` | [`List<VOAIReportIncomeStream>`](../../doc/models/voai-report-income-stream.md) | Optional | A list of income stream records | List<VOAIReportIncomeStream> getIncomeStreams() | setIncomeStreams(List<VOAIReportIncomeStream> incomeStreams) |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "availableBalance": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "details": null,
  "asset": null,
  "incomeStreams": null
}
```

