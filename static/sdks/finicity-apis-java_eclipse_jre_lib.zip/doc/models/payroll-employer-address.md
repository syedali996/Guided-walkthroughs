
# Payroll Employer Address

## Structure

`PayrollEmployerAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Address1` | `String` | Optional | Employer address as stated by the employer in the payroll system | String getAddress1() | setAddress1(String address1) |
| `City` | `String` | Optional | Employer city as stated by the employer in the payroll system | String getCity() | setCity(String city) |
| `State` | `String` | Optional | Employer state as stated by the employer in the payroll system | String getState() | setState(String state) |
| `Zip` | `String` | Optional | Employer zip code as stated by the employer in the payroll system | String getZip() | setZip(String zip) |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

