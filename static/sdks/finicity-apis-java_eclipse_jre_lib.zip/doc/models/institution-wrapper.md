
# Institution Wrapper

## Structure

`InstitutionWrapper`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Institution` | [`Institution`](../../doc/models/institution.md) | Required | A financial institution | Institution getInstitution() | setInstitution(Institution institution) |

## Example (as JSON)

```json
{
  "institution": {
    "id": 4222,
    "transAgg": true,
    "ach": true,
    "stateAgg": false,
    "voi": true,
    "voa": true,
    "aha": false,
    "availBalance": false,
    "accountOwner": true,
    "oauthEnabled": true,
    "currency": "USD",
    "status": "online"
  }
}
```

