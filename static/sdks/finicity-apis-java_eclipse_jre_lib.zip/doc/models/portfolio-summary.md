
# Portfolio Summary

## Structure

`PortfolioSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PortfolioId` | `String` | Required | A unique identifier that will be consistent across all reports created for the same customer | String getPortfolioId() | setPortfolioId(String portfolioId) |
| `Reports` | [`List<PortfolioReport>`](../../doc/models/portfolio-report.md) | Required | A list of reports in the portfolio | List<PortfolioReport> getReports() | setReports(List<PortfolioReport> reports) |

## Example (as JSON)

```json
{
  "portfolioId": "y4zsgccj4xpw-6-port",
  "reports": {
    "id": "u4hstnnak45g",
    "portfolioId": "y4zsgccj4xpw-6-port",
    "type": "voi",
    "status": "inProgress",
    "createdDate": 1607450357
  }
}
```

