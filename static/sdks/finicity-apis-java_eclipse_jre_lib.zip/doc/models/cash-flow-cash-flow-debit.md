
# Cash Flow Cash Flow Debit

## Structure

`CashFlowCashFlowDebit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyCashFlowDebits` | [`List<CashFlowMonthlycashflowDebits>`](../../doc/models/cash-flow-monthlycashflow-debits.md) | Required | List of attributes for each month | List<CashFlowMonthlycashflowDebits> getMonthlyCashFlowDebits() | setMonthlyCashFlowDebits(List<CashFlowMonthlycashflowDebits> monthlyCashFlowDebits) |
| `TwelveMonthDebitTotal` | `double` | Required | Sum of all monthly debit transactions for each month by account | double getTwelveMonthDebitTotal() | setTwelveMonthDebitTotal(double twelveMonthDebitTotal) |
| `TwelveMonthDebitTotalLessTransfers` | `double` | Required | Sum of all monthly debit transactions without transfers for the account | double getTwelveMonthDebitTotalLessTransfers() | setTwelveMonthDebitTotalLessTransfers(double twelveMonthDebitTotalLessTransfers) |
| `SixMonthDebitTotal` | `double` | Required | Six month sum of all debit transactions | double getSixMonthDebitTotal() | setSixMonthDebitTotal(double sixMonthDebitTotal) |
| `SixMonthDebitTotalLessTransfers` | `double` | Required | Six month sum of all debit transactions without transfers for the account | double getSixMonthDebitTotalLessTransfers() | setSixMonthDebitTotalLessTransfers(double sixMonthDebitTotalLessTransfers) |
| `TwoMonthDebitTotal` | `double` | Required | Two month sum of all debit transactions | double getTwoMonthDebitTotal() | setTwoMonthDebitTotal(double twoMonthDebitTotal) |
| `TwoMonthDebitTotalLessTransfers` | `double` | Required | Two month sum of all debit transactions without transfers for the account | double getTwoMonthDebitTotalLessTransfers() | setTwoMonthDebitTotalLessTransfers(double twoMonthDebitTotalLessTransfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebits": {
    "month": 1512111600,
    "numberOfDebits": "5",
    "totalDebitsAmount": -12345,
    "largestDebit": -2000,
    "numberOfDebitsLessTransfers": "3",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": 1200,
  "twelveMonthDebitTotalLessTransfers": 1000,
  "sixMonthDebitTotal": 750,
  "sixMonthDebitTotalLessTransfers": 500,
  "twoMonthDebitTotal": 150,
  "twoMonthDebitTotalLessTransfers": 100
}
```

