
# VOI Report Ack

## Structure

`VOIReportAck`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | A report ID | String getId() | setId(String id) |
| `CustomerType` | `String` | Required | The type of customer ("active" or "testing" or "" for all types) | String getCustomerType() | setCustomerType(String customerType) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `RequestId` | `String` | Required | Finicity indicator to track all activity associated with this report | String getRequestId() | setRequestId(String requestId) |
| `RequesterName` | `String` | Required | Name of a Finicity partner | String getRequesterName() | setRequesterName(String requesterName) |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getCreatedDate() | setCreatedDate(long createdDate) |
| `Title` | `String` | Required | Title of the report | String getTitle() | setTitle(String title) |
| `ConsumerId` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getConsumerId() | setConsumerId(String consumerId) |
| `ConsumerSsn` | `String` | Required | Last 4 digits of a SSN | String getConsumerSsn() | setConsumerSsn(String consumerSsn) |
| `Type` | `String` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | String getType() | setType(String type) |
| `Status` | `String` | Required | A report generation status. Possible values: "inProgress", "success", "failure". | String getStatus() | setStatus(String status) |
| `Errors` | [`List<ErrorMessage>`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | List<ErrorMessage> getErrors() | setErrors(List<ErrorMessage> errors) |
| `PortfolioId` | `String` | Required | A unique identifier that will be consistent across all reports created for the same customer | String getPortfolioId() | setPortfolioId(String portfolioId) |
| `Constraints` | [`VOIReportConstraintsOut`](../../doc/models/voi-report-constraints-out.md) | Required | - | VOIReportConstraintsOut getConstraints() | setConstraints(VOIReportConstraintsOut constraints) |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "customerType": "active",
  "customerId": 1005061234,
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "title": "Finicity Asset Ready Report (CRA)",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress",
  "portfolioId": "y4zsgccj4xpw-6-port",
  "constraints": null
}
```

