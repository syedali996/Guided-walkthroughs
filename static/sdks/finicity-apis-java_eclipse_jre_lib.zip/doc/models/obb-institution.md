
# Obb Institution

## Structure

`ObbInstitution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InstitutionIconUrl` | `String` | Optional | URL of the institution logo icon for reporting<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getInstitutionIconUrl() | setInstitutionIconUrl(String institutionIconUrl) |
| `InstitutionId` | `int` | Required | ID of the financial institution | int getInstitutionId() | setInstitutionId(int institutionId) |
| `InstitutionName` | `String` | Optional | Name of the financial institution<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getInstitutionName() | setInstitutionName(String institutionName) |
| `InstitutionPrimaryColor` | `String` | Optional | Primary branding color of the institution, in hex color format<br>**Constraints**: *Minimum Length*: `7`, *Maximum Length*: `7` | String getInstitutionPrimaryColor() | setInstitutionPrimaryColor(String institutionPrimaryColor) |

## Example (as JSON)

```json
{
  "institutionId": 12345
}
```

