
# Account Details

## Structure

`AccountDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InterestMarginBalance` | `Double` | Optional | Only available for investment accounts. Net interest earned after deducting interest paid out. | Double getInterestMarginBalance() | setInterestMarginBalance(Double interestMarginBalance) |
| `AvailableCashBalance` | `Double` | Optional | Only available for investment accounts. Amount available for cash withdrawal. | Double getAvailableCashBalance() | setAvailableCashBalance(Double availableCashBalance) |
| `VestedBalance` | `Double` | Optional | Only available for investment accounts. Vested amount in account. | Double getVestedBalance() | setVestedBalance(Double vestedBalance) |
| `CurrentLoanBalance` | `Double` | Optional | Only available for investment accounts. Current loan balance. | Double getCurrentLoanBalance() | setCurrentLoanBalance(Double currentLoanBalance) |
| `AvailableBalanceAmount` | `Double` | Optional | The available balance for the account | Double getAvailableBalanceAmount() | setAvailableBalanceAmount(Double availableBalanceAmount) |

## Example (as JSON)

```json
{
  "interestMarginBalance": null,
  "availableCashBalance": null,
  "vestedBalance": null,
  "currentLoanBalance": null,
  "availableBalanceAmount": null
}
```

