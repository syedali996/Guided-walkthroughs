
# Cash Flow Outflow Attributes

## Structure

`CashFlowOutflowAttributes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AverageWithdrawalByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of withdrawals during periods in the report | List<ObbDateRangeAndAmount> getAverageWithdrawalByMonthForTheReportTimePeriod() | setAverageWithdrawalByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> averageWithdrawalByMonthForTheReportTimePeriod) |
| `CountWithdrawalsByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all withdrawals during periods in the report | List<ObbDateRangeAndCount> getCountWithdrawalsByMonthForTheReportTimePeriod() | setCountWithdrawalsByMonthForTheReportTimePeriod(List<ObbDateRangeAndCount> countWithdrawalsByMonthForTheReportTimePeriod) |
| `HistoricCountOfWithdrawalTransactions` | `int` | Required | Count of ALL withdrawals over entire known history of the account (may exceed requested length of report) | int getHistoricCountOfWithdrawalTransactions() | setHistoricCountOfWithdrawalTransactions(int historicCountOfWithdrawalTransactions) |
| `HistoricSumOfWithdrawals` | `Double` | Optional | Sum of ALL withdrawals over entire known history of the account (may exceed requested length of report) | Double getHistoricSumOfWithdrawals() | setHistoricSumOfWithdrawals(Double historicSumOfWithdrawals) |
| `MaximumWithdrawalByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum withdrawal value for different periods in the report | List<ObbDateRangeAndAmount> getMaximumWithdrawalByMonthForTheReportTimePeriod() | setMaximumWithdrawalByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> maximumWithdrawalByMonthForTheReportTimePeriod) |
| `MinimumWithdrawalByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum withdrawal value for different periods in the report | List<ObbDateRangeAndAmount> getMinimumWithdrawalByMonthForTheReportTimePeriod() | setMinimumWithdrawalByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> minimumWithdrawalByMonthForTheReportTimePeriod) |
| `SumWithdrawalsByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all withdrawals during periods in the report | List<ObbDateRangeAndAmount> getSumWithdrawalsByMonthForTheReportTimePeriod() | setSumWithdrawalsByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> sumWithdrawalsByMonthForTheReportTimePeriod) |

## Example (as JSON)

```json
{
  "countWithdrawalsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfWithdrawalTransactions": 20,
  "maximumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumWithdrawalsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

