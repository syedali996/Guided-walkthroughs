
# Cash Flow Monthly Cash Flow Debit Summaries

## Structure

`CashFlowMonthlyCashFlowDebitSummaries`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report | long getMonth() | setMonth(long month) |
| `NumberOfDebits` | `String` | Required | Number of Debits by month across all accounts | String getNumberOfDebits() | setNumberOfDebits(String numberOfDebits) |
| `TotalDebitsAmount` | `double` | Required | Total Amount of Debits by month across all accounts | double getTotalDebitsAmount() | setTotalDebitsAmount(double totalDebitsAmount) |
| `LargestDebit` | `double` | Required | Largest Debit by month | double getLargestDebit() | setLargestDebit(double largestDebit) |
| `NumberOfDebitsLessTransfers` | `String` | Required | Number of Debits by month (less transfers) | String getNumberOfDebitsLessTransfers() | setNumberOfDebitsLessTransfers(String numberOfDebitsLessTransfers) |
| `TotalDebitsAmountLessTransfers` | `double` | Required | Total amount of debits by month (less transfers) | double getTotalDebitsAmountLessTransfers() | setTotalDebitsAmountLessTransfers(double totalDebitsAmountLessTransfers) |
| `AverageDebitAmount` | `double` | Required | The average debit amount | double getAverageDebitAmount() | setAverageDebitAmount(double averageDebitAmount) |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfDebits": "1500",
  "totalDebitsAmount": -12345.46,
  "largestDebit": -20000,
  "numberOfDebitsLessTransfers": "5",
  "totalDebitsAmountLessTransfers": -2000,
  "averageDebitAmount": 500
}
```

