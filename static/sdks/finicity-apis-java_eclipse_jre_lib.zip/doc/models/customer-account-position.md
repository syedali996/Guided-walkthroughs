
# Customer Account Position

Details for investment account holdings

## Structure

`CustomerAccountPosition`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Long` | Optional | The id of the investment position | Long getId() | setId(Long id) |
| `Description` | `String` | Optional | The description of the holding | String getDescription() | setDescription(String description) |
| `Symbol` | `String` | Optional | The investment position's market ticker symbol | String getSymbol() | setSymbol(String symbol) |
| `Units` | `Double` | Optional | The number of units of the holding | Double getUnits() | setUnits(Double units) |
| `CurrentPrice` | `Double` | Optional | The current price of the investment holding | Double getCurrentPrice() | setCurrentPrice(Double currentPrice) |
| `SecurityName` | `String` | Optional | The security name for the investment holding | String getSecurityName() | setSecurityName(String securityName) |
| `TransactionType` | `String` | Optional | The transaction type of the holding, such as cash, margin, and more | String getTransactionType() | setTransactionType(String transactionType) |
| `MarketValue` | `Double` | Optional | Market value of an investment position at the time of retrieval | Double getMarketValue() | setMarketValue(Double marketValue) |
| `CostBasis` | `Double` | Optional | The total cost of acquiring the security | Double getCostBasis() | setCostBasis(Double costBasis) |
| `Status` | `String` | Optional | The status of the holding | String getStatus() | setStatus(String status) |
| `CurrentPriceDate` | `Long` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getCurrentPriceDate() | setCurrentPriceDate(Long currentPriceDate) |
| `SecurityType` | `String` | Optional | Type of security for the investment position | String getSecurityType() | setSecurityType(String securityType) |
| `MfType` | `String` | Optional | Type of mutual fund, such as open ended | String getMfType() | setMfType(String mfType) |
| `PosType` | `String` | Optional | Fund type assigned by the FI (long or short) | String getPosType() | setPosType(String posType) |
| `TotalGLDollar` | `Double` | Optional | Total gain and loss of the position at the time of aggregation in dollars | Double getTotalGLDollar() | setTotalGLDollar(Double totalGLDollar) |
| `TotalGLPercent` | `Double` | Optional | Total gain and loss of the position at the time of aggregation in percentage | Double getTotalGLPercent() | setTotalGLPercent(Double totalGLPercent) |
| `OptionStrikePrice` | `Double` | Optional | The strike price of the option contract | Double getOptionStrikePrice() | setOptionStrikePrice(Double optionStrikePrice) |
| `OptionType` | `String` | Optional | The type of option contract (PUT or CALL) | String getOptionType() | setOptionType(String optionType) |
| `OptionSharesPerContract` | `Double` | Optional | The number of shares per option contract | Double getOptionSharesPerContract() | setOptionSharesPerContract(Double optionSharesPerContract) |
| `OptionExpireDate` | `LocalDate` | Optional | Expiration date of option | LocalDate getOptionExpireDate() | setOptionExpireDate(LocalDate optionExpireDate) |
| `FiAssetClass` | `String` | Optional | Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS) | String getFiAssetClass() | setFiAssetClass(String fiAssetClass) |
| `AssetClass` | `String` | Optional | An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER) | String getAssetClass() | setAssetClass(String assetClass) |
| `CurrencyRate` | `Double` | Optional | Currency rate, ratio of currency to original currency | Double getCurrencyRate() | setCurrencyRate(Double currencyRate) |
| `SecurityId` | `String` | Optional | The security ID of the transaction | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | `String` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" | String getSecurityIdType() | setSecurityIdType(String securityIdType) |
| `CostBasisPerShare` | `Double` | Optional | The per share cost of acquiring the security | Double getCostBasisPerShare() | setCostBasisPerShare(Double costBasisPerShare) |
| `SubAccountType` | `String` | Optional | The subaccount's type, such as cash | String getSubAccountType() | setSubAccountType(String subAccountType) |
| `SecurityCurrency` | `String` | Optional | Symbol for the currency that the account is being converted into | String getSecurityCurrency() | setSecurityCurrency(String securityCurrency) |
| `TodayGLDollar` | `Double` | Optional | The current day's gain and loss of the position at the time of aggregation in dollars | Double getTodayGLDollar() | setTodayGLDollar(Double todayGLDollar) |
| `TodayGLPercent` | `Double` | Optional | The current day's gain and loss of the position at the time of aggregation in percentage | Double getTodayGLPercent() | setTodayGLPercent(Double todayGLPercent) |

## Example (as JSON)

```json
{
  "id": null,
  "description": null,
  "symbol": null,
  "units": null,
  "currentPrice": null,
  "securityName": null,
  "transactionType": null,
  "marketValue": null,
  "costBasis": null,
  "status": null,
  "currentPriceDate": null,
  "securityType": null,
  "mfType": null,
  "posType": null,
  "totalGLDollar": null,
  "totalGLPercent": null,
  "optionStrikePrice": null,
  "optionType": null,
  "optionSharesPerContract": null,
  "optionExpireDate": null,
  "fiAssetClass": null,
  "assetClass": null,
  "currencyRate": null,
  "securityId": null,
  "securityIdType": null,
  "costBasisPerShare": null,
  "subAccountType": null,
  "securityCurrency": null,
  "todayGLDollar": null,
  "todayGLPercent": null
}
```

