
# Transaction

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `long` | Required | A transaction ID | long getId() | setId(long id) |
| `Amount` | `double` | Required | The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values. | double getAmount() | setAmount(double amount) |
| `AccountId` | `long` | Required | An account ID represented as a number | long getAccountId() | setAccountId(long accountId) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `Status` | `String` | Required | One of "active", "pending", or "shadow" (see [Pending and Shadow Transactions](https://docs.finicity.com/pending-and-shadow-transactions/)) | String getStatus() | setStatus(String status) |
| `Description` | `String` | Required | The description value is from the financial institution (FI), often known as the payee. The value "No description provided by institution" is returned when the FI doesn't provide one | String getDescription() | setDescription(String description) |
| `Memo` | `String` | Optional | The institution must provide either a description, a memo, or both. We recommended concatenating the two fields into a single value. | String getMemo() | setMemo(String memo) |
| `Type` | `String` | Optional | If provided by the institution, the following values may be returned in the field of a record:<br><br>* "atm"<br><br>* "cash"<br><br>* "check"<br><br>* "credit"<br><br>* "debit"<br><br>* "deposit"<br><br>* "directDebit"<br><br>* "directDeposit"<br><br>* "dividend"<br><br>* "fee"<br><br>* "interest"<br><br>* "other"<br><br>* "payment"<br><br>* "pointOfSale"<br><br>* "repeatPayment"<br><br>* "serviceCharge"<br><br>* "transfer" | String getType() | setType(String type) |
| `TransactionDate` | `Long` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it occurred. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getTransactionDate() | setTransactionDate(Long transactionDate) |
| `PostedDate` | `Long` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it was posted or cleared by the institution. This value isn't required for student loan transaction data. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getPostedDate() | setPostedDate(Long postedDate) |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it was added to our platform. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getCreatedDate() | setCreatedDate(long createdDate) |
| `FirstEffectiveDate` | `Long` | Optional | A date in Unix epoch time (in seconds). Represents the first timestamp of the transaction recorded in the `effectiveDate` field. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getFirstEffectiveDate() | setFirstEffectiveDate(Long firstEffectiveDate) |
| `EffectiveDate` | `Long` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it became effective on an account by an institution. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getEffectiveDate() | setEffectiveDate(Long effectiveDate) |
| `OptionExpireDate` | `Long` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction expiration date when it became expires on an account by an institution. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getOptionExpireDate() | setOptionExpireDate(Long optionExpireDate) |
| `CheckNum` | `Integer` | Optional | The check number of the transaction | Integer getCheckNum() | setCheckNum(Integer checkNum) |
| `EscrowAmount` | `Double` | Optional | The portion of the transaction allocated to escrow | Double getEscrowAmount() | setEscrowAmount(Double escrowAmount) |
| `FeeAmount` | `Double` | Optional | The portion of the overall transaction amount applied to fees | Double getFeeAmount() | setFeeAmount(Double feeAmount) |
| `SuspenseAmount` | `Double` | Optional | Temporarily hold funds if you overpay or underpay your monthly payment | Double getSuspenseAmount() | setSuspenseAmount(Double suspenseAmount) |
| `InterestAmount` | `Double` | Optional | The portion of the transaction allocated to interest | Double getInterestAmount() | setInterestAmount(Double interestAmount) |
| `PrincipalAmount` | `Double` | Optional | The portion of the transaction allocated to principal | Double getPrincipalAmount() | setPrincipalAmount(Double principalAmount) |
| `OptionStrikePrice` | `Double` | Optional | The strike price of the option contract | Double getOptionStrikePrice() | setOptionStrikePrice(Double optionStrikePrice) |
| `UnitQuantity` | `Integer` | Optional | The number of units (individual shares) in the transaction | Integer getUnitQuantity() | setUnitQuantity(Integer unitQuantity) |
| `UnitPrice` | `Double` | Optional | Share price for the investment unit: stocks, mutual funds, ETFs | Double getUnitPrice() | setUnitPrice(Double unitPrice) |
| `Categorization` | [`Categorization`](../../doc/models/categorization.md) | Required | Categorization Record | Categorization getCategorization() | setCategorization(Categorization categorization) |
| `RunningBalanceAmount` | `Double` | Optional | The ending balance after the transaction was posted | Double getRunningBalanceAmount() | setRunningBalanceAmount(Double runningBalanceAmount) |
| `SubaccountSecurityType` | `String` | Optional | The type of sub account the funds came from | String getSubaccountSecurityType() | setSubaccountSecurityType(String subaccountSecurityType) |
| `CommissionAmount` | `Integer` | Optional | Transaction commission | Integer getCommissionAmount() | setCommissionAmount(Integer commissionAmount) |
| `Ticker` | `String` | Optional | Ticker symbol for the investment related to the transaction | String getTicker() | setTicker(String ticker) |
| `InvestmentTransactionType` | `String` | Optional | Keywords in the `description` and `memo` fields were used to translate investment transactions into these types.<br><br>Possible values:<br><br>* "cancel"<br><br>* "purchaseToClose"<br><br>* "purchaseToCover"<br><br>* "contribution"<br><br>* "optionExercise"<br><br>* "optionExpiration"<br><br>* "fee"<br><br>* "soldToClose"<br><br>* "soldToOpen"<br><br>* "split"<br><br>* "transfer"<br><br>* "returnOfCapital"<br><br>* "income"<br><br>* "purchased"<br><br>* "sold"<br><br>* "dividendreInvest"<br><br>* "tax"<br><br>* "dividend"<br><br>* "reinvestOfIncome"<br><br>* "interest"<br><br>* "deposit"<br><br>* "otherInfo" | String getInvestmentTransactionType() | setInvestmentTransactionType(String investmentTransactionType) |
| `TaxesAmount` | `Integer` | Optional | Taxes applicable to the investment trade | Integer getTaxesAmount() | setTaxesAmount(Integer taxesAmount) |
| `CurrencySymbol` | `String` | Optional | If the foreign amount value is present then this is the currency code of that foreign amount | String getCurrencySymbol() | setCurrencySymbol(String currencySymbol) |
| `IncomeType` | `String` | Optional | Capital gains applied in short, long, or miscellaneous terms for tax purposes | String getIncomeType() | setIncomeType(String incomeType) |
| `SplitDenominator` | `Double` | Optional | Denominator of the stock split for the transaction | Double getSplitDenominator() | setSplitDenominator(Double splitDenominator) |
| `SplitNumerator` | `Double` | Optional | Numerator of the stock split for the transaction | Double getSplitNumerator() | setSplitNumerator(Double splitNumerator) |
| `SharesPerContract` | `Double` | Optional | Shares per contract of the underlying stock option | Double getSharesPerContract() | setSharesPerContract(Double sharesPerContract) |
| `SubAccountFund` | `String` | Optional | The sub account where the funds came from | String getSubAccountFund() | setSubAccountFund(String subAccountFund) |
| `SecurityId` | `String` | Optional | The security ID of the transaction | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | `String` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" | String getSecurityIdType() | setSecurityIdType(String securityIdType) |

## Example (as JSON)

```json
{
  "id": 21284820852,
  "amount": -828.9,
  "accountId": 5011648377,
  "customerId": 1005061234,
  "status": "active",
  "description": "Buy Stock",
  "createdDate": 1607450357,
  "categorization": {
    "normalizedPayeeName": "Mad Science Research",
    "category": "ATM Fee",
    "country": "USA"
  }
}
```

