
# Application

## Structure

`Application`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AppDescription` | `String` | Required | A short description of the app. This will be visible to end users in the FI interface. | String getAppDescription() | setAppDescription(String appDescription) |
| `AppName` | `String` | Required | The name of the application assigned to the customer | String getAppName() | setAppName(String appName) |
| `AppUrl` | `String` | Required | An URL for the app. This will be visible to end users in the FI interface. | String getAppUrl() | setAppUrl(String appUrl) |
| `OwnerAddressLine1` | `String` | Required | An address line 1 | String getOwnerAddressLine1() | setOwnerAddressLine1(String ownerAddressLine1) |
| `OwnerAddressLine2` | `String` | Required | An address line 2 | String getOwnerAddressLine2() | setOwnerAddressLine2(String ownerAddressLine2) |
| `OwnerCity` | `String` | Required | City for the business entity that owns the app. Information for registration purposes only and not given to the end user. | String getOwnerCity() | setOwnerCity(String ownerCity) |
| `OwnerCountry` | `String` | Required | Country for the  business entity that owns the app. Information for registration purposes only and not given to the end user. | String getOwnerCountry() | setOwnerCountry(String ownerCountry) |
| `OwnerName` | `String` | Required | Business name for the business entity that owns the app. Information for registration purposes only and not given to the end user. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerPostalCode` | `String` | Required | Zip code for the business entity that owns the app. Information for registration purposes only and not given to the end user. | String getOwnerPostalCode() | setOwnerPostalCode(String ownerPostalCode) |
| `OwnerState` | `String` | Required | State for the business entity that owns the app. Information for registration purposes only and not given to the end user. | String getOwnerState() | setOwnerState(String ownerState) |
| `Image` | `String` | Required | An app logo passed as a Base64 encoded image (1:1 SVG file, must be less than 50KB) | String getImage() | setImage(String image) |

## Example (as JSON)

```json
{
  "appDescription": "The app that makes your budgeting experience awesome",
  "appName": "Awesome Budget App",
  "appUrl": "https://www.finicity.com/",
  "ownerAddressLine1": "434 W Ascension Way",
  "ownerAddressLine2": "Suite #200",
  "ownerCity": "Murray",
  "ownerCountry": "USA",
  "ownerName": "Finicity",
  "ownerPostalCode": "84123",
  "ownerState": "UT",
  "image": "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K"
}
```

