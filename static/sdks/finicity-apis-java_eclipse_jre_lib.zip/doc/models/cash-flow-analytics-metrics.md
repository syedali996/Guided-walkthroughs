
# Cash Flow Analytics Metrics

## Structure

`CashFlowAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Inflow` | [`CashFlowInflowAttributes`](../../doc/models/cash-flow-inflow-attributes.md) | Optional | Inflow Attributes | CashFlowInflowAttributes getInflow() | setInflow(CashFlowInflowAttributes inflow) |
| `NegativeTriggers` | [`CashFlowNegativeTriggers`](../../doc/models/cash-flow-negative-triggers.md) | Optional | Details of transactions that may be warning signs of bad creditworthiness | CashFlowNegativeTriggers getNegativeTriggers() | setNegativeTriggers(CashFlowNegativeTriggers negativeTriggers) |
| `Outflow` | [`CashFlowOutflowAttributes`](../../doc/models/cash-flow-outflow-attributes.md) | Optional | Outflow attributes | CashFlowOutflowAttributes getOutflow() | setOutflow(CashFlowOutflowAttributes outflow) |
| `RevenueByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Sum of all transactions categorized as revenue, split by months | List<ObbDateRangeAndAmount> getRevenueByMonthForTheReportTimePeriod() | setRevenueByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> revenueByMonthForTheReportTimePeriod) |
| `RevenueForTheReportTimePeriod` | `Double` | Optional | Sum of all transactions categorized as revenue | Double getRevenueForTheReportTimePeriod() | setRevenueForTheReportTimePeriod(Double revenueForTheReportTimePeriod) |
| `TransactionAnalytics` | [`CashFlowTransactionAnalyticsAttributes`](../../doc/models/cash-flow-transaction-analytics-attributes.md) | Optional | Transaction Analytics Attributes | CashFlowTransactionAnalyticsAttributes getTransactionAnalytics() | setTransactionAnalytics(CashFlowTransactionAnalyticsAttributes transactionAnalytics) |

## Example (as JSON)

```json
{
  "inflow": null,
  "negativeTriggers": null,
  "outflow": null,
  "revenueByMonthForTheReportTimePeriod": null,
  "revenueForTheReportTimePeriod": null,
  "transactionAnalytics": null
}
```

