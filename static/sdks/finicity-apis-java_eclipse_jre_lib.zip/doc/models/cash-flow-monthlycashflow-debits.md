
# Cash Flow Monthlycashflow Debits

## Structure

`CashFlowMonthlycashflowDebits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report | long getMonth() | setMonth(long month) |
| `NumberOfDebits` | `String` | Required | Number of Debits by month | String getNumberOfDebits() | setNumberOfDebits(String numberOfDebits) |
| `TotalDebitsAmount` | `double` | Required | Total Amount of Debits by month | double getTotalDebitsAmount() | setTotalDebitsAmount(double totalDebitsAmount) |
| `LargestDebit` | `double` | Required | Largest Debit by month | double getLargestDebit() | setLargestDebit(double largestDebit) |
| `NumberOfDebitsLessTransfers` | `String` | Required | Number of Debits by month (less transfers) | String getNumberOfDebitsLessTransfers() | setNumberOfDebitsLessTransfers(String numberOfDebitsLessTransfers) |
| `TotalDebitsAmountLessTransfers` | `double` | Required | Total amount of debits by month (less transfers) | double getTotalDebitsAmountLessTransfers() | setTotalDebitsAmountLessTransfers(double totalDebitsAmountLessTransfers) |
| `AverageDebitAmount` | `double` | Required | The average debit amount | double getAverageDebitAmount() | setAverageDebitAmount(double averageDebitAmount) |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfDebits": "5",
  "totalDebitsAmount": -12345,
  "largestDebit": -2000,
  "numberOfDebitsLessTransfers": "3",
  "totalDebitsAmountLessTransfers": -2000,
  "averageDebitAmount": 500
}
```

