
# Balance Analytics Metrics

## Structure

`BalanceAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AvailableBalance` | `Double` | Optional | Available Balance | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `AvailableBalanceDate` | `String` | Optional | Available Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getAvailableBalanceDate() | setAvailableBalanceDate(String availableBalanceDate) |
| `AverageDailyBalanceByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average daily ending balance each month over the report time period | List<ObbDateRangeAndAmount> getAverageDailyBalanceByMonthForTheReportTimePeriod() | setAverageDailyBalanceByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> averageDailyBalanceByMonthForTheReportTimePeriod) |
| `AverageDailyBalanceForTheReportTimePeriod` | `Double` | Optional | Average Daily Balance | Double getAverageDailyBalanceForTheReportTimePeriod() | setAverageDailyBalanceForTheReportTimePeriod(Double averageDailyBalanceForTheReportTimePeriod) |
| `AverageWeekdayBalanceForTheReportTimePeriod` | `Double` | Optional | Average Weekday Balance | Double getAverageWeekdayBalanceForTheReportTimePeriod() | setAverageWeekdayBalanceForTheReportTimePeriod(Double averageWeekdayBalanceForTheReportTimePeriod) |
| `CountDailyNegativeBalancesByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Optional | Number of negative daily ending balances each month over the report time period | List<ObbDateRangeAndCount> getCountDailyNegativeBalancesByMonthForTheReportTimePeriod() | setCountDailyNegativeBalancesByMonthForTheReportTimePeriod(List<ObbDateRangeAndCount> countDailyNegativeBalancesByMonthForTheReportTimePeriod) |
| `CurrentRunningBalance` | `Double` | Optional | Current Running Balance Date | Double getCurrentRunningBalance() | setCurrentRunningBalance(Double currentRunningBalance) |
| `CurrentRunningBalanceDate` | `String` | Optional | Current Running Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | String getCurrentRunningBalanceDate() | setCurrentRunningBalanceDate(String currentRunningBalanceDate) |
| `DailyBalancesByWeekdayForTheReportTimePeriod` | [`List<ObbDailyBalance>`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account during weekdays over the length of the report | List<ObbDailyBalance> getDailyBalancesByWeekdayForTheReportTimePeriod() | setDailyBalancesByWeekdayForTheReportTimePeriod(List<ObbDailyBalance> dailyBalancesByWeekdayForTheReportTimePeriod) |
| `DailyBalancesForTheReportTimePeriod` | [`List<ObbDailyBalance>`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account over the length of the report | List<ObbDailyBalance> getDailyBalancesForTheReportTimePeriod() | setDailyBalancesForTheReportTimePeriod(List<ObbDailyBalance> dailyBalancesForTheReportTimePeriod) |
| `HistoricNumberOfWeeksAverageBalanceIncreasing` | [`ObbNumWeeksAverageBalanceIncreasing`](../../doc/models/obb-num-weeks-average-balance-increasing.md) | Optional | Report of average account balance week over week and count of weeks where the average balance increased | ObbNumWeeksAverageBalanceIncreasing getHistoricNumberOfWeeksAverageBalanceIncreasing() | setHistoricNumberOfWeeksAverageBalanceIncreasing(ObbNumWeeksAverageBalanceIncreasing historicNumberOfWeeksAverageBalanceIncreasing) |
| `MaximumDailyBalanceByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Maximum daily ending balance each month over the report time period | List<ObbDateRangeAndAmount> getMaximumDailyBalanceByMonthForTheReportTimePeriod() | setMaximumDailyBalanceByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> maximumDailyBalanceByMonthForTheReportTimePeriod) |
| `MaximumRunningBalanceForTheReportTimePeriod` | `Double` | Optional | Maximum Running Balance | Double getMaximumRunningBalanceForTheReportTimePeriod() | setMaximumRunningBalanceForTheReportTimePeriod(Double maximumRunningBalanceForTheReportTimePeriod) |
| `MinimumDailyBalanceByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Minimum daily ending balance each month over the report time period | List<ObbDateRangeAndAmount> getMinimumDailyBalanceByMonthForTheReportTimePeriod() | setMinimumDailyBalanceByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> minimumDailyBalanceByMonthForTheReportTimePeriod) |
| `MinimumRunningBalanceForTheReportTimePeriod` | `Double` | Optional | Minimum Running Balance | Double getMinimumRunningBalanceForTheReportTimePeriod() | setMinimumRunningBalanceForTheReportTimePeriod(Double minimumRunningBalanceForTheReportTimePeriod) |

## Example (as JSON)

```json
{
  "availableBalance": null,
  "availableBalanceDate": null,
  "averageDailyBalanceByMonthForTheReportTimePeriod": null,
  "averageDailyBalanceForTheReportTimePeriod": null,
  "averageWeekdayBalanceForTheReportTimePeriod": null,
  "countDailyNegativeBalancesByMonthForTheReportTimePeriod": null,
  "currentRunningBalance": null,
  "currentRunningBalanceDate": null,
  "dailyBalancesByWeekdayForTheReportTimePeriod": null,
  "dailyBalancesForTheReportTimePeriod": null,
  "historicNumberOfWeeksAverageBalanceIncreasing": null,
  "maximumDailyBalanceByMonthForTheReportTimePeriod": null,
  "maximumRunningBalanceForTheReportTimePeriod": null,
  "minimumDailyBalanceByMonthForTheReportTimePeriod": null,
  "minimumRunningBalanceForTheReportTimePeriod": null
}
```

