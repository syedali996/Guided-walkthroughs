
# Cash Flow Negative Triggers

## Structure

`CashFlowNegativeTriggers`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InsufficientFundFees` | [`CashFlowInsufficientFundsFees`](../../doc/models/cash-flow-insufficient-funds-fees.md) | Optional | Non Sufficient Fund Fees | CashFlowInsufficientFundsFees getInsufficientFundFees() | setInsufficientFundFees(CashFlowInsufficientFundsFees insufficientFundFees) |

## Example (as JSON)

```json
{
  "insufficientFundFees": null
}
```

