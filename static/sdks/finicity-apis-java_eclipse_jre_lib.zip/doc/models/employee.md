
# Employee

## Structure

`Employee`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | The name of the employee | String getName() | setName(String name) |

## Example (as JSON)

```json
{
  "name": null
}
```

