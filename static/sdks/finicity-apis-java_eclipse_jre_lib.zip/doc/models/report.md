
# Report

A report

## Structure

`Report`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | A report ID | String getId() | setId(String id) |
| `CustomerType` | `String` | Required | The type of customer ("active" or "testing" or "" for all types) | String getCustomerType() | setCustomerType(String customerType) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | long getCustomerId() | setCustomerId(long customerId) |
| `RequestId` | `String` | Required | Finicity indicator to track all activity associated with this report | String getRequestId() | setRequestId(String requestId) |
| `RequesterName` | `String` | Required | Name of a Finicity partner | String getRequesterName() | setRequesterName(String requesterName) |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | long getCreatedDate() | setCreatedDate(long createdDate) |
| `Title` | `String` | Required | Title of the report | String getTitle() | setTitle(String title) |
| `ConsumerId` | `String` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | String getConsumerId() | setConsumerId(String consumerId) |
| `ConsumerSsn` | `String` | Required | Last 4 digits of a SSN | String getConsumerSsn() | setConsumerSsn(String consumerSsn) |
| `Type` | `String` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | String getType() | setType(String type) |
| `Status` | `String` | Required | A report generation status. Possible values: "inProgress", "success", "failure". | String getStatus() | setStatus(String status) |
| `Errors` | [`List<ErrorMessage>`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | List<ErrorMessage> getErrors() | setErrors(List<ErrorMessage> errors) |
| `PortfolioId` | `String` | Optional | A unique identifier that will be consistent across all reports created for the same customer | String getPortfolioId() | setPortfolioId(String portfolioId) |
| `StartDate` | `Long` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getStartDate() | setStartDate(Long startDate) |
| `EndDate` | `Long` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getEndDate() | setEndDate(Long endDate) |
| `Days` | `Long` | Optional | Number of days covered by the report | Long getDays() | setDays(Long days) |
| `Seasoned` | `Boolean` | Optional | "true" if the report covers more than 365 days | Boolean getSeasoned() | setSeasoned(Boolean seasoned) |
| `Institutions` | [`List<ReportInstitution2>`](../../doc/models/report-institution-2.md) | Optional | A list of institution records, including information about the individual accounts used in this report | List<ReportInstitution2> getInstitutions() | setInstitutions(List<ReportInstitution2> institutions) |
| `CashFlowBalanceSummary` | [`CashFlowCashFlowBalanceSummary`](../../doc/models/cash-flow-cash-flow-balance-summary.md) | Optional | - | CashFlowCashFlowBalanceSummary getCashFlowBalanceSummary() | setCashFlowBalanceSummary(CashFlowCashFlowBalanceSummary cashFlowBalanceSummary) |
| `CashFlowCreditSummary` | [`CashFlowCashFlowCreditSummary`](../../doc/models/cash-flow-cash-flow-credit-summary.md) | Optional | - | CashFlowCashFlowCreditSummary getCashFlowCreditSummary() | setCashFlowCreditSummary(CashFlowCashFlowCreditSummary cashFlowCreditSummary) |
| `CashFlowDebitSummary` | [`CashFlowCashFlowDebitSummary`](../../doc/models/cash-flow-cash-flow-debit-summary.md) | Optional | - | CashFlowCashFlowDebitSummary getCashFlowDebitSummary() | setCashFlowDebitSummary(CashFlowCashFlowDebitSummary cashFlowDebitSummary) |
| `CashFlowCharacteristicsSummary` | [`CashFlowCashFlowCharacteristicsSummary`](../../doc/models/cash-flow-cash-flow-characteristics-summary.md) | Optional | - | CashFlowCashFlowCharacteristicsSummary getCashFlowCharacteristicsSummary() | setCashFlowCharacteristicsSummary(CashFlowCashFlowCharacteristicsSummary cashFlowCharacteristicsSummary) |
| `PossibleLoanDeposits` | [`List<CashFlowPossibleLoanDeposits>`](../../doc/models/cash-flow-possible-loan-deposits.md) | Optional | A possible loan deposits record | List<CashFlowPossibleLoanDeposits> getPossibleLoanDeposits() | setPossibleLoanDeposits(List<CashFlowPossibleLoanDeposits> possibleLoanDeposits) |
| `ConsolidatedAvailableBalance` | `Double` | Optional | The sum of available balance for all of the accounts included in the report | Double getConsolidatedAvailableBalance() | setConsolidatedAvailableBalance(Double consolidatedAvailableBalance) |
| `Assets` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | PrequalificationReportAssetSummary getAssets() | setAssets(PrequalificationReportAssetSummary assets) |
| `ReportStyle` | `String` | Optional | - | String getReportStyle() | setReportStyle(String reportStyle) |
| `NumberOfBillableAssets` | `Integer` | Optional | Total number of billable pay statements included in the report | Integer getNumberOfBillableAssets() | setNumberOfBillableAssets(Integer numberOfBillableAssets) |
| `AssetIds` | `List<String>` | Optional | The pay statements included in the report | List<String> getAssetIds() | setAssetIds(List<String> assetIds) |
| `PayStatements` | [`List<VOIEPayStatement2>`](../../doc/models/voie-pay-statement-2.md) | Optional | Extracted pay statement details | List<VOIEPayStatement2> getPayStatements() | setPayStatements(List<VOIEPayStatement2> payStatements) |
| `AssetId` | `String` | Optional | An asset ID. Generated by Connect or by using the Store Customer Pay Statement API. | String getAssetId() | setAssetId(String assetId) |
| `EmploymentHistory` | [`List<PayrollEmploymentHistory>`](../../doc/models/payroll-employment-history.md) | Optional | An array of employment histories, one for each of the consumer's verified employers | List<PayrollEmploymentHistory> getEmploymentHistory() | setEmploymentHistory(List<PayrollEmploymentHistory> employmentHistory) |
| `Income` | [`List<ReportIncomeStreamSummary>`](../../doc/models/report-income-stream-summary.md) | Optional | - | List<ReportIncomeStreamSummary> getIncome() | setIncome(List<ReportIncomeStreamSummary> income) |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "customerType": "active",
  "customerId": 1005061234,
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "title": "Finicity Asset Ready Report (CRA)",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress"
}
```

