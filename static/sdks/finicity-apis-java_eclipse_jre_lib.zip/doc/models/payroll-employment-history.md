
# Payroll Employment History

## Structure

`PayrollEmploymentHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AsOfDate` | `long` | Required | The last time the payroll data was updated in the payroll provider's system | long getAsOfDate() | setAsOfDate(long asOfDate) |
| `EmployerName` | `String` | Required | Name of the employer as stated by the employer in the payroll system | String getEmployerName() | setEmployerName(String employerName) |
| `PayrollSource` | `String` | Required | The name of the payroll source where the data was retrieved | String getPayrollSource() | setPayrollSource(String payrollSource) |
| `Employee` | [`PayrollEmployeeRecord`](../../doc/models/payroll-employee-record.md) | Required | - | PayrollEmployeeRecord getEmployee() | setEmployee(PayrollEmployeeRecord employee) |
| `Employment` | [`PayrollEmploymentRecord`](../../doc/models/payroll-employment-record.md) | Required | - | PayrollEmploymentRecord getEmployment() | setEmployment(PayrollEmploymentRecord employment) |
| `Income` | [`PayrollVOEIncomeRecord`](../../doc/models/payroll-voe-income-record.md) | Required | - | PayrollVOEIncomeRecord getIncome() | setIncome(PayrollVOEIncomeRecord income) |

## Example (as JSON)

```json
{
  "asOfDate": 1596175200,
  "employerName": "ACME INC",
  "payrollSource": "finPayroll",
  "employee": {
    "name": "John Doe Smith",
    "givenName": "John",
    "familyName": "Smith"
  },
  "employment": {
    "employerName": "ACME INC",
    "latestPayDate": 1596175200,
    "daysSinceLastPay": 10,
    "numberPayCadenceWithoutPay": 1,
    "employmentStatusCode": "A",
    "employmentStatusName": "Active",
    "workLevelStatus": "Full Time"
  },
  "income": {
    "payFrequency": "Weekly"
  }
}
```

