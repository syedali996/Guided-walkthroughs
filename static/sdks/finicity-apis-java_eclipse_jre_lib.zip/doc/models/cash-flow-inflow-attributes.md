
# Cash Flow Inflow Attributes

## Structure

`CashFlowInflowAttributes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AverageDepositByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of deposits during periods in the report | List<ObbDateRangeAndAmount> getAverageDepositByMonthForTheReportTimePeriod() | setAverageDepositByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> averageDepositByMonthForTheReportTimePeriod) |
| `CountDepositsByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all deposits during periods in the report | List<ObbDateRangeAndCount> getCountDepositsByMonthForTheReportTimePeriod() | setCountDepositsByMonthForTheReportTimePeriod(List<ObbDateRangeAndCount> countDepositsByMonthForTheReportTimePeriod) |
| `HistoricCountOfDepositTransactions` | `int` | Required | Count of ALL deposits over entire known history of the account (may exceed requested length of report) | int getHistoricCountOfDepositTransactions() | setHistoricCountOfDepositTransactions(int historicCountOfDepositTransactions) |
| `HistoricSumOfDeposits` | `Double` | Optional | Sum of ALL deposits over entire known history of the account (may exceed requested length of report) | Double getHistoricSumOfDeposits() | setHistoricSumOfDeposits(Double historicSumOfDeposits) |
| `MaximumDepositByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum deposit value for different periods in the report | List<ObbDateRangeAndAmount> getMaximumDepositByMonthForTheReportTimePeriod() | setMaximumDepositByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> maximumDepositByMonthForTheReportTimePeriod) |
| `MinimumDepositByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum deposit value for different periods in the report | List<ObbDateRangeAndAmount> getMinimumDepositByMonthForTheReportTimePeriod() | setMinimumDepositByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> minimumDepositByMonthForTheReportTimePeriod) |
| `SumDepositsByMonthForTheReportTimePeriod` | [`List<ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all deposits during periods in the report | List<ObbDateRangeAndAmount> getSumDepositsByMonthForTheReportTimePeriod() | setSumDepositsByMonthForTheReportTimePeriod(List<ObbDateRangeAndAmount> sumDepositsByMonthForTheReportTimePeriod) |

## Example (as JSON)

```json
{
  "countDepositsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfDepositTransactions": 20,
  "maximumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumDepositsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

