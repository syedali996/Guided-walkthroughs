
# Prequalification Report Account

## Structure

`PrequalificationReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `Long` | Optional | The ID of the account | Long getId() | setId(Long id) |
| `Number` | `String` | Optional | The account number from the institution (all digits except the last four are obfuscated) | String getNumber() | setNumber(String number) |
| `OwnerName` | `String` | Optional | The name of the account owner. If no owner information is available, this field won't appear in the report. | String getOwnerName() | setOwnerName(String ownerName) |
| `OwnerAddress` | `String` | Optional | The mailing address of the account owner. If no owner information is available, this field won't appear in the report. | String getOwnerAddress() | setOwnerAddress(String ownerAddress) |
| `Name` | `String` | Optional | The account name from the institution | String getName() | setName(String name) |
| `Type` | `String` | Optional | One of the values from account types | String getType() | setType(String type) |
| `AggregationStatusCode` | `Integer` | Optional | The status of the most recent aggregation attempt | Integer getAggregationStatusCode() | setAggregationStatusCode(Integer aggregationStatusCode) |
| `Balance` | `Double` | Optional | The cleared balance of the account as-of `balanceDate` | Double getBalance() | setBalance(Double balance) |
| `BalanceDate` | `Long` | Optional | A timestamp of the balance | Long getBalanceDate() | setBalanceDate(Long balanceDate) |
| `AvailableBalance` | `Double` | Optional | Available balance | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `AverageMonthlyBalance` | `Double` | Optional | The average monthly balance of the account | Double getAverageMonthlyBalance() | setAverageMonthlyBalance(Double averageMonthlyBalance) |
| `TotNumberInsufficientFundsFeeDebitTxAccount` | `Integer` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report | Integer getTotNumberInsufficientFundsFeeDebitTxAccount() | setTotNumberInsufficientFundsFeeDebitTxAccount(Integer totNumberInsufficientFundsFeeDebitTxAccount) |
| `TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `Integer` | Optional | The total number of  insufficient funds fees for the account over six months | Integer getTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount() | setTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount(Integer totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount) |
| `TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `Long` | Optional | The total number of days since the most recent insufficient funds fee for the account | Long getTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount() | setTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(Long totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount) |
| `Transactions` | [`List<ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | List<ReportTransaction> getTransactions() | setTransactions(List<ReportTransaction> transactions) |
| `Asset` | [`PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | PrequalificationReportAssetSummary getAsset() | setAsset(PrequalificationReportAssetSummary asset) |
| `Details` | [`AccountDetails`](../../doc/models/account-details.md) | Optional | - | AccountDetails getDetails() | setDetails(AccountDetails details) |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "availableBalance": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "asset": null,
  "details": null
}
```

