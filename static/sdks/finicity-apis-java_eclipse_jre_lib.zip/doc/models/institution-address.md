
# Institution Address

The address of a financial institution

## Structure

`InstitutionAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `City` | `String` | Optional | A city | String getCity() | setCity(String city) |
| `State` | `String` | Optional | A state | String getState() | setState(String state) |
| `Country` | `String` | Optional | A country code | String getCountry() | setCountry(String country) |
| `PostalCode` | `String` | Optional | A ZIP code | String getPostalCode() | setPostalCode(String postalCode) |
| `AddressLine1` | `String` | Optional | An address line 1 | String getAddressLine1() | setAddressLine1(String addressLine1) |
| `AddressLine2` | `String` | Optional | An address line 2 | String getAddressLine2() | setAddressLine2(String addressLine2) |

## Example (as JSON)

```json
{
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "addressLine1": null,
  "addressLine2": null
}
```

