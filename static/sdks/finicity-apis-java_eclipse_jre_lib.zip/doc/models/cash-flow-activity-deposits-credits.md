
# Cash Flow Activity Deposits Credits

## Structure

`CashFlowActivityDepositsCredits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Date` | `String` | Required | Date the deposit transaction was posted<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | String getDate() | setDate(String date) |
| `DepositsCredits` | `double` | Required | Amount of the deposit | double getDepositsCredits() | setDepositsCredits(double depositsCredits) |
| `TransactionDescription` | `String` | Optional | Description of transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getTransactionDescription() | setTransactionDescription(String transactionDescription) |

## Example (as JSON)

```json
{
  "date": "2020-03-25",
  "depositsCredits": 500
}
```

