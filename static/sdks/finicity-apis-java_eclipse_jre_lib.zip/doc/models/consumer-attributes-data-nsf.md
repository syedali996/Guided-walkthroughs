
# Consumer Attributes Data NSF

## Structure

`ConsumerAttributesDataNSF`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MonthlyNSFOccurrences` | `Object` | Required | The number of non-sufficient funds occurrences per calendar month | Object getMonthlyNSFOccurrences() | setMonthlyNSFOccurrences(Object monthlyNSFOccurrences) |
| `MonthlyLateFeeOccurrences` | `Object` | Required | The number of late fee occurrences | Object getMonthlyLateFeeOccurrences() | setMonthlyLateFeeOccurrences(Object monthlyLateFeeOccurrences) |

## Example (as JSON)

```json
{
  "monthlyNSFOccurrences": {
    "2021-04-30": 1,
    "2021-07-31": 1
  },
  "monthlyLateFeeOccurrences": {}
}
```

