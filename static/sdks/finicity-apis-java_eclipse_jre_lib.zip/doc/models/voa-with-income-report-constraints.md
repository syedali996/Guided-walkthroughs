
# VOA With Income Report Constraints

## Structure

`VOAWithIncomeReportConstraints`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountIds` | `String` | Optional | A whitespace-separated list of account IDs to be included in the report (all accounts will be included if not set) | String getAccountIds() | setAccountIds(String accountIds) |
| `ReportCustomFields` | [`List<ReportCustomField>`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. | List<ReportCustomField> getReportCustomFields() | setReportCustomFields(List<ReportCustomField> reportCustomFields) |
| `ShowNsf` | `Boolean` | Optional | Include the non-sufficient funds (NSF) summary JSON and the NSF summary PDF section in the report. Data included:<br><br>* Account<br><br>* Total number of NSF funds<br><br>* Days since the most recent NFS funds fee | Boolean getShowNsf() | setShowNsf(Boolean showNsf) |
| `FromDate` | `Long` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | Long getFromDate() | setFromDate(Long fromDate) |
| `IncomeStreamConfidenceMinimum` | `Integer` | Optional | Include income streams in the report, based on the income stream's confidence score. For example, Use the value 50 to include only income streams with a confidence score of 50 or higher. | Integer getIncomeStreamConfidenceMinimum() | setIncomeStreamConfidenceMinimum(Integer incomeStreamConfidenceMinimum) |

## Example (as JSON)

```json
{
  "accountIds": null,
  "reportCustomFields": null,
  "showNsf": null,
  "fromDate": null,
  "incomeStreamConfidenceMinimum": null
}
```

