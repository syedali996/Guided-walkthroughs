
# Report Custom Field

## Structure

`ReportCustomField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Label` | `String` | Optional | The name of the custom field | String getLabel() | setLabel(String label) |
| `Value` | `String` | Optional | The value of the custom field | String getValue() | setValue(String value) |
| `Shown` | `Boolean` | Optional | If the custom field will show on the PDF or not | Boolean getShown() | setShown(Boolean shown) |

## Example (as JSON)

```json
{
  "label": null,
  "value": null,
  "shown": null
}
```

