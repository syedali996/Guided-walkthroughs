
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `httpClientConfig` | [`ReadonlyHttpClientConfiguration`](http-client-configuration.md) | Http Client Configuration instance. |
| `finicityAppKey` | `String` | The "Finicity-App-Key" from the developer dashboard |
| `finicityAppToken` | `String` | A token returned by the `/authentication` API |

The API client can be initialized as follows:

```java
FinicityAPIsClient client = new FinicityAPIsClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .customHeaderAuthenticationCredentials("Finicity-App-Key", "Finicity-App-Token")
    .build();
```

## Finicity APIsClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getAccountsController()` | Provides access to Accounts controller. | `AccountsController` |
| `getAnalyticsAndAttributesController()` | Provides access to AnalyticsAndAttributes controller. | `AnalyticsAndAttributesController` |
| `getAppRegistrationController()` | Provides access to AppRegistration controller. | `AppRegistrationController` |
| `getAssetsController()` | Provides access to Assets controller. | `AssetsController` |
| `getAuthenticationController()` | Provides access to Authentication controller. | `AuthenticationController` |
| `getBalanceAnalyticsController()` | Provides access to BalanceAnalytics controller. | `BalanceAnalyticsController` |
| `getBankStatementsController()` | Provides access to BankStatements controller. | `BankStatementsController` |
| `getCashFlowController()` | Provides access to CashFlow controller. | `CashFlowController` |
| `getCashFlowAnalyticsController()` | Provides access to CashFlowAnalytics controller. | `CashFlowAnalyticsController` |
| `getConnectController()` | Provides access to Connect controller. | `ConnectController` |
| `getConsumersController()` | Provides access to Consumers controller. | `ConsumersController` |
| `getCustomersController()` | Provides access to Customers controller. | `CustomersController` |
| `getInstitutionsController()` | Provides access to Institutions controller. | `InstitutionsController` |
| `getPayStatementsController()` | Provides access to PayStatements controller. | `PayStatementsController` |
| `getPaymentsController()` | Provides access to Payments controller. | `PaymentsController` |
| `getPortfoliosController()` | Provides access to Portfolios controller. | `PortfoliosController` |
| `getReportsController()` | Provides access to Reports controller. | `ReportsController` |
| `getTransactionsController()` | Provides access to Transactions controller. | `TransactionsController` |
| `getTxPushController()` | Provides access to TxPush controller. | `TxPushController` |
| `getVerifyAssetsController()` | Provides access to VerifyAssets controller. | `VerifyAssetsController` |
| `getVerifyIncomeAndEmploymentController()` | Provides access to VerifyIncomeAndEmployment controller. | `VerifyIncomeAndEmploymentController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](http-client-configuration.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

