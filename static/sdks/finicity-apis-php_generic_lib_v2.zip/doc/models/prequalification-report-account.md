
# Prequalification Report Account

## Structure

`PrequalificationReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the account | getId(): ?int | setId(?int id): void |
| `number` | `?string` | Optional | The account number from the institution (all digits except the last four are obfuscated) | getNumber(): ?string | setNumber(?string number): void |
| `ownerName` | `?string` | Optional | The name of the account owner. If no owner information is available, this field won't appear in the report. | getOwnerName(): ?string | setOwnerName(?string ownerName): void |
| `ownerAddress` | `?string` | Optional | The mailing address of the account owner. If no owner information is available, this field won't appear in the report. | getOwnerAddress(): ?string | setOwnerAddress(?string ownerAddress): void |
| `name` | `?string` | Optional | The account name from the institution | getName(): ?string | setName(?string name): void |
| `type` | `?string` | Optional | One of the values from account types | getType(): ?string | setType(?string type): void |
| `aggregationStatusCode` | `?int` | Optional | The status of the most recent aggregation attempt | getAggregationStatusCode(): ?int | setAggregationStatusCode(?int aggregationStatusCode): void |
| `balance` | `?float` | Optional | The cleared balance of the account as-of `balanceDate` | getBalance(): ?float | setBalance(?float balance): void |
| `balanceDate` | `?int` | Optional | A timestamp of the balance | getBalanceDate(): ?int | setBalanceDate(?int balanceDate): void |
| `availableBalance` | `?float` | Optional | Available balance | getAvailableBalance(): ?float | setAvailableBalance(?float availableBalance): void |
| `averageMonthlyBalance` | `?float` | Optional | The average monthly balance of the account | getAverageMonthlyBalance(): ?float | setAverageMonthlyBalance(?float averageMonthlyBalance): void |
| `totNumberInsufficientFundsFeeDebitTxAccount` | `?int` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report | getTotNumberInsufficientFundsFeeDebitTxAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxAccount(?int totNumberInsufficientFundsFeeDebitTxAccount): void |
| `totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `?int` | Optional | The total number of  insufficient funds fees for the account over six months | getTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount(?int totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount): void |
| `totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `?int` | Optional | The total number of days since the most recent insufficient funds fee for the account | getTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(): ?int | setTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(?int totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount): void |
| `transactions` | [`?(ReportTransaction[])`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | getTransactions(): ?array | setTransactions(?array transactions): void |
| `asset` | [`?PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | getAsset(): ?PrequalificationReportAssetSummary | setAsset(?PrequalificationReportAssetSummary asset): void |
| `details` | [`?AccountDetails`](../../doc/models/account-details.md) | Optional | - | getDetails(): ?AccountDetails | setDetails(?AccountDetails details): void |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "availableBalance": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "asset": null,
  "details": null
}
```

