
# Transaction

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | A transaction ID | getId(): int | setId(int id): void |
| `amount` | `float` | Required | The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values. | getAmount(): float | setAmount(float amount): void |
| `accountId` | `int` | Required | An account ID represented as a number | getAccountId(): int | setAccountId(int accountId): void |
| `customerId` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): int | setCustomerId(int customerId): void |
| `status` | `string` | Required | One of "active", "pending", or "shadow" (see [Pending and Shadow Transactions](https://docs.finicity.com/pending-and-shadow-transactions/)) | getStatus(): string | setStatus(string status): void |
| `description` | `string` | Required | The description value is from the financial institution (FI), often known as the payee. The value "No description provided by institution" is returned when the FI doesn't provide one | getDescription(): string | setDescription(string description): void |
| `memo` | `?string` | Optional | The institution must provide either a description, a memo, or both. We recommended concatenating the two fields into a single value. | getMemo(): ?string | setMemo(?string memo): void |
| `type` | `?string` | Optional | If provided by the institution, the following values may be returned in the field of a record:<br><br>* "atm"<br><br>* "cash"<br><br>* "check"<br><br>* "credit"<br><br>* "debit"<br><br>* "deposit"<br><br>* "directDebit"<br><br>* "directDeposit"<br><br>* "dividend"<br><br>* "fee"<br><br>* "interest"<br><br>* "other"<br><br>* "payment"<br><br>* "pointOfSale"<br><br>* "repeatPayment"<br><br>* "serviceCharge"<br><br>* "transfer" | getType(): ?string | setType(?string type): void |
| `transactionDate` | `?int` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it occurred. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getTransactionDate(): ?int | setTransactionDate(?int transactionDate): void |
| `postedDate` | `?int` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it was posted or cleared by the institution. This value isn't required for student loan transaction data. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getPostedDate(): ?int | setPostedDate(?int postedDate): void |
| `createdDate` | `int` | Required | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it was added to our platform. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): int | setCreatedDate(int createdDate): void |
| `firstEffectiveDate` | `?int` | Optional | A date in Unix epoch time (in seconds). Represents the first timestamp of the transaction recorded in the `effectiveDate` field. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getFirstEffectiveDate(): ?int | setFirstEffectiveDate(?int firstEffectiveDate): void |
| `effectiveDate` | `?int` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it became effective on an account by an institution. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getEffectiveDate(): ?int | setEffectiveDate(?int effectiveDate): void |
| `optionExpireDate` | `?int` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction expiration date when it became expires on an account by an institution. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getOptionExpireDate(): ?int | setOptionExpireDate(?int optionExpireDate): void |
| `checkNum` | `?int` | Optional | The check number of the transaction | getCheckNum(): ?int | setCheckNum(?int checkNum): void |
| `escrowAmount` | `?float` | Optional | The portion of the transaction allocated to escrow | getEscrowAmount(): ?float | setEscrowAmount(?float escrowAmount): void |
| `feeAmount` | `?float` | Optional | The portion of the overall transaction amount applied to fees | getFeeAmount(): ?float | setFeeAmount(?float feeAmount): void |
| `suspenseAmount` | `?float` | Optional | Temporarily hold funds if you overpay or underpay your monthly payment | getSuspenseAmount(): ?float | setSuspenseAmount(?float suspenseAmount): void |
| `interestAmount` | `?float` | Optional | The portion of the transaction allocated to interest | getInterestAmount(): ?float | setInterestAmount(?float interestAmount): void |
| `principalAmount` | `?float` | Optional | The portion of the transaction allocated to principal | getPrincipalAmount(): ?float | setPrincipalAmount(?float principalAmount): void |
| `optionStrikePrice` | `?float` | Optional | The strike price of the option contract | getOptionStrikePrice(): ?float | setOptionStrikePrice(?float optionStrikePrice): void |
| `unitQuantity` | `?int` | Optional | The number of units (individual shares) in the transaction | getUnitQuantity(): ?int | setUnitQuantity(?int unitQuantity): void |
| `unitPrice` | `?float` | Optional | Share price for the investment unit: stocks, mutual funds, ETFs | getUnitPrice(): ?float | setUnitPrice(?float unitPrice): void |
| `categorization` | [`Categorization`](../../doc/models/categorization.md) | Required | Categorization Record | getCategorization(): Categorization | setCategorization(Categorization categorization): void |
| `runningBalanceAmount` | `?float` | Optional | The ending balance after the transaction was posted | getRunningBalanceAmount(): ?float | setRunningBalanceAmount(?float runningBalanceAmount): void |
| `subaccountSecurityType` | `?string` | Optional | The type of sub account the funds came from | getSubaccountSecurityType(): ?string | setSubaccountSecurityType(?string subaccountSecurityType): void |
| `commissionAmount` | `?int` | Optional | Transaction commission | getCommissionAmount(): ?int | setCommissionAmount(?int commissionAmount): void |
| `ticker` | `?string` | Optional | Ticker symbol for the investment related to the transaction | getTicker(): ?string | setTicker(?string ticker): void |
| `investmentTransactionType` | `?string` | Optional | Keywords in the `description` and `memo` fields were used to translate investment transactions into these types.<br><br>Possible values:<br><br>* "cancel"<br><br>* "purchaseToClose"<br><br>* "purchaseToCover"<br><br>* "contribution"<br><br>* "optionExercise"<br><br>* "optionExpiration"<br><br>* "fee"<br><br>* "soldToClose"<br><br>* "soldToOpen"<br><br>* "split"<br><br>* "transfer"<br><br>* "returnOfCapital"<br><br>* "income"<br><br>* "purchased"<br><br>* "sold"<br><br>* "dividendreInvest"<br><br>* "tax"<br><br>* "dividend"<br><br>* "reinvestOfIncome"<br><br>* "interest"<br><br>* "deposit"<br><br>* "otherInfo" | getInvestmentTransactionType(): ?string | setInvestmentTransactionType(?string investmentTransactionType): void |
| `taxesAmount` | `?int` | Optional | Taxes applicable to the investment trade | getTaxesAmount(): ?int | setTaxesAmount(?int taxesAmount): void |
| `currencySymbol` | `?string` | Optional | If the foreign amount value is present then this is the currency code of that foreign amount | getCurrencySymbol(): ?string | setCurrencySymbol(?string currencySymbol): void |
| `incomeType` | `?string` | Optional | Capital gains applied in short, long, or miscellaneous terms for tax purposes | getIncomeType(): ?string | setIncomeType(?string incomeType): void |
| `splitDenominator` | `?float` | Optional | Denominator of the stock split for the transaction | getSplitDenominator(): ?float | setSplitDenominator(?float splitDenominator): void |
| `splitNumerator` | `?float` | Optional | Numerator of the stock split for the transaction | getSplitNumerator(): ?float | setSplitNumerator(?float splitNumerator): void |
| `sharesPerContract` | `?float` | Optional | Shares per contract of the underlying stock option | getSharesPerContract(): ?float | setSharesPerContract(?float sharesPerContract): void |
| `subAccountFund` | `?string` | Optional | The sub account where the funds came from | getSubAccountFund(): ?string | setSubAccountFund(?string subAccountFund): void |
| `securityId` | `?string` | Optional | The security ID of the transaction | getSecurityId(): ?string | setSecurityId(?string securityId): void |
| `securityIdType` | `?string` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" | getSecurityIdType(): ?string | setSecurityIdType(?string securityIdType): void |

## Example (as JSON)

```json
{
  "id": 21284820852,
  "amount": -828.9,
  "accountId": 5011648377,
  "customerId": 1005061234,
  "status": "active",
  "description": "Buy Stock",
  "createdDate": 1607450357,
  "categorization": {
    "normalizedPayeeName": "Mad Science Research",
    "category": "ATM Fee",
    "country": "USA"
  }
}
```

