
# VOIE With Statement Data

## Structure

`VOIEWithStatementData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `assetIds` | `string[]` | Required | A list of pay statement asset IDs | getAssetIds(): array | setAssetIds(array assetIds): void |
| `extractEarnings` | `?bool` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `true` | getExtractEarnings(): ?bool | setExtractEarnings(?bool extractEarnings): void |
| `extractDeductions` | `?bool` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `false` | getExtractDeductions(): ?bool | setExtractDeductions(?bool extractDeductions): void |
| `extractDirectDeposit` | `?bool` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `true` | getExtractDirectDeposit(): ?bool | setExtractDirectDeposit(?bool extractDirectDeposit): void |

## Example (as JSON)

```json
{
  "assetIds": [
    "assetIds3"
  ],
  "extractEarnings": null,
  "extractDeductions": null,
  "extractDirectDeposit": null
}
```

