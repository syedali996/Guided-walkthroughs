
# VOA With Income Report Account

## Structure

`VOAWithIncomeReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the account | getId(): ?int | setId(?int id): void |
| `number` | `?string` | Optional | The account number from the institution (all digits except the last four are obfuscated) | getNumber(): ?string | setNumber(?string number): void |
| `ownerName` | `?string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | getOwnerName(): ?string | setOwnerName(?string ownerName): void |
| `ownerAddress` | `?string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | getOwnerAddress(): ?string | setOwnerAddress(?string ownerAddress): void |
| `name` | `?string` | Optional | The account name from the institution | getName(): ?string | setName(?string name): void |
| `type` | `?string` | Optional | One of the values from account types | getType(): ?string | setType(?string type): void |
| `availableBalance` | `?float` | Optional | The available balance for the account | getAvailableBalance(): ?float | setAvailableBalance(?float availableBalance): void |
| `aggregationStatusCode` | `?int` | Optional | The status of the most recent aggregation attempt | getAggregationStatusCode(): ?int | setAggregationStatusCode(?int aggregationStatusCode): void |
| `balance` | `?float` | Optional | The cleared balance of the account as-of balanceDate | getBalance(): ?float | setBalance(?float balance): void |
| `balanceDate` | `?int` | Optional | A timestamp showing when the balance was captured | getBalanceDate(): ?int | setBalanceDate(?int balanceDate): void |
| `averageMonthlyBalance` | `?float` | Optional | The average monthly balance of this account | getAverageMonthlyBalance(): ?float | setAverageMonthlyBalance(?float averageMonthlyBalance): void |
| `totNumberInsufficientFundsFeeDebitTxAccount` | `?int` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report. | getTotNumberInsufficientFundsFeeDebitTxAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxAccount(?int totNumberInsufficientFundsFeeDebitTxAccount): void |
| `totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `?int` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. | getTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount(?int totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount): void |
| `totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `?int` | Optional | The number of days since the most recent insufficient funds transaction, based on the `fromDate` of the report. | getTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(): ?int | setTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(?int totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount): void |
| `transactions` | [`?(ReportTransaction[])`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | getTransactions(): ?array | setTransactions(?array transactions): void |
| `details` | [`?AccountDetails`](../../doc/models/account-details.md) | Optional | - | getDetails(): ?AccountDetails | setDetails(?AccountDetails details): void |
| `asset` | [`?PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | getAsset(): ?PrequalificationReportAssetSummary | setAsset(?PrequalificationReportAssetSummary asset): void |
| `incomeStreams` | [`?(VOAIReportIncomeStream[])`](../../doc/models/voai-report-income-stream.md) | Optional | A list of income stream records | getIncomeStreams(): ?array | setIncomeStreams(?array incomeStreams): void |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "availableBalance": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "details": null,
  "asset": null,
  "incomeStreams": null
}
```

