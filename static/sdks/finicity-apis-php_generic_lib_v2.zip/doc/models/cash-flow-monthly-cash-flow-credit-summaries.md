
# Cash Flow Monthly Cash Flow Credit Summaries

## Structure

`CashFlowMonthlyCashFlowCreditSummaries`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | One instance for each complete calendar month in the report | getMonth(): int | setMonth(int month): void |
| `numberOfCredits` | `string` | Required | Number of credits by month across all accounts | getNumberOfCredits(): string | setNumberOfCredits(string numberOfCredits): void |
| `totalCreditsAmount` | `float` | Required | Total amount of credits by month across all accounts | getTotalCreditsAmount(): float | setTotalCreditsAmount(float totalCreditsAmount): void |
| `largestCredit` | `float` | Required | Largest credit by month across all accounts | getLargestCredit(): float | setLargestCredit(float largestCredit): void |
| `numberOfCreditsLessTransfers` | `string` | Required | Number of credits by month (less transfers) across all accounts | getNumberOfCreditsLessTransfers(): string | setNumberOfCreditsLessTransfers(string numberOfCreditsLessTransfers): void |
| `totalCreditsAmountLessTransfers` | `float` | Required | Total amount of credits by month (less transfers) across all accounts | getTotalCreditsAmountLessTransfers(): float | setTotalCreditsAmountLessTransfers(float totalCreditsAmountLessTransfers): void |
| `averageCreditAmount` | `float` | Required | The average credit amount | getAverageCreditAmount(): float | setAverageCreditAmount(float averageCreditAmount): void |
| `estimatedNumberOfLoanDeposits` | `string` | Required | The estimated number of loan deposits by month | getEstimatedNumberOfLoanDeposits(): string | setEstimatedNumberOfLoanDeposits(string estimatedNumberOfLoanDeposits): void |
| `estimatedLoanDepositAmount` | `float` | Required | The estimated loan deposit amount by month | getEstimatedLoanDepositAmount(): float | setEstimatedLoanDepositAmount(float estimatedLoanDepositAmount): void |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "57",
  "totalCreditsAmount": 3479.39,
  "largestCredit": 3000.49,
  "numberOfCreditsLessTransfers": "5",
  "totalCreditsAmountLessTransfers": 25.46,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

