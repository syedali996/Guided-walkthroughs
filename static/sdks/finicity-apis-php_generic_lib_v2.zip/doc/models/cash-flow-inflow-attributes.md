
# Cash Flow Inflow Attributes

## Structure

`CashFlowInflowAttributes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `averageDepositByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of deposits during periods in the report | getAverageDepositByMonthForTheReportTimePeriod(): ?array | setAverageDepositByMonthForTheReportTimePeriod(?array averageDepositByMonthForTheReportTimePeriod): void |
| `countDepositsByMonthForTheReportTimePeriod` | [`ObbDateRangeAndCount[]`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all deposits during periods in the report | getCountDepositsByMonthForTheReportTimePeriod(): array | setCountDepositsByMonthForTheReportTimePeriod(array countDepositsByMonthForTheReportTimePeriod): void |
| `historicCountOfDepositTransactions` | `int` | Required | Count of ALL deposits over entire known history of the account (may exceed requested length of report) | getHistoricCountOfDepositTransactions(): int | setHistoricCountOfDepositTransactions(int historicCountOfDepositTransactions): void |
| `historicSumOfDeposits` | `?float` | Optional | Sum of ALL deposits over entire known history of the account (may exceed requested length of report) | getHistoricSumOfDeposits(): ?float | setHistoricSumOfDeposits(?float historicSumOfDeposits): void |
| `maximumDepositByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum deposit value for different periods in the report | getMaximumDepositByMonthForTheReportTimePeriod(): array | setMaximumDepositByMonthForTheReportTimePeriod(array maximumDepositByMonthForTheReportTimePeriod): void |
| `minimumDepositByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum deposit value for different periods in the report | getMinimumDepositByMonthForTheReportTimePeriod(): array | setMinimumDepositByMonthForTheReportTimePeriod(array minimumDepositByMonthForTheReportTimePeriod): void |
| `sumDepositsByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all deposits during periods in the report | getSumDepositsByMonthForTheReportTimePeriod(): array | setSumDepositsByMonthForTheReportTimePeriod(array sumDepositsByMonthForTheReportTimePeriod): void |

## Example (as JSON)

```json
{
  "countDepositsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfDepositTransactions": 20,
  "maximumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumDepositsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

