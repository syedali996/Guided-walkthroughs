
# Test Tx Push Transaction

A fake transaction for TxPush testing

## Structure

`TestTxPushTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | The amount of the transaction | getAmount(): float | setAmount(float amount): void |
| `description` | `string` | Required | The description of the transaction | getDescription(): string | setDescription(string description): void |
| `status` | `?string` | Optional | "active" or "pending" (optional)<br>**Default**: `'active'` | getStatus(): ?string | setStatus(?string status): void |
| `postedDate` | `?int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getPostedDate(): ?int | setPostedDate(?int postedDate): void |
| `transactionDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getTransactionDate(): int | setTransactionDate(int transactionDate): void |

## Example (as JSON)

```json
{
  "amount": -4.25,
  "description": "a testing transaction description",
  "transactionDate": 1607450357
}
```

