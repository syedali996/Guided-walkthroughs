
# Customer Update

Represent an update to customer fields

## Structure

`CustomerUpdate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | First name(s) / given name(s) | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | Last name(s) / surname(s) | getLastName(): ?string | setLastName(?string lastName): void |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

