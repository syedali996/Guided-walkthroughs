
# Report Transaction

## Structure

`ReportTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | A transaction ID | getId(): int | setId(int id): void |
| `amount` | `?float` | Optional | The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values. | getAmount(): ?float | setAmount(?float amount): void |
| `postedDate` | `int` | Required | A timestamp showing when the transaction was posted or cleared by the institution | getPostedDate(): int | setPostedDate(int postedDate): void |
| `description` | `string` | Required | The description of the transaction, as provided by the institution (often known as `payee`). In the event that this field is left blank by the institution, Finicity will pass a value of "No description provided by institution". All other values are provided by the institution. | getDescription(): string | setDescription(string description): void |
| `memo` | `?string` | Optional | The memo field of the transaction, as provided by the institution. The institution must provide either a description, a memo, or both. It is recommended to concatenate the two fields into a single value. | getMemo(): ?string | setMemo(?string memo): void |
| `normalizedPayee` | `string` | Required | A normalized payee, derived from the transaction's `description` and `memo` fields | getNormalizedPayee(): string | setNormalizedPayee(string normalizedPayee): void |
| `institutionTransactionId` | `string` | Required | The unique identifier given by the FI for each transaction | getInstitutionTransactionId(): string | setInstitutionTransactionId(string institutionTransactionId): void |
| `category` | `string` | Required | One of the values from Categories (assigned based on the payee name) | getCategory(): string | setCategory(string category): void |
| `type` | `?string` | Optional | One of the values from transaction types | getType(): ?string | setType(?string type): void |
| `securityType` | `?string` | Optional | The type of investment security (VOA only) | getSecurityType(): ?string | setSecurityType(?string securityType): void |
| `symbol` | `?string` | Optional | Investment symbol (VOA only) | getSymbol(): ?string | setSymbol(?string symbol): void |
| `commission` | `?float` | Optional | - | getCommission(): ?float | setCommission(?float commission): void |

## Example (as JSON)

```json
{
  "id": 21284820852,
  "postedDate": 1571313600,
  "description": "ATM CHECK DEPOSIT mm/dd",
  "normalizedPayee": "T-Mobile",
  "institutionTransactionId": "0000000000",
  "category": "Income"
}
```

