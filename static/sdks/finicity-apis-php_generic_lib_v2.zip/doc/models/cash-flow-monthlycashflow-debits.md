
# Cash Flow Monthlycashflow Debits

## Structure

`CashFlowMonthlycashflowDebits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | One instance for each complete calendar month in the report | getMonth(): int | setMonth(int month): void |
| `numberOfDebits` | `string` | Required | Number of Debits by month | getNumberOfDebits(): string | setNumberOfDebits(string numberOfDebits): void |
| `totalDebitsAmount` | `float` | Required | Total Amount of Debits by month | getTotalDebitsAmount(): float | setTotalDebitsAmount(float totalDebitsAmount): void |
| `largestDebit` | `float` | Required | Largest Debit by month | getLargestDebit(): float | setLargestDebit(float largestDebit): void |
| `numberOfDebitsLessTransfers` | `string` | Required | Number of Debits by month (less transfers) | getNumberOfDebitsLessTransfers(): string | setNumberOfDebitsLessTransfers(string numberOfDebitsLessTransfers): void |
| `totalDebitsAmountLessTransfers` | `float` | Required | Total amount of debits by month (less transfers) | getTotalDebitsAmountLessTransfers(): float | setTotalDebitsAmountLessTransfers(float totalDebitsAmountLessTransfers): void |
| `averageDebitAmount` | `float` | Required | The average debit amount | getAverageDebitAmount(): float | setAverageDebitAmount(float averageDebitAmount): void |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfDebits": "5",
  "totalDebitsAmount": -12345,
  "largestDebit": -2000,
  "numberOfDebitsLessTransfers": "3",
  "totalDebitsAmountLessTransfers": -2000,
  "averageDebitAmount": 500
}
```

