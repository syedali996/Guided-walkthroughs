
# Cash Flow Monthly Cash Flow Characteristics

## Structure

`CashFlowMonthlyCashFlowCharacteristics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | One instance for each complete calendar month in the report | getMonth(): int | setMonth(int month): void |
| `totalCreditsLessTotalDebits` | `float` | Required | Total Credits - Total Debits by month | getTotalCreditsLessTotalDebits(): float | setTotalCreditsLessTotalDebits(float totalCreditsLessTotalDebits): void |
| `totalCreditsLessTotalDebitsLessTransfers` | `float` | Required | Total Credits - Total Debits by month (Without Transfers) | getTotalCreditsLessTotalDebitsLessTransfers(): float | setTotalCreditsLessTotalDebitsLessTransfers(float totalCreditsLessTotalDebitsLessTransfers): void |
| `averageTransactionAmount` | `float` | Required | Average transaction amount by month | getAverageTransactionAmount(): float | setAverageTransactionAmount(float averageTransactionAmount): void |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "totalCreditsLessTotalDebits": 15000,
  "totalCreditsLessTotalDebitsLessTransfers": 11000,
  "averageTransactionAmount": 10
}
```

