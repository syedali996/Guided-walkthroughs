
# App Financial Institution Status

The registration status fields for each specific OAuth financial institution

## Structure

`AppFinancialInstitutionStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | The ID of a financial institution, represented as a number | getId(): int | setId(int id): void |
| `abbrvName` | `?string` | Optional | The application's abbreviated name | getAbbrvName(): ?string | setAbbrvName(?string abbrvName): void |
| `logoUrl` | `?string` | Optional | An URL to a logo file | getLogoUrl(): ?string | setLogoUrl(?string logoUrl): void |
| `decryptionKeyActivated` | `bool` | Required | Status of decryption keys for financial institution app registration | getDecryptionKeyActivated(): bool | setDecryptionKeyActivated(bool decryptionKeyActivated): void |
| `createdDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): int | setCreatedDate(int createdDate): void |
| `lastModifiedDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLastModifiedDate(): int | setLastModifiedDate(int lastModifiedDate): void |
| `status` | `bool` | Required | "false" indicates registration is still pending | getStatus(): bool | setStatus(bool status): void |

## Example (as JSON)

```json
{
  "id": 4222,
  "decryptionKeyActivated": false,
  "createdDate": 1607450357,
  "lastModifiedDate": 1607450357,
  "status": true
}
```

