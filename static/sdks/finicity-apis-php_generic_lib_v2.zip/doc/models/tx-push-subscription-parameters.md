
# Tx Push Subscription Parameters

## Structure

`TxPushSubscriptionParameters`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callbackUrl` | `string` | Required | A callback URL where to receive TxPush notifications | getCallbackUrl(): string | setCallbackUrl(string callbackUrl): void |

## Example (as JSON)

```json
{
  "callbackUrl": "https://www.mydomain.com/txpush/listener"
}
```

