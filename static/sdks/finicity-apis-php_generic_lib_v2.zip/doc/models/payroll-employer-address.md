
# Payroll Employer Address

## Structure

`PayrollEmployerAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `address1` | `?string` | Optional | Employer address as stated by the employer in the payroll system | getAddress1(): ?string | setAddress1(?string address1): void |
| `city` | `?string` | Optional | Employer city as stated by the employer in the payroll system | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | Employer state as stated by the employer in the payroll system | getState(): ?string | setState(?string state): void |
| `zip` | `?string` | Optional | Employer zip code as stated by the employer in the payroll system | getZip(): ?string | setZip(?string zip): void |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

