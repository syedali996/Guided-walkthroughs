
# VOIE Pay Statement 2

## Structure

`VOIEPayStatement2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payPeriod` | `string` | Required | The pay period of the pay statement | getPayPeriod(): string | setPayPeriod(string payPeriod): void |
| `billable` | `bool` | Required | Designates whether the pay statement is billable | getBillable(): bool | setBillable(bool billable): void |
| `assetId` | `string` | Required | The asset ID of the stored pay statement | getAssetId(): string | setAssetId(string assetId): void |
| `payDate` | `int` | Required | The listed pay date for the pay statement | getPayDate(): int | setPayDate(int payDate): void |
| `startDate` | `int` | Required | The beginning of the pay period | getStartDate(): int | setStartDate(int startDate): void |
| `endDate` | `int` | Required | The end of the pay period | getEndDate(): int | setEndDate(int endDate): void |
| `netPayCurrent` | `float` | Required | The total pay after deductions for the employee for the current pay period | getNetPayCurrent(): float | setNetPayCurrent(float netPayCurrent): void |
| `netPayYTD` | `float` | Required | The total accumulation of pay after deductions for the employee for the current pay year | getNetPayYTD(): float | setNetPayYTD(float netPayYTD): void |
| `grossPayCurrent` | `float` | Required | The total pay before deductions for the employee for the current pay period | getGrossPayCurrent(): float | setGrossPayCurrent(float grossPayCurrent): void |
| `grossPayYTD` | `float` | Required | The total accumulation of pay before deductions for the employee for the current pay year | getGrossPayYTD(): float | setGrossPayYTD(float grossPayYTD): void |
| `payrollProvider` | `?string` | Optional | The company that provides the pay stub. | getPayrollProvider(): ?string | setPayrollProvider(?string payrollProvider): void |
| `employer` | [`Employer`](../../doc/models/employer.md) | Required | - | getEmployer(): Employer | setEmployer(Employer employer): void |
| `employee` | [`Employee`](../../doc/models/employee.md) | Required | - | getEmployee(): Employee | setEmployee(Employee employee): void |
| `payStat` | [`PayStat[]`](../../doc/models/pay-stat.md) | Required | Information pertaining to the earnings on the pay statement | getPayStat(): array | setPayStat(array payStat): void |
| `deductions` | [`?(Deduction[])`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement | getDeductions(): ?array | setDeductions(?array deductions): void |
| `directDeposits` | [`DirectDeposit[]`](../../doc/models/direct-deposit.md) | Required | Information pertaining to direct deposits on the pay statement | getDirectDeposits(): array | setDirectDeposits(array directDeposits): void |
| `monthlyIncome` | [`PaystubMonthlyIncomeRecord`](../../doc/models/paystub-monthly-income-record.md) | Required | - | getMonthlyIncome(): PaystubMonthlyIncomeRecord | setMonthlyIncome(PaystubMonthlyIncomeRecord monthlyIncome): void |
| `institutions` | `string[]` | Required | Not populated for the voieWithStatement style of paystub report. For the VOIE - Paystub (with TXVerify) reports this would include details of the financial institution accounts and income streams with matching transactions to the pay statement. | getInstitutions(): array | setInstitutions(array institutions): void |
| `errorCode` | `?int` | Optional | Error code for the asset | getErrorCode(): ?int | setErrorCode(?int errorCode): void |
| `errorMessage` | `?string` | Optional | Error message for the asset | getErrorMessage(): ?string | setErrorMessage(?string errorMessage): void |

## Example (as JSON)

```json
{
  "payPeriod": "LastPayPeriod",
  "billable": true,
  "assetId": "6f8fb0a0-e882-4f57-b672-cf53f1397581",
  "payDate": 1559241000,
  "startDate": 1557513000,
  "endDate": 1558722600,
  "netPayCurrent": 1802.22,
  "netPayYTD": 36000,
  "grossPayCurrent": 24200,
  "grossPayYTD": 72600,
  "employer": null,
  "employee": null,
  "payStat": null,
  "directDeposits": null,
  "monthlyIncome": null,
  "institutions": []
}
```

