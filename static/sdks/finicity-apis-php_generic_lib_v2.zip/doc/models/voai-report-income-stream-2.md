
# VOAI Report Income Stream 2

A report income stream record

## Structure

`VOAIReportIncomeStream2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Income stream ID | getId(): string | setId(string id): void |
| `name` | `string` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream | getName(): string | setName(string name): void |
| `status` | `string` | Required | Possible values: "ACTIVE", "INACTIVE" | getStatus(): string | setStatus(string status): void |
| `estimateInclusion` | `string` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" | getEstimateInclusion(): string | setEstimateInclusion(string estimateInclusion): void |
| `confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) | getConfidence(): int | setConfidence(int confidence): void |
| `cadence` | [`CadenceDetails`](../../doc/models/cadence-details.md) | Required | - | getCadence(): CadenceDetails | setCadence(CadenceDetails cadence): void |
| `netMonthly` | [`NetMonthly[]`](../../doc/models/net-monthly.md) | Required | A list of net monthly records. One instance for each complete calendar month in the report. | getNetMonthly(): array | setNetMonthly(array netMonthly): void |
| `netAnnual` | `float` | Required | Sum of all values in `netMonthlyIncome` over the previous 12 months | getNetAnnual(): float | setNetAnnual(float netAnnual): void |
| `projectedNetAnnual` | `float` | Required | Projected net income over the next 12 months, across all income streams, based on `netAnnualIncome` | getProjectedNetAnnual(): float | setProjectedNetAnnual(float projectedNetAnnual): void |
| `estimatedGrossAnnual` | `float` | Required | Before-tax gross annual income (estimated from `netAnnual`) across all income stream in the past 12 months | getEstimatedGrossAnnual(): float | setEstimatedGrossAnnual(float estimatedGrossAnnual): void |
| `projectedGrossAnnual` | `float` | Required | Projected gross income over the next 12 months, across all active income streams, based on `projectedNetAnnual` | getProjectedGrossAnnual(): float | setProjectedGrossAnnual(float projectedGrossAnnual): void |
| `averageMonthlyIncomeNet` | `float` | Required | Monthly average amount over the previous 24 months | getAverageMonthlyIncomeNet(): float | setAverageMonthlyIncomeNet(float averageMonthlyIncomeNet): void |
| `incomeStreamMonths` | `int` | Required | The number of months the income transactions are observed | getIncomeStreamMonths(): int | setIncomeStreamMonths(int incomeStreamMonths): void |
| `transactions` | [`ReportTransaction[]`](../../doc/models/report-transaction.md) | Required | A list of transaction records | getTransactions(): array | setTransactions(array transactions): void |
| `daysSinceLastTransaction` | `int` | Required | The number of days since the last credit transaction for the particular income stream | getDaysSinceLastTransaction(): int | setDaysSinceLastTransaction(int daysSinceLastTransaction): void |
| `nextExpectedTransactionDate` | `int` | Required | The next expected credit transaction date for the particular income stream, based on the cadence | getNextExpectedTransactionDate(): int | setNextExpectedTransactionDate(int nextExpectedTransactionDate): void |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voah",
  "name": "none",
  "status": null,
  "estimateInclusion": null,
  "confidence": 70,
  "cadence": null,
  "netMonthly": [
    {
      "month": 1522562400,
      "net": 2004.77
    }
  ],
  "netAnnual": 110475.7,
  "projectedNetAnnual": 0,
  "estimatedGrossAnnual": 12321.1,
  "projectedGrossAnnual": 151609,
  "averageMonthlyIncomeNet": 9206.31,
  "incomeStreamMonths": 18,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "daysSinceLastTransaction": 15,
  "nextExpectedTransactionDate": 1572625469
}
```

