
# Loan Payment Details Account

## Structure

`LoanPaymentDetailsAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountId` | `string` | Required | An account ID | getAccountId(): string | setAccountId(string accountId): void |
| `accountNumber` | `string` | Required | Institution's ID of the Student Loan Account | getAccountNumber(): string | setAccountNumber(string accountNumber): void |
| `accountPaymentNumber` | `string` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. | getAccountPaymentNumber(): string | setAccountPaymentNumber(string accountPaymentNumber): void |
| `accountPaymentAddress` | `string` | Required | The payment address to which send manual payments should be sent | getAccountPaymentAddress(): string | setAccountPaymentAddress(string accountPaymentAddress): void |
| `accountFuturePayoffAmount` | `?float` | Optional | The payoff amount for the account | getAccountFuturePayoffAmount(): ?float | setAccountFuturePayoffAmount(?float accountFuturePayoffAmount): void |
| `accountFuturePayoffDate` | `?\DateTime` | Optional | The date to which the "Future Payoff Amount" applies | getAccountFuturePayoffDate(): ?\DateTime | setAccountFuturePayoffDate(?\DateTime accountFuturePayoffDate): void |
| `groupDetail` | [`?(LoanPaymentDetailsGroup[])`](../../doc/models/loan-payment-details-group.md) | Optional | Group details | getGroupDetail(): ?array | setGroupDetail(?array groupDetail): void |
| `loanDetail` | [`?(LoanPaymentDetailsLoan[])`](../../doc/models/loan-payment-details-loan.md) | Optional | Loan details | getLoanDetail(): ?array | setLoanDetail(?array loanDetail): void |

## Example (as JSON)

```json
{
  "accountId": "5011648377",
  "accountNumber": "9876543210",
  "accountPaymentNumber": "00001234895413",
  "accountPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054"
}
```

