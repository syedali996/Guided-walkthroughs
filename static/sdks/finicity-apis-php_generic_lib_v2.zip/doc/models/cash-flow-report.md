
# Cash Flow Report

A Cash Flow report

## Structure

`CashFlowReport`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | A report ID | getId(): ?string | setId(?string id): void |
| `customerType` | `?string` | Optional | The type of customer ("active" or "testing" or "" for all types) | getCustomerType(): ?string | setCustomerType(?string customerType): void |
| `customerId` | `?int` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): ?int | setCustomerId(?int customerId): void |
| `requestId` | `?string` | Optional | Finicity indicator to track all activity associated with this report | getRequestId(): ?string | setRequestId(?string requestId): void |
| `requesterName` | `?string` | Optional | Name of a Finicity partner | getRequesterName(): ?string | setRequesterName(?string requesterName): void |
| `createdDate` | `?int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): ?int | setCreatedDate(?int createdDate): void |
| `title` | `?string` | Optional | Title of the report | getTitle(): ?string | setTitle(?string title): void |
| `consumerId` | `?string` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. | getConsumerId(): ?string | setConsumerId(?string consumerId): void |
| `consumerSsn` | `?string` | Optional | Last 4 digits of a SSN | getConsumerSsn(): ?string | setConsumerSsn(?string consumerSsn): void |
| `type` | `?string` | Optional | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | getType(): ?string | setType(?string type): void |
| `status` | `?string` | Optional | A report generation status. Possible values: "inProgress", "success", "failure". | getStatus(): ?string | setStatus(?string status): void |
| `errors` | [`?(ErrorMessage[])`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | getErrors(): ?array | setErrors(?array errors): void |
| `portfolioId` | `?string` | Optional | A unique identifier that will be consistent across all reports created for the same customer | getPortfolioId(): ?string | setPortfolioId(?string portfolioId): void |
| `startDate` | `?int` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getStartDate(): ?int | setStartDate(?int startDate): void |
| `endDate` | `?int` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getEndDate(): ?int | setEndDate(?int endDate): void |
| `days` | `?int` | Optional | Number of days covered by the report | getDays(): ?int | setDays(?int days): void |
| `seasoned` | `?bool` | Optional | "true" if the report covers more than 365 days | getSeasoned(): ?bool | setSeasoned(?bool seasoned): void |
| `institutions` | [`?(ReportInstitution[])`](../../doc/models/report-institution.md) | Optional | A list of institution records, including information about the individual accounts used in this report | getInstitutions(): ?array | setInstitutions(?array institutions): void |
| `cashFlowBalanceSummary` | [`?CashFlowCashFlowBalanceSummary`](../../doc/models/cash-flow-cash-flow-balance-summary.md) | Optional | - | getCashFlowBalanceSummary(): ?CashFlowCashFlowBalanceSummary | setCashFlowBalanceSummary(?CashFlowCashFlowBalanceSummary cashFlowBalanceSummary): void |
| `cashFlowCreditSummary` | [`?CashFlowCashFlowCreditSummary`](../../doc/models/cash-flow-cash-flow-credit-summary.md) | Optional | - | getCashFlowCreditSummary(): ?CashFlowCashFlowCreditSummary | setCashFlowCreditSummary(?CashFlowCashFlowCreditSummary cashFlowCreditSummary): void |
| `cashFlowDebitSummary` | [`?CashFlowCashFlowDebitSummary`](../../doc/models/cash-flow-cash-flow-debit-summary.md) | Optional | - | getCashFlowDebitSummary(): ?CashFlowCashFlowDebitSummary | setCashFlowDebitSummary(?CashFlowCashFlowDebitSummary cashFlowDebitSummary): void |
| `cashFlowCharacteristicsSummary` | [`?CashFlowCashFlowCharacteristicsSummary`](../../doc/models/cash-flow-cash-flow-characteristics-summary.md) | Optional | - | getCashFlowCharacteristicsSummary(): ?CashFlowCashFlowCharacteristicsSummary | setCashFlowCharacteristicsSummary(?CashFlowCashFlowCharacteristicsSummary cashFlowCharacteristicsSummary): void |
| `possibleLoanDeposits` | [`?(CashFlowPossibleLoanDeposits[])`](../../doc/models/cash-flow-possible-loan-deposits.md) | Optional | A possible loan deposits record | getPossibleLoanDeposits(): ?array | setPossibleLoanDeposits(?array possibleLoanDeposits): void |

## Example (as JSON)

```json
{
  "id": null,
  "customerType": null,
  "customerId": null,
  "requestId": null,
  "requesterName": null,
  "createdDate": null,
  "title": null,
  "consumerId": null,
  "consumerSsn": null,
  "type": null,
  "status": null,
  "errors": null,
  "portfolioId": null,
  "startDate": null,
  "endDate": null,
  "days": null,
  "seasoned": null,
  "institutions": null,
  "cashFlowBalanceSummary": null,
  "cashFlowCreditSummary": null,
  "cashFlowDebitSummary": null,
  "cashFlowCharacteristicsSummary": null,
  "possibleLoanDeposits": null
}
```

