
# Cash Flow Analytics Metrics

## Structure

`CashFlowAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `inflow` | [`?CashFlowInflowAttributes`](../../doc/models/cash-flow-inflow-attributes.md) | Optional | Inflow Attributes | getInflow(): ?CashFlowInflowAttributes | setInflow(?CashFlowInflowAttributes inflow): void |
| `negativeTriggers` | [`?CashFlowNegativeTriggers`](../../doc/models/cash-flow-negative-triggers.md) | Optional | Details of transactions that may be warning signs of bad creditworthiness | getNegativeTriggers(): ?CashFlowNegativeTriggers | setNegativeTriggers(?CashFlowNegativeTriggers negativeTriggers): void |
| `outflow` | [`?CashFlowOutflowAttributes`](../../doc/models/cash-flow-outflow-attributes.md) | Optional | Outflow attributes | getOutflow(): ?CashFlowOutflowAttributes | setOutflow(?CashFlowOutflowAttributes outflow): void |
| `revenueByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Sum of all transactions categorized as revenue, split by months | getRevenueByMonthForTheReportTimePeriod(): ?array | setRevenueByMonthForTheReportTimePeriod(?array revenueByMonthForTheReportTimePeriod): void |
| `revenueForTheReportTimePeriod` | `?float` | Optional | Sum of all transactions categorized as revenue | getRevenueForTheReportTimePeriod(): ?float | setRevenueForTheReportTimePeriod(?float revenueForTheReportTimePeriod): void |
| `transactionAnalytics` | [`?CashFlowTransactionAnalyticsAttributes`](../../doc/models/cash-flow-transaction-analytics-attributes.md) | Optional | Transaction Analytics Attributes | getTransactionAnalytics(): ?CashFlowTransactionAnalyticsAttributes | setTransactionAnalytics(?CashFlowTransactionAnalyticsAttributes transactionAnalytics): void |

## Example (as JSON)

```json
{
  "inflow": null,
  "negativeTriggers": null,
  "outflow": null,
  "revenueByMonthForTheReportTimePeriod": null,
  "revenueForTheReportTimePeriod": null,
  "transactionAnalytics": null
}
```

