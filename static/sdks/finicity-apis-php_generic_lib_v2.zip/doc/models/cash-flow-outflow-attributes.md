
# Cash Flow Outflow Attributes

## Structure

`CashFlowOutflowAttributes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `averageWithdrawalByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of withdrawals during periods in the report | getAverageWithdrawalByMonthForTheReportTimePeriod(): ?array | setAverageWithdrawalByMonthForTheReportTimePeriod(?array averageWithdrawalByMonthForTheReportTimePeriod): void |
| `countWithdrawalsByMonthForTheReportTimePeriod` | [`ObbDateRangeAndCount[]`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all withdrawals during periods in the report | getCountWithdrawalsByMonthForTheReportTimePeriod(): array | setCountWithdrawalsByMonthForTheReportTimePeriod(array countWithdrawalsByMonthForTheReportTimePeriod): void |
| `historicCountOfWithdrawalTransactions` | `int` | Required | Count of ALL withdrawals over entire known history of the account (may exceed requested length of report) | getHistoricCountOfWithdrawalTransactions(): int | setHistoricCountOfWithdrawalTransactions(int historicCountOfWithdrawalTransactions): void |
| `historicSumOfWithdrawals` | `?float` | Optional | Sum of ALL withdrawals over entire known history of the account (may exceed requested length of report) | getHistoricSumOfWithdrawals(): ?float | setHistoricSumOfWithdrawals(?float historicSumOfWithdrawals): void |
| `maximumWithdrawalByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum withdrawal value for different periods in the report | getMaximumWithdrawalByMonthForTheReportTimePeriod(): array | setMaximumWithdrawalByMonthForTheReportTimePeriod(array maximumWithdrawalByMonthForTheReportTimePeriod): void |
| `minimumWithdrawalByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum withdrawal value for different periods in the report | getMinimumWithdrawalByMonthForTheReportTimePeriod(): array | setMinimumWithdrawalByMonthForTheReportTimePeriod(array minimumWithdrawalByMonthForTheReportTimePeriod): void |
| `sumWithdrawalsByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all withdrawals during periods in the report | getSumWithdrawalsByMonthForTheReportTimePeriod(): array | setSumWithdrawalsByMonthForTheReportTimePeriod(array sumWithdrawalsByMonthForTheReportTimePeriod): void |

## Example (as JSON)

```json
{
  "countWithdrawalsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfWithdrawalTransactions": 20,
  "maximumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumWithdrawalsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

