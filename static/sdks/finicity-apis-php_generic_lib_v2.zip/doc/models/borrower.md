
# Borrower

## Structure

`Borrower`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `customerId` | `string` | Required | A customer ID. See Add Customer API for how to create a customer ID. | getCustomerId(): string | setCustomerId(string customerId): void |
| `consumerId` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | getConsumerId(): string | setConsumerId(string consumerId): void |
| `type` | `string` | Required | "primary" or "jointBorrower" | getType(): string | setType(string type): void |
| `optionalConsumerInfo` | [`?ConsumerInfo`](../../doc/models/consumer-info.md) | Optional | The SSN and date of birth of a consumer | getOptionalConsumerInfo(): ?ConsumerInfo | setOptionalConsumerInfo(?ConsumerInfo optionalConsumerInfo): void |

## Example (as JSON)

```json
{
  "customerId": "1005061234",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "type": "primary"
}
```

