
# Statement Data

## Structure

`StatementData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountId` | `int` | Required | An account ID represented as a number | getAccountId(): int | setAccountId(int accountId): void |
| `index` | `?int` | Optional | Index of the statement to retrieve<br>**Default**: `1`<br>**Constraints**: `<= 6` | getIndex(): ?int | setIndex(?int index): void |

## Example (as JSON)

```json
{
  "accountId": 5011648377
}
```

