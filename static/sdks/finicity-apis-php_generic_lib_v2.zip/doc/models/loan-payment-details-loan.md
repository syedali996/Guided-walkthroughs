
# Loan Payment Details Loan

Loan details

## Structure

`LoanPaymentDetailsLoan`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountId` | `string` | Required | An account ID | getAccountId(): string | setAccountId(string accountId): void |
| `loanNumber` | `string` | Required | Institution's ID of the Student Loan | getLoanNumber(): string | setLoanNumber(string loanNumber): void |
| `loanPaymentNumber` | `string` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. | getLoanPaymentNumber(): string | setLoanPaymentNumber(string loanPaymentNumber): void |
| `loanPaymentAddress` | `string` | Required | The payment address to which send manual payments should be sent | getLoanPaymentAddress(): string | setLoanPaymentAddress(string loanPaymentAddress): void |
| `loanFuturePayoffAmount` | `?float` | Optional | The payoff amount for the loan | getLoanFuturePayoffAmount(): ?float | setLoanFuturePayoffAmount(?float loanFuturePayoffAmount): void |
| `loanFuturePayoffDate` | `?\DateTime` | Optional | The date to which the "Future Payoff Amount" applies | getLoanFuturePayoffDate(): ?\DateTime | setLoanFuturePayoffDate(?\DateTime loanFuturePayoffDate): void |

## Example (as JSON)

```json
{
  "accountId": "5011648377",
  "loanNumber": "3210-Group A-1",
  "loanPaymentNumber": "00001234895413-A-1",
  "loanPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054"
}
```

