
# Customer Account Position

Details for investment account holdings

## Structure

`CustomerAccountPosition`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The id of the investment position | getId(): ?int | setId(?int id): void |
| `description` | `?string` | Optional | The description of the holding | getDescription(): ?string | setDescription(?string description): void |
| `symbol` | `?string` | Optional | The investment position's market ticker symbol | getSymbol(): ?string | setSymbol(?string symbol): void |
| `units` | `?float` | Optional | The number of units of the holding | getUnits(): ?float | setUnits(?float units): void |
| `currentPrice` | `?float` | Optional | The current price of the investment holding | getCurrentPrice(): ?float | setCurrentPrice(?float currentPrice): void |
| `securityName` | `?string` | Optional | The security name for the investment holding | getSecurityName(): ?string | setSecurityName(?string securityName): void |
| `transactionType` | `?string` | Optional | The transaction type of the holding, such as cash, margin, and more | getTransactionType(): ?string | setTransactionType(?string transactionType): void |
| `marketValue` | `?float` | Optional | Market value of an investment position at the time of retrieval | getMarketValue(): ?float | setMarketValue(?float marketValue): void |
| `costBasis` | `?float` | Optional | The total cost of acquiring the security | getCostBasis(): ?float | setCostBasis(?float costBasis): void |
| `status` | `?string` | Optional | The status of the holding | getStatus(): ?string | setStatus(?string status): void |
| `currentPriceDate` | `?int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCurrentPriceDate(): ?int | setCurrentPriceDate(?int currentPriceDate): void |
| `securityType` | `?string` | Optional | Type of security for the investment position | getSecurityType(): ?string | setSecurityType(?string securityType): void |
| `mfType` | `?string` | Optional | Type of mutual fund, such as open ended | getMfType(): ?string | setMfType(?string mfType): void |
| `posType` | `?string` | Optional | Fund type assigned by the FI (long or short) | getPosType(): ?string | setPosType(?string posType): void |
| `totalGLDollar` | `?float` | Optional | Total gain and loss of the position at the time of aggregation in dollars | getTotalGLDollar(): ?float | setTotalGLDollar(?float totalGLDollar): void |
| `totalGLPercent` | `?float` | Optional | Total gain and loss of the position at the time of aggregation in percentage | getTotalGLPercent(): ?float | setTotalGLPercent(?float totalGLPercent): void |
| `optionStrikePrice` | `?float` | Optional | The strike price of the option contract | getOptionStrikePrice(): ?float | setOptionStrikePrice(?float optionStrikePrice): void |
| `optionType` | `?string` | Optional | The type of option contract (PUT or CALL) | getOptionType(): ?string | setOptionType(?string optionType): void |
| `optionSharesPerContract` | `?float` | Optional | The number of shares per option contract | getOptionSharesPerContract(): ?float | setOptionSharesPerContract(?float optionSharesPerContract): void |
| `optionExpireDate` | `?\DateTime` | Optional | Expiration date of option | getOptionExpireDate(): ?\DateTime | setOptionExpireDate(?\DateTime optionExpireDate): void |
| `fiAssetClass` | `?string` | Optional | Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS) | getFiAssetClass(): ?string | setFiAssetClass(?string fiAssetClass): void |
| `assetClass` | `?string` | Optional | An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER) | getAssetClass(): ?string | setAssetClass(?string assetClass): void |
| `currencyRate` | `?float` | Optional | Currency rate, ratio of currency to original currency | getCurrencyRate(): ?float | setCurrencyRate(?float currencyRate): void |
| `securityId` | `?string` | Optional | The security ID of the transaction | getSecurityId(): ?string | setSecurityId(?string securityId): void |
| `securityIdType` | `?string` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" | getSecurityIdType(): ?string | setSecurityIdType(?string securityIdType): void |
| `costBasisPerShare` | `?float` | Optional | The per share cost of acquiring the security | getCostBasisPerShare(): ?float | setCostBasisPerShare(?float costBasisPerShare): void |
| `subAccountType` | `?string` | Optional | The subaccount's type, such as cash | getSubAccountType(): ?string | setSubAccountType(?string subAccountType): void |
| `securityCurrency` | `?string` | Optional | Symbol for the currency that the account is being converted into | getSecurityCurrency(): ?string | setSecurityCurrency(?string securityCurrency): void |
| `todayGLDollar` | `?float` | Optional | The current day's gain and loss of the position at the time of aggregation in dollars | getTodayGLDollar(): ?float | setTodayGLDollar(?float todayGLDollar): void |
| `todayGLPercent` | `?float` | Optional | The current day's gain and loss of the position at the time of aggregation in percentage | getTodayGLPercent(): ?float | setTodayGLPercent(?float todayGLPercent): void |

## Example (as JSON)

```json
{
  "id": null,
  "description": null,
  "symbol": null,
  "units": null,
  "currentPrice": null,
  "securityName": null,
  "transactionType": null,
  "marketValue": null,
  "costBasis": null,
  "status": null,
  "currentPriceDate": null,
  "securityType": null,
  "mfType": null,
  "posType": null,
  "totalGLDollar": null,
  "totalGLPercent": null,
  "optionStrikePrice": null,
  "optionType": null,
  "optionSharesPerContract": null,
  "optionExpireDate": null,
  "fiAssetClass": null,
  "assetClass": null,
  "currencyRate": null,
  "securityId": null,
  "securityIdType": null,
  "costBasisPerShare": null,
  "subAccountType": null,
  "securityCurrency": null,
  "todayGLDollar": null,
  "todayGLPercent": null
}
```

