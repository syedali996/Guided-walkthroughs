
# Cash Flow Cash Flow Credit

## Structure

`CashFlowCashFlowCredit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyCashFlowCredits` | [`CashFlowMonthlyCashFlowCredits[]`](../../doc/models/cash-flow-monthly-cash-flow-credits.md) | Required | List of attributes for each month | getMonthlyCashFlowCredits(): array | setMonthlyCashFlowCredits(array monthlyCashFlowCredits): void |
| `twelveMonthCreditTotal` | `float` | Required | Sum of all credit transactions for each month by account | getTwelveMonthCreditTotal(): float | setTwelveMonthCreditTotal(float twelveMonthCreditTotal): void |
| `twelveMonthCreditTotalLessTransfers` | `float` | Required | Sum of all monthly credit transactions without transfers for the account | getTwelveMonthCreditTotalLessTransfers(): float | setTwelveMonthCreditTotalLessTransfers(float twelveMonthCreditTotalLessTransfers): void |
| `sixMonthCreditTotal` | `float` | Required | Sum of six month credit transactions | getSixMonthCreditTotal(): float | setSixMonthCreditTotal(float sixMonthCreditTotal): void |
| `sixMonthCreditTotalLessTransfers` | `float` | Required | Sum of six month credit transactions without transfers | getSixMonthCreditTotalLessTransfers(): float | setSixMonthCreditTotalLessTransfers(float sixMonthCreditTotalLessTransfers): void |
| `twoMonthCreditTotal` | `float` | Required | Sum of two month credit transactions | getTwoMonthCreditTotal(): float | setTwoMonthCreditTotal(float twoMonthCreditTotal): void |
| `twoMonthCreditTotalLessTransfers` | `float` | Required | Sum of two month credit transactions without transfers | getTwoMonthCreditTotalLessTransfers(): float | setTwoMonthCreditTotalLessTransfers(float twoMonthCreditTotalLessTransfers): void |

## Example (as JSON)

```json
{
  "monthlyCashFlowCredits": {
    "month": 1512111600,
    "numberOfCredits": "3",
    "totalCreditsAmount": 5000,
    "largestCredit": 2000,
    "numberOfCreditsLessTransfers": "2",
    "totalCreditsAmountLessTransfers": 4000,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

