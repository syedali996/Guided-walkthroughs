
# Cash Flow Transaction Analytics Attributes

## Structure

`CashFlowTransactionAnalyticsAttributes`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `activityDepositsCreditsForTheReportTimePeriod` | [`CashFlowActivityDepositsCredits[]`](../../doc/models/cash-flow-activity-deposits-credits.md) | Required | List of all deposit transactions posted to the account during the report period | getActivityDepositsCreditsForTheReportTimePeriod(): array | setActivityDepositsCreditsForTheReportTimePeriod(array activityDepositsCreditsForTheReportTimePeriod): void |
| `activityWithdrawalsDebitsForTheReportTimePeriod` | [`CashFlowActivityWithdrawalsDebits[]`](../../doc/models/cash-flow-activity-withdrawals-debits.md) | Required | List of all withdrawal transactions posted to the account during the report period | getActivityWithdrawalsDebitsForTheReportTimePeriod(): array | setActivityWithdrawalsDebitsForTheReportTimePeriod(array activityWithdrawalsDebitsForTheReportTimePeriod): void |
| `averageTransactionValueByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Average value of transactions during periods in the report. Values may be positive or negative | getAverageTransactionValueByMonthForTheReportTimePeriod(): array | setAverageTransactionValueByMonthForTheReportTimePeriod(array averageTransactionValueByMonthForTheReportTimePeriod): void |
| `historicWeeksWithZeroTransactions` | [`?CashFlowNumWeeksZeros`](../../doc/models/cash-flow-num-weeks-zeros.md) | Optional | Details of weeks with zero transactions during the known history of the account | getHistoricWeeksWithZeroTransactions(): ?CashFlowNumWeeksZeros | setHistoricWeeksWithZeroTransactions(?CashFlowNumWeeksZeros historicWeeksWithZeroTransactions): void |
| `lastTransactionDate` | [`?(LastTransactionDate[])`](../../doc/models/last-transaction-date.md) | Optional | Latest posted transaction(s) to the account. May be more than one if they share the same timestamp | getLastTransactionDate(): ?array | setLastTransactionDate(?array lastTransactionDate): void |
| `netCashFlowByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Net cash flow for each month during the report period | getNetCashFlowByMonthForTheReportTimePeriod(): ?array | setNetCashFlowByMonthForTheReportTimePeriod(?array netCashFlowByMonthForTheReportTimePeriod): void |
| `netCashFlowForTheReportTimePeriod` | `?float` | Optional | Net cash flow during the report period (may be positive or negative) | getNetCashFlowForTheReportTimePeriod(): ?float | setNetCashFlowForTheReportTimePeriod(?float netCashFlowForTheReportTimePeriod): void |

## Example (as JSON)

```json
{
  "activityDepositsCreditsForTheReportTimePeriod": {
    "date": "2020-03-25",
    "depositsCredits": 500
  },
  "activityWithdrawalsDebitsForTheReportTimePeriod": {
    "date": "2020-03-25",
    "withdrawalsDebits": 15.69
  },
  "averageTransactionValueByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

