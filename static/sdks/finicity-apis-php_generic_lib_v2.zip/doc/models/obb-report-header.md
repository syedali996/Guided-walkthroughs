
# Obb Report Header

Includes details about the business the report is generated for and metadata about the report

## Structure

`ObbReportHeader`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `businessAddress` | `?string` | Optional | Business address line 1<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getBusinessAddress(): ?string | setBusinessAddress(?string businessAddress): void |
| `businessCity` | `?string` | Optional | Business address city<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getBusinessCity(): ?string | setBusinessCity(?string businessCity): void |
| `businessName` | `?string` | Optional | Name of the business<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `businessState` | `?string` | Optional | Business address state<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getBusinessState(): ?string | setBusinessState(?string businessState): void |
| `businessZip` | `?string` | Optional | Business address zip<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getBusinessZip(): ?string | setBusinessZip(?string businessZip): void |
| `referenceNumber` | `?string` | Optional | Partner-provided reference number<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getReferenceNumber(): ?string | setReferenceNumber(?string referenceNumber): void |
| `reportDate` | `string` | Required | Date the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getReportDate(): string | setReportDate(string reportDate): void |
| `reportId` | `string` | Required | Generated unique report ID<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getReportId(): string | setReportId(string reportId): void |

## Example (as JSON)

```json
{
  "reportDate": "03/17/2022 04:28:38",
  "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
}
```

