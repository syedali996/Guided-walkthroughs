
# Customers

A list of customers

## Structure

`Customers`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `found` | `int` | Required | The total number of results matching search criteria | getFound(): int | setFound(int found): void |
| `displaying` | `int` | Required | The number of results returned | getDisplaying(): int | setDisplaying(int displaying): void |
| `moreAvailable` | `bool` | Required | If the value of `moreAvailable` is "true", you can retrieve the next page of results by increasing the value of the start parameter in your next request:"...&start=6&limit=5" | getMoreAvailable(): bool | setMoreAvailable(bool moreAvailable): void |
| `customers` | [`Customer[]`](../../doc/models/customer.md) | Required | A list of customer records | getCustomers(): array | setCustomers(array customers): void |

## Example (as JSON)

```json
{
  "found": 200,
  "displaying": 2,
  "moreAvailable": true,
  "customers": {
    "id": "1005061234",
    "username": "customerusername1",
    "type": "active",
    "createdDate": "1607450357"
  }
}
```

