
# Cash Flow Cash Flow Balance

## Structure

`CashFlowCashFlowBalance`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyCashFlowBalances` | [`CashFlowMonthlyCashFlowBalances[]`](../../doc/models/cash-flow-monthly-cash-flow-balances.md) | Required | List of attributes for each month | getMonthlyCashFlowBalances(): array | setMonthlyCashFlowBalances(array monthlyCashFlowBalances): void |
| `minDailyBalance` | `float` | Required | Min daily balance across entire transaction history | getMinDailyBalance(): float | setMinDailyBalance(float minDailyBalance): void |
| `maxDailyBalance` | `float` | Required | Max Daily Balance across entire transaction history | getMaxDailyBalance(): float | setMaxDailyBalance(float maxDailyBalance): void |
| `twelveMonthAverageDailyBalance` | `float` | Required | Average Daily Balance across twelve months for the account | getTwelveMonthAverageDailyBalance(): float | setTwelveMonthAverageDailyBalance(float twelveMonthAverageDailyBalance): void |
| `sixMonthAverageDailyBalance` | `float` | Required | Average Daily Balance across six months for the account | getSixMonthAverageDailyBalance(): float | setSixMonthAverageDailyBalance(float sixMonthAverageDailyBalance): void |
| `twoMonthAverageDailyBalance` | `float` | Required | Average Daily Balance across two months for the account | getTwoMonthAverageDailyBalance(): float | setTwoMonthAverageDailyBalance(float twoMonthAverageDailyBalance): void |
| `twelveMonthStandardDeviationOfDailyBalance` | `string` | Required | Standard Deviation of Daily Balance across twelve months for the account | getTwelveMonthStandardDeviationOfDailyBalance(): string | setTwelveMonthStandardDeviationOfDailyBalance(string twelveMonthStandardDeviationOfDailyBalance): void |
| `sixMonthStandardDeviationOfDailyBalance` | `string` | Required | Standard Deviation of Daily Balance across six months for the account | getSixMonthStandardDeviationOfDailyBalance(): string | setSixMonthStandardDeviationOfDailyBalance(string sixMonthStandardDeviationOfDailyBalance): void |
| `twoMonthStandardDeviationOfDailyBalance` | `string` | Required | Standard Deviation of Daily Balance across two months for the account | getTwoMonthStandardDeviationOfDailyBalance(): string | setTwoMonthStandardDeviationOfDailyBalance(string twoMonthStandardDeviationOfDailyBalance): void |
| `numberDaysNegativeBalance` | `string` | Required | Number of Days Negative Balance over entire transaction history | getNumberDaysNegativeBalance(): string | setNumberDaysNegativeBalance(string numberDaysNegativeBalance): void |
| `numberOfDaysPositiveBalance` | `string` | Required | Number of Days positive balance over entire transaction history | getNumberOfDaysPositiveBalance(): string | setNumberOfDaysPositiveBalance(string numberOfDaysPositiveBalance): void |

## Example (as JSON)

```json
{
  "monthlyCashFlowBalances": {
    "month": 1512111600,
    "minDailyBalance": 3479.39,
    "maxDailyBalance": 3479.39,
    "averageDailyBalance": 3479.39,
    "standardDeviationOfDailyBalance": "20",
    "numberOfDaysNegativeBalance": "6",
    "numberOfDaysPositiveBalance": "0"
  },
  "minDailyBalance": 3479.39,
  "maxDailyBalance": 3479.39,
  "twelveMonthAverageDailyBalance": 3479.39,
  "sixMonthAverageDailyBalance": 3479.39,
  "twoMonthAverageDailyBalance": 3479.39,
  "twelveMonthStandardDeviationOfDailyBalance": "20",
  "sixMonthStandardDeviationOfDailyBalance": "20",
  "twoMonthStandardDeviationOfDailyBalance": "20",
  "numberDaysNegativeBalance": "6",
  "numberOfDaysPositiveBalance": "0"
}
```

