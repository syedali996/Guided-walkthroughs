
# Prequalification Report Asset Summary

## Structure

`PrequalificationReportAssetSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | The asset type: "checking", "savings", "moneyMarket", "cd", "investment" | getType(): ?string | setType(?string type): void |
| `availableBalance` | `?float` | Optional | The available balance for the account | getAvailableBalance(): ?float | setAvailableBalance(?float availableBalance): void |
| `currentBalance` | `float` | Required | The current balance of the account | getCurrentBalance(): float | setCurrentBalance(float currentBalance): void |
| `twoMonthAverage` | `float` | Required | The two month average daily balance of the account | getTwoMonthAverage(): float | setTwoMonthAverage(float twoMonthAverage): void |
| `sixMonthAverage` | `float` | Required | The six month average daily balance of the account | getSixMonthAverage(): float | setSixMonthAverage(float sixMonthAverage): void |
| `beginningBalance` | `float` | Required | The beginning balance of the account per the time period of the report | getBeginningBalance(): float | setBeginningBalance(float beginningBalance): void |

## Example (as JSON)

```json
{
  "currentBalance": 1000,
  "twoMonthAverage": -1865.96,
  "sixMonthAverage": -7616.01,
  "beginningBalance": -17795.6
}
```

