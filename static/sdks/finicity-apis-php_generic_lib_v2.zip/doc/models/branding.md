
# Branding

All assets are SVGs so can be slightly resized without any issues.

## Structure

`Branding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `logo` | `?string` | Optional | File path of the institution's logo. For white backgrounds designed at 375 x 72, has built in spacing around it to normalize brand sizing. | getLogo(): ?string | setLogo(?string logo): void |
| `alternateLogo` | `?string` | Optional | File path of the institution's alternate logo. For colored backgrounds designed at 375 x 72 has built in spacing around it to normalize brand sizing. | getAlternateLogo(): ?string | setAlternateLogo(?string alternateLogo): void |
| `icon` | `?string` | Optional | File path of the institution's icon. For search results designed at 40 x 40. | getIcon(): ?string | setIcon(?string icon): void |
| `primaryColor` | `?string` | Optional | Hex code for the institution's primary color | getPrimaryColor(): ?string | setPrimaryColor(?string primaryColor): void |
| `tile` | `?string` | Optional | File path of institution name logo. For popular banks designed at 160 x 72. | getTile(): ?string | setTile(?string tile): void |

## Example (as JSON)

```json
{
  "logo": null,
  "alternateLogo": null,
  "icon": null,
  "primaryColor": null,
  "tile": null
}
```

