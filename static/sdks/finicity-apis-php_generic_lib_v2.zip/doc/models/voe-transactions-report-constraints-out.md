
# VOE Transactions Report Constraints Out

## Structure

`VOETransactionsReportConstraintsOut`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reportId` | `?string` | Optional | A report ID | getReportId(): ?string | setReportId(?string reportId): void |
| `accountIds` | `?(string[])` | Optional | An array of account IDs to be included in the report (all accounts will be included if not set) | getAccountIds(): ?array | setAccountIds(?array accountIds): void |
| `reportCustomFields` | [`?(ReportCustomField[])`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. | getReportCustomFields(): ?array | setReportCustomFields(?array reportCustomFields): void |
| `fromDate` | `?int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getFromDate(): ?int | setFromDate(?int fromDate): void |
| `incomeStreamConfidenceMinimum` | `?int` | Optional | Include income streams in the report, based on the income stream's confidence score. For example, Use the value 50 to include only income streams with a confidence score of 50 or higher. | getIncomeStreamConfidenceMinimum(): ?int | setIncomeStreamConfidenceMinimum(?int incomeStreamConfidenceMinimum): void |

## Example (as JSON)

```json
{
  "reportId": null,
  "accountIds": null,
  "reportCustomFields": null,
  "fromDate": null,
  "incomeStreamConfidenceMinimum": null
}
```

