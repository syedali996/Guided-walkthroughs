
# Cash Flow Cash Flow Credit Summary

## Structure

`CashFlowCashFlowCreditSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyCashFlowCreditSummaries` | [`CashFlowMonthlyCashFlowCreditSummaries[]`](../../doc/models/cash-flow-monthly-cash-flow-credit-summaries.md) | Required | List of attributes for each month | getMonthlyCashFlowCreditSummaries(): array | setMonthlyCashFlowCreditSummaries(array monthlyCashFlowCreditSummaries): void |
| `twelveMonthCreditTotal` | `float` | Required | Sum of all credit transactions for each month for all accounts | getTwelveMonthCreditTotal(): float | setTwelveMonthCreditTotal(float twelveMonthCreditTotal): void |
| `twelveMonthCreditTotalLessTransfers` | `float` | Required | Sum of all monthly credit transactions without transfers for all accounts | getTwelveMonthCreditTotalLessTransfers(): float | setTwelveMonthCreditTotalLessTransfers(float twelveMonthCreditTotalLessTransfers): void |
| `sixMonthCreditTotal` | `float` | Required | Six month sum of all credit transactions | getSixMonthCreditTotal(): float | setSixMonthCreditTotal(float sixMonthCreditTotal): void |
| `sixMonthCreditTotalLessTransfers` | `float` | Required | Six month sum of all monthly credit transactions without transfers for all accounts | getSixMonthCreditTotalLessTransfers(): float | setSixMonthCreditTotalLessTransfers(float sixMonthCreditTotalLessTransfers): void |
| `twoMonthCreditTotal` | `float` | Required | Two month sum of all credit transactions | getTwoMonthCreditTotal(): float | setTwoMonthCreditTotal(float twoMonthCreditTotal): void |
| `twoMonthCreditTotalLessTransfers` | `float` | Required | Two month sum of all monthly credit transactions without transfers for all accounts | getTwoMonthCreditTotalLessTransfers(): float | setTwoMonthCreditTotalLessTransfers(float twoMonthCreditTotalLessTransfers): void |

## Example (as JSON)

```json
{
  "monthlyCashFlowCreditSummaries": {
    "month": 1512111600,
    "numberOfCredits": "57",
    "totalCreditsAmount": 3479.39,
    "largestCredit": 3000.49,
    "numberOfCreditsLessTransfers": "5",
    "totalCreditsAmountLessTransfers": 25.46,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

