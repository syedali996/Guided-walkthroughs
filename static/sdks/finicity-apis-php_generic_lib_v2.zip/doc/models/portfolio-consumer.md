
# Portfolio Consumer

## Structure

`PortfolioConsumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | getId(): string | setId(string id): void |
| `firstName` | `string` | Required | First name(s) / given name(s) | getFirstName(): string | setFirstName(string firstName): void |
| `lastName` | `string` | Required | Last name(s) / surname(s) | getLastName(): string | setLastName(string lastName): void |
| `customerId` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): int | setCustomerId(int customerId): void |
| `ssn` | `string` | Required | A full SSN with or without hyphens | getSsn(): string | setSsn(string ssn): void |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date | getBirthday(): Birthday | setBirthday(Birthday birthday): void |
| `suffix` | `?string` | Optional | A person suffix | getSuffix(): ?string | setSuffix(?string suffix): void |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "ssn": "999-99-9999",
  "birthday": null
}
```

