
# Cash Flow Monthly Cash Flow Credits

## Structure

`CashFlowMonthlyCashFlowCredits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | One instance for each complete calendar month in the report | getMonth(): int | setMonth(int month): void |
| `numberOfCredits` | `string` | Required | Number of credits by month | getNumberOfCredits(): string | setNumberOfCredits(string numberOfCredits): void |
| `totalCreditsAmount` | `float` | Required | Total amount of credits by month | getTotalCreditsAmount(): float | setTotalCreditsAmount(float totalCreditsAmount): void |
| `largestCredit` | `float` | Required | Largest credit by month | getLargestCredit(): float | setLargestCredit(float largestCredit): void |
| `numberOfCreditsLessTransfers` | `string` | Required | Number of credits by month (less transfers) | getNumberOfCreditsLessTransfers(): string | setNumberOfCreditsLessTransfers(string numberOfCreditsLessTransfers): void |
| `totalCreditsAmountLessTransfers` | `float` | Required | Total amount of credits by month (less transfers) | getTotalCreditsAmountLessTransfers(): float | setTotalCreditsAmountLessTransfers(float totalCreditsAmountLessTransfers): void |
| `averageCreditAmount` | `float` | Required | The average credit amount | getAverageCreditAmount(): float | setAverageCreditAmount(float averageCreditAmount): void |
| `estimatedNumberOfLoanDeposits` | `string` | Required | The estimated number of loan deposits | getEstimatedNumberOfLoanDeposits(): string | setEstimatedNumberOfLoanDeposits(string estimatedNumberOfLoanDeposits): void |
| `estimatedLoanDepositAmount` | `float` | Required | The estimated loan deposit amount | getEstimatedLoanDepositAmount(): float | setEstimatedLoanDepositAmount(float estimatedLoanDepositAmount): void |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "3",
  "totalCreditsAmount": 5000,
  "largestCredit": 2000,
  "numberOfCreditsLessTransfers": "2",
  "totalCreditsAmountLessTransfers": 4000,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

