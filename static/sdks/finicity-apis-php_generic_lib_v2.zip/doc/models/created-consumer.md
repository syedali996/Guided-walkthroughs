
# Created Consumer

A consumer that was just created

## Structure

`CreatedConsumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. | getId(): ?string | setId(?string id): void |
| `createdDate` | `?int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): ?int | setCreatedDate(?int createdDate): void |
| `customerId` | `?int` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): ?int | setCustomerId(?int customerId): void |

## Example (as JSON)

```json
{
  "id": null,
  "createdDate": null,
  "customerId": null
}
```

