
# Payroll Employment Record

## Structure

`PayrollEmploymentRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `employerName` | `string` | Required | Name of the employer as stated by the employer in the payroll system | getEmployerName(): string | setEmployerName(string employerName): void |
| `legalEntityId` | `?string` | Optional | Employer identification number (EIN) | getLegalEntityId(): ?string | setLegalEntityId(?string legalEntityId): void |
| `originalHireDate` | `?int` | Optional | The original hired date of an employee at the company | getOriginalHireDate(): ?int | setOriginalHireDate(?int originalHireDate): void |
| `latestHireDate` | `?int` | Optional | If an employee leaves the company and returns later, then the employer states the latest hire date at the company | getLatestHireDate(): ?int | setLatestHireDate(?int latestHireDate): void |
| `latestPayDate` | `int` | Required | The most recent pay date from an employer | getLatestPayDate(): int | setLatestPayDate(int latestPayDate): void |
| `daysSinceLastPay` | `int` | Required | The number of days since an employee was last paid | getDaysSinceLastPay(): int | setDaysSinceLastPay(int daysSinceLastPay): void |
| `numberPayCadenceWithoutPay` | `int` | Required | The number of pay cadences an employee has not been paid; determined by the pay frequency | getNumberPayCadenceWithoutPay(): int | setNumberPayCadenceWithoutPay(int numberPayCadenceWithoutPay): void |
| `employmentEndDate` | `?int` | Optional | The date an employee ended their employment at the company | getEmploymentEndDate(): ?int | setEmploymentEndDate(?int employmentEndDate): void |
| `employmentDuration` | `?string` | Optional | The length of time an employee has been employed with that employer in ISO 8601 format (eg P1Y6M0D) | getEmploymentDuration(): ?string | setEmploymentDuration(?string employmentDuration): void |
| `employerAddress` | [`?(PayrollEmployerAddress[])`](../../doc/models/payroll-employer-address.md) | Optional | Array of addresses | getEmployerAddress(): ?array | setEmployerAddress(?array employerAddress): void |
| `employmentStatusCode` | `string` | Required | Status codes: `A` - Active, `NLE` - No Longer Employed, `L` - Leave | getEmploymentStatusCode(): string | setEmploymentStatusCode(string employmentStatusCode): void |
| `employmentStatusName` | `string` | Required | Status name: `Active`, `No Longer Employed`, or `Leave` | getEmploymentStatusName(): string | setEmploymentStatusName(string employmentStatusName): void |
| `workLevelCode` | `?string` | Optional | The abbreviate code for the employment level names (workLevelName) that we receive from the employer | getWorkLevelCode(): ?string | setWorkLevelCode(?string workLevelCode): void |
| `workLevelName` | `?string` | Optional | The employment level name is whatever we receive from the employer, such as full time, part time, temp, contractor, and more | getWorkLevelName(): ?string | setWorkLevelName(?string workLevelName): void |
| `workLevelStatus` | `string` | Required | The categorized work level status. Enumerations are: <br> * `Temporary` <br> * `Seasonal` <br> * `Retired` <br> * `Student` <br> * `Full Time` <br> * `Part Time` <br> * `Unspecified` <br> This is a new field, currently enabled only for testing reports. It will be added for all reports in August 2021. | getWorkLevelStatus(): string | setWorkLevelStatus(string workLevelStatus): void |
| `positionTitle` | `?string` | Optional | Employee job title | getPositionTitle(): ?string | setPositionTitle(?string positionTitle): void |
| `positionDuration` | `?string` | Optional | The length of time an employee has been employed at their current or latest position for this employment in ISO 8601 format (eg P1Y6M0D) | getPositionDuration(): ?string | setPositionDuration(?string positionDuration): void |

## Example (as JSON)

```json
{
  "employerName": "ACME INC",
  "latestPayDate": 1596175200,
  "daysSinceLastPay": 10,
  "numberPayCadenceWithoutPay": 1,
  "employmentStatusCode": "A",
  "employmentStatusName": "Active",
  "workLevelStatus": "Full Time"
}
```

