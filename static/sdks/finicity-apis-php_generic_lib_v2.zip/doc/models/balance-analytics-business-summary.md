
# Balance Analytics Business Summary

## Structure

`BalanceAnalyticsBusinessSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `balanceAnalyticsMetrics` | [`?BalanceAnalyticsMetrics`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations across all accounts in the report | getBalanceAnalyticsMetrics(): ?BalanceAnalyticsMetrics | setBalanceAnalyticsMetrics(?BalanceAnalyticsMetrics balanceAnalyticsMetrics): void |
| `currentReportRequest` | [`?ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Optional | Describes the requested attributes of the report | getCurrentReportRequest(): ?ObbCurrentReportRequestDetails | setCurrentReportRequest(?ObbCurrentReportRequestDetails currentReportRequest): void |
| `historicDataAvailability` | [`?ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Optional | Describes the availability of historical data for all accounts owned by the business | getHistoricDataAvailability(): ?ObbDataAvailability | setHistoricDataAvailability(?ObbDataAvailability historicDataAvailability): void |

## Example (as JSON)

```json
{
  "balanceAnalyticsMetrics": null,
  "currentReportRequest": null,
  "historicDataAvailability": null
}
```

