
# Cash Flow Activity Withdrawals Debits

## Structure

`CashFlowActivityWithdrawalsDebits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `date` | `string` | Required | Date the withdrawal transaction was posted<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getDate(): string | setDate(string date): void |
| `transactionDescription` | `?string` | Optional | Description of transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getTransactionDescription(): ?string | setTransactionDescription(?string transactionDescription): void |
| `withdrawalsDebits` | `float` | Required | Amount of the withdrawal | getWithdrawalsDebits(): float | setWithdrawalsDebits(float withdrawalsDebits): void |

## Example (as JSON)

```json
{
  "date": "2020-03-25",
  "withdrawalsDebits": 15.69
}
```

