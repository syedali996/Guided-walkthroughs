
# Report Income Estimate

## Structure

`ReportIncomeEstimate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `netAnnual` | `float` | Required | - | getNetAnnual(): float | setNetAnnual(float netAnnual): void |
| `projectedNetAnnual` | `float` | Required | - | getProjectedNetAnnual(): float | setProjectedNetAnnual(float projectedNetAnnual): void |
| `estimatedGrossAnnual` | `float` | Required | - | getEstimatedGrossAnnual(): float | setEstimatedGrossAnnual(float estimatedGrossAnnual): void |
| `projectedGrossAnnual` | `float` | Required | - | getProjectedGrossAnnual(): float | setProjectedGrossAnnual(float projectedGrossAnnual): void |

## Example (as JSON)

```json
{
  "netAnnual": 1000.12,
  "projectedNetAnnual": 1500.23,
  "estimatedGrossAnnual": 2000.12,
  "projectedGrossAnnual": 2500.23
}
```

