
# Cash Flow Monthly Cash Flow Balances

## Structure

`CashFlowMonthlyCashFlowBalances`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | One instance for each complete calendar month in the report | getMonth(): int | setMonth(int month): void |
| `minDailyBalance` | `float` | Required | Min Daily Balance for each month | getMinDailyBalance(): float | setMinDailyBalance(float minDailyBalance): void |
| `maxDailyBalance` | `float` | Required | Max Daily Balance for each month | getMaxDailyBalance(): float | setMaxDailyBalance(float maxDailyBalance): void |
| `averageDailyBalance` | `float` | Required | Average Daily Balance for each month | getAverageDailyBalance(): float | setAverageDailyBalance(float averageDailyBalance): void |
| `standardDeviationOfDailyBalance` | `string` | Required | Standard Deviation of Daily Balance for each month | getStandardDeviationOfDailyBalance(): string | setStandardDeviationOfDailyBalance(string standardDeviationOfDailyBalance): void |
| `numberOfDaysNegativeBalance` | `string` | Required | Number of Days Negative Balance for each month | getNumberOfDaysNegativeBalance(): string | setNumberOfDaysNegativeBalance(string numberOfDaysNegativeBalance): void |
| `numberOfDaysPositiveBalance` | `string` | Required | Number of Days positive balance for each month | getNumberOfDaysPositiveBalance(): string | setNumberOfDaysPositiveBalance(string numberOfDaysPositiveBalance): void |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "minDailyBalance": 3479.39,
  "maxDailyBalance": 3479.39,
  "averageDailyBalance": 3479.39,
  "standardDeviationOfDailyBalance": "20",
  "numberOfDaysNegativeBalance": "6",
  "numberOfDaysPositiveBalance": "0"
}
```

