
# Cash Flow Report Ack

## Structure

`CashFlowReportAck`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | A report ID | getId(): string | setId(string id): void |
| `customerType` | `string` | Required | The type of customer ("active" or "testing" or "" for all types) | getCustomerType(): string | setCustomerType(string customerType): void |
| `customerId` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): int | setCustomerId(int customerId): void |
| `requestId` | `string` | Required | Finicity indicator to track all activity associated with this report | getRequestId(): string | setRequestId(string requestId): void |
| `requesterName` | `string` | Required | Name of a Finicity partner | getRequesterName(): string | setRequesterName(string requesterName): void |
| `createdDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): int | setCreatedDate(int createdDate): void |
| `title` | `string` | Required | Title of the report | getTitle(): string | setTitle(string title): void |
| `consumerId` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | getConsumerId(): string | setConsumerId(string consumerId): void |
| `consumerSsn` | `string` | Required | Last 4 digits of a SSN | getConsumerSsn(): string | setConsumerSsn(string consumerSsn): void |
| `type` | `string` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | getType(): string | setType(string type): void |
| `status` | `string` | Required | A report generation status. Possible values: "inProgress", "success", "failure". | getStatus(): string | setStatus(string status): void |
| `errors` | [`?(ErrorMessage[])`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | getErrors(): ?array | setErrors(?array errors): void |
| `constraints` | [`CashFlowReportConstraintsOut`](../../doc/models/cash-flow-report-constraints-out.md) | Required | - | getConstraints(): CashFlowReportConstraintsOut | setConstraints(CashFlowReportConstraintsOut constraints): void |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "customerType": "active",
  "customerId": 1005061234,
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "title": "Finicity Asset Ready Report (CRA)",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress",
  "constraints": null
}
```

