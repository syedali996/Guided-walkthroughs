
# Cash Flow Monthly Cash Flow Characteristic Summaries

## Structure

`CashFlowMonthlyCashFlowCharacteristicSummaries`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | One instance for each complete calendar month in the report | getMonth(): int | setMonth(int month): void |
| `totalCreditsLessTotalDebits` | `float` | Required | Total Credits - Total Debits by month across all accounts | getTotalCreditsLessTotalDebits(): float | setTotalCreditsLessTotalDebits(float totalCreditsLessTotalDebits): void |
| `totalCreditsLessTotalDebitsLessTransfers` | `float` | Required | Total Credits - Total Debits by month (Without Transfers) across all accounts | getTotalCreditsLessTotalDebitsLessTransfers(): float | setTotalCreditsLessTotalDebitsLessTransfers(float totalCreditsLessTotalDebitsLessTransfers): void |
| `averageTransactionAmount` | `float` | Required | Average transaction amount across all accounts | getAverageTransactionAmount(): float | setAverageTransactionAmount(float averageTransactionAmount): void |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "totalCreditsLessTotalDebits": 15000,
  "totalCreditsLessTotalDebitsLessTransfers": 11000,
  "averageTransactionAmount": 10
}
```

