
# Obb Average Weekly Balance

## Structure

`ObbAverageWeeklyBalance`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Average daily ending balance during the week | getAmount(): float | setAmount(float amount): void |
| `fromDate` | `string` | Required | Begin date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getFromDate(): string | setFromDate(string fromDate): void |
| `toDate` | `string` | Required | End date of the week<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getToDate(): string | setToDate(string toDate): void |
| `week` | `int` | Required | Week number, where the first week of each year begins on January 1st and ends on January 7th. May be in the range [1, 53] | getWeek(): int | setWeek(int week): void |

## Example (as JSON)

```json
{
  "amount": 679.07,
  "fromDate": "2020-01-01",
  "toDate": "2020-01-07",
  "week": 1
}
```

