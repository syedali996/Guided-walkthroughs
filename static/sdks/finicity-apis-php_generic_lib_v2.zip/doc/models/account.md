
# Account

## Structure

`Account`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Finicity account ID | getId(): string | setId(string id): void |
| `ownerName` | `string` | Required | The name(s) of the account owner(s), retrieved from the institution. | getOwnerName(): string | setOwnerName(string ownerName): void |
| `ownerAddress` | `string` | Required | The mailing address of the account owner, retrieved from the institution. | getOwnerAddress(): string | setOwnerAddress(string ownerAddress): void |
| `name` | `string` | Required | The account name from the institution | getName(): string | setName(string name): void |
| `number` | `string` | Required | The account number from the institution (obfuscated) | getNumber(): string | setNumber(string number): void |
| `type` | `string` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) | getType(): string | setType(string type): void |
| `aggregationStatusCode` | `string` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) | getAggregationStatusCode(): string | setAggregationStatusCode(string aggregationStatusCode): void |
| `currentBalance` | `?float` | Optional | The cleared balance of the account as-of `balanceDate` | getCurrentBalance(): ?float | setCurrentBalance(?float currentBalance): void |
| `availableBalance` | `float` | Required | Available balance | getAvailableBalance(): float | setAvailableBalance(float availableBalance): void |
| `balanceDate` | `?int` | Optional | A timestamp showing when the `balance` was captured | getBalanceDate(): ?int | setBalanceDate(?int balanceDate): void |
| `transactions` | [`ReportTransaction[]`](../../doc/models/report-transaction.md) | Required | a list of transaction records | getTransactions(): array | setTransactions(array transactions): void |
| `cashFlowBalance` | [`?CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - | getCashFlowBalance(): ?CashFlowCashFlowBalance | setCashFlowBalance(?CashFlowCashFlowBalance cashFlowBalance): void |
| `cashFlowCredit` | [`?CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - | getCashFlowCredit(): ?CashFlowCashFlowCredit | setCashFlowCredit(?CashFlowCashFlowCredit cashFlowCredit): void |
| `cashFlowDebit` | [`?CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - | getCashFlowDebit(): ?CashFlowCashFlowDebit | setCashFlowDebit(?CashFlowCashFlowDebit cashFlowDebit): void |
| `cashFlowCharacteristic` | [`?CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - | getCashFlowCharacteristic(): ?CashFlowCashFlowCharacteristic | setCashFlowCharacteristic(?CashFlowCashFlowCharacteristic cashFlowCharacteristic): void |
| `balance` | `float` | Required | The cleared balance of the account as-of `balanceDate` | getBalance(): float | setBalance(float balance): void |
| `averageMonthlyBalance` | `float` | Required | The average monthly balance of the account | getAverageMonthlyBalance(): float | setAverageMonthlyBalance(float averageMonthlyBalance): void |
| `totNumberInsufficientFundsFeeDebitTxAccount` | `?int` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report | getTotNumberInsufficientFundsFeeDebitTxAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxAccount(?int totNumberInsufficientFundsFeeDebitTxAccount): void |
| `totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `?int` | Optional | The total number of  insufficient funds fees for the account over six months | getTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount(?int totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount): void |
| `totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `?int` | Optional | The total number of days since the most recent insufficient funds fee for the account | getTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(): ?int | setTotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount(?int totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount): void |
| `asset` | [`?PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | getAsset(): ?PrequalificationReportAssetSummary | setAsset(?PrequalificationReportAssetSummary asset): void |
| `details` | [`?AccountDetails`](../../doc/models/account-details.md) | Optional | - | getDetails(): ?AccountDetails | setDetails(?AccountDetails details): void |
| `totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `?int` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. | getTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount(): ?int | setTotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount(?int totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount): void |
| `incomeStreams` | [`VOAIReportIncomeStream2[]`](../../doc/models/voai-report-income-stream-2.md) | Required | A list of income stream records | getIncomeStreams(): array | setIncomeStreams(array incomeStreams): void |
| `beginningBalance` | `?float` | Optional | Beginning balance of account per the time period in the report | getBeginningBalance(): ?float | setBeginningBalance(?float beginningBalance): void |
| `miscDeposits` | [`?(ReportTransaction[])`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` | getMiscDeposits(): ?array | setMiscDeposits(?array miscDeposits): void |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "availableBalance": 1000,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "balance": 501.24,
  "averageMonthlyBalance": 501.02,
  "incomeStreams": {
    "id": "dens28i3vsch-voah",
    "name": "none",
    "status": null,
    "estimateInclusion": null,
    "confidence": 70,
    "cadence": null,
    "netMonthly": [
      {
        "month": 1522562400,
        "net": 2004.77
      }
    ],
    "netAnnual": 110475.7,
    "projectedNetAnnual": 0,
    "estimatedGrossAnnual": 12321.1,
    "projectedGrossAnnual": 151609,
    "averageMonthlyIncomeNet": 9206.31,
    "incomeStreamMonths": 18,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    },
    "daysSinceLastTransaction": 15,
    "nextExpectedTransactionDate": 1572625469
  }
}
```

