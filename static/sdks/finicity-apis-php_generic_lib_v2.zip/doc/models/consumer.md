
# Consumer

A finicity consumer record

## Structure

`Consumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | getId(): string | setId(string id): void |
| `firstName` | `string` | Required | First name(s) / given name(s) | getFirstName(): string | setFirstName(string firstName): void |
| `lastName` | `string` | Required | Last name(s) / surname(s) | getLastName(): string | setLastName(string lastName): void |
| `customerId` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): int | setCustomerId(int customerId): void |
| `address` | `string` | Required | A street address | getAddress(): string | setAddress(string address): void |
| `city` | `string` | Required | A city | getCity(): string | setCity(string city): void |
| `state` | `string` | Required | A state | getState(): string | setState(string state): void |
| `zip` | `string` | Required | A ZIP code | getZip(): string | setZip(string zip): void |
| `phone` | `string` | Required | A phone number | getPhone(): string | setPhone(string phone): void |
| `ssn` | `string` | Required | Last 4 digits of a SSN | getSsn(): string | setSsn(string ssn): void |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date | getBirthday(): Birthday | setBirthday(Birthday birthday): void |
| `email` | `string` | Required | An email address | getEmail(): string | setEmail(string email): void |
| `createdDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): int | setCreatedDate(int createdDate): void |
| `suffix` | `?string` | Optional | A person suffix | getSuffix(): ?string | setSuffix(?string suffix): void |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "9999",
  "birthday": null,
  "email": "finicity@test.com",
  "createdDate": 1607450357
}
```

