
# Cash Flow Report Account

## Structure

`CashFlowReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | Finicity account ID | getId(): ?string | setId(?string id): void |
| `ownerName` | `?string` | Optional | The name(s) of the account owner(s), retrieved from the institution. | getOwnerName(): ?string | setOwnerName(?string ownerName): void |
| `ownerAddress` | `?string` | Optional | The mailing address of the account owner, retrieved from the institution. | getOwnerAddress(): ?string | setOwnerAddress(?string ownerAddress): void |
| `name` | `?string` | Optional | The account name from the institution | getName(): ?string | setName(?string name): void |
| `number` | `?string` | Optional | The account number from the institution (obfuscated) | getNumber(): ?string | setNumber(?string number): void |
| `type` | `?string` | Optional | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) | getType(): ?string | setType(?string type): void |
| `aggregationStatusCode` | `?string` | Optional | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) | getAggregationStatusCode(): ?string | setAggregationStatusCode(?string aggregationStatusCode): void |
| `currentBalance` | `?float` | Optional | The cleared balance of the account as-of `balanceDate` | getCurrentBalance(): ?float | setCurrentBalance(?float currentBalance): void |
| `availableBalance` | `?float` | Optional | Available balance | getAvailableBalance(): ?float | setAvailableBalance(?float availableBalance): void |
| `balanceDate` | `?int` | Optional | A timestamp showing when the `balance` was captured | getBalanceDate(): ?int | setBalanceDate(?int balanceDate): void |
| `transactions` | [`?(ReportTransaction[])`](../../doc/models/report-transaction.md) | Optional | a list of transaction records | getTransactions(): ?array | setTransactions(?array transactions): void |
| `cashFlowBalance` | [`?CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - | getCashFlowBalance(): ?CashFlowCashFlowBalance | setCashFlowBalance(?CashFlowCashFlowBalance cashFlowBalance): void |
| `cashFlowCredit` | [`?CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - | getCashFlowCredit(): ?CashFlowCashFlowCredit | setCashFlowCredit(?CashFlowCashFlowCredit cashFlowCredit): void |
| `cashFlowDebit` | [`?CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - | getCashFlowDebit(): ?CashFlowCashFlowDebit | setCashFlowDebit(?CashFlowCashFlowDebit cashFlowDebit): void |
| `cashFlowCharacteristic` | [`?CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - | getCashFlowCharacteristic(): ?CashFlowCashFlowCharacteristic | setCashFlowCharacteristic(?CashFlowCashFlowCharacteristic cashFlowCharacteristic): void |

## Example (as JSON)

```json
{
  "id": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "number": null,
  "type": null,
  "aggregationStatusCode": null,
  "currentBalance": null,
  "availableBalance": null,
  "balanceDate": null,
  "transactions": null,
  "cashFlowBalance": null,
  "cashFlowCredit": null,
  "cashFlowDebit": null,
  "cashFlowCharacteristic": null
}
```

