
# Email Options

Configuration for the Connect email's sent to customers

## Structure

`EmailOptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `to` | `string` | Required | The email address for the customer receiving the Connect email | getTo(): string | setTo(string to): void |
| `from` | `?string` | Optional | The name of a person or business sending the Connect email | getFrom(): ?string | setFrom(?string from): void |
| `supportPhone` | `?string` | Optional | The support phone number listed in the email | getSupportPhone(): ?string | setSupportPhone(?string supportPhone): void |
| `subject` | `?string` | Optional | The subject line of the email. The default is "Verify your Financial Information". | getSubject(): ?string | setSubject(?string subject): void |
| `firstName` | `?string` | Optional | The first name of the customer or both names of the customers for joint borrowers. Example: "Marvin and Jenny". | getFirstName(): ?string | setFirstName(?string firstName): void |
| `institutionName` | `?string` | Optional | The name of your company | getInstitutionName(): ?string | setInstitutionName(?string institutionName): void |
| `institutionAddress` | `?string` | Optional | The institution address to appear in the footer of the email | getInstitutionAddress(): ?string | setInstitutionAddress(?string institutionAddress): void |
| `signature` | `?(string[])` | Optional | A signature for the email | getSignature(): ?array | setSignature(?array signature): void |

## Example (as JSON)

```json
{
  "to": "alex.salido@finicity.com"
}
```

