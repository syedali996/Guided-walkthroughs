
# Consumer Attribute List

## Structure

`ConsumerAttributeList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `analyticIds` | [`ConsumerAttributesAnalyticId[]`](../../doc/models/consumer-attributes-analytic-id.md) | Required | A list of analytic IDs | getAnalyticIds(): array | setAnalyticIds(array analyticIds): void |

## Example (as JSON)

```json
{
  "analytic_ids": {
    "analytic_id": "CA-5dfbaa3ac-5321",
    "created_date": "04/12/2022 11:51:23"
  }
}
```

