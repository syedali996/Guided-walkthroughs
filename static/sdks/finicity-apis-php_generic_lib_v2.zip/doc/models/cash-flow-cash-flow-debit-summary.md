
# Cash Flow Cash Flow Debit Summary

## Structure

`CashFlowCashFlowDebitSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyCashFlowDebitSummaries` | [`CashFlowMonthlyCashFlowDebitSummaries[]`](../../doc/models/cash-flow-monthly-cash-flow-debit-summaries.md) | Required | List of attributes for each month | getMonthlyCashFlowDebitSummaries(): array | setMonthlyCashFlowDebitSummaries(array monthlyCashFlowDebitSummaries): void |
| `twelveMonthDebitTotal` | `float` | Required | Sum of all monthly debit transactions for each month by account | getTwelveMonthDebitTotal(): float | setTwelveMonthDebitTotal(float twelveMonthDebitTotal): void |
| `twelveMonthDebitTotalLessTransfers` | `float` | Required | Sum of all monthly debit transactions without transfers for the account | getTwelveMonthDebitTotalLessTransfers(): float | setTwelveMonthDebitTotalLessTransfers(float twelveMonthDebitTotalLessTransfers): void |
| `sixMonthDebitTotal` | `float` | Required | Six month sum of all debit transactions by account | getSixMonthDebitTotal(): float | setSixMonthDebitTotal(float sixMonthDebitTotal): void |
| `sixMonthDebitTotalLessTransfers` | `float` | Required | Six month sum of all debit transactions without transfers for the account | getSixMonthDebitTotalLessTransfers(): float | setSixMonthDebitTotalLessTransfers(float sixMonthDebitTotalLessTransfers): void |
| `twoMonthDebitTotal` | `float` | Required | Two month sum of all debit transactions by account | getTwoMonthDebitTotal(): float | setTwoMonthDebitTotal(float twoMonthDebitTotal): void |
| `twoMonthDebitTotalLessTransfers` | `float` | Required | Two month sum of all debit transactions without transfers for the account | getTwoMonthDebitTotalLessTransfers(): float | setTwoMonthDebitTotalLessTransfers(float twoMonthDebitTotalLessTransfers): void |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebitSummaries": {
    "month": 1512111600,
    "numberOfDebits": "1500",
    "totalDebitsAmount": -12345.46,
    "largestDebit": -20000,
    "numberOfDebitsLessTransfers": "5",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": -1200,
  "twelveMonthDebitTotalLessTransfers": -1000,
  "sixMonthDebitTotal": -750,
  "sixMonthDebitTotalLessTransfers": -500,
  "twoMonthDebitTotal": -150,
  "twoMonthDebitTotalLessTransfers": -100
}
```

