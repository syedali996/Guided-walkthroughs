
# Cash Flow Cash Flow Characteristic

## Structure

`CashFlowCashFlowCharacteristic`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyCashFlowCharacteristics` | [`CashFlowMonthlyCashFlowCharacteristics[]`](../../doc/models/cash-flow-monthly-cash-flow-characteristics.md) | Required | List of attributes for each month | getMonthlyCashFlowCharacteristics(): array | setMonthlyCashFlowCharacteristics(array monthlyCashFlowCharacteristics): void |
| `averageMonthlyNet` | `float` | Required | Average (Total Credits - Total Debits) for the account | getAverageMonthlyNet(): float | setAverageMonthlyNet(float averageMonthlyNet): void |
| `averageMonthlyNetLessTransfers` | `float` | Required | Average (Total Credits - Total Debits) without transfers for the account | getAverageMonthlyNetLessTransfers(): float | setAverageMonthlyNetLessTransfers(float averageMonthlyNetLessTransfers): void |
| `twelveMonthTotalNet` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) each month for the account | getTwelveMonthTotalNet(): float | setTwelveMonthTotalNet(float twelveMonthTotalNet): void |
| `twelveMonthTotalNetLessTransfers` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers for the account | getTwelveMonthTotalNetLessTransfers(): float | setTwelveMonthTotalNetLessTransfers(float twelveMonthTotalNetLessTransfers): void |
| `sixMonthAverageTotalCreditsLessTotalDebits` | `float` | Required | 6 Month Average (Total Credits - Total Debits) | getSixMonthAverageTotalCreditsLessTotalDebits(): float | setSixMonthAverageTotalCreditsLessTotalDebits(float sixMonthAverageTotalCreditsLessTotalDebits): void |
| `sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `float` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) | getSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers(): float | setSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers(float sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers): void |
| `twoMonthAverageTotalCreditsLessTotalDebits` | `float` | Required | 2 Month Average (Total Credits - Total Debits) | getTwoMonthAverageTotalCreditsLessTotalDebits(): float | setTwoMonthAverageTotalCreditsLessTotalDebits(float twoMonthAverageTotalCreditsLessTotalDebits): void |
| `twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `float` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) | getTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers(): float | setTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers(float twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers): void |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristics": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 2350,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

