
# Obb Account Details

## Structure

`ObbAccountDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountNumberDisplay` | `?string` | Optional | The account number from a financial institution in truncated format<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | getAccountNumberDisplay(): ?string | setAccountNumberDisplay(?string accountNumberDisplay): void |
| `accountOwner` | [`ObbAccountOwner`](../../doc/models/obb-account-owner.md) | Required | Details about who is on record as the owner of the account. May be the business name, the business owner name, or otherwise | getAccountOwner(): ObbAccountOwner | setAccountOwner(ObbAccountOwner accountOwner): void |
| `aggregationAttemptDate` | `?string` | Optional | A timestamp showing the last aggregation attempt. This will not be present until you have run your first aggregation for the account.<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getAggregationAttemptDate(): ?string | setAggregationAttemptDate(?string aggregationAttemptDate): void |
| `aggregationStatusCode` | `?int` | Optional | The status of the most recent aggregation attempt. This will not be present until you have run your first aggregation for the account | getAggregationStatusCode(): ?int | setAggregationStatusCode(?int aggregationStatusCode): void |
| `aggregationSuccessDate` | `?string` | Optional | A timestamp showing the last successful aggregation of the account. This will not be present until you have run your first aggregation for the account.<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getAggregationSuccessDate(): ?string | setAggregationSuccessDate(?string aggregationSuccessDate): void |
| `currency` | `?string` | Optional | The currency of the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `5` | getCurrency(): ?string | setCurrency(?string currency): void |
| `currentBalance` | `?float` | Optional | Current reported balance of the account | getCurrentBalance(): ?float | setCurrentBalance(?float currentBalance): void |
| `id` | `int` | Required | An account ID represented as a number | getId(): int | setId(int id): void |
| `institution` | [`ObbInstitution`](../../doc/models/obb-institution.md) | Required | Details of the financial institution this account is home to | getInstitution(): ObbInstitution | setInstitution(ObbInstitution institution): void |
| `institutionLoginId` | `?int` | Optional | An institution login ID (from the account record), represented as a number | getInstitutionLoginId(): ?int | setInstitutionLoginId(?int institutionLoginId): void |
| `name` | `?string` | Optional | The account name from the institution<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | getName(): ?string | setName(?string name): void |
| `realAccountNumberLast4` | `?int` | Optional | The last 4 digits of the ACH account number | getRealAccountNumberLast4(): ?int | setRealAccountNumberLast4(?int realAccountNumberLast4): void |
| `status` | `?string` | Optional | pending during account discovery, always active following successful account activation<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | getStatus(): ?string | setStatus(?string status): void |
| `type` | `?string` | Optional | Account type, e.g. checking/saving<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | getType(): ?string | setType(?string type): void |

## Example (as JSON)

```json
{
  "accountOwner": {
    "address": "123 Main St, Portland, OR 12345",
    "name": "Johnny Appleseed"
  },
  "id": 5011648377,
  "institution": {
    "institutionId": 12345
  }
}
```

