
# Last Transaction Date

## Structure

`LastTransactionDate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `date` | `string` | Required | Date the deposit transaction was posted | getDate(): string | setDate(string date): void |
| `depositsCredits` | `?float` | Optional | Amount of transaction if deposit, otherwise null | getDepositsCredits(): ?float | setDepositsCredits(?float depositsCredits): void |
| `withdrawalsDebits` | `?float` | Optional | Amount of transaction if withdrawal, otherwise null | getWithdrawalsDebits(): ?float | setWithdrawalsDebits(?float withdrawalsDebits): void |
| `zeroAmountTransaction` | `?float` | Optional | Amount of transaction if zero, otherwise null | getZeroAmountTransaction(): ?float | setZeroAmountTransaction(?float zeroAmountTransaction): void |
| `transactionDescription` | `?string` | Optional | Description of transaction | getTransactionDescription(): ?string | setTransactionDescription(?string transactionDescription): void |

## Example (as JSON)

```json
{
  "date": "2020-03-25"
}
```

