
# Obb Date Range and Amount

## Structure

`ObbDateRangeAndAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `?float` | Optional | Metric value for the given period | getAmount(): ?float | setAmount(?float amount): void |
| `period` | `string` | Required | Period represented by this metric<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `12` | getPeriod(): string | setPeriod(string period): void |
| `periodBeginDate` | `string` | Required | Begin date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getPeriodBeginDate(): string | setPeriodBeginDate(string periodBeginDate): void |
| `periodEndDate` | `string` | Required | End date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getPeriodEndDate(): string | setPeriodEndDate(string periodEndDate): void |

## Example (as JSON)

```json
{
  "period": "last30to1",
  "periodBeginDate": "2022-03-01",
  "periodEndDate": "2022-03-30"
}
```

