
# Cash Flow Insufficient Funds Fees

## Structure

`CashFlowInsufficientFundsFees`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `countOfTransactionsForTheReportTimePeriod` | `?int` | Optional | Count of all NSF transactions during the report | getCountOfTransactionsForTheReportTimePeriod(): ?int | setCountOfTransactionsForTheReportTimePeriod(?int countOfTransactionsForTheReportTimePeriod): void |
| `sumOfTransactionsForTheReportTimePeriod` | `?float` | Optional | Sum of all NSF transactions during the report | getSumOfTransactionsForTheReportTimePeriod(): ?float | setSumOfTransactionsForTheReportTimePeriod(?float sumOfTransactionsForTheReportTimePeriod): void |
| `transactions` | [`?(InsufficientFundsTransaction[])`](../../doc/models/insufficient-funds-transaction.md) | Optional | Transactions categorized as NSF | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "countOfTransactionsForTheReportTimePeriod": null,
  "sumOfTransactionsForTheReportTimePeriod": null,
  "transactions": null
}
```

