
# Branding Wrapper

## Structure

`BrandingWrapper`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `branding` | [`Branding`](../../doc/models/branding.md) | Required | All assets are SVGs so can be slightly resized without any issues. | getBranding(): Branding | setBranding(Branding branding): void |

## Example (as JSON)

```json
{
  "branding": {
    "logo": null,
    "alternateLogo": null,
    "icon": null,
    "primaryColor": null,
    "tile": null
  }
}
```

