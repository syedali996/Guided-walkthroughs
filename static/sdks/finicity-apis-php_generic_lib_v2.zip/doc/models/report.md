
# Report

A report

## Structure

`Report`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | A report ID | getId(): string | setId(string id): void |
| `customerType` | `string` | Required | The type of customer ("active" or "testing" or "" for all types) | getCustomerType(): string | setCustomerType(string customerType): void |
| `customerId` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): int | setCustomerId(int customerId): void |
| `requestId` | `string` | Required | Finicity indicator to track all activity associated with this report | getRequestId(): string | setRequestId(string requestId): void |
| `requesterName` | `string` | Required | Name of a Finicity partner | getRequesterName(): string | setRequesterName(string requesterName): void |
| `createdDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): int | setCreatedDate(int createdDate): void |
| `title` | `string` | Required | Title of the report | getTitle(): string | setTitle(string title): void |
| `consumerId` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. | getConsumerId(): string | setConsumerId(string consumerId): void |
| `consumerSsn` | `string` | Required | Last 4 digits of a SSN | getConsumerSsn(): string | setConsumerSsn(string consumerSsn): void |
| `type` | `string` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | getType(): string | setType(string type): void |
| `status` | `string` | Required | A report generation status. Possible values: "inProgress", "success", "failure". | getStatus(): string | setStatus(string status): void |
| `errors` | [`?(ErrorMessage[])`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | getErrors(): ?array | setErrors(?array errors): void |
| `portfolioId` | `?string` | Optional | A unique identifier that will be consistent across all reports created for the same customer | getPortfolioId(): ?string | setPortfolioId(?string portfolioId): void |
| `startDate` | `?int` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getStartDate(): ?int | setStartDate(?int startDate): void |
| `endDate` | `?int` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getEndDate(): ?int | setEndDate(?int endDate): void |
| `days` | `?int` | Optional | Number of days covered by the report | getDays(): ?int | setDays(?int days): void |
| `seasoned` | `?bool` | Optional | "true" if the report covers more than 365 days | getSeasoned(): ?bool | setSeasoned(?bool seasoned): void |
| `institutions` | [`?(ReportInstitution2[])`](../../doc/models/report-institution-2.md) | Optional | A list of institution records, including information about the individual accounts used in this report | getInstitutions(): ?array | setInstitutions(?array institutions): void |
| `cashFlowBalanceSummary` | [`?CashFlowCashFlowBalanceSummary`](../../doc/models/cash-flow-cash-flow-balance-summary.md) | Optional | - | getCashFlowBalanceSummary(): ?CashFlowCashFlowBalanceSummary | setCashFlowBalanceSummary(?CashFlowCashFlowBalanceSummary cashFlowBalanceSummary): void |
| `cashFlowCreditSummary` | [`?CashFlowCashFlowCreditSummary`](../../doc/models/cash-flow-cash-flow-credit-summary.md) | Optional | - | getCashFlowCreditSummary(): ?CashFlowCashFlowCreditSummary | setCashFlowCreditSummary(?CashFlowCashFlowCreditSummary cashFlowCreditSummary): void |
| `cashFlowDebitSummary` | [`?CashFlowCashFlowDebitSummary`](../../doc/models/cash-flow-cash-flow-debit-summary.md) | Optional | - | getCashFlowDebitSummary(): ?CashFlowCashFlowDebitSummary | setCashFlowDebitSummary(?CashFlowCashFlowDebitSummary cashFlowDebitSummary): void |
| `cashFlowCharacteristicsSummary` | [`?CashFlowCashFlowCharacteristicsSummary`](../../doc/models/cash-flow-cash-flow-characteristics-summary.md) | Optional | - | getCashFlowCharacteristicsSummary(): ?CashFlowCashFlowCharacteristicsSummary | setCashFlowCharacteristicsSummary(?CashFlowCashFlowCharacteristicsSummary cashFlowCharacteristicsSummary): void |
| `possibleLoanDeposits` | [`?(CashFlowPossibleLoanDeposits[])`](../../doc/models/cash-flow-possible-loan-deposits.md) | Optional | A possible loan deposits record | getPossibleLoanDeposits(): ?array | setPossibleLoanDeposits(?array possibleLoanDeposits): void |
| `consolidatedAvailableBalance` | `?float` | Optional | The sum of available balance for all of the accounts included in the report | getConsolidatedAvailableBalance(): ?float | setConsolidatedAvailableBalance(?float consolidatedAvailableBalance): void |
| `assets` | [`?PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - | getAssets(): ?PrequalificationReportAssetSummary | setAssets(?PrequalificationReportAssetSummary assets): void |
| `reportStyle` | `?string` | Optional | - | getReportStyle(): ?string | setReportStyle(?string reportStyle): void |
| `numberOfBillableAssets` | `?int` | Optional | Total number of billable pay statements included in the report | getNumberOfBillableAssets(): ?int | setNumberOfBillableAssets(?int numberOfBillableAssets): void |
| `assetIds` | `?(string[])` | Optional | The pay statements included in the report | getAssetIds(): ?array | setAssetIds(?array assetIds): void |
| `payStatements` | [`?(VOIEPayStatement2[])`](../../doc/models/voie-pay-statement-2.md) | Optional | Extracted pay statement details | getPayStatements(): ?array | setPayStatements(?array payStatements): void |
| `assetId` | `?string` | Optional | An asset ID. Generated by Connect or by using the Store Customer Pay Statement API. | getAssetId(): ?string | setAssetId(?string assetId): void |
| `employmentHistory` | [`?(PayrollEmploymentHistory[])`](../../doc/models/payroll-employment-history.md) | Optional | An array of employment histories, one for each of the consumer's verified employers | getEmploymentHistory(): ?array | setEmploymentHistory(?array employmentHistory): void |
| `income` | [`?(ReportIncomeStreamSummary[])`](../../doc/models/report-income-stream-summary.md) | Optional | - | getIncome(): ?array | setIncome(?array income): void |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "customerType": "active",
  "customerId": 1005061234,
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "title": "Finicity Asset Ready Report (CRA)",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress"
}
```

