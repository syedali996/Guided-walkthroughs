
# Customer Account

An account represents a bank account such as a checking or savings that the customer has added via the Connect interface.

## Structure

`CustomerAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | An account ID | getId(): string | setId(string id): void |
| `number` | `string` | Required | Use the `accountNumberDisplay` field. Starting July 1, 2021 the `number` field will sunset with limited support until April 1, 2022, at which time it will be deprecated (no longer available). | getNumber(): string | setNumber(string number): void |
| `accountNumberDisplay` | `string` | Required | The account number from a financial institution in truncated format:<br><br>* Last four digits: "1234"<br>* Last four digits with suffix: "1234-9"<br>* Full value for string accounts: "john@gmail.com" | getAccountNumberDisplay(): string | setAccountNumberDisplay(string accountNumberDisplay): void |
| `realAccountNumberLast4` | `?string` | Optional | The last 4 digits of the ACH account number | getRealAccountNumberLast4(): ?string | setRealAccountNumberLast4(?string realAccountNumberLast4): void |
| `name` | `string` | Required | The account name from the institution | getName(): string | setName(string name): void |
| `balance` | `float` | Required | The cleared balance of the account as of `balanceDate` | getBalance(): float | setBalance(float balance): void |
| `type` | `string` | Required | The list of supported account types.<br><br>* "checking": Standard checking<br>* "savings": Standard savings<br>* "cd": Certificates of deposit<br>* "moneyMarket": Money Market<br>* "creditCard": Standard credit cards<br>* "lineOfCredit": Home equity, line of credit<br>* "investment": Generic investment (no details)<br>* "investmentTaxDeferred": Generic tax-advantaged investment (no details)<br>* "employeeStockPurchasePlan": ESPP, Employee Stock Ownership Plans (ESOP), Stock Purchase Plans<br>* "ira": Individual Retirement Account (not Rollover or Roth)<br>* "401k": 401K Plan<br>* "roth": Roth IRA, Roth 401K<br>* "403b": 403B Plan<br>* "529plan": 529 Plan (True value is 529)<br>* "rollover": Rollover IRA<br>* "ugma": Uniform Gifts to Minors Act<br>* "utma": Uniform Transfers to Minors Act<br>* "keogh": Keogh Plan<br>* "457plan": 457 Plan (True value is 457)<br>* "401a": 401A Plan<br>* "brokerageAccount": Brokerage Account<br>* "educationSavings": Education Savings Account that is not a 529<br>* "healthSavingsAccount": HSA (Health Savings Accounts)<br>* "pension": Pension<br>* "profitSharingPlan": Profit Sharing Plan<br>* "roth401k": Roth 401K<br>* "sepIRA": Simplified Employee Pension IRA<br>* "simpleIRA": Simple IRA<br>* "thriftSavingsPlan": Thrift Savings Plan<br>* "variableAnnuity": Variable Annuity<br>* "cryptocurrency": Cryptocurrency Wallet, Cryptocurrency Account<br>* "mortgage": Standard Mortgages<br>* "loan": Auto loans, equity loans, other loans<br>* "studentLoan": Student Loan<br>* "studentLoanGroup": Student Loan Group<br>* "studentLoanAccount": Student Loan Account | getType(): string | setType(string type): void |
| `aggregationStatusCode` | `?int` | Optional | The status of the most recent aggregation attempt (see [Aggregation Status Codes](https://docs.finicity.com/aggregation-status-codes/)). Won't be present until you have run your first aggregation for the account. | getAggregationStatusCode(): ?int | setAggregationStatusCode(?int aggregationStatusCode): void |
| `status` | `string` | Required | "pending" during account discovery, always "active" following successful account activation | getStatus(): string | setStatus(string status): void |
| `customerId` | `string` | Required | A customer ID. See Add Customer API for how to create a customer ID. | getCustomerId(): string | setCustomerId(string customerId): void |
| `institutionId` | `string` | Required | The ID of a financial institution | getInstitutionId(): string | setInstitutionId(string institutionId): void |
| `balanceDate` | `int` | Required | A timestamp showing when the balance was captured. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getBalanceDate(): int | setBalanceDate(int balanceDate): void |
| `aggregationSuccessDate` | `?int` | Optional | A timestamp showing the last successful aggregation of the account. This will not be present until you have run your first aggregation for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getAggregationSuccessDate(): ?int | setAggregationSuccessDate(?int aggregationSuccessDate): void |
| `aggregationAttemptDate` | `?int` | Optional | A timestamp showing the last aggregation attempt, whether successful or not. This will not be present until you have run your first aggregation for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getAggregationAttemptDate(): ?int | setAggregationAttemptDate(?int aggregationAttemptDate): void |
| `createdDate` | `int` | Required | A timestamp showing when the account was added to the system. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): int | setCreatedDate(int createdDate): void |
| `currency` | `string` | Required | A currency code | getCurrency(): string | setCurrency(string currency): void |
| `lastTransactionDate` | `?int` | Optional | The date of the latest transaction on the account. This will not be present until you have run your first aggregation for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLastTransactionDate(): ?int | setLastTransactionDate(?int lastTransactionDate): void |
| `oldestTransactionDate` | `int` | Required | The date of the oldest transaction in the transactions for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getOldestTransactionDate(): int | setOldestTransactionDate(int oldestTransactionDate): void |
| `institutionLoginId` | `int` | Required | An institution login ID (from the account record), represented as a number | getInstitutionLoginId(): int | setInstitutionLoginId(int institutionLoginId): void |
| `detail` | [`?CustomerAccountDetail`](../../doc/models/customer-account-detail.md) | Optional | Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution. | getDetail(): ?CustomerAccountDetail | setDetail(?CustomerAccountDetail detail): void |
| `position` | [`?(CustomerAccountPosition[])`](../../doc/models/customer-account-position.md) | Optional | Investment holdings | getPosition(): ?array | setPosition(?array position): void |
| `displayPosition` | `?int` | Optional | Display position of the account at the financial institution, "1" being the top listed account | getDisplayPosition(): ?int | setDisplayPosition(?int displayPosition): void |
| `parentAccount` | `?string` | Optional | The assigned account ID for the account one level higher in the student loan account hierarchy | getParentAccount(): ?string | setParentAccount(?string parentAccount): void |

## Example (as JSON)

```json
{
  "id": "5011648377",
  "number": "2000004444",
  "accountNumberDisplay": "1234-9",
  "name": "Super Checking",
  "balance": 401.26,
  "type": "checking",
  "status": "active",
  "customerId": "1005061234",
  "institutionId": "4222",
  "balanceDate": 1607450357,
  "createdDate": 1607450357,
  "currency": "USD",
  "oldestTransactionDate": 1607450357,
  "institutionLoginId": 1007302745
}
```

