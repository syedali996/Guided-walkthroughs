
# Deduction

## Structure

`Deduction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | The normalized category of the deductions in the format [type][number]. The number is the will be the iterating number of the type's occurrence starting at one. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | The deduction line's deduction type description | getDescription(): ?string | setDescription(?string description): void |
| `amountCurrent` | `?float` | Optional | The amount for the deduction line deducted from employee's pay for the specified pay period | getAmountCurrent(): ?float | setAmountCurrent(?float amountCurrent): void |
| `amountYTD` | `?float` | Optional | The amount for the deduction line being deducted from the employee's pay for the current pay year | getAmountYTD(): ?float | setAmountYTD(?float amountYTD): void |
| `type` | `?string` | Optional | Categorization based on the deduction line's description | getType(): ?string | setType(?string type): void |

## Example (as JSON)

```json
{
  "name": null,
  "description": null,
  "amountCurrent": null,
  "amountYTD": null,
  "type": null
}
```

