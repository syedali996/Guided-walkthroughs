
# Cash Flow Analytics Business Summary

## Structure

`CashFlowAnalyticsBusinessSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cashflowAnalyticsMetrics` | [`?CashFlowAnalyticsMetrics`](../../doc/models/cash-flow-analytics-metrics.md) | Optional | Cash flow analytics metrics and calculations across all accounts in the report | getCashflowAnalyticsMetrics(): ?CashFlowAnalyticsMetrics | setCashflowAnalyticsMetrics(?CashFlowAnalyticsMetrics cashflowAnalyticsMetrics): void |
| `currentReportRequest` | [`ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Required | Describes the requested attributes of the report | getCurrentReportRequest(): ObbCurrentReportRequestDetails | setCurrentReportRequest(ObbCurrentReportRequestDetails currentReportRequest): void |
| `historicDataAvailability` | [`ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Required | Describes the availability of historical data for all accounts owned by the business | getHistoricDataAvailability(): ObbDataAvailability | setHistoricDataAvailability(ObbDataAvailability historicDataAvailability): void |

## Example (as JSON)

```json
{
  "currentReportRequest": {
    "reportBeginDate": "2022-03-01",
    "reportEndDate": "2022-03-30",
    "reportRequestDate": "03/30/2022 21:47:19",
    "requestedDaysForReport": 90,
    "requestedReportBeginDate": "2022-01-01"
  },
  "historicDataAvailability": {
    "historicAvailabilityBeginDate": "2022-03-01",
    "historicAvailabilityEndDate": "2022-03-30",
    "historicAvailableDays": 30,
    "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
  }
}
```

