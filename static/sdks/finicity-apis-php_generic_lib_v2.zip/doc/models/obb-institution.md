
# Obb Institution

## Structure

`ObbInstitution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `institutionIconUrl` | `?string` | Optional | URL of the institution logo icon for reporting<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getInstitutionIconUrl(): ?string | setInstitutionIconUrl(?string institutionIconUrl): void |
| `institutionId` | `int` | Required | ID of the financial institution | getInstitutionId(): int | setInstitutionId(int institutionId): void |
| `institutionName` | `?string` | Optional | Name of the financial institution<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getInstitutionName(): ?string | setInstitutionName(?string institutionName): void |
| `institutionPrimaryColor` | `?string` | Optional | Primary branding color of the institution, in hex color format<br>**Constraints**: *Minimum Length*: `7`, *Maximum Length*: `7` | getInstitutionPrimaryColor(): ?string | setInstitutionPrimaryColor(?string institutionPrimaryColor): void |

## Example (as JSON)

```json
{
  "institutionId": 12345
}
```

