
# Net Monthly

## Structure

`NetMonthly`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `month` | `int` | Required | Timestamp for the first day of this month | getMonth(): int | setMonth(int month): void |
| `net` | `float` | Required | Total income during the given month, across all income streams | getNet(): float | setNet(float net): void |

## Example (as JSON)

```json
{
  "month": 1522562400,
  "net": 2004.77
}
```

