
# Insufficient Funds Transaction

## Structure

`InsufficientFundsTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amount` | `float` | Required | Amount of the NSF transaction | getAmount(): float | setAmount(float amount): void |
| `description` | `?string` | Optional | Description of the transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getDescription(): ?string | setDescription(?string description): void |
| `memo` | `?string` | Optional | Transaction memo<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getMemo(): ?string | setMemo(?string memo): void |
| `postedDate` | `string` | Required | Posted date of the NSF transaction<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getPostedDate(): string | setPostedDate(string postedDate): void |
| `transactionId` | `int` | Required | Finicity transaction ID | getTransactionId(): int | setTransactionId(int transactionId): void |

## Example (as JSON)

```json
{
  "amount": -1.65,
  "postedDate": "2022-12-19",
  "transactionId": 23092384290
}
```

