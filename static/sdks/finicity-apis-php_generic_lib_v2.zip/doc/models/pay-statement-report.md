
# Pay Statement Report

A Pay Statement report

## Structure

`PayStatementReport`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | A report ID | getId(): ?string | setId(?string id): void |
| `customerType` | `?string` | Optional | The type of customer ("active" or "testing" or "" for all types) | getCustomerType(): ?string | setCustomerType(?string customerType): void |
| `customerId` | `?int` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): ?int | setCustomerId(?int customerId): void |
| `requestId` | `?string` | Optional | Finicity indicator to track all activity associated with this report | getRequestId(): ?string | setRequestId(?string requestId): void |
| `requesterName` | `?string` | Optional | Name of a Finicity partner | getRequesterName(): ?string | setRequesterName(?string requesterName): void |
| `createdDate` | `?int` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getCreatedDate(): ?int | setCreatedDate(?int createdDate): void |
| `title` | `?string` | Optional | Title of the report | getTitle(): ?string | setTitle(?string title): void |
| `consumerId` | `?string` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. | getConsumerId(): ?string | setConsumerId(?string consumerId): void |
| `consumerSsn` | `?string` | Optional | Last 4 digits of a SSN | getConsumerSsn(): ?string | setConsumerSsn(?string consumerSsn): void |
| `type` | `?string` | Optional | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" | getType(): ?string | setType(?string type): void |
| `status` | `?string` | Optional | A report generation status. Possible values: "inProgress", "success", "failure". | getStatus(): ?string | setStatus(?string status): void |
| `errors` | [`?(ErrorMessage[])`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation | getErrors(): ?array | setErrors(?array errors): void |
| `portfolioId` | `?string` | Optional | A unique identifier that will be consistent across all reports created for the same customer | getPortfolioId(): ?string | setPortfolioId(?string portfolioId): void |
| `startDate` | `?int` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getStartDate(): ?int | setStartDate(?int startDate): void |
| `endDate` | `?int` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getEndDate(): ?int | setEndDate(?int endDate): void |
| `reportStyle` | `?string` | Optional | - | getReportStyle(): ?string | setReportStyle(?string reportStyle): void |
| `numberOfBillableAssets` | `?int` | Optional | Total number of billable pay statements included in the report | getNumberOfBillableAssets(): ?int | setNumberOfBillableAssets(?int numberOfBillableAssets): void |
| `assetIds` | `?(string[])` | Optional | - | getAssetIds(): ?array | setAssetIds(?array assetIds): void |
| `payStatements` | [`?(VOIEPayStatement[])`](../../doc/models/voie-pay-statement.md) | Optional | Extracted pay statement details | getPayStatements(): ?array | setPayStatements(?array payStatements): void |

## Example (as JSON)

```json
{
  "id": null,
  "customerType": null,
  "customerId": null,
  "requestId": null,
  "requesterName": null,
  "createdDate": null,
  "title": null,
  "consumerId": null,
  "consumerSsn": null,
  "type": null,
  "status": null,
  "errors": null,
  "portfolioId": null,
  "startDate": null,
  "endDate": null,
  "reportStyle": null,
  "numberOfBillableAssets": null,
  "assetIds": null,
  "payStatements": null
}
```

