
# Consumer Attribute Account I Ds

A list of account IDs

## Structure

`ConsumerAttributeAccountIDs`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountIds` | `string[]` | Required | The list of account IDs | getAccountIds(): array | setAccountIds(array accountIds): void |

## Example (as JSON)

```json
{
  "accountIds": [
    "accountIds5",
    "accountIds6"
  ]
}
```

