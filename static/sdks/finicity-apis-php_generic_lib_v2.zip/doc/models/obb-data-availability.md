
# Obb Data Availability

## Structure

`ObbDataAvailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `historicAvailabilityBeginDate` | `string` | Required | Begin date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getHistoricAvailabilityBeginDate(): string | setHistoricAvailabilityBeginDate(string historicAvailabilityBeginDate): void |
| `historicAvailabilityEndDate` | `string` | Required | End date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getHistoricAvailabilityEndDate(): string | setHistoricAvailabilityEndDate(string historicAvailabilityEndDate): void |
| `historicAvailableDays` | `int` | Required | Days for which transaction details are available | getHistoricAvailableDays(): int | setHistoricAvailableDays(int historicAvailableDays): void |
| `historicDataAvailability` | `string` | Required | Description of historic data availability<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getHistoricDataAvailability(): string | setHistoricDataAvailability(string historicDataAvailability): void |

## Example (as JSON)

```json
{
  "historicAvailabilityBeginDate": "2022-03-01",
  "historicAvailabilityEndDate": "2022-03-30",
  "historicAvailableDays": 30,
  "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
}
```

