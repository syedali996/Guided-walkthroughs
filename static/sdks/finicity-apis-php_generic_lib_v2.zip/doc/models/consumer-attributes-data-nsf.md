
# Consumer Attributes Data NSF

## Structure

`ConsumerAttributesDataNSF`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyNSFOccurrences` | `array` | Required | The number of non-sufficient funds occurrences per calendar month | getMonthlyNSFOccurrences(): array | setMonthlyNSFOccurrences(array monthlyNSFOccurrences): void |
| `monthlyLateFeeOccurrences` | `array` | Required | The number of late fee occurrences | getMonthlyLateFeeOccurrences(): array | setMonthlyLateFeeOccurrences(array monthlyLateFeeOccurrences): void |

## Example (as JSON)

```json
{
  "monthlyNSFOccurrences": {
    "2021-04-30": 1,
    "2021-07-31": 1
  },
  "monthlyLateFeeOccurrences": {}
}
```

