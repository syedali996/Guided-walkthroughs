
# Cash Flow Num Weeks Zeros

## Structure

`CashFlowNumWeeksZeros`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `historicNumberOfWeeksWithDataAvailable` | `int` | Required | Number of weeks during known history of account in which data was available | getHistoricNumberOfWeeksWithDataAvailable(): int | setHistoricNumberOfWeeksWithDataAvailable(int historicNumberOfWeeksWithDataAvailable): void |
| `historicNumberOfWeeksZeroTransactions` | `int` | Required | Number of weeks during known history of account where zero transactions were posted | getHistoricNumberOfWeeksZeroTransactions(): int | setHistoricNumberOfWeeksZeroTransactions(int historicNumberOfWeeksZeroTransactions): void |
| `historicWeeksWithZeroTransactions` | [`ObbWeekOfYear[]`](../../doc/models/obb-week-of-year.md) | Required | List of weeks with zero reported transactions | getHistoricWeeksWithZeroTransactions(): array | setHistoricWeeksWithZeroTransactions(array historicWeeksWithZeroTransactions): void |

## Example (as JSON)

```json
{
  "historicNumberOfWeeksWithDataAvailable": 10,
  "historicNumberOfWeeksZeroTransactions": 5,
  "historicWeeksWithZeroTransactions": {
    "fromDate": "2020-01-01",
    "toDate": "2020-01-07",
    "week": 1
  }
}
```

