
# Available Balance

## Structure

`AvailableBalance`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getId(): int | setId(int id): void |
| `realAccountNumberLast4` | `string` | Required | The last 4 digits of the ACH account number | getRealAccountNumberLast4(): string | setRealAccountNumberLast4(string realAccountNumberLast4): void |
| `availableBalance` | `float` | Required | The available balance of the account | getAvailableBalance(): float | setAvailableBalance(float availableBalance): void |
| `availableBalanceDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getAvailableBalanceDate(): int | setAvailableBalanceDate(int availableBalanceDate): void |
| `clearedBalance` | `float` | Required | The cleared balance of the account. Also referred as posted balance, current balance, ledger balance | getClearedBalance(): float | setClearedBalance(float clearedBalance): void |
| `clearedBalanceDate` | `int` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getClearedBalanceDate(): int | setClearedBalanceDate(int clearedBalanceDate): void |
| `aggregationStatusCode` | `int` | Required | The status of the most recent aggregation attempt (see [Aggregation Status Codes](https://docs.finicity.com/aggregation-status-codes/)). Won't be present until you have run your first aggregation for the account. | getAggregationStatusCode(): int | setAggregationStatusCode(int aggregationStatusCode): void |
| `currency` | `string` | Required | A currency code | getCurrency(): string | setCurrency(string currency): void |

## Example (as JSON)

```json
{
  "id": 1005061234,
  "realAccountNumberLast4": "5678",
  "availableBalance": 173.47,
  "availableBalanceDate": 1607450357,
  "clearedBalance": 222.25,
  "clearedBalanceDate": 1607450357,
  "aggregationStatusCode": null,
  "currency": "USD"
}
```

