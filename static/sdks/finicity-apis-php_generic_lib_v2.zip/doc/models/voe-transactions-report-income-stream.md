
# VOE Transactions Report Income Stream

## Structure

`VOETransactionsReportIncomeStream`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Income stream ID | getId(): string | setId(string id): void |
| `name` | `string` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream | getName(): string | setName(string name): void |
| `status` | `string` | Required | Possible values: "ACTIVE", "INACTIVE" | getStatus(): string | setStatus(string status): void |
| `estimateInclusion` | `string` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" | getEstimateInclusion(): string | setEstimateInclusion(string estimateInclusion): void |
| `confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) | getConfidence(): int | setConfidence(int confidence): void |
| `cadence` | [`CadenceDetails`](../../doc/models/cadence-details.md) | Required | - | getCadence(): CadenceDetails | setCadence(CadenceDetails cadence): void |
| `daysSinceLastTransaction` | `int` | Required | The number of days since the last credit transaction for the particular income stream | getDaysSinceLastTransaction(): int | setDaysSinceLastTransaction(int daysSinceLastTransaction): void |
| `nextExpectedTransactionDate` | `int` | Required | The next expected credit transaction date for the particular income stream, based on the cadence | getNextExpectedTransactionDate(): int | setNextExpectedTransactionDate(int nextExpectedTransactionDate): void |
| `incomeStreamMonths` | `int` | Required | The number of months the income transactions are observed | getIncomeStreamMonths(): int | setIncomeStreamMonths(int incomeStreamMonths): void |
| `transactions` | [`ReportTransaction[]`](../../doc/models/report-transaction.md) | Required | A list of transaction records | getTransactions(): array | setTransactions(array transactions): void |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voah",
  "name": "none",
  "status": null,
  "estimateInclusion": null,
  "confidence": 70,
  "cadence": null,
  "daysSinceLastTransaction": 15,
  "nextExpectedTransactionDate": 1572625469,
  "incomeStreamMonths": 18,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

