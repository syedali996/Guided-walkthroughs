
# Institution

A financial institution

## Structure

`Institution`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | The ID of a financial institution, represented as a number | getId(): int | setId(int id): void |
| `name` | `?string` | Optional | The name of the institution | getName(): ?string | setName(?string name): void |
| `transAgg` | `bool` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product | getTransAgg(): bool | setTransAgg(bool transAgg): void |
| `ach` | `bool` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product | getAch(): bool | setAch(bool ach): void |
| `stateAgg` | `bool` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product | getStateAgg(): bool | setStateAgg(bool stateAgg): void |
| `voi` | `bool` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product | getVoi(): bool | setVoi(bool voi): void |
| `voa` | `bool` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product | getVoa(): bool | setVoa(bool voa): void |
| `aha` | `bool` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product | getAha(): bool | setAha(bool aha): void |
| `availBalance` | `bool` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product | getAvailBalance(): bool | setAvailBalance(bool availBalance): void |
| `accountOwner` | `bool` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product | getAccountOwner(): bool | setAccountOwner(bool accountOwner): void |
| `studentLoanData` | `?bool` | Optional | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product | getStudentLoanData(): ?bool | setStudentLoanData(?bool studentLoanData): void |
| `loanPaymentDetails` | `?bool` | Optional | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product | getLoanPaymentDetails(): ?bool | setLoanPaymentDetails(?bool loanPaymentDetails): void |
| `accountTypeDescription` | `?string` | Optional | Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance | getAccountTypeDescription(): ?string | setAccountTypeDescription(?string accountTypeDescription): void |
| `phone` | `?string` | Optional | A phone number | getPhone(): ?string | setPhone(?string phone): void |
| `urlHomeApp` | `?string` | Optional | The URL of the institution's primary home page | getUrlHomeApp(): ?string | setUrlHomeApp(?string urlHomeApp): void |
| `urlLogonApp` | `?string` | Optional | The URL of the institution's login page | getUrlLogonApp(): ?string | setUrlLogonApp(?string urlLogonApp): void |
| `oauthEnabled` | `bool` | Required | "true": The institution is an OAuth connection<br><br>"false": The institution isn't an OAuth connection | getOauthEnabled(): bool | setOauthEnabled(bool oauthEnabled): void |
| `urlForgotPassword` | `?string` | Optional | Institution's forgot password page | getUrlForgotPassword(): ?string | setUrlForgotPassword(?string urlForgotPassword): void |
| `urlOnlineRegistration` | `?string` | Optional | Institution's signup page | getUrlOnlineRegistration(): ?string | setUrlOnlineRegistration(?string urlOnlineRegistration): void |
| `class` | `?string` | Optional | Institution's class | getClass(): ?string | setClass(?string class): void |
| `specialText` | `?string` | Optional | Special instructions given to customers for login | getSpecialText(): ?string | setSpecialText(?string specialText): void |
| `timeZone` | `?string` | Optional | The time zone of the institution. | getTimeZone(): ?string | setTimeZone(?string timeZone): void |
| `specialInstructions` | `?(string[])` | Optional | Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.<br><br>Note: this helps the customer to provide the proper permission for data needed for the application. | getSpecialInstructions(): ?array | setSpecialInstructions(?array specialInstructions): void |
| `specialInstutionsTitle` | `?string` | Optional | The title of the special instructions, if one exists or is required. | getSpecialInstutionsTitle(): ?string | setSpecialInstutionsTitle(?string specialInstutionsTitle): void |
| `address` | [`?InstitutionAddress`](../../doc/models/institution-address.md) | Optional | The address of a financial institution | getAddress(): ?InstitutionAddress | setAddress(?InstitutionAddress address): void |
| `currency` | `string` | Required | A currency code | getCurrency(): string | setCurrency(string currency): void |
| `email` | `?string` | Optional | An email address | getEmail(): ?string | setEmail(?string email): void |
| `status` | `string` | Required | Status for the institution: "online", "offline", "maintenance", "testing" | getStatus(): string | setStatus(string status): void |
| `newInstitutionId` | `?int` | Optional | The ID of a financial institution, represented as a number | getNewInstitutionId(): ?int | setNewInstitutionId(?int newInstitutionId): void |
| `branding` | [`?Branding`](../../doc/models/branding.md) | Optional | All assets are SVGs so can be slightly resized without any issues. | getBranding(): ?Branding | setBranding(?Branding branding): void |
| `oauthInstitutionId` | `?int` | Optional | The ID of a financial institution, represented as a number | getOauthInstitutionId(): ?int | setOauthInstitutionId(?int oauthInstitutionId): void |

## Example (as JSON)

```json
{
  "id": 4222,
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "oauthEnabled": true,
  "currency": "USD",
  "status": "online"
}
```

