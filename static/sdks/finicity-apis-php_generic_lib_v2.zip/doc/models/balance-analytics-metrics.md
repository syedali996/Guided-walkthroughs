
# Balance Analytics Metrics

## Structure

`BalanceAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `availableBalance` | `?float` | Optional | Available Balance | getAvailableBalance(): ?float | setAvailableBalance(?float availableBalance): void |
| `availableBalanceDate` | `?string` | Optional | Available Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getAvailableBalanceDate(): ?string | setAvailableBalanceDate(?string availableBalanceDate): void |
| `averageDailyBalanceByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average daily ending balance each month over the report time period | getAverageDailyBalanceByMonthForTheReportTimePeriod(): ?array | setAverageDailyBalanceByMonthForTheReportTimePeriod(?array averageDailyBalanceByMonthForTheReportTimePeriod): void |
| `averageDailyBalanceForTheReportTimePeriod` | `?float` | Optional | Average Daily Balance | getAverageDailyBalanceForTheReportTimePeriod(): ?float | setAverageDailyBalanceForTheReportTimePeriod(?float averageDailyBalanceForTheReportTimePeriod): void |
| `averageWeekdayBalanceForTheReportTimePeriod` | `?float` | Optional | Average Weekday Balance | getAverageWeekdayBalanceForTheReportTimePeriod(): ?float | setAverageWeekdayBalanceForTheReportTimePeriod(?float averageWeekdayBalanceForTheReportTimePeriod): void |
| `countDailyNegativeBalancesByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndCount[])`](../../doc/models/obb-date-range-and-count.md) | Optional | Number of negative daily ending balances each month over the report time period | getCountDailyNegativeBalancesByMonthForTheReportTimePeriod(): ?array | setCountDailyNegativeBalancesByMonthForTheReportTimePeriod(?array countDailyNegativeBalancesByMonthForTheReportTimePeriod): void |
| `currentRunningBalance` | `?float` | Optional | Current Running Balance Date | getCurrentRunningBalance(): ?float | setCurrentRunningBalance(?float currentRunningBalance): void |
| `currentRunningBalanceDate` | `?string` | Optional | Current Running Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getCurrentRunningBalanceDate(): ?string | setCurrentRunningBalanceDate(?string currentRunningBalanceDate): void |
| `dailyBalancesByWeekdayForTheReportTimePeriod` | [`?(ObbDailyBalance[])`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account during weekdays over the length of the report | getDailyBalancesByWeekdayForTheReportTimePeriod(): ?array | setDailyBalancesByWeekdayForTheReportTimePeriod(?array dailyBalancesByWeekdayForTheReportTimePeriod): void |
| `dailyBalancesForTheReportTimePeriod` | [`?(ObbDailyBalance[])`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account over the length of the report | getDailyBalancesForTheReportTimePeriod(): ?array | setDailyBalancesForTheReportTimePeriod(?array dailyBalancesForTheReportTimePeriod): void |
| `historicNumberOfWeeksAverageBalanceIncreasing` | [`?ObbNumWeeksAverageBalanceIncreasing`](../../doc/models/obb-num-weeks-average-balance-increasing.md) | Optional | Report of average account balance week over week and count of weeks where the average balance increased | getHistoricNumberOfWeeksAverageBalanceIncreasing(): ?ObbNumWeeksAverageBalanceIncreasing | setHistoricNumberOfWeeksAverageBalanceIncreasing(?ObbNumWeeksAverageBalanceIncreasing historicNumberOfWeeksAverageBalanceIncreasing): void |
| `maximumDailyBalanceByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Maximum daily ending balance each month over the report time period | getMaximumDailyBalanceByMonthForTheReportTimePeriod(): ?array | setMaximumDailyBalanceByMonthForTheReportTimePeriod(?array maximumDailyBalanceByMonthForTheReportTimePeriod): void |
| `maximumRunningBalanceForTheReportTimePeriod` | `?float` | Optional | Maximum Running Balance | getMaximumRunningBalanceForTheReportTimePeriod(): ?float | setMaximumRunningBalanceForTheReportTimePeriod(?float maximumRunningBalanceForTheReportTimePeriod): void |
| `minimumDailyBalanceByMonthForTheReportTimePeriod` | [`?(ObbDateRangeAndAmount[])`](../../doc/models/obb-date-range-and-amount.md) | Optional | Minimum daily ending balance each month over the report time period | getMinimumDailyBalanceByMonthForTheReportTimePeriod(): ?array | setMinimumDailyBalanceByMonthForTheReportTimePeriod(?array minimumDailyBalanceByMonthForTheReportTimePeriod): void |
| `minimumRunningBalanceForTheReportTimePeriod` | `?float` | Optional | Minimum Running Balance | getMinimumRunningBalanceForTheReportTimePeriod(): ?float | setMinimumRunningBalanceForTheReportTimePeriod(?float minimumRunningBalanceForTheReportTimePeriod): void |

## Example (as JSON)

```json
{
  "availableBalance": null,
  "availableBalanceDate": null,
  "averageDailyBalanceByMonthForTheReportTimePeriod": null,
  "averageDailyBalanceForTheReportTimePeriod": null,
  "averageWeekdayBalanceForTheReportTimePeriod": null,
  "countDailyNegativeBalancesByMonthForTheReportTimePeriod": null,
  "currentRunningBalance": null,
  "currentRunningBalanceDate": null,
  "dailyBalancesByWeekdayForTheReportTimePeriod": null,
  "dailyBalancesForTheReportTimePeriod": null,
  "historicNumberOfWeeksAverageBalanceIncreasing": null,
  "maximumDailyBalanceByMonthForTheReportTimePeriod": null,
  "maximumRunningBalanceForTheReportTimePeriod": null,
  "minimumDailyBalanceByMonthForTheReportTimePeriod": null,
  "minimumRunningBalanceForTheReportTimePeriod": null
}
```

