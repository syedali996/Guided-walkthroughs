
# Consumer Attributes Data Date Range

## Structure

`ConsumerAttributesDataDateRange`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `from` | `\DateTime` | Required | A 'YYYY-MM-DD' date notation as defined by [RFC 3339, section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | getFrom(): \DateTime | setFrom(\DateTime from): void |
| `to` | `\DateTime` | Required | A 'YYYY-MM-DD' date notation as defined by [RFC 3339, section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) | getTo(): \DateTime | setTo(\DateTime to): void |

## Example (as JSON)

```json
{
  "From": "2022-04-12",
  "To": "2022-04-12"
}
```

