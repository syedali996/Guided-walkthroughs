
# Obb Account Owner

## Structure

`ObbAccountOwner`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `address` | `string` | Required | Address of the owner on record for the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getAddress(): string | setAddress(string address): void |
| `name` | `string` | Required | Name of the owner on record for the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getName(): string | setName(string name): void |

## Example (as JSON)

```json
{
  "address": "123 Main St, Portland, OR 12345",
  "name": "Johnny Appleseed"
}
```

