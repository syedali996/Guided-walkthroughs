
# Cash Flow Activity Deposits Credits

## Structure

`CashFlowActivityDepositsCredits`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `date` | `string` | Required | Date the deposit transaction was posted<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getDate(): string | setDate(string date): void |
| `depositsCredits` | `float` | Required | Amount of the deposit | getDepositsCredits(): float | setDepositsCredits(float depositsCredits): void |
| `transactionDescription` | `?string` | Optional | Description of transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getTransactionDescription(): ?string | setTransactionDescription(?string transactionDescription): void |

## Example (as JSON)

```json
{
  "date": "2020-03-25",
  "depositsCredits": 500
}
```

