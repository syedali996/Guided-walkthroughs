
# Employer

## Structure

`Employer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | The name of the employer | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "name": null
}
```

