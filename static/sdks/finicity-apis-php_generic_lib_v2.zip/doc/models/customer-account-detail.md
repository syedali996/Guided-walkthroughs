
# Customer Account Detail

Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution.

## Structure

`CustomerAccountDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `dateAsOf` | `?int` | Optional | (All Account Types) Most recent date of the following information. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getDateAsOf(): ?int | setDateAsOf(?int dateAsOf): void |
| `availableBalanceAmount` | `float` | Required | (Checking/Savings/CD/MoneyMarket) and (Mortgage/Loan) The available balance (typically the current balance with adjustments for any pending transactions) | getAvailableBalanceAmount(): float | setAvailableBalanceAmount(float availableBalanceAmount): void |
| `openDate` | `?int` | Optional | (Checking/Savings/CD/MoneyMarket) Date when account was opened. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getOpenDate(): ?int | setOpenDate(?int openDate): void |
| `periodStartDate` | `?int` | Optional | (Checking/Savings/CD/MoneyMarket) Start date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getPeriodStartDate(): ?int | setPeriodStartDate(?int periodStartDate): void |
| `periodEndDate` | `?int` | Optional | End date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getPeriodEndDate(): ?int | setPeriodEndDate(?int periodEndDate): void |
| `periodInterestRate` | `?float` | Optional | (Checking/Savings/CD/MoneyMarket) The APY for the current period interest rate | getPeriodInterestRate(): ?float | setPeriodInterestRate(?float periodInterestRate): void |
| `periodDepositAmount` | `?float` | Optional | (Checking/Savings/CD/MoneyMarket) Amount deposited in period | getPeriodDepositAmount(): ?float | setPeriodDepositAmount(?float periodDepositAmount): void |
| `periodInterestAmount` | `?float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued during the current period | getPeriodInterestAmount(): ?float | setPeriodInterestAmount(?float periodInterestAmount): void |
| `interestYtdAmount` | `?float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued year-to-date | getInterestYtdAmount(): ?float | setInterestYtdAmount(?float interestYtdAmount): void |
| `interestPriorYtdAmount` | `?float` | Optional | (Checking/Savings/CD/MoneyMarket) Interest earned in prior year | getInterestPriorYtdAmount(): ?float | setInterestPriorYtdAmount(?float interestPriorYtdAmount): void |
| `maturityDate` | `?int` | Optional | (Checking/Savings/CD/MoneyMarket) Maturity date of account type. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getMaturityDate(): ?int | setMaturityDate(?int maturityDate): void |
| `interestRate` | `?string` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The account's current interest rate | getInterestRate(): ?string | setInterestRate(?string interestRate): void |
| `creditAvailableAmount` | `?float` | Optional | (Credit Card/Line Of Credit) The available credit (typically the credit limit minus the current balance) | getCreditAvailableAmount(): ?float | setCreditAvailableAmount(?float creditAvailableAmount): void |
| `creditMaxAmount` | `?float` | Optional | (Credit Card/Line Of Credit) The account's credit limit | getCreditMaxAmount(): ?float | setCreditMaxAmount(?float creditMaxAmount): void |
| `cashAdvanceAvailableAmount` | `?float` | Optional | (Credit Card/Line Of Credit) Currently available cash advance | getCashAdvanceAvailableAmount(): ?float | setCashAdvanceAvailableAmount(?float cashAdvanceAvailableAmount): void |
| `cashAdvanceMaxAmount` | `?float` | Optional | (Credit Card/Line Of Credit) Maximum cash advance amount | getCashAdvanceMaxAmount(): ?float | setCashAdvanceMaxAmount(?float cashAdvanceMaxAmount): void |
| `cashAdvanceBalance` | `?float` | Optional | (Credit Card/Line Of Credit) Balance of current cash advance | getCashAdvanceBalance(): ?float | setCashAdvanceBalance(?float cashAdvanceBalance): void |
| `cashAdvanceInterestRate` | `?float` | Optional | (Credit Card/Line Of Credit) Interest rate for cash advances | getCashAdvanceInterestRate(): ?float | setCashAdvanceInterestRate(?float cashAdvanceInterestRate): void |
| `currentBalance` | `?float` | Optional | (Credit Card/Line Of Credit) and (Investment) Current balance | getCurrentBalance(): ?float | setCurrentBalance(?float currentBalance): void |
| `paymentMinAmount` | `?float` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) Minimum payment due | getPaymentMinAmount(): ?float | setPaymentMinAmount(?float paymentMinAmount): void |
| `paymentDueDate` | `?int` | Optional | (Credit Card/Line Of Credit) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getPaymentDueDate(): ?int | setPaymentDueDate(?int paymentDueDate): void |
| `previousBalance` | `?float` | Optional | (Credit Card/Line Of Credit) Prior balance in last statement | getPreviousBalance(): ?float | setPreviousBalance(?float previousBalance): void |
| `statementStartDate` | `?int` | Optional | (Credit Card/Line Of Credit) Start date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getStatementStartDate(): ?int | setStatementStartDate(?int statementStartDate): void |
| `statementEndDate` | `?int` | Optional | (Credit Card/Line Of Credit) End date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getStatementEndDate(): ?int | setStatementEndDate(?int statementEndDate): void |
| `statementPurchaseAmount` | `?float` | Optional | (Credit Card/Line Of Credit) Purchase amount of statement period | getStatementPurchaseAmount(): ?float | setStatementPurchaseAmount(?float statementPurchaseAmount): void |
| `statementFinanceAmount` | `?float` | Optional | (Credit Card/Line Of Credit) Finance amount of statement period | getStatementFinanceAmount(): ?float | setStatementFinanceAmount(?float statementFinanceAmount): void |
| `statementCreditAmount` | `?float` | Optional | (Credit Card/Line Of Credit) Credit amount applied in statement period | getStatementCreditAmount(): ?float | setStatementCreditAmount(?float statementCreditAmount): void |
| `rewardEarnedBalance` | `?int` | Optional | (Credit Card/Line Of Credit) Earned reward balance | getRewardEarnedBalance(): ?int | setRewardEarnedBalance(?int rewardEarnedBalance): void |
| `pastDueAmount` | `?float` | Optional | (Credit Card/Line Of Credit) Balance past due | getPastDueAmount(): ?float | setPastDueAmount(?float pastDueAmount): void |
| `lastPaymentAmount` | `?float` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The amount received in the last payment | getLastPaymentAmount(): ?float | setLastPaymentAmount(?float lastPaymentAmount): void |
| `lastPaymentDate` | `?int` | Optional | (Credit Card/Line Of Credit) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLastPaymentDate(): ?int | setLastPaymentDate(?int lastPaymentDate): void |
| `statementCloseBalance` | `?float` | Optional | (Credit Card/Line Of Credit) Balance of statement at close | getStatementCloseBalance(): ?float | setStatementCloseBalance(?float statementCloseBalance): void |
| `termOfMl` | `?string` | Optional | (Mortgage/Loan) Length of loan in months | getTermOfMl(): ?string | setTermOfMl(?string termOfMl): void |
| `mlHolderName` | `?string` | Optional | (Mortgage/Loan) Holder of the mortgage or loan | getMlHolderName(): ?string | setMlHolderName(?string mlHolderName): void |
| `description` | `?string` | Optional | (Mortgage/Loan) Description of loan | getDescription(): ?string | setDescription(?string description): void |
| `lateFeeAmount` | `?float` | Optional | (Mortgage/Loan) Late fee charged | getLateFeeAmount(): ?float | setLateFeeAmount(?float lateFeeAmount): void |
| `payoffAmount` | `?float` | Optional | (Mortgage/Loan) The amount required to payoff the loan | getPayoffAmount(): ?float | setPayoffAmount(?float payoffAmount): void |
| `payoffAmountDate` | `?int` | Optional | (Mortgage/Loan) Date of final payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getPayoffAmountDate(): ?int | setPayoffAmountDate(?int payoffAmountDate): void |
| `originalMaturityDate` | `?int` | Optional | (Mortgage/Loan) Original date of loan maturity. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getOriginalMaturityDate(): ?int | setOriginalMaturityDate(?int originalMaturityDate): void |
| `principalBalance` | `?float` | Optional | (Mortgage/Loan) The principal balance | getPrincipalBalance(): ?float | setPrincipalBalance(?float principalBalance): void |
| `escrowBalance` | `?float` | Optional | (Mortgage/Loan) The escrow balance | getEscrowBalance(): ?float | setEscrowBalance(?float escrowBalance): void |
| `interestPeriod` | `?string` | Optional | (Mortgage/Loan) Period of interest | getInterestPeriod(): ?string | setInterestPeriod(?string interestPeriod): void |
| `initialMlAmount` | `?float` | Optional | (Mortgage/Loan) Original loan amount | getInitialMlAmount(): ?float | setInitialMlAmount(?float initialMlAmount): void |
| `initialMlDate` | `?int` | Optional | (Mortgage/Loan) Original date of loan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getInitialMlDate(): ?int | setInitialMlDate(?int initialMlDate): void |
| `nextPaymentPrincipalAmount` | `?float` | Optional | (Mortgage/Loan) Amount towards principal in next payment | getNextPaymentPrincipalAmount(): ?float | setNextPaymentPrincipalAmount(?float nextPaymentPrincipalAmount): void |
| `nextPaymentInterestAmount` | `?float` | Optional | (Mortgage/Loan) Amount of interest in next payment | getNextPaymentInterestAmount(): ?float | setNextPaymentInterestAmount(?float nextPaymentInterestAmount): void |
| `nextPayment` | `?float` | Optional | (Mortgage/Loan) Minimum payment due | getNextPayment(): ?float | setNextPayment(?float nextPayment): void |
| `nextPaymentDate` | `?int` | Optional | (Mortgage/Loan) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getNextPaymentDate(): ?int | setNextPaymentDate(?int nextPaymentDate): void |
| `lastPaymentDueDate` | `?int` | Optional | (Mortgage/Loan) Due date of last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLastPaymentDueDate(): ?int | setLastPaymentDueDate(?int lastPaymentDueDate): void |
| `lastPaymentReceiveDate` | `?int` | Optional | (Mortgage/Loan) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLastPaymentReceiveDate(): ?int | setLastPaymentReceiveDate(?int lastPaymentReceiveDate): void |
| `lastPaymentPrincipalAmount` | `?float` | Optional | (Mortgage/Loan) Amount towards principal in last payment | getLastPaymentPrincipalAmount(): ?float | setLastPaymentPrincipalAmount(?float lastPaymentPrincipalAmount): void |
| `lastPaymentInterestAmount` | `?float` | Optional | (Mortgage/Loan) Amount of interest in last payment | getLastPaymentInterestAmount(): ?float | setLastPaymentInterestAmount(?float lastPaymentInterestAmount): void |
| `lastPaymentEscrowAmount` | `?float` | Optional | (Mortgage/Loan) Amount towards escrow in last payment | getLastPaymentEscrowAmount(): ?float | setLastPaymentEscrowAmount(?float lastPaymentEscrowAmount): void |
| `lastPaymentLastFeeAmount` | `?float` | Optional | (Mortgage/Loan) Amount of last fee in last payment | getLastPaymentLastFeeAmount(): ?float | setLastPaymentLastFeeAmount(?float lastPaymentLastFeeAmount): void |
| `lastPaymentLateCharge` | `?float` | Optional | (Mortgage/Loan) Amount of late charge in last payment | getLastPaymentLateCharge(): ?float | setLastPaymentLateCharge(?float lastPaymentLateCharge): void |
| `ytdPrincipalPaid` | `?float` | Optional | (Mortgage/Loan) Principal paid year-to-date | getYtdPrincipalPaid(): ?float | setYtdPrincipalPaid(?float ytdPrincipalPaid): void |
| `ytdInterestPaid` | `?float` | Optional | (Mortgage/Loan) Interest paid year-to-date | getYtdInterestPaid(): ?float | setYtdInterestPaid(?float ytdInterestPaid): void |
| `ytdInsurancePaid` | `?float` | Optional | (Mortgage/Loan) Insurance paid year-to-date | getYtdInsurancePaid(): ?float | setYtdInsurancePaid(?float ytdInsurancePaid): void |
| `ytdTaxPaid` | `?float` | Optional | (Mortgage/Loan) Tax paid year-to-date | getYtdTaxPaid(): ?float | setYtdTaxPaid(?float ytdTaxPaid): void |
| `autoPayEnrolled` | `?bool` | Optional | (Mortgage/Loan) Enrolled in autopay (F/Y) | getAutoPayEnrolled(): ?bool | setAutoPayEnrolled(?bool autoPayEnrolled): void |
| `collateral` | `?string` | Optional | (Mortgage/Loan) Collateral on loan | getCollateral(): ?string | setCollateral(?string collateral): void |
| `currentSchool` | `?string` | Optional | (Mortgage/Loan) Current school | getCurrentSchool(): ?string | setCurrentSchool(?string currentSchool): void |
| `firstPaymentDate` | `?int` | Optional | (Mortgage/Loan) First payment due date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getFirstPaymentDate(): ?int | setFirstPaymentDate(?int firstPaymentDate): void |
| `firstMortgage` | `?bool` | Optional | (Mortgage/Loan) First mortgage (F/Y) | getFirstMortgage(): ?bool | setFirstMortgage(?bool firstMortgage): void |
| `loanPaymentFreq` | `?string` | Optional | (Mortgage/Loan) Frequency of payments (monthly, etc.) | getLoanPaymentFreq(): ?string | setLoanPaymentFreq(?string loanPaymentFreq): void |
| `originalSchool` | `?string` | Optional | (Mortgage/Loan) Original school | getOriginalSchool(): ?string | setOriginalSchool(?string originalSchool): void |
| `recurringPaymentAmount` | `?float` | Optional | (Mortgage/Loan) Recurring payment amount | getRecurringPaymentAmount(): ?float | setRecurringPaymentAmount(?float recurringPaymentAmount): void |
| `lender` | `?string` | Optional | (Mortgage/Loan) Owner of loan | getLender(): ?string | setLender(?string lender): void |
| `endingBalanceAmount` | `?float` | Optional | (Mortgage/Loan) Ending balance | getEndingBalanceAmount(): ?float | setEndingBalanceAmount(?float endingBalanceAmount): void |
| `loanTermType` | `?string` | Optional | (Mortgage/Loan) Type of loan term | getLoanTermType(): ?string | setLoanTermType(?string loanTermType): void |
| `paymentsMade` | `?int` | Optional | (Mortgage/Loan) Number of payments made | getPaymentsMade(): ?int | setPaymentsMade(?int paymentsMade): void |
| `balloonAmount` | `?float` | Optional | (Mortgage/Loan) Balloon payment amount | getBalloonAmount(): ?float | setBalloonAmount(?float balloonAmount): void |
| `projectedInterest` | `?float` | Optional | (Mortgage/Loan) Projected interest on the loan | getProjectedInterest(): ?float | setProjectedInterest(?float projectedInterest): void |
| `interestPaidLtd` | `?float` | Optional | (Mortgage/Loan) Interest paid since inception of loan (life to date) | getInterestPaidLtd(): ?float | setInterestPaidLtd(?float interestPaidLtd): void |
| `interestRateType` | `?string` | Optional | (Mortgage/Loan) Type of interest rate | getInterestRateType(): ?string | setInterestRateType(?string interestRateType): void |
| `loanPaymentType` | `?string` | Optional | (Mortgage/Loan) Type of loan payment | getLoanPaymentType(): ?string | setLoanPaymentType(?string loanPaymentType): void |
| `repaymentPlan` | `?string` | Optional | (Mortgage/Loan) Type of repayment plan for the student loan | getRepaymentPlan(): ?string | setRepaymentPlan(?string repaymentPlan): void |
| `paymentsRemaining` | `?int` | Optional | (Mortgage/Loan) Number of payments remaining before loan is paid off | getPaymentsRemaining(): ?int | setPaymentsRemaining(?int paymentsRemaining): void |
| `marginBalance` | `?float` | Optional | (Investment) Net interest earned after deducting interest paid out | getMarginBalance(): ?float | setMarginBalance(?float marginBalance): void |
| `shortBalance` | `?float` | Optional | (Investment) Sum of short balance | getShortBalance(): ?float | setShortBalance(?float shortBalance): void |
| `availableCashBalance` | `?float` | Optional | (Investment) Amount available for cash withdrawal | getAvailableCashBalance(): ?float | setAvailableCashBalance(?float availableCashBalance): void |
| `maturityValueAmount` | `?float` | Optional | (Investment) amount payable to an investor at maturity | getMaturityValueAmount(): ?float | setMaturityValueAmount(?float maturityValueAmount): void |
| `vestedBalance` | `?float` | Optional | (Investment) Vested amount in account | getVestedBalance(): ?float | setVestedBalance(?float vestedBalance): void |
| `empMatchAmount` | `?float` | Optional | (Investment) Employer matched contributions | getEmpMatchAmount(): ?float | setEmpMatchAmount(?float empMatchAmount): void |
| `empPretaxContribAmount` | `?float` | Optional | (Investment) Employer pretax contribution amount | getEmpPretaxContribAmount(): ?float | setEmpPretaxContribAmount(?float empPretaxContribAmount): void |
| `empPretaxContribAmountYtd` | `?float` | Optional | (Investment) Employer pretax contribution amount year to date | getEmpPretaxContribAmountYtd(): ?float | setEmpPretaxContribAmountYtd(?float empPretaxContribAmountYtd): void |
| `contribTotalYtd` | `?float` | Optional | (Investment) Total year to date contributions | getContribTotalYtd(): ?float | setContribTotalYtd(?float contribTotalYtd): void |
| `cashBalanceAmount` | `?float` | Optional | (Investment) Cash balance of account | getCashBalanceAmount(): ?float | setCashBalanceAmount(?float cashBalanceAmount): void |
| `preTaxAmount` | `?float` | Optional | (Investment) Pre tax amount of total balance | getPreTaxAmount(): ?float | setPreTaxAmount(?float preTaxAmount): void |
| `afterTaxAmount` | `?float` | Optional | (Investment) Post tax amount of total balance | getAfterTaxAmount(): ?float | setAfterTaxAmount(?float afterTaxAmount): void |
| `matchAmount` | `?float` | Optional | (Investment) Amount matched | getMatchAmount(): ?float | setMatchAmount(?float matchAmount): void |
| `profitSharingAmount` | `?float` | Optional | (Investment) Amount of balance for profit sharing | getProfitSharingAmount(): ?float | setProfitSharingAmount(?float profitSharingAmount): void |
| `rolloverAmount` | `?float` | Optional | (Investment) Amount of balance rolled over from original account (401k, etc.) | getRolloverAmount(): ?float | setRolloverAmount(?float rolloverAmount): void |
| `otherVestAmount` | `?float` | Optional | (Investment) Other vested amount | getOtherVestAmount(): ?float | setOtherVestAmount(?float otherVestAmount): void |
| `otherNonvestAmount` | `?float` | Optional | (Investment) Other nonvested amount | getOtherNonvestAmount(): ?float | setOtherNonvestAmount(?float otherNonvestAmount): void |
| `currentLoanBalance` | `?float` | Optional | (Investment) Current loan balance | getCurrentLoanBalance(): ?float | setCurrentLoanBalance(?float currentLoanBalance): void |
| `loanRate` | `?float` | Optional | (Investment) Interest rate of loan | getLoanRate(): ?float | setLoanRate(?float loanRate): void |
| `buyPower` | `?float` | Optional | (Investment) Money available to buy securities | getBuyPower(): ?float | setBuyPower(?float buyPower): void |
| `rolloverLtd` | `?float` | Optional | (Investment) Life to date of money rolled over | getRolloverLtd(): ?float | setRolloverLtd(?float rolloverLtd): void |
| `loanAwardId` | `?string` | Optional | (Student Loan) The federal unique loan identifying number | getLoanAwardId(): ?string | setLoanAwardId(?string loanAwardId): void |
| `originalInterestRate` | `?float` | Optional | (Student Loan) The original interest rate to which the loan was disbursed, in APY | getOriginalInterestRate(): ?float | setOriginalInterestRate(?float originalInterestRate): void |
| `guarantor` | `?string` | Optional | (Student Loan) The financial institution guarantor of the loan (who will pay the loan amount to the owner if the borrower defaults) | getGuarantor(): ?string | setGuarantor(?string guarantor): void |
| `owner` | `?string` | Optional | (Student Loan) Owner of the loan | getOwner(): ?string | setOwner(?string owner): void |
| `interestSubsidyType` | `?string` | Optional | (Student Loan) The indication of the presence of an interest subsidy (i.e. subsidized) | getInterestSubsidyType(): ?string | setInterestSubsidyType(?string interestSubsidyType): void |
| `interestBalance` | `?float` | Optional | (Student Loan) The total outstanding interest balance | getInterestBalance(): ?float | setInterestBalance(?float interestBalance): void |
| `remainingTermOfMl` | `?float` | Optional | (Student Loan) The number of months still outstanding on a loan | getRemainingTermOfMl(): ?float | setRemainingTermOfMl(?float remainingTermOfMl): void |
| `initialInterestRate` | `?float` | Optional | (Student Loan) Initial interest rate of loan | getInitialInterestRate(): ?float | setInitialInterestRate(?float initialInterestRate): void |
| `feesBalance` | `?float` | Optional | (Student Loan) The total outstanding fees balance | getFeesBalance(): ?float | setFeesBalance(?float feesBalance): void |
| `loanYtdInterestPaid` | `?float` | Optional | (Student Loan) Loan interest paid year-to-date | getLoanYtdInterestPaid(): ?float | setLoanYtdInterestPaid(?float loanYtdInterestPaid): void |
| `loanYtdFeesPaid` | `?float` | Optional | (Student Loan) Loan fees paid year-to-date | getLoanYtdFeesPaid(): ?float | setLoanYtdFeesPaid(?float loanYtdFeesPaid): void |
| `loanYtdPrincipalPaid` | `?float` | Optional | (Student Loan) Loan principal paid year-to-date | getLoanYtdPrincipalPaid(): ?float | setLoanYtdPrincipalPaid(?float loanYtdPrincipalPaid): void |
| `loanStatus` | `?string` | Optional | (Student Loan) The repayment status phase (i.e. In School, Grace, Repayment, Deferment, Forbearance) | getLoanStatus(): ?string | setLoanStatus(?string loanStatus): void |
| `loanStatusStartDate` | `?int` | Optional | (Student Loan) The start date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLoanStatusStartDate(): ?int | setLoanStatusStartDate(?int loanStatusStartDate): void |
| `loanStatusEndDate` | `?int` | Optional | (Student Loan) The end date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getLoanStatusEndDate(): ?int | setLoanStatusEndDate(?int loanStatusEndDate): void |
| `weightedInterestRate` | `?float` | Optional | (Student Loan) The interest rate of multiple interest rates and balances at the group level, in APY | getWeightedInterestRate(): ?float | setWeightedInterestRate(?float weightedInterestRate): void |
| `repaymentPlanStartDate` | `?int` | Optional | (Student Loan) The start date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getRepaymentPlanStartDate(): ?int | setRepaymentPlanStartDate(?int repaymentPlanStartDate): void |
| `repaymentPlanEndDate` | `?int` | Optional | (Student Loan) The end date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getRepaymentPlanEndDate(): ?int | setRepaymentPlanEndDate(?int repaymentPlanEndDate): void |
| `expectedPayoffDate` | `?int` | Optional | (Student Loan) The expected date of the payoff date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getExpectedPayoffDate(): ?int | setExpectedPayoffDate(?int expectedPayoffDate): void |
| `outOfSchoolDate` | `?int` | Optional | (Student Loan) The date the borrower graduated or dropped below half-time enrollment in school. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getOutOfSchoolDate(): ?int | setOutOfSchoolDate(?int outOfSchoolDate): void |
| `convertToRepayment` | `?int` | Optional | (Student Loan) The date the loan enters into repayment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). | getConvertToRepayment(): ?int | setConvertToRepayment(?int convertToRepayment): void |
| `daysDelinquent` | `?int` | Optional | (Student Loan) The number of days past a due date that a payment should have been made | getDaysDelinquent(): ?int | setDaysDelinquent(?int daysDelinquent): void |
| `totalPrincipalPaid` | `?float` | Optional | (Student Loan) The total amount paid towards the principal balance | getTotalPrincipalPaid(): ?float | setTotalPrincipalPaid(?float totalPrincipalPaid): void |
| `totalInterestPaid` | `?float` | Optional | (Student Loan) The total amount paid towards interest | getTotalInterestPaid(): ?float | setTotalInterestPaid(?float totalInterestPaid): void |
| `totalAmountPaid` | `?float` | Optional | (Student Loan) The total amount paid | getTotalAmountPaid(): ?float | setTotalAmountPaid(?float totalAmountPaid): void |

## Example (as JSON)

```json
{
  "availableBalanceAmount": 5678.78
}
```

