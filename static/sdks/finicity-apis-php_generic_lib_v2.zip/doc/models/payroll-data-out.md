
# Payroll Data Out

## Structure

`PayrollDataOut`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payrollDataRetrievalId` | `string` | Required | An id to identify the data retrieved from the payroll providers for the report. | getPayrollDataRetrievalId(): string | setPayrollDataRetrievalId(string payrollDataRetrievalId): void |
| `employerNames` | `string[]` | Required | An array of employer names that the consumer submitted after completing the Connect application. | getEmployerNames(): array | setEmployerNames(array employerNames): void |
| `reportId` | `?string` | Optional | A report ID | getReportId(): ?string | setReportId(?string reportId): void |

## Example (as JSON)

```json
{
  "payrollDataRetrievalId": "hahvhe2k0000",
  "employerNames": null
}
```

