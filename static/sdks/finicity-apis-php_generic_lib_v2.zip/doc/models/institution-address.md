
# Institution Address

The address of a financial institution

## Structure

`InstitutionAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `city` | `?string` | Optional | A city | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | A state | getState(): ?string | setState(?string state): void |
| `country` | `?string` | Optional | A country code | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | A ZIP code | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `addressLine1` | `?string` | Optional | An address line 1 | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | An address line 2 | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |

## Example (as JSON)

```json
{
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "addressLine1": null,
  "addressLine2": null
}
```

