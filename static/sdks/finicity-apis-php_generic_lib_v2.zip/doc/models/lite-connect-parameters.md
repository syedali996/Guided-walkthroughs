
# Lite Connect Parameters

## Structure

`LiteConnectParameters`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `language` | `?string` | Optional | Generate a translated Connect URL link.<br><br>Supported languages:<br><br>* English (default)<br>* Spanish (United States): `es`<br>* French (Canada): `fr` or `fr-CA` | getLanguage(): ?string | setLanguage(?string language): void |
| `partnerId` | `string` | Required | Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin) | getPartnerId(): string | setPartnerId(string partnerId): void |
| `customerId` | `string` | Required | A customer ID. See Add Customer API for how to create a customer ID. | getCustomerId(): string | setCustomerId(string customerId): void |
| `institutionId` | `int` | Required | The ID of a financial institution, represented as a number | getInstitutionId(): int | setInstitutionId(int institutionId): void |
| `redirectUri` | `?string` | Optional | The URL that customers will be redirected to after completing Finicity Connect. Required unless Connect is embedded inside our application (iframe). | getRedirectUri(): ?string | setRedirectUri(?string redirectUri): void |
| `webhook` | `?string` | Optional | The publicly available URL you want to be notified with events as the user progresses through the application. See [Connect Webhook Event](https://docs.finicity.com/connect-and-mvs-webhooks/) for event details. | getWebhook(): ?string | setWebhook(?string webhook): void |
| `webhookContentType` | `?string` | Optional | The content type the webhook events will be sent in. Supported types: "application/json" and "application/xml".<br>**Default**: `'application/json'` | getWebhookContentType(): ?string | setWebhookContentType(?string webhookContentType): void |
| `webhookData` | `?array` | Optional | Allows additional identifiable information to be inserted into the payload of connect webhook events. See: [Custom Webhooks](https://docs.finicity.com/custom-webhooks/). | getWebhookData(): ?array | setWebhookData(?array webhookData): void |
| `webhookHeaders` | `?array` | Optional | Allows additional identifiable information to be included as headers of connect webhook event. See: [Custom Webhooks](https://docs.finicity.com/custom-webhooks/). | getWebhookHeaders(): ?array | setWebhookHeaders(?array webhookHeaders): void |
| `experience` | `?string` | Optional | The `experience` field allows you to customize:<br><br>* Brand: color and logo<br>* Icon: displayed on the "Share your data" page<br>* Popular institutions: displayed on the Bank Search page<br>* Report: the credit decisioning report to send when Connect completes.<br>* MVS modules: financial, payroll, paystub<br><br>Note: the Finicity sales engineers (SE) help you set up a default experience for your company when you migrate to Connect 2.0. For each additional experience you create thereafter, they'll give you a unique ID. See [Generate 2.0 Connect URL APIs](https://docs.finicity.com/migrate-to-connect-web-sdk-2-0/#migrate-connect-web-sdk-1).<br><br>Experience values options:<br><br>* "default": your default experience (must be defined)<br>* GUID: the code for a different experience<br>* Not defined: If you don't pass the experience parameter, then Connect's out of the box default experience (add accounts but no branding) is used, and the MVS modules will not run. | getExperience(): ?string | setExperience(?string experience): void |
| `singleUseUrl` | `?bool` | Optional | "true": The URL link expires after a Connect session successfully completes.<br><br>Note: when the `singleUseUrl` and the `experience` parameters are passed in the same call, the `singleUseUrl` value overrides the `singleUseUrl` value configured in the `experience` parameter. | getSingleUseUrl(): ?bool | setSingleUseUrl(?bool singleUseUrl): void |

## Example (as JSON)

```json
{
  "partnerId": "1234583871234",
  "customerId": "1005061234",
  "institutionId": 4222
}
```

