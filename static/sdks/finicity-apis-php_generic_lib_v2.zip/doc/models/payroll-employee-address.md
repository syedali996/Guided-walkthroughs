
# Payroll Employee Address

## Structure

`PayrollEmployeeAddress`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `address1` | `?string` | Optional | Employee address as stated by the employer in the payroll system | getAddress1(): ?string | setAddress1(?string address1): void |
| `city` | `?string` | Optional | Employee city as stated by the employer in the payroll system | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | Employee state as stated by the employer in the payroll system | getState(): ?string | setState(?string state): void |
| `zip` | `?string` | Optional | Employee zip code as stated by the employer in the payroll system | getZip(): ?string | setZip(?string zip): void |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

