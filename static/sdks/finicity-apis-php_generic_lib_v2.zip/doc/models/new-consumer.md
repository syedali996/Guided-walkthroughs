
# New Consumer

A new consumer to be created

## Structure

`NewConsumer`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `string` | Required | First name(s) / given name(s) | getFirstName(): string | setFirstName(string firstName): void |
| `lastName` | `string` | Required | Last name(s) / surname(s) | getLastName(): string | setLastName(string lastName): void |
| `address` | `string` | Required | A street address | getAddress(): string | setAddress(string address): void |
| `city` | `string` | Required | A city | getCity(): string | setCity(string city): void |
| `state` | `string` | Required | A state | getState(): string | setState(string state): void |
| `zip` | `string` | Required | A ZIP code | getZip(): string | setZip(string zip): void |
| `phone` | `string` | Required | A phone number | getPhone(): string | setPhone(string phone): void |
| `ssn` | `string` | Required | A full SSN with or without hyphens | getSsn(): string | setSsn(string ssn): void |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date | getBirthday(): Birthday | setBirthday(Birthday birthday): void |
| `email` | `?string` | Optional | An email address | getEmail(): ?string | setEmail(?string email): void |
| `suffix` | `?string` | Optional | A person suffix | getSuffix(): ?string | setSuffix(?string suffix): void |

## Example (as JSON)

```json
{
  "firstName": "John",
  "lastName": "Smith",
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "999-99-9999",
  "birthday": null
}
```

