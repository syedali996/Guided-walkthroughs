
# Customer Accounts

A list of customer accounts

## Structure

`CustomerAccounts`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accounts` | [`CustomerAccount[]`](../../doc/models/customer-account.md) | Required | List of customer accounts | getAccounts(): array | setAccounts(array accounts): void |

## Example (as JSON)

```json
{
  "accounts": {
    "id": "5011648377",
    "number": "2000004444",
    "accountNumberDisplay": "1234-9",
    "name": "Super Checking",
    "balance": 401.26,
    "type": "checking",
    "status": "active",
    "customerId": "1005061234",
    "institutionId": "4222",
    "balanceDate": 1607450357,
    "createdDate": 1607450357,
    "currency": "USD",
    "oldestTransactionDate": 1607450357,
    "institutionLoginId": 1007302745
  }
}
```

