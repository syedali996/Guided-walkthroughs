
# VOE Transactions Report Account

## Structure

`VOETransactionsReportAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the account | getId(): ?int | setId(?int id): void |
| `number` | `?string` | Optional | The account number from the institution (all digits except the last four are obfuscated) | getNumber(): ?string | setNumber(?string number): void |
| `ownerName` | `?string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | getOwnerName(): ?string | setOwnerName(?string ownerName): void |
| `ownerAddress` | `?string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. | getOwnerAddress(): ?string | setOwnerAddress(?string ownerAddress): void |
| `name` | `?string` | Optional | The account name from the institution | getName(): ?string | setName(?string name): void |
| `type` | `?string` | Optional | One of the values from account types | getType(): ?string | setType(?string type): void |
| `aggregationStatusCode` | `?int` | Optional | The status of the most recent aggregation attempt | getAggregationStatusCode(): ?int | setAggregationStatusCode(?int aggregationStatusCode): void |
| `incomeStreams` | [`?(VOETransactionsReportIncomeStream[])`](../../doc/models/voe-transactions-report-income-stream.md) | Optional | A list of income stream records | getIncomeStreams(): ?array | setIncomeStreams(?array incomeStreams): void |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null
}
```

