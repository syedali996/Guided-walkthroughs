
# Cash Flow Cash Flow Characteristics Summary

## Structure

`CashFlowCashFlowCharacteristicsSummary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyCashFlowCharacteristicSummaries` | [`CashFlowMonthlyCashFlowCharacteristicSummaries[]`](../../doc/models/cash-flow-monthly-cash-flow-characteristic-summaries.md) | Required | List of attributes for each month | getMonthlyCashFlowCharacteristicSummaries(): array | setMonthlyCashFlowCharacteristicSummaries(array monthlyCashFlowCharacteristicSummaries): void |
| `averageMonthlyNet` | `float` | Required | Average monthly net amount | getAverageMonthlyNet(): float | setAverageMonthlyNet(float averageMonthlyNet): void |
| `averageMonthlyNetLessTransfers` | `float` | Required | Average monthly net less transfers | getAverageMonthlyNetLessTransfers(): float | setAverageMonthlyNetLessTransfers(float averageMonthlyNetLessTransfers): void |
| `twelveMonthTotalNet` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) each month by the account | getTwelveMonthTotalNet(): float | setTwelveMonthTotalNet(float twelveMonthTotalNet): void |
| `twelveMonthTotalNetLessTransfers` | `float` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers by the account | getTwelveMonthTotalNetLessTransfers(): float | setTwelveMonthTotalNetLessTransfers(float twelveMonthTotalNetLessTransfers): void |
| `sixMonthAverageTotalCreditsLessTotalDebits` | `float` | Required | 6 Month Average (Total Credits - Total Debits) across all accounts | getSixMonthAverageTotalCreditsLessTotalDebits(): float | setSixMonthAverageTotalCreditsLessTotalDebits(float sixMonthAverageTotalCreditsLessTotalDebits): void |
| `sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `float` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts | getSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers(): float | setSixMonthAverageTotalCreditsLessTotalDebitsLessTransfers(float sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers): void |
| `twoMonthAverageTotalCreditsLessTotalDebits` | `float` | Required | 2 Month Average (Total Credits - Total Debits) across all accounts | getTwoMonthAverageTotalCreditsLessTotalDebits(): float | setTwoMonthAverageTotalCreditsLessTotalDebits(float twoMonthAverageTotalCreditsLessTotalDebits): void |
| `twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `float` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts | getTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers(): float | setTwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers(float twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers): void |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristicSummaries": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 1250,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

