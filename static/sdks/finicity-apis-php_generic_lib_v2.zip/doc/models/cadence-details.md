
# Cadence Details

## Structure

`CadenceDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `startDate` | `?int` | Optional | `postedDate` of the first deposit transaction | getStartDate(): ?int | setStartDate(?int startDate): void |
| `stopDate` | `?int` | Optional | `postedDate` of the final deposit transaction (omitted if status is active) | getStopDate(): ?int | setStopDate(?int stopDate): void |
| `days` | `?int` | Optional | Number of days between the recurring deposits | getDays(): ?int | setDays(?int days): void |

## Example (as JSON)

```json
{
  "startDate": null,
  "stopDate": null,
  "days": null
}
```

