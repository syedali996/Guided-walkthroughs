
# Report Custom Field

## Structure

`ReportCustomField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `label` | `?string` | Optional | The name of the custom field | getLabel(): ?string | setLabel(?string label): void |
| `value` | `?string` | Optional | The value of the custom field | getValue(): ?string | setValue(?string value): void |
| `shown` | `?bool` | Optional | If the custom field will show on the PDF or not | getShown(): ?bool | setShown(?bool shown): void |

## Example (as JSON)

```json
{
  "label": null,
  "value": null,
  "shown": null
}
```

