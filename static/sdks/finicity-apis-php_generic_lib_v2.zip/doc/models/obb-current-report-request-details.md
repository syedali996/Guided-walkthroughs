
# Obb Current Report Request Details

## Structure

`ObbCurrentReportRequestDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reportBeginDate` | `string` | Required | Date from when the requested data is available<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getReportBeginDate(): string | setReportBeginDate(string reportBeginDate): void |
| `reportEndDate` | `string` | Required | Date to which the requested data is available<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getReportEndDate(): string | setReportEndDate(string reportEndDate): void |
| `reportRequestDate` | `string` | Required | The date and time the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getReportRequestDate(): string | setReportRequestDate(string reportRequestDate): void |
| `requestedDaysForReport` | `int` | Required | Number of days requested for the report | getRequestedDaysForReport(): int | setRequestedDaysForReport(int requestedDaysForReport): void |
| `requestedReportBeginDate` | `string` | Required | Date the report would have began on if enough data was available for which the partner requested<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` | getRequestedReportBeginDate(): string | setRequestedReportBeginDate(string requestedReportBeginDate): void |

## Example (as JSON)

```json
{
  "reportBeginDate": "2022-03-01",
  "reportEndDate": "2022-03-30",
  "reportRequestDate": "03/30/2022 21:47:19",
  "requestedDaysForReport": 90,
  "requestedReportBeginDate": "2022-01-01"
}
```

