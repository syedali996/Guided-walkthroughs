
# Consumer Attributes Data Liabilities

## Structure

`ConsumerAttributesDataLiabilities`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `monthlyLoanDeposits` | `array` | Required | Monthly loan deposits amount by account | getMonthlyLoanDeposits(): array | setMonthlyLoanDeposits(array monthlyLoanDeposits): void |
| `monthlyLoanWitdrawls` | `array` | Required | Monthly loan withdrawal amount by account | getMonthlyLoanWitdrawls(): array | setMonthlyLoanWitdrawls(array monthlyLoanWitdrawls): void |
| `monthlyNumberOfLoanDeposits` | `array` | Required | Monthly count of the number of loan deposits by account | getMonthlyNumberOfLoanDeposits(): array | setMonthlyNumberOfLoanDeposits(array monthlyNumberOfLoanDeposits): void |
| `monthlyNumberOfLoanWithdrawls` | `array` | Required | Monthly amount of the number of loan deposits by account | getMonthlyNumberOfLoanWithdrawls(): array | setMonthlyNumberOfLoanWithdrawls(array monthlyNumberOfLoanWithdrawls): void |

## Example (as JSON)

```json
{
  "monthlyLoanDeposits": {
    "3-2021": 2799.08,
    "4-2021": 2947.63,
    "5-2021": 2863.37
  },
  "monthlyLoanWitdrawls": {
    "3-2021": -150.17,
    "4-2021": -95.03,
    "5-2021": -341.26
  },
  "monthlyNumberOfLoanDeposits": {
    "3-2021": 1,
    "4-2021": 1,
    "5-2021": 1
  },
  "monthlyNumberOfLoanWithdrawls": {
    "3-2021": 1,
    "4-2021": 1,
    "5-2021": 1
  }
}
```

