
# VOIE With Interview Data

## Structure

`VOIEWithInterviewData`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `txVerifyInterview` | [`TxVerifyInterview[]`](../../doc/models/tx-verify-interview.md) | Required | An array of `TxVerifyInterview` objects | getTxVerifyInterview(): array | setTxVerifyInterview(array txVerifyInterview): void |
| `extractEarnings` | `?bool` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `true` | getExtractEarnings(): ?bool | setExtractEarnings(?bool extractEarnings): void |
| `extractDeductions` | `?bool` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `false` | getExtractDeductions(): ?bool | setExtractDeductions(?bool extractDeductions): void |
| `extractDirectDeposit` | `?bool` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `true` | getExtractDirectDeposit(): ?bool | setExtractDirectDeposit(?bool extractDirectDeposit): void |

## Example (as JSON)

```json
{
  "txVerifyInterview": {
    "assetId": "097545c5-1c2a-4f20-a5ef-77f0820344c9-2018601178"
  }
}
```

