
# Paystub Monthly Income Record

## Structure

`PaystubMonthlyIncomeRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `estimatedMonthlyBasePay` | `?float` | Optional | The estimated monthly base pay amount for the employment from the paystub, calculated by Finicity | getEstimatedMonthlyBasePay(): ?float | setEstimatedMonthlyBasePay(?float estimatedMonthlyBasePay): void |
| `estimatedMonthlyOvertimePay` | `?float` | Optional | The estimated monthly overtime pay amount for the employment from the paystub, calculated by Finicity | getEstimatedMonthlyOvertimePay(): ?float | setEstimatedMonthlyOvertimePay(?float estimatedMonthlyOvertimePay): void |
| `estimatedMonthlyBonusPay` | `?float` | Optional | The estimated monthly bonus pay amount for the employment from the paystub, calculated by Finicity | getEstimatedMonthlyBonusPay(): ?float | setEstimatedMonthlyBonusPay(?float estimatedMonthlyBonusPay): void |
| `estimatedMonthlyCommissionPay` | `?float` | Optional | The estimated commission bonus pay amount for the employment from the paystub, calculated by Finicity | getEstimatedMonthlyCommissionPay(): ?float | setEstimatedMonthlyCommissionPay(?float estimatedMonthlyCommissionPay): void |

## Example (as JSON)

```json
{
  "estimatedMonthlyBasePay": null,
  "estimatedMonthlyOvertimePay": null,
  "estimatedMonthlyBonusPay": null,
  "estimatedMonthlyCommissionPay": null
}
```

