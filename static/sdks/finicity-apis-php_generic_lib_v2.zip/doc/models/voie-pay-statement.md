
# VOIE Pay Statement

## Structure

`VOIEPayStatement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `payPeriod` | `?string` | Optional | The pay period of the pay statement | getPayPeriod(): ?string | setPayPeriod(?string payPeriod): void |
| `billable` | `?bool` | Optional | Designates whether the pay statement is billable | getBillable(): ?bool | setBillable(?bool billable): void |
| `assetId` | `?string` | Optional | The asset ID of the stored pay statement | getAssetId(): ?string | setAssetId(?string assetId): void |
| `payDate` | `?int` | Optional | The listed pay date for the pay statement | getPayDate(): ?int | setPayDate(?int payDate): void |
| `startDate` | `?int` | Optional | The beginning of the pay period | getStartDate(): ?int | setStartDate(?int startDate): void |
| `endDate` | `?int` | Optional | The end of the pay period | getEndDate(): ?int | setEndDate(?int endDate): void |
| `netPayCurrent` | `?float` | Optional | The total pay after deductions for the employee for the current pay period | getNetPayCurrent(): ?float | setNetPayCurrent(?float netPayCurrent): void |
| `netPayYTD` | `?float` | Optional | The total accumulation of pay after deductions for the employee for the current pay year | getNetPayYTD(): ?float | setNetPayYTD(?float netPayYTD): void |
| `grossPayCurrent` | `?float` | Optional | The total pay before deductions for the employee for the current pay period | getGrossPayCurrent(): ?float | setGrossPayCurrent(?float grossPayCurrent): void |
| `grossPayYTD` | `?float` | Optional | The total accumulation of pay before deductions for the employee for the current pay year | getGrossPayYTD(): ?float | setGrossPayYTD(?float grossPayYTD): void |
| `payrollProvider` | `?string` | Optional | The company that provides the pay stub. | getPayrollProvider(): ?string | setPayrollProvider(?string payrollProvider): void |
| `employer` | [`?Employer`](../../doc/models/employer.md) | Optional | - | getEmployer(): ?Employer | setEmployer(?Employer employer): void |
| `employee` | [`?Employee`](../../doc/models/employee.md) | Optional | - | getEmployee(): ?Employee | setEmployee(?Employee employee): void |
| `payStat` | [`?(PayStat[])`](../../doc/models/pay-stat.md) | Optional | Information pertaining to the earnings on the pay statement | getPayStat(): ?array | setPayStat(?array payStat): void |
| `deductions` | [`?(Deduction[])`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement | getDeductions(): ?array | setDeductions(?array deductions): void |
| `directDeposits` | [`?(DirectDeposit[])`](../../doc/models/direct-deposit.md) | Optional | Information pertaining to direct deposits on the pay statement | getDirectDeposits(): ?array | setDirectDeposits(?array directDeposits): void |

## Example (as JSON)

```json
{
  "payPeriod": null,
  "billable": null,
  "assetId": null,
  "payDate": null,
  "startDate": null,
  "endDate": null,
  "netPayCurrent": null,
  "netPayYTD": null,
  "grossPayCurrent": null,
  "grossPayYTD": null,
  "payrollProvider": null,
  "employer": null,
  "employee": null,
  "payStat": null,
  "deductions": null,
  "directDeposits": null
}
```

