
# Birthday

A birth date

## Structure

`Birthday`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `year` | `?int` | Optional | The birthday 4-digit year | getYear(): ?int | setYear(?int year): void |
| `month` | `?int` | Optional | The birthday 2-digit month (1 is January) | getMonth(): ?int | setMonth(?int month): void |
| `dayOfMonth` | `?int` | Optional | The birthday 2-digit day-of-month | getDayOfMonth(): ?int | setDayOfMonth(?int dayOfMonth): void |

## Example (as JSON)

```json
{
  "year": null,
  "month": null,
  "dayOfMonth": null
}
```

