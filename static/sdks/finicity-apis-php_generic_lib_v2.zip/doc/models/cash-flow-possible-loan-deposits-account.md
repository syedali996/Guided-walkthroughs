
# Cash Flow Possible Loan Deposits Account

## Structure

`CashFlowPossibleLoanDepositsAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Finicity account ID | getId(): string | setId(string id): void |
| `ownerName` | `string` | Required | The name(s) of the account owner(s), retrieved from the institution. | getOwnerName(): string | setOwnerName(string ownerName): void |
| `ownerAddress` | `string` | Required | The mailing address of the account owner, retrieved from the institution. | getOwnerAddress(): string | setOwnerAddress(string ownerAddress): void |
| `name` | `string` | Required | The account name from the institution | getName(): string | setName(string name): void |
| `number` | `string` | Required | The account number from the institution (obfuscated) | getNumber(): string | setNumber(string number): void |
| `type` | `string` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) | getType(): string | setType(string type): void |
| `aggregationStatusCode` | `string` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) | getAggregationStatusCode(): string | setAggregationStatusCode(string aggregationStatusCode): void |
| `currentBalance` | `float` | Required | The cleared balance of the account as-of `balanceDate` | getCurrentBalance(): float | setCurrentBalance(float currentBalance): void |
| `availableBalance` | `float` | Required | Available balance | getAvailableBalance(): float | setAvailableBalance(float availableBalance): void |
| `balanceDate` | `int` | Required | A timestamp showing when the `balance` was captured | getBalanceDate(): int | setBalanceDate(int balanceDate): void |
| `transactions` | [`ReportTransaction[]`](../../doc/models/report-transaction.md) | Required | a list of transaction records | getTransactions(): array | setTransactions(array transactions): void |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "currentBalance": 100000,
  "availableBalance": 1000,
  "balanceDate": 1614880526,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

