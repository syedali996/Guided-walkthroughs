
# Direct Deposit

## Structure

`DirectDeposit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amountCurrent` | `?float` | Optional | The amount of the deposit | getAmountCurrent(): ?float | setAmountCurrent(?float amountCurrent): void |
| `accountLastFour` | `?string` | Optional | The last four numbers of the account the deposit went into | getAccountLastFour(): ?string | setAccountLastFour(?string accountLastFour): void |

## Example (as JSON)

```json
{
  "amountCurrent": null,
  "accountLastFour": null
}
```

