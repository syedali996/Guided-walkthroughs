
# Balance and Cash Flow Analytics Report Ack

Response given when analtyics were generated successfully, providing the caller with a report ID which can be used to retrieve the report as JSON or a PDF.

## Structure

`BalanceAndCashFlowAnalyticsReportAck`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountIds` | `int[]` | Required | List of account IDs included in the report | getAccountIds(): array | setAccountIds(array accountIds): void |
| `businessId` | `?int` | Optional | Business ID associated with the requested customer | getBusinessId(): ?int | setBusinessId(?int businessId): void |
| `createdDate` | `string` | Required | Created date of balance analytics request<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` | getCreatedDate(): string | setCreatedDate(string createdDate): void |
| `customerId` | `int` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. | getCustomerId(): int | setCustomerId(int customerId): void |
| `reportId` | `string` | Required | A report ID | getReportId(): string | setReportId(string reportId): void |
| `reportPin` | `string` | Required | PIN that may be used to access the report<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` | getReportPin(): string | setReportPin(string reportPin): void |
| `requesterName` | `?string` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getRequesterName(): ?string | setRequesterName(?string requesterName): void |
| `title` | `string` | Required | Title of the report | getTitle(): string | setTitle(string title): void |

## Example (as JSON)

```json
{
  "accountIds": null,
  "createdDate": null,
  "customerId": 1005061234,
  "reportId": "u4hstnnak45g",
  "reportPin": null,
  "title": "Finicity Asset Ready Report (CRA)"
}
```

