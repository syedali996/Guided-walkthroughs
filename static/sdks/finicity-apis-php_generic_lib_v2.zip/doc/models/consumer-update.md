
# Consumer Update

## Structure

`ConsumerUpdate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | First name(s) / given name(s) | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | Last name(s) / surname(s) | getLastName(): ?string | setLastName(?string lastName): void |
| `address` | `?string` | Optional | A street address | getAddress(): ?string | setAddress(?string address): void |
| `city` | `?string` | Optional | A city | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | A state | getState(): ?string | setState(?string state): void |
| `zip` | `?string` | Optional | A ZIP code | getZip(): ?string | setZip(?string zip): void |
| `phone` | `?string` | Optional | A phone number | getPhone(): ?string | setPhone(?string phone): void |
| `ssn` | `?string` | Optional | A full SSN with or without hyphens | getSsn(): ?string | setSsn(?string ssn): void |
| `birthday` | [`?Birthday`](../../doc/models/birthday.md) | Optional | A birth date | getBirthday(): ?Birthday | setBirthday(?Birthday birthday): void |
| `email` | `?string` | Optional | An email address | getEmail(): ?string | setEmail(?string email): void |
| `suffix` | `?string` | Optional | A person suffix | getSuffix(): ?string | setSuffix(?string suffix): void |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "address": null,
  "city": null,
  "state": null,
  "zip": null,
  "phone": null,
  "ssn": null,
  "birthday": null,
  "email": null,
  "suffix": null
}
```

