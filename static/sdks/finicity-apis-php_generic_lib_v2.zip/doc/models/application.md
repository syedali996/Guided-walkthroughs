
# Application

## Structure

`Application`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appDescription` | `string` | Required | A short description of the app. This will be visible to end users in the FI interface. | getAppDescription(): string | setAppDescription(string appDescription): void |
| `appName` | `string` | Required | The name of the application assigned to the customer | getAppName(): string | setAppName(string appName): void |
| `appUrl` | `string` | Required | An URL for the app. This will be visible to end users in the FI interface. | getAppUrl(): string | setAppUrl(string appUrl): void |
| `ownerAddressLine1` | `string` | Required | An address line 1 | getOwnerAddressLine1(): string | setOwnerAddressLine1(string ownerAddressLine1): void |
| `ownerAddressLine2` | `string` | Required | An address line 2 | getOwnerAddressLine2(): string | setOwnerAddressLine2(string ownerAddressLine2): void |
| `ownerCity` | `string` | Required | City for the business entity that owns the app. Information for registration purposes only and not given to the end user. | getOwnerCity(): string | setOwnerCity(string ownerCity): void |
| `ownerCountry` | `string` | Required | Country for the  business entity that owns the app. Information for registration purposes only and not given to the end user. | getOwnerCountry(): string | setOwnerCountry(string ownerCountry): void |
| `ownerName` | `string` | Required | Business name for the business entity that owns the app. Information for registration purposes only and not given to the end user. | getOwnerName(): string | setOwnerName(string ownerName): void |
| `ownerPostalCode` | `string` | Required | Zip code for the business entity that owns the app. Information for registration purposes only and not given to the end user. | getOwnerPostalCode(): string | setOwnerPostalCode(string ownerPostalCode): void |
| `ownerState` | `string` | Required | State for the business entity that owns the app. Information for registration purposes only and not given to the end user. | getOwnerState(): string | setOwnerState(string ownerState): void |
| `image` | `string` | Required | An app logo passed as a Base64 encoded image (1:1 SVG file, must be less than 50KB) | getImage(): string | setImage(string image): void |

## Example (as JSON)

```json
{
  "appDescription": "The app that makes your budgeting experience awesome",
  "appName": "Awesome Budget App",
  "appUrl": "https://www.finicity.com/",
  "ownerAddressLine1": "434 W Ascension Way",
  "ownerAddressLine2": "Suite #200",
  "ownerCity": "Murray",
  "ownerCountry": "USA",
  "ownerName": "Finicity",
  "ownerPostalCode": "84123",
  "ownerState": "UT",
  "image": "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K"
}
```

