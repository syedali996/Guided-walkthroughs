
# Payroll Employee Record

## Structure

`PayrollEmployeeRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Full name of the employee: first, middle (if stated), and last name | getName(): string | setName(string name): void |
| `givenName` | `string` | Required | First name of employee | getGivenName(): string | setGivenName(string givenName): void |
| `middleName` | `?string` | Optional | Middle name of employee, if stated | getMiddleName(): ?string | setMiddleName(?string middleName): void |
| `familyName` | `string` | Required | Last name of employee | getFamilyName(): string | setFamilyName(string familyName): void |
| `address` | [`?(PayrollEmployeeAddress[])`](../../doc/models/payroll-employee-address.md) | Optional | Array of addresses | getAddress(): ?array | setAddress(?array address): void |

## Example (as JSON)

```json
{
  "name": "John Doe Smith",
  "givenName": "John",
  "familyName": "Smith"
}
```

