
# Obb Error Message Exception

OBB Error response message

## Structure

`ObbErrorMessageException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `errorCode` | `int` | Required | Error code | getErrorCode(): int | setErrorCode(int errorCode): void |
| `message` | `string` | Required | Detailed reason about the source of the error<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getMessage(): string | setMessage(string message): void |

## Example (as JSON)

```json
{
  "errorCode": 4,
  "message": "message0"
}
```

