# Balance Analytics

```php
$balanceAnalyticsController = $client->getBalanceAnalyticsController();
```

## Class Name

`BalanceAnalyticsController`

## Methods

* [Generate Balance Analytics](../../doc/controllers/balance-analytics.md#generate-balance-analytics)
* [Generate Balance Analytics Fcra](../../doc/controllers/balance-analytics.md#generate-balance-analytics-fcra)
* [Get Obb Analytics Report](../../doc/controllers/balance-analytics.md#get-obb-analytics-report)
* [Get Obb Analytics Report Fcra](../../doc/controllers/balance-analytics.md#get-obb-analytics-report-fcra)


# Generate Balance Analytics

Balance Analytics for Business analyzes bank balances over time to report metrics and identify behavior that may indicate risk.

Calculated metrics include:

* Current/available account balances

* Minimum/maximum/average account balances over the requested time
  period and broken down by month

* Daily ending balance of accounts for each day in the requested time
  period

* Propensity of the customer's account balances to increase week over
  week

* Number of days in the requested time period ending with a negative
  balance

This version of the API is intended for piloting and integration testing your application with the Balance Analytics product. It does not adhere to FCRA requirements, and should not be used for production/lending purposes. See _Generate Balance Analytics - FCRA_ for the FCRA compliant version of this API.

A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Balance Analytics Report_ (operation: _GetObbAnalyticsReport_).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateBalanceAnalytics(
    string $customerId,
    BalanceAndCashFlowAnalyticsReportConstraints $body,
    ?string $referenceNumber = null
): BalanceAndCashFlowAnalyticsReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`BalanceAndCashFlowAnalyticsReportConstraints`](../../doc/models/balance-and-cash-flow-analytics-report-constraints.md) | Body, Required | - |
| `referenceNumber` | `?string` | Query, Optional | Partner-provided reference number to correlate reports. |

## Response Type

[`BalanceAndCashFlowAnalyticsReportAck`](../../doc/models/balance-and-cash-flow-analytics-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body = new Models\BalanceAndCashFlowAnalyticsReportConstraints();
$referenceNumber = 'abc123';

$result = $balanceAnalyticsController->generateBalanceAnalytics($customerId, $body, $referenceNumber);
```

## Example Response *(as JSON)*

```json
{
  "accountIds": [
    10001,
    10002,
    10003
  ],
  "businessId": 123,
  "createdDate": "2022-02-10T05:00:00-07:00",
  "customerId": 10001,
  "reportId": "145cabe0-2b38-4175-9b7e-115431359839",
  "reportPin": "qert",
  "requesterName": "Mortage ABC LLC",
  "title": "Finicity Balance Analytics"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A bad request was provided | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 401 | Unauthorized request | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 403 | Access forbidden | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 404 | Resource not found | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 409 | Resource conflict | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |


# Generate Balance Analytics Fcra

Balance Analytics for Business analyzes bank balances over time to report metrics and identify behavior that may indicate risk.

Calculated metrics include:

* Current/available account balances

* Minimum/maximum/average account balances over the requested time
  period and broken down by month

* Daily ending balance of accounts for each day in the requested time
  period

* Propensity of the customer's account balances to increase week over
  week

* Number of days in the requested time period ending with a negative
  balance

This version of the API is intended for production use. It maintains and enforces all compliance with FCRA rules and requirements.

*Note:* this is a premium service, billable per every successful API call for non-testing customers.

A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Balance Analytics Report - FCRA_ (operation: _GetObbAnalyticsReportFCRA_).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateBalanceAnalyticsFcra(
    string $customerId,
    BalanceAndCashFlowAnalyticsReportConstraints $body,
    ?string $referenceNumber = null
): BalanceAndCashFlowAnalyticsReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`BalanceAndCashFlowAnalyticsReportConstraints`](../../doc/models/balance-and-cash-flow-analytics-report-constraints.md) | Body, Required | - |
| `referenceNumber` | `?string` | Query, Optional | Partner-provided reference number to correlate reports. |

## Response Type

[`BalanceAndCashFlowAnalyticsReportAck`](../../doc/models/balance-and-cash-flow-analytics-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body = new Models\BalanceAndCashFlowAnalyticsReportConstraints();
$referenceNumber = 'abc123';

$result = $balanceAnalyticsController->generateBalanceAnalyticsFcra($customerId, $body, $referenceNumber);
```

## Example Response *(as JSON)*

```json
{
  "accountIds": [
    10001,
    10002,
    10003
  ],
  "businessId": 123,
  "createdDate": "2022-02-10T05:00:00-07:00",
  "customerId": 10001,
  "reportId": "145cabe0-2b38-4175-9b7e-115431359839",
  "reportPin": "qert",
  "requesterName": "Mortage ABC LLC",
  "title": "Finicity Balance Analytics"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A bad request was provided | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 401 | Unauthorized request | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 403 | Access forbidden | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 404 | Resource not found | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |
| 409 | Resource conflict | [`ObbErrorMessageException`](../../doc/models/obb-error-message-exception.md) |


# Get Obb Analytics Report

Retrieve the report saved by _Generate Balance Analytics_ or _Generate Cash Flow Analytics_. Requires the report ID generated by the previous call.

Report data can either be retrieved as a JSON document or PDF file.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getObbAnalyticsReport(string $obbReportId): GetObbAnalyticsReportResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `obbReportId` | `string` | Template, Required | Report ID generated and returned by OBB products |

## Response Type

[`GetObbAnalyticsReportResponse`](../../doc/models/get-obb-analytics-report-response.md)

## Example Usage

```php
$obbReportId = 'bcab9592-e032-4e7b-b737-0380619a0573';

$result = $balanceAnalyticsController->getObbAnalyticsReport($obbReportId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Obb Analytics Report Fcra

Retrieve the report saved by _Generate Balance Analytics - FCRA_ or _Generate Cash Flow Analytics - FCRA_. Requires the report ID generated by the previous call.

Report data can either be retrieved as a JSON document or PDF file.

*Note:* this is a premium service, billable per every successful API call for non-testing customers.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getObbAnalyticsReportFcra(string $obbReportId, string $purpose): GetObbAnalyticsReportFcraResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `obbReportId` | `string` | Template, Required | Report ID generated and returned by OBB products |
| `purpose` | `string` | Query, Required | 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports. |

## Response Type

[`GetObbAnalyticsReportFcraResponse`](../../doc/models/get-obb-analytics-report-fcra-response.md)

## Example Usage

```php
$obbReportId = 'bcab9592-e032-4e7b-b737-0380619a0573';
$purpose = 'purpose6';

$result = $balanceAnalyticsController->getObbAnalyticsReportFcra($obbReportId, $purpose);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

