# Cash Flow

```php
$cashFlowController = $client->getCashFlowController();
```

## Class Name

`CashFlowController`

## Methods

* [Generate Cash Flow Business Report](../../doc/controllers/cash-flow.md#generate-cash-flow-business-report)
* [Generate Cash Flow Personal Report](../../doc/controllers/cash-flow.md#generate-cash-flow-personal-report)


# Generate Cash Flow Business Report

Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.

This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateCashFlowBusinessReport(
    string $customerId,
    CashFlowReportConstraints $body,
    ?string $callbackUrl = null
): CashFlowReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`CashFlowReportAck`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body = new Models\CashFlowReportConstraints();
$body->setAccountIds('1000535275');
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);

$body_reportCustomFields[1] = new Models\ReportCustomField();
$body_reportCustomFields[1]->setLabel('trackingID');
$body_reportCustomFields[1]->setValue('5555');
$body_reportCustomFields[1]->setShown(true);

$body_reportCustomFields[2] = new Models\ReportCustomField();
$body_reportCustomFields[2]->setLabel('loanType');
$body_reportCustomFields[2]->setValue('car');
$body_reportCustomFields[2]->setShown(false);

$body_reportCustomFields[3] = new Models\ReportCustomField();
$body_reportCustomFields[3]->setLabel('vendorID');
$body_reportCustomFields[3]->setValue('1613aa23');
$body_reportCustomFields[3]->setShown(true);

$body_reportCustomFields[4] = new Models\ReportCustomField();
$body_reportCustomFields[4]->setLabel('vendorName');
$body_reportCustomFields[4]->setValue('PSC Finance');
$body_reportCustomFields[4]->setShown(false);
$body->setReportCustomFields($body_reportCustomFields);

$body->setShowNsf(false);
$body->setFromDate(1580558400);
$body->setIncomeStreamConfidenceMinimum(50);
$callbackUrl = 'https://finicity-test/webhook';

$result = $cashFlowController->generateCashFlowBusinessReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "383z55zudewm-cfrb",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Business",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrb",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Cash Flow Personal Report

Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.

This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateCashFlowPersonalReport(
    string $customerId,
    CashFlowReportConstraints $body,
    ?string $callbackUrl = null
): CashFlowReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`CashFlowReportAck`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body = new Models\CashFlowReportConstraints();
$body->setAccountIds('1000535275');
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);

$body_reportCustomFields[1] = new Models\ReportCustomField();
$body_reportCustomFields[1]->setLabel('trackingID');
$body_reportCustomFields[1]->setValue('5555');
$body_reportCustomFields[1]->setShown(true);

$body_reportCustomFields[2] = new Models\ReportCustomField();
$body_reportCustomFields[2]->setLabel('loanType');
$body_reportCustomFields[2]->setValue('car');
$body_reportCustomFields[2]->setShown(false);

$body_reportCustomFields[3] = new Models\ReportCustomField();
$body_reportCustomFields[3]->setLabel('vendorID');
$body_reportCustomFields[3]->setValue('1613aa23');
$body_reportCustomFields[3]->setShown(true);

$body_reportCustomFields[4] = new Models\ReportCustomField();
$body_reportCustomFields[4]->setLabel('vendorName');
$body_reportCustomFields[4]->setValue('PSC Finance');
$body_reportCustomFields[4]->setShown(false);
$body->setReportCustomFields($body_reportCustomFields);

$body->setShowNsf(false);
$body->setFromDate(1580558400);
$body->setIncomeStreamConfidenceMinimum(50);
$callbackUrl = 'https://finicity-test/webhook';

$result = $cashFlowController->generateCashFlowPersonalReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "383z51zurqwo-cfrp",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Personal",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrp",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

