# App Registration

```php
$appRegistrationController = $client->getAppRegistrationController();
```

## Class Name

`AppRegistrationController`

## Methods

* [Register App](../../doc/controllers/app-registration.md#register-app)
* [Modify App Registration](../../doc/controllers/app-registration.md#modify-app-registration)
* [Get App Registration Status](../../doc/controllers/app-registration.md#get-app-registration-status)
* [Set Customer App ID](../../doc/controllers/app-registration.md#set-customer-app-id)
* [Migrate Institution Login Accounts](../../doc/controllers/app-registration.md#migrate-institution-login-accounts)


# Register App

Register a new application to access financial institutions using OAuth connections.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function registerApp(Application $body): RegisteredApplication
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```php
$body_appDescription = 'The app that makes your budgeting experience awesome';
$body_appName = 'Awesome Budget App';
$body_appUrl = 'https://www.finicity.com/';
$body_ownerAddressLine1 = '434 W Ascension Way';
$body_ownerAddressLine2 = 'Suite #200';
$body_ownerCity = 'Murray';
$body_ownerCountry = 'USA';
$body_ownerName = 'Finicity';
$body_ownerPostalCode = '84123';
$body_ownerState = 'UT';
$body_image = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K';
$body = new Models\Application(
    $body_appDescription,
    $body_appName,
    $body_appUrl,
    $body_ownerAddressLine1,
    $body_ownerAddressLine2,
    $body_ownerCity,
    $body_ownerCountry,
    $body_ownerName,
    $body_ownerPostalCode,
    $body_ownerState,
    $body_image
);

$result = $appRegistrationController->registerApp($body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify App Registration

Update a registered application.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function modifyAppRegistration(string $preAppId, Application $body): RegisteredApplication
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preAppId` | `string` | Template, Required | The application registration tracking ID |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`RegisteredApplication`](../../doc/models/registered-application.md)

## Example Usage

```php
$preAppId = '2581';
$body_appDescription = 'The app that makes your budgeting experience awesome';
$body_appName = 'Awesome Budget App';
$body_appUrl = 'https://www.finicity.com/';
$body_ownerAddressLine1 = '434 W Ascension Way';
$body_ownerAddressLine2 = 'Suite #200';
$body_ownerCity = 'Murray';
$body_ownerCountry = 'USA';
$body_ownerName = 'Finicity';
$body_ownerPostalCode = '84123';
$body_ownerState = 'UT';
$body_image = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K';
$body = new Models\Application(
    $body_appDescription,
    $body_appName,
    $body_appUrl,
    $body_ownerAddressLine1,
    $body_ownerAddressLine2,
    $body_ownerCity,
    $body_ownerCountry,
    $body_ownerName,
    $body_ownerPostalCode,
    $body_ownerState,
    $body_image
);

$result = $appRegistrationController->modifyAppRegistration($preAppId, $body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get App Registration Status

Get the status of your application registration(s).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getAppRegistrationStatus(
    ?string $preAppId = null,
    ?string $applicationId = null,
    ?string $status = null,
    ?string $appName = null,
    ?int $submittedDate = null,
    ?int $modifiedDate = null,
    ?int $page = 1,
    ?int $pageSize = 1
): AppStatuses
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preAppId` | `?string` | Query, Optional | The application registration tracking ID |
| `applicationId` | `?string` | Query, Optional | The application ID |
| `status` | `?string` | Query, Optional | Look up app registration requests by status |
| `appName` | `?string` | Query, Optional | Look up app registration requests by app name |
| `submittedDate` | `?int` | Query, Optional | Look up app registration requests by the date they were submitted |
| `modifiedDate` | `?int` | Query, Optional | Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R". |
| `page` | `?int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `pageSize` | `?int` | Query, Optional | Maximum number of results per page<br>**Default**: `1` |

## Response Type

[`AppStatuses`](../../doc/models/app-statuses.md)

## Example Usage

```php
$preAppId = '2581';
$applicationId = '123456789';
$status = 'P';
$appName = 'Awesome Budget App';
$submittedDate = 1607450357;
$modifiedDate = 1607450357;
$page = 1;
$pageSize = 20;

$result = $appRegistrationController->getAppRegistrationStatus($preAppId, $applicationId, $status, $appName, $submittedDate, $modifiedDate, $page, $pageSize);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Set Customer App ID

If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function setCustomerAppID(string $customerId, string $applicationId, ?array $body = null): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `applicationId` | `string` | Template, Required | The application ID |
| `body` | `?array` | Body, Optional | No payload expected |

## Response Type

`void`

## Example Usage

```php
$customerId = '1005061234';
$applicationId = '123456789';

$appRegistrationController->setCustomerAppID($customerId, $applicationId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Migrate Institution Login Accounts

The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.

This API returns a list of accounts for the given institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function migrateInstitutionLoginAccounts(
    string $customerId,
    string $institutionLoginId,
    array $body
): CustomerAccounts
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `institutionLoginId` | `string` | Template, Required | The institution login ID |
| `body` | `array` | Body, Required | No payload expected |

## Response Type

[`CustomerAccounts`](../../doc/models/customer-accounts.md)

## Example Usage

```php
$customerId = '1005061234';
$institutionLoginId = '1007302745';
$body = FinicityAPIsLib\ApiHelper::deserialize('{"key1":"val1","key2":"val2"}');

$result = $appRegistrationController->migrateInstitutionLoginAccounts($customerId, $institutionLoginId, $body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

