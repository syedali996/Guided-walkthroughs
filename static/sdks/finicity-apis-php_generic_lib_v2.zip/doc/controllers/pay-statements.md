# Pay Statements

```php
$payStatementsController = $client->getPayStatementsController();
```

## Class Name

`PayStatementsController`


# Store Customer Pay Statement

Upload pay statements for a customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function storeCustomerPayStatement(string $customerId, PayStatement $body): Asset
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`PayStatement`](../../doc/models/pay-statement.md) | Body, Required | - |

## Response Type

[`Asset`](../../doc/models/asset.md)

## Example Usage

```php
$customerId = '1005061234';
$body_label = 'lastPayPeriod';
$body_statement = 'VGhpcyBtdXN0IGJlIGFuIGltYWdl';
$body = new Models\PayStatement(
    $body_label,
    $body_statement
);

$result = $payStatementsController->storeCustomerPayStatement($customerId, $body);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

