# Assets

Download asset files

```php
$assetsController = $client->getAssetsController();
```

## Class Name

`AssetsController`


# Get Asset by Customer ID

Retrieve a binary file for the given asset ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getAssetByCustomerID(string $customerId, string $assetId): string
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `assetId` | `string` | Template, Required | The asset ID |

## Response Type

`string`

## Example Usage

```php
$customerId = '1005061234';
$assetId = '097545c5-1c2a-4f20-a5ef-77f0820344c9-2018601178';

$result = $assetsController->getAssetByCustomerID($customerId, $assetId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

