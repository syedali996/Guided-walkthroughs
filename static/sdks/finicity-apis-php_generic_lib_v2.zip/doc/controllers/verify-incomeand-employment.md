# Verify Incomeand Employment

```php
$verifyIncomeandEmploymentController = $client->getVerifyIncomeandEmploymentController();
```

## Class Name

`VerifyIncomeandEmploymentController`

## Methods

* [Generate VOI Report](../../doc/controllers/verify-incomeand-employment.md#generate-voi-report)
* [Generate VOE Payroll Report](../../doc/controllers/verify-incomeand-employment.md#generate-voe-payroll-report)
* [Generate VOE Transactions Report](../../doc/controllers/verify-incomeand-employment.md#generate-voe-transactions-report)
* [Generate Pay Statement Report](../../doc/controllers/verify-incomeand-employment.md#generate-pay-statement-report)
* [Generate VOIE Paystub With TX Verify Report](../../doc/controllers/verify-incomeand-employment.md#generate-voie-paystub-with-tx-verify-report)
* [Generate VOIE Paystub Report](../../doc/controllers/verify-incomeand-employment.md#generate-voie-paystub-report)
* [Refresh VOIE Payroll Report](../../doc/controllers/verify-incomeand-employment.md#refresh-voie-payroll-report)


# Generate VOI Report

Generate a Verification of Income (VOI) report for all checking, savings, and money market accounts for the given customer. This service retrieves up to two years of transaction history for each account and uses this information to generate the VOI report.

This is a premium service. The billing rate is the variable rate for Verification of Income under the current subscription plan. The billable event is the successful generation of a VOI report.

If no account of type checking, savings, or money market is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateVOIReport(
    string $customerId,
    VOIReportConstraints $body,
    ?string $callbackUrl = null
): VOIReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`VOIReportConstraints`](../../doc/models/voi-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`VOIReportAck`](../../doc/models/voi-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body = new Models\VOIReportConstraints();
$body->setAccountIds('1000535275 1000535276');
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);

$body_reportCustomFields[1] = new Models\ReportCustomField();
$body_reportCustomFields[1]->setLabel('trackingID');
$body_reportCustomFields[1]->setValue('5555');
$body_reportCustomFields[1]->setShown(true);

$body_reportCustomFields[2] = new Models\ReportCustomField();
$body_reportCustomFields[2]->setLabel('loanType');
$body_reportCustomFields[2]->setValue('car');
$body_reportCustomFields[2]->setShown(false);

$body_reportCustomFields[3] = new Models\ReportCustomField();
$body_reportCustomFields[3]->setLabel('vendorID');
$body_reportCustomFields[3]->setValue('1613aa23');
$body_reportCustomFields[3]->setShown(true);

$body_reportCustomFields[4] = new Models\ReportCustomField();
$body_reportCustomFields[4]->setLabel('vendorName');
$body_reportCustomFields[4]->setValue('PSC Finance');
$body_reportCustomFields[4]->setShown(false);
$body->setReportCustomFields($body_reportCustomFields);

$body->setFromDate(1577986990);
$body->setIncomeStreamConfidenceMinimum(50);
$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->generateVOIReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "u4hstnnaewetr-voi",
  "portfolioId": "dyr6qvqd2erw-1-port",
  "customerType": "active",
  "customerId": 1000006677,
  "requestId": "sfb7xp4wer",
  "requesterName": "Decisioning API",
  "createdDate": 1588350269,
  "title": "Finicity Verification of Income",
  "consumerId": "ac39e237c7619a4ecf014b8d399c0696",
  "consumerSsn": "6789",
  "constraints": {
    "accountIds": [
      "1000535275",
      "1000535276"
    ],
    "fromDate": 1577986990,
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "voi",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate VOE Payroll Report

Premium Service: A billable event when the API response is successful.

MVS Implementation Options: Direct API Integration.

Used as a complementary report to the VOIE-Payroll report. This report is used to fulfill the pre-close VOE requirements. It retrieves the customer's employment details and employment status through the payroll source without any income information.

To generate this report, pass the values from the customer SSN, DOB, and the report ID from the first VOIE-Payroll report generated after the Connect session.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateVOEPayrollReport(
    string $customerId,
    PayrollReportConstraints $body,
    ?string $callbackUrl = null
): PayrollReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`PayrollReportConstraints`](../../doc/models/payroll-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`PayrollReportAck`](../../doc/models/payroll-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body_payrollData_ssn = '999990000';
$body_payrollData_dob = 315576000;
$body_payrollData = new Models\PayrollData(
    $body_payrollData_ssn,
    $body_payrollData_dob
);
$body_payrollData->setReportId('abcdefghijkl-voiepayroll');
$body = new Models\PayrollReportConstraints(
    $body_payrollData
);
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);
$body->setReportCustomFields($body_reportCustomFields);

$body->setPayStatementsFromDate(1580558400);
$body->setMarketSegment('Mortgage');
$body->setExcludeEmpInfo(true);
$body->setPurpose('99');
$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->generateVOEPayrollReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "41h4nzppn47u-voepayroll",
  "portfolioId": "9qud7dtuzbew-3-port",
  "customerType": "active",
  "customerId": 1011140000,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Verification of Employment - Payroll",
  "consumerId": "656cf7083c5c06e0c125a698579f0000",
  "consumerSsn": "6789",
  "constraints": {
    "payrollData": {
      "payrollDataRetrievalId": "hahvhe2k0000",
      "employerNames": [
        "ACME INC"
      ],
      "reportId": "abcdefghijkl-voiepayroll"
    },
    "payStatementsFromDate": 1580558400,
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      }
    ]
  },
  "type": "voePayroll",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate VOE Transactions Report

Premium Service: A billable event when the API response is successful.

MVS-Direct integration developers only.

Used as a complimentary report to the VOA with Income and VOIE - Paystub (with TXVerify) reports and used to fulfill the pre-close VOE requirements.

Retrieve the latest credit transaction information from the borrower's connected bank accounts and groups them into income streams so that you can view their payment history to ensure a direct deport was made within the expected cadence. The report displays transaction descriptions without any dollar amounts so that income re-verification isn't necessary.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateVOETransactionsReport(
    string $customerId,
    VOETransactionsReportConstraints $body,
    ?string $callbackUrl = null
): VOETransactionsReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`VOETransactionsReportConstraints`](../../doc/models/voe-transactions-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`VOETransactionsReportAck`](../../doc/models/voe-transactions-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body = new Models\VOETransactionsReportConstraints();
$body->setReportId('j7k8qbgwsa7d-voietxverify');
$body->setAccountIds('123456789');
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);

$body_reportCustomFields[1] = new Models\ReportCustomField();
$body_reportCustomFields[1]->setLabel('trackingID');
$body_reportCustomFields[1]->setValue('5555');
$body_reportCustomFields[1]->setShown(true);

$body_reportCustomFields[2] = new Models\ReportCustomField();
$body_reportCustomFields[2]->setLabel('loanType');
$body_reportCustomFields[2]->setValue('car');
$body_reportCustomFields[2]->setShown(false);

$body_reportCustomFields[3] = new Models\ReportCustomField();
$body_reportCustomFields[3]->setLabel('vendorID');
$body_reportCustomFields[3]->setValue('1613aa23');
$body_reportCustomFields[3]->setShown(true);

$body_reportCustomFields[4] = new Models\ReportCustomField();
$body_reportCustomFields[4]->setLabel('vendorName');
$body_reportCustomFields[4]->setValue('PSC Finance');
$body_reportCustomFields[4]->setShown(false);
$body->setReportCustomFields($body_reportCustomFields);

$body->setFromDate(1580558400);
$body->setIncomeStreamConfidenceMinimum(50);
$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->generateVOETransactionsReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "u4hstny1k25g-voetransactions",
  "portfolioId": "dyr6weqd2yhb-2-port",
  "customerType": "active",
  "customerId": 1000006677,
  "requestId": "sfb7x1we9w",
  "requesterName": "Decisioning API",
  "createdDate": 1588350269,
  "title": "Finicity Verification Employment - Transactions",
  "consumerId": "ac39e237c7619a4ecf014b8d399c0696",
  "consumerSsn": "6789",
  "constraints": {
    "reportId": "j7k8qbgwsa7d-voietxverify",
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "voeTransactions",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Pay Statement Report

Generate Pay Statement Extraction Report for the given customer. This service accepts asset IDs of the stored pay statements to generate a Pay Statement Extraction Report.

This is a premium service. The billing rate is the variable rate for Pay Statement Extraction Report under the current subscription plan. The billable event is the successful generation of a Pay Statement Extraction Report.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generatePayStatementReport(
    string $customerId,
    PayStatementReportConstraints $body,
    ?string $callbackUrl = null
): PayStatementReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`PayStatementReportConstraints`](../../doc/models/pay-statement-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`PayStatementReportAck`](../../doc/models/pay-statement-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body_paystatementReport_assetIds = ['6f8fb0a0-e882-4f57-b672-cf53f1397581'];
$body_paystatementReport = new Models\PayStatementData(
    $body_paystatementReport_assetIds
);
$body_paystatementReport->setExtractEarnings(true);
$body_paystatementReport->setExtractDeductions(false);
$body_paystatementReport->setExtractDirectDeposit(true);
$body = new Models\PayStatementReportConstraints(
    $body_paystatementReport
);
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);

$body_reportCustomFields[1] = new Models\ReportCustomField();
$body_reportCustomFields[1]->setLabel('trackingID');
$body_reportCustomFields[1]->setValue('5555');
$body_reportCustomFields[1]->setShown(true);

$body_reportCustomFields[2] = new Models\ReportCustomField();
$body_reportCustomFields[2]->setLabel('loanType');
$body_reportCustomFields[2]->setValue('car');
$body_reportCustomFields[2]->setShown(false);

$body_reportCustomFields[3] = new Models\ReportCustomField();
$body_reportCustomFields[3]->setLabel('vendorID');
$body_reportCustomFields[3]->setValue('1613aa23');
$body_reportCustomFields[3]->setShown(true);

$body_reportCustomFields[4] = new Models\ReportCustomField();
$body_reportCustomFields[4]->setLabel('vendorName');
$body_reportCustomFields[4]->setValue('PSC Finance');
$body_reportCustomFields[4]->setShown(false);
$body->setReportCustomFields($body_reportCustomFields);

$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->generatePayStatementReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "y0ejausptjg1-paystatement",
  "portfolioId": "spd8aehuw63i-10-port",
  "customerType": "active",
  "customerId": 1003413624,
  "requestId": "8wy5htqg8u",
  "requesterName": "Decisioning API",
  "createdDate": 1588350269,
  "title": "Finicity Pay Statement Extraction Report",
  "consumerId": "4089f408963dd6b90b28a935e9903c0e",
  "consumerSsn": "6789",
  "constraints": {
    "paystatementReport": {
      "assetIds": [
        "6f8fb0a0-e882-4f57-b672-cf53f1397581"
      ],
      "extractEarnings": true,
      "extractDeductions": false,
      "extractDirectDeposit": true
    },
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "paystatement",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate VOIE Paystub With TX Verify Report

Generate a VOIE - Paystub (with TXVerify) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given accounts. It then uses this information as well as the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub (with TXVerify) report.

Note: if you are using this API to refresh the bank transactions, use the same asset ID from the first report. A new paystub is not required unless the paystub is too old for underwriting requirements. Using the same asset ID that was on the original report and the previously extracted details will be used to speed up report generation response time.

This is a premium service. The billing rate is the variable rate for VOIE TXVerify under the current subscription plan. The billable event is the successful generation of a VOIE TXVerify Report.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateVOIEPaystubWithTXVerifyReport(
    string $customerId,
    VOIEWithTXVerifyReportConstraints $body,
    ?string $callbackUrl = null
): VOIEPaystubWithTXVerifyReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`VOIEWithTXVerifyReportConstraints`](../../doc/models/voie-with-tx-verify-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`VOIEPaystubWithTXVerifyReportAck`](../../doc/models/voie-paystub-with-tx-verify-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body_voieWithInterviewData_txVerifyInterview = [];

$body_voieWithInterviewData_txVerifyInterview_0_assetId = '7eb57060-6d98-4449-992d-4dd4490448f3-1236011097';
$body_voieWithInterviewData_txVerifyInterview[0] = new Models\TxVerifyInterview(
    $body_voieWithInterviewData_txVerifyInterview_0_assetId
);

$body_voieWithInterviewData = new Models\VOIEWithInterviewData(
    $body_voieWithInterviewData_txVerifyInterview
);
$body = new Models\VOIEWithTXVerifyReportConstraints(
    $body_voieWithInterviewData
);
$body->setAccountIds('1028361677');
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('123456');
$body_reportCustomFields[0]->setShown(true);
$body->setReportCustomFields($body_reportCustomFields);

$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->generateVOIEPaystubWithTXVerifyReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "2f3z55zuwewm-voietxverify",
  "customerId": 1275320,
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "6789",
  "requesterName": "Decisioning API",
  "requestId": "7a7qyps2iy",
  "type": "voieTxVerify",
  "status": "inProgress",
  "createdDate": 1579819592,
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "voieWithInterviewData": {
      "txVerifyInterview": [
        {
          "assetId": "6f8fb0a0-e882-4f57-b672-cf53f1397581",
          "accounts": []
        }
      ],
      "extractEarnings": true,
      "extractDeductions": false,
      "extractDirectDeposit": true
    },
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "123456",
        "shown": true
      }
    ]
  },
  "customerType": "active",
  "title": "Finicity Verification of Income and Employment - Paystub (with TXVerify)",
  "portfolioId": "9qud7dtuzbew-2-port"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate VOIE Paystub Report

Generate a VOIE - Paystub report. This service uses the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub report with digitized paystub details.

This is a premium service. The billing rate is the variable rate for VOIE - Paystub under the current subscription plan. The billable event is the successful generation of a VOIE - Paystub Report.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateVOIEPaystubReport(
    string $customerId,
    VOIEReportConstraints $body,
    ?string $callbackUrl = null
): VOIEPaystubReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`VOIEReportConstraints`](../../doc/models/voie-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`VOIEPaystubReportAck`](../../doc/models/voie-paystub-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body_voieWithStatementData_assetIds = ['d50ed92f-543b-431c-8286-c8b8f6556679'];
$body_voieWithStatementData = new Models\VOIEWithStatementData(
    $body_voieWithStatementData_assetIds
);
$body = new Models\VOIEReportConstraints(
    $body_voieWithStatementData
);
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('123456');
$body_reportCustomFields[0]->setShown(true);

$body_reportCustomFields[1] = new Models\ReportCustomField();
$body_reportCustomFields[1]->setLabel('trackingID');
$body_reportCustomFields[1]->setValue('5555');
$body_reportCustomFields[1]->setShown(true);
$body->setReportCustomFields($body_reportCustomFields);

$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->generateVOIEPaystubReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "2f3z55zuwewm-voietxverify",
  "portfolioId": "9qud7dtuzbew-13-port",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Verification of Income and Employment - Paystub",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "6789",
  "constraints": {
    "voieWithStatementData": {
      "assetIds": [
        "d50ed92f-543b-431c-8286-c8b8f6556679"
      ],
      "extractEarnings": true,
      "extractDeductions": false,
      "extractDirectDeposit": true
    },
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "123456",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      }
    ]
  },
  "type": "voieTxVerify",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Refresh VOIE Payroll Report

The VOIE – Payroll report generates when the customer completes Connect. Lenders, who commonly use this report for pre-close verification employment check, can refresh this report by passing the consumer's SSN, DOB, and the report ID from the first VOIE – Payroll report they received.

We'll refresh this report and update any new pay histories since the first report generated, including borrower's employment status as active or not.

Note: lenders can only refresh this report one time in a 60-day period starting from the date of the first report. Any further report refreshes will incur additional charges.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function refreshVOIEPayrollReport(
    string $customerId,
    PayrollReportConstraints $body,
    ?string $callbackUrl = null
): PayrollReportAck
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`PayrollReportConstraints`](../../doc/models/payroll-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `?string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`PayrollReportAck`](../../doc/models/payroll-report-ack.md)

## Example Usage

```php
$customerId = '1005061234';
$body_payrollData_ssn = '999990000';
$body_payrollData_dob = 315576000;
$body_payrollData = new Models\PayrollData(
    $body_payrollData_ssn,
    $body_payrollData_dob
);
$body_payrollData->setReportId('abcdefghijkl-voiepayroll');
$body = new Models\PayrollReportConstraints(
    $body_payrollData
);
$body_reportCustomFields = [];

$body_reportCustomFields[0] = new Models\ReportCustomField();
$body_reportCustomFields[0]->setLabel('loanID');
$body_reportCustomFields[0]->setValue('12345');
$body_reportCustomFields[0]->setShown(true);
$body->setReportCustomFields($body_reportCustomFields);

$body->setPayStatementsFromDate(1580558400);
$body->setMarketSegment('Mortgage');
$body->setExcludeEmpInfo(true);
$body->setPurpose('99');
$callbackUrl = 'https://finicity-test/webhook';

$result = $verifyIncomeAndEmploymentController->refreshVOIEPayrollReport($customerId, $body, $callbackUrl);
```

## Example Response *(as JSON)*

```json
{
  "id": "123456789012-voiepayroll",
  "customerId": 1011140000,
  "consumerId": "656cf7083c5c06e0c125a698579f0000",
  "consumerSsn": "6789",
  "requesterName": "Decisioning API",
  "requestId": "7a7qyps2iy",
  "type": "voiePayroll",
  "status": "inProgress",
  "createdDate": 1579819592,
  "constraints": {
    "payrollData": {
      "payrollDataRetrievalId": "hahvhe2k0000",
      "employerNames": [
        "ACME INC"
      ],
      "reportId": "abcdefghijkl-voiepayroll"
    },
    "payStatementsFromDate": 1580558400,
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      }
    ]
  },
  "customerType": "active",
  "title": "Finicity Verification of Income and Employment - Payroll",
  "portfolioId": "9qud7dtuzbew-2-port"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

