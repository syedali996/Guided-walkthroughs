# Institutions

Search and fetch financial institutions

```php
$institutionsController = $client->getInstitutionsController();
```

## Class Name

`InstitutionsController`

## Methods

* [Get Certified Institutions With RSSD](../../doc/controllers/institutions.md#get-certified-institutions-with-rssd)
* [Get Institutions](../../doc/controllers/institutions.md#get-institutions)
* [Get Certified Institutions](../../doc/controllers/institutions.md#get-certified-institutions)
* [Get Institution](../../doc/controllers/institutions.md#get-institution)
* [Get Institution Branding](../../doc/controllers/institutions.md#get-institution-branding)


# Get Certified Institutions With RSSD

Search for certified financial institutions w/RSSD.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getCertifiedInstitutionsWithRSSD(
    ?string $search = null,
    ?int $start = 1,
    ?int $limit = 25,
    ?string $type = null
): CertifiedInstitutions
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `?string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `?int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `?int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `?string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`CertifiedInstitutions`](../../doc/models/certified-institutions.md)

## Example Usage

```php
$search = 'finbank';
$start = 1;
$limit = 25;
$type = 'voa';

$result = $institutionsController->getCertifiedInstitutionsWithRSSD($search, $start, $limit, $type);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institutions

Search for financial institutions.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getInstitutions(
    ?string $search = null,
    ?int $start = 1,
    ?int $limit = 25,
    ?string $type = null
): Institutions
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `?string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `?int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `?int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `?string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`Institutions`](../../doc/models/institutions.md)

## Example Usage

```php
$search = 'finbank';
$start = 1;
$limit = 25;
$type = 'voa';

$result = $institutionsController->getInstitutions($search, $start, $limit, $type);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Certified Institutions

Search for financial institutions by certified product.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getCertifiedInstitutions(
    ?string $search = null,
    ?int $start = 1,
    ?int $limit = 25,
    ?string $type = null
): CertifiedInstitutions
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `?string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `?int` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `?int` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `?string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`CertifiedInstitutions`](../../doc/models/certified-institutions.md)

## Example Usage

```php
$search = 'finbank';
$start = 1;
$limit = 25;
$type = 'voa';

$result = $institutionsController->getCertifiedInstitutions($search, $start, $limit, $type);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution

Get financial institution details by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getInstitution(int $institutionId): InstitutionWrapper
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institutionId` | `int` | Template, Required | The institution ID |

## Response Type

[`InstitutionWrapper`](../../doc/models/institution-wrapper.md)

## Example Usage

```php
$institutionId = 4222;

$result = $institutionsController->getInstitution($institutionId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution Branding

Return the branding information for a financial institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getInstitutionBranding(int $institutionId): BrandingWrapper
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institutionId` | `int` | Template, Required | The institution ID |

## Response Type

[`BrandingWrapper`](../../doc/models/branding-wrapper.md)

## Example Usage

```php
$institutionId = 4222;

$result = $institutionsController->getInstitutionBranding($institutionId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

