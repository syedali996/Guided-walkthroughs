# Analyticsand Attributes

```php
$analyticsandAttributesController = $client->getAnalyticsandAttributesController();
```

## Class Name

`AnalyticsandAttributesController`

## Methods

* [Generate Consumer Attributes](../../doc/controllers/analyticsand-attributes.md#generate-consumer-attributes)
* [List Consumer Attributes](../../doc/controllers/analyticsand-attributes.md#list-consumer-attributes)
* [Generate FCRA Consumer Attributes](../../doc/controllers/analyticsand-attributes.md#generate-fcra-consumer-attributes)
* [Get Consumer Attributes by ID](../../doc/controllers/analyticsand-attributes.md#get-consumer-attributes-by-id)
* [Get FCRA Consumer Attributes by ID](../../doc/controllers/analyticsand-attributes.md#get-fcra-consumer-attributes-by-id)


# Generate Consumer Attributes

Generate a Consumer Attributes report for the given customer. The "to" and "from" date range is the last 12 months of consumer data, based on the date at which the report was generated.

An analytic ID is created and associated with the customer's ID. If you generate multiple Consumer Attributes reports for the same customer, then each report will have its own analytic ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateConsumerAttributes(
    string $customerId,
    ?ConsumerAttributeAccountIDs $body = null
): ConsumerAttributesAnalyticId
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`?ConsumerAttributeAccountIDs`](../../doc/models/consumer-attribute-account-i-ds.md) | Body, Optional | - |

## Response Type

[`ConsumerAttributesAnalyticId`](../../doc/models/consumer-attributes-analytic-id.md)

## Example Usage

```php
$customerId = '1005061234';

$result = $analyticsAndAttributesController->generateConsumerAttributes($customerId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# List Consumer Attributes

Retrieve a list of all analytic IDs previously created for a customer using the Generate Consumer Attributes APIs.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function listConsumerAttributes(string $customerId): ConsumerAttributeList
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |

## Response Type

[`ConsumerAttributeList`](../../doc/models/consumer-attribute-list.md)

## Example Usage

```php
$customerId = '1005061234';

$result = $analyticsAndAttributesController->listConsumerAttributes($customerId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate FCRA Consumer Attributes

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function generateFCRAConsumerAttributes(
    string $customerId,
    ?ConsumerAttributeAccountIDs $body = null
): ConsumerAttributesAnalyticId
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`?ConsumerAttributeAccountIDs`](../../doc/models/consumer-attribute-account-i-ds.md) | Body, Optional | - |

## Response Type

[`ConsumerAttributesAnalyticId`](../../doc/models/consumer-attributes-analytic-id.md)

## Example Usage

```php
$customerId = '1005061234';

$result = $analyticsAndAttributesController->generateFCRAConsumerAttributes($customerId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer Attributes by ID

Retrieve a Consumer Attributes report for a customer.

Use the analytic and customer IDs to retrieve 12 months of data attributes according to the "to" and "from" date range of the report at the time it was created.

If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getConsumerAttributesByID(string $analyticsId, string $customerId): ConsumerAttributes
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `analyticsId` | `string` | Template, Required | The analytic ID |
| `customerId` | `string` | Template, Required | A customer ID |

## Response Type

[`ConsumerAttributes`](../../doc/models/consumer-attributes.md)

## Example Usage

```php
$analyticsId = 'CA-5dfbaa3ac-5321';
$customerId = '1005061234';

$result = $analyticsAndAttributesController->getConsumerAttributesByID($analyticsId, $customerId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get FCRA Consumer Attributes by ID

Retrieve a FCRA Consumer Attributes report for a customer.

Use the analytic and customer IDs to retrieve 12 months of FCRA data attributes according to the `To` and `From` date range of the report at the time it was created.

If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```php
function getFCRAConsumerAttributesByID(
    string $analyticsId,
    string $customerId,
    ?string $purpose = null
): ConsumerAttributes
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `analyticsId` | `string` | Template, Required | The analytic ID |
| `customerId` | `string` | Template, Required | A customer ID |
| `purpose` | `?string` | Query, Optional | 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports. |

## Response Type

[`ConsumerAttributes`](../../doc/models/consumer-attributes.md)

## Example Usage

```php
$analyticsId = 'CA-5dfbaa3ac-5321';
$customerId = '1005061234';
$purpose = '99';

$result = $analyticsAndAttributesController->getFCRAConsumerAttributesByID($analyticsId, $customerId, $purpose);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

