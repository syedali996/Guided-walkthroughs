
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `timeout` | `int` | Timeout for API calls in seconds.<br>*Default*: `0` |
| `enableRetries` | `bool` | Whether to enable retries and backoff feature.<br>*Default*: `false` |
| `numberOfRetries` | `int` | The number of retries to make.<br>*Default*: `0` |
| `retryInterval` | `float` | The retry time interval between the endpoint calls.<br>*Default*: `1` |
| `backOffFactor` | `float` | Exponential backoff factor to increase interval between retries.<br>*Default*: `2` |
| `maximumRetryWaitTime` | `int` | The maximum wait time in seconds for overall retrying requests.<br>*Default*: `0` |
| `retryOnTimeout` | `bool` | Whether to retry on request timeout.<br>*Default*: `true` |
| `httpStatusCodesToRetry` | `array` | Http status codes to retry against.<br>*Default*: `408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524` |
| `httpMethodsToRetry` | `array` | Http methods to retry against.<br>*Default*: `'GET', 'PUT', 'GET', 'PUT'` |
| `finicityAppKey` | `string` | The "Finicity-App-Key" from the developer dashboard |
| `finicityAppToken` | `string` | A token returned by the `/authentication` API |

The API client can be initialized as follows:

```php
$client = FinicityAPIsLib\FinicityAPIsClientBuilder::init()
    ->finicityAppKey('Finicity-App-Key')
    ->finicityAppToken('Finicity-App-Token')
    ->build();
```

## Finicity APIs Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| getAccountsController() | Gets AccountsController |
| getAnalyticsAndAttributesController() | Gets AnalyticsAndAttributesController |
| getAppRegistrationController() | Gets AppRegistrationController |
| getAssetsController() | Gets AssetsController |
| getAuthenticationController() | Gets AuthenticationController |
| getBalanceAnalyticsController() | Gets BalanceAnalyticsController |
| getBankStatementsController() | Gets BankStatementsController |
| getCashFlowController() | Gets CashFlowController |
| getCashFlowAnalyticsController() | Gets CashFlowAnalyticsController |
| getConnectController() | Gets ConnectController |
| getConsumersController() | Gets ConsumersController |
| getCustomersController() | Gets CustomersController |
| getInstitutionsController() | Gets InstitutionsController |
| getPayStatementsController() | Gets PayStatementsController |
| getPaymentsController() | Gets PaymentsController |
| getPortfoliosController() | Gets PortfoliosController |
| getReportsController() | Gets ReportsController |
| getTransactionsController() | Gets TransactionsController |
| getTxPushController() | Gets TxPushController |
| getVerifyAssetsController() | Gets VerifyAssetsController |
| getVerifyIncomeAndEmploymentController() | Gets VerifyIncomeAndEmploymentController |

