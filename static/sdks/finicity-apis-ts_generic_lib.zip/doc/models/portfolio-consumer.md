
# Portfolio Consumer

## Structure

`PortfolioConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `firstName` | `string` | Required | First name(s) / given name(s) |
| `lastName` | `string` | Required | Last name(s) / surname(s) |
| `customerId` | `bigint` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `ssn` | `string` | Required | A full SSN with or without hyphens |
| `birthday` | [`Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `suffix` | `string \| undefined` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "ssn": "999-99-9999",
  "birthday": null
}
```

