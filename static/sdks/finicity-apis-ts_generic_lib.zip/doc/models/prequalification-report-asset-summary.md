
# Prequalification Report Asset Summary

## Structure

`PrequalificationReportAssetSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string \| undefined` | Optional | The asset type: "checking", "savings", "moneyMarket", "cd", "investment" |
| `availableBalance` | `number \| undefined` | Optional | The available balance for the account |
| `currentBalance` | `number` | Required | The current balance of the account |
| `twoMonthAverage` | `number` | Required | The two month average daily balance of the account |
| `sixMonthAverage` | `number` | Required | The six month average daily balance of the account |
| `beginningBalance` | `number` | Required | The beginning balance of the account per the time period of the report |

## Example (as JSON)

```json
{
  "currentBalance": 1000,
  "twoMonthAverage": -1865.96,
  "sixMonthAverage": -7616.01,
  "beginningBalance": -17795.6
}
```

