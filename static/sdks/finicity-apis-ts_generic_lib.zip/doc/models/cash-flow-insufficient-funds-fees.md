
# Cash Flow Insufficient Funds Fees

## Structure

`CashFlowInsufficientFundsFees`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `countOfTransactionsForTheReportTimePeriod` | `number \| undefined` | Optional | Count of all NSF transactions during the report |
| `sumOfTransactionsForTheReportTimePeriod` | `number \| undefined` | Optional | Sum of all NSF transactions during the report |
| `transactions` | [`InsufficientFundsTransaction[] \| undefined`](../../doc/models/insufficient-funds-transaction.md) | Optional | Transactions categorized as NSF |

## Example (as JSON)

```json
{
  "countOfTransactionsForTheReportTimePeriod": null,
  "sumOfTransactionsForTheReportTimePeriod": null,
  "transactions": null
}
```

