
# Employee

## Structure

`Employee`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | The name of the employee |

## Example (as JSON)

```json
{
  "name": null
}
```

