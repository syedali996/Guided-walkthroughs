
# Last Transaction Date

## Structure

`LastTransactionDate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `string` | Required | Date the deposit transaction was posted |
| `depositsCredits` | `number \| undefined` | Optional | Amount of transaction if deposit, otherwise null |
| `withdrawalsDebits` | `number \| undefined` | Optional | Amount of transaction if withdrawal, otherwise null |
| `zeroAmountTransaction` | `number \| undefined` | Optional | Amount of transaction if zero, otherwise null |
| `transactionDescription` | `string \| undefined` | Optional | Description of transaction |

## Example (as JSON)

```json
{
  "date": "2020-03-25"
}
```

