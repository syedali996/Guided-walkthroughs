
# Balance Analytics Metrics

## Structure

`BalanceAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `availableBalance` | `number \| undefined` | Optional | Available Balance |
| `availableBalanceDate` | `string \| undefined` | Optional | Available Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `averageDailyBalanceByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[] \| undefined`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average daily ending balance each month over the report time period |
| `averageDailyBalanceForTheReportTimePeriod` | `number \| undefined` | Optional | Average Daily Balance |
| `averageWeekdayBalanceForTheReportTimePeriod` | `number \| undefined` | Optional | Average Weekday Balance |
| `countDailyNegativeBalancesByMonthForTheReportTimePeriod` | [`ObbDateRangeAndCount[] \| undefined`](../../doc/models/obb-date-range-and-count.md) | Optional | Number of negative daily ending balances each month over the report time period |
| `currentRunningBalance` | `number \| undefined` | Optional | Current Running Balance Date |
| `currentRunningBalanceDate` | `string \| undefined` | Optional | Current Running Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `dailyBalancesByWeekdayForTheReportTimePeriod` | [`ObbDailyBalance[] \| undefined`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account during weekdays over the length of the report |
| `dailyBalancesForTheReportTimePeriod` | [`ObbDailyBalance[] \| undefined`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account over the length of the report |
| `historicNumberOfWeeksAverageBalanceIncreasing` | [`ObbNumWeeksAverageBalanceIncreasing \| undefined`](../../doc/models/obb-num-weeks-average-balance-increasing.md) | Optional | Report of average account balance week over week and count of weeks where the average balance increased |
| `maximumDailyBalanceByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[] \| undefined`](../../doc/models/obb-date-range-and-amount.md) | Optional | Maximum daily ending balance each month over the report time period |
| `maximumRunningBalanceForTheReportTimePeriod` | `number \| undefined` | Optional | Maximum Running Balance |
| `minimumDailyBalanceByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[] \| undefined`](../../doc/models/obb-date-range-and-amount.md) | Optional | Minimum daily ending balance each month over the report time period |
| `minimumRunningBalanceForTheReportTimePeriod` | `number \| undefined` | Optional | Minimum Running Balance |

## Example (as JSON)

```json
{
  "availableBalance": null,
  "availableBalanceDate": null,
  "averageDailyBalanceByMonthForTheReportTimePeriod": null,
  "averageDailyBalanceForTheReportTimePeriod": null,
  "averageWeekdayBalanceForTheReportTimePeriod": null,
  "countDailyNegativeBalancesByMonthForTheReportTimePeriod": null,
  "currentRunningBalance": null,
  "currentRunningBalanceDate": null,
  "dailyBalancesByWeekdayForTheReportTimePeriod": null,
  "dailyBalancesForTheReportTimePeriod": null,
  "historicNumberOfWeeksAverageBalanceIncreasing": null,
  "maximumDailyBalanceByMonthForTheReportTimePeriod": null,
  "maximumRunningBalanceForTheReportTimePeriod": null,
  "minimumDailyBalanceByMonthForTheReportTimePeriod": null,
  "minimumRunningBalanceForTheReportTimePeriod": null
}
```

