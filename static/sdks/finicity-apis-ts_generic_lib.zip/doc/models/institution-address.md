
# Institution Address

The address of a financial institution

## Structure

`InstitutionAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `city` | `string \| undefined` | Optional | A city |
| `state` | `string \| undefined` | Optional | A state |
| `country` | `string \| undefined` | Optional | A country code |
| `postalCode` | `string \| undefined` | Optional | A ZIP code |
| `addressLine1` | `string \| undefined` | Optional | An address line 1 |
| `addressLine2` | `string \| undefined` | Optional | An address line 2 |

## Example (as JSON)

```json
{
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "addressLine1": null,
  "addressLine2": null
}
```

