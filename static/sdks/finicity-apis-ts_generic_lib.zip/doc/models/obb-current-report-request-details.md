
# Obb Current Report Request Details

## Structure

`ObbCurrentReportRequestDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportBeginDate` | `string` | Required | Date from when the requested data is available<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `reportEndDate` | `string` | Required | Date to which the requested data is available<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `reportRequestDate` | `string` | Required | The date and time the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `requestedDaysForReport` | `number` | Required | Number of days requested for the report |
| `requestedReportBeginDate` | `string` | Required | Date the report would have began on if enough data was available for which the partner requested<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |

## Example (as JSON)

```json
{
  "reportBeginDate": "2022-03-01",
  "reportEndDate": "2022-03-30",
  "reportRequestDate": "03/30/2022 21:47:19",
  "requestedDaysForReport": 90,
  "requestedReportBeginDate": "2022-01-01"
}
```

