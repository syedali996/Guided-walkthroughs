
# Institution

A financial institution

## Structure

`Institution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint` | Required | The ID of a financial institution, represented as a number |
| `name` | `string \| undefined` | Optional | The name of the institution |
| `transAgg` | `boolean` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product |
| `ach` | `boolean` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product |
| `stateAgg` | `boolean` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product |
| `voi` | `boolean` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product |
| `voa` | `boolean` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product |
| `aha` | `boolean` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product |
| `availBalance` | `boolean` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product |
| `accountOwner` | `boolean` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product |
| `studentLoanData` | `boolean \| undefined` | Optional | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product |
| `loanPaymentDetails` | `boolean \| undefined` | Optional | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product |
| `accountTypeDescription` | `string \| undefined` | Optional | Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance |
| `phone` | `string \| undefined` | Optional | A phone number |
| `urlHomeApp` | `string \| undefined` | Optional | The URL of the institution's primary home page |
| `urlLogonApp` | `string \| undefined` | Optional | The URL of the institution's login page |
| `oauthEnabled` | `boolean` | Required | "true": The institution is an OAuth connection<br><br>"false": The institution isn't an OAuth connection |
| `urlForgotPassword` | `string \| undefined` | Optional | Institution's forgot password page |
| `urlOnlineRegistration` | `string \| undefined` | Optional | Institution's signup page |
| `mClass` | `string \| undefined` | Optional | Institution's class |
| `specialText` | `string \| undefined` | Optional | Special instructions given to customers for login |
| `timeZone` | `string \| undefined` | Optional | The time zone of the institution. |
| `specialInstructions` | `string[] \| undefined` | Optional | Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.<br><br>Note: this helps the customer to provide the proper permission for data needed for the application. |
| `specialInstutionsTitle` | `string \| undefined` | Optional | The title of the special instructions, if one exists or is required. |
| `address` | [`InstitutionAddress \| undefined`](../../doc/models/institution-address.md) | Optional | The address of a financial institution |
| `currency` | `string` | Required | A currency code |
| `email` | `string \| undefined` | Optional | An email address |
| `status` | `string` | Required | Status for the institution: "online", "offline", "maintenance", "testing" |
| `newInstitutionId` | `bigint \| undefined` | Optional | The ID of a financial institution, represented as a number |
| `branding` | [`Branding \| undefined`](../../doc/models/branding.md) | Optional | All assets are SVGs so can be slightly resized without any issues. |
| `oauthInstitutionId` | `bigint \| undefined` | Optional | The ID of a financial institution, represented as a number |

## Example (as JSON)

```json
{
  "id": 4222,
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "oauthEnabled": true,
  "currency": "USD",
  "status": "online"
}
```

