
# Payroll Report Constraints

## Structure

`PayrollReportConstraints`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payrollData` | [`PayrollData`](../../doc/models/payroll-data.md) | Required | - |
| `reportCustomFields` | [`ReportCustomField[] \| undefined`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. |
| `payStatementsFromDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `marketSegment` | `string \| undefined` | Optional | Filter consumer’s data based on the market segment. Currently supported values are; "Mortgage", "KYC", and "Identity". |
| `excludeEmpInfo` | `boolean \| undefined` | Optional | If true is passed, Employment information data will not be searched or returned. |
| `purpose` | `string \| undefined` | Optional | 2-digit code from [Permissible Purpose Codes] (https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. |

## Example (as JSON)

```json
{
  "payrollData": {
    "ssn": "999999999",
    "dob": 1607450357
  }
}
```

