
# Balance Analytics Business Summary

## Structure

`BalanceAnalyticsBusinessSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `balanceAnalyticsMetrics` | [`BalanceAnalyticsMetrics \| undefined`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations across all accounts in the report |
| `currentReportRequest` | [`ObbCurrentReportRequestDetails \| undefined`](../../doc/models/obb-current-report-request-details.md) | Optional | Describes the requested attributes of the report |
| `historicDataAvailability` | [`ObbDataAvailability \| undefined`](../../doc/models/obb-data-availability.md) | Optional | Describes the availability of historical data for all accounts owned by the business |

## Example (as JSON)

```json
{
  "balanceAnalyticsMetrics": null,
  "currentReportRequest": null,
  "historicDataAvailability": null
}
```

