
# VOI Report Account

## Structure

`VOIReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint \| undefined` | Optional | The ID of the account |
| `number` | `string \| undefined` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `ownerName` | `string \| undefined` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `ownerAddress` | `string \| undefined` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `name` | `string \| undefined` | Optional | The account name from the institution |
| `type` | `string \| undefined` | Optional | One of the values from account types |
| `aggregationStatusCode` | `number \| undefined` | Optional | The status of the most recent aggregation attempt |
| `incomeStreams` | [`VOIReportIncomeStream[] \| undefined`](../../doc/models/voi-report-income-stream.md) | Optional | A list of income stream records |
| `balance` | `number \| undefined` | Optional | The cleared balance of the account as-of `balanceDate` |
| `averageMonthlyBalance` | `number \| undefined` | Optional | The average monthly balance of this account |
| `transactions` | [`ReportTransaction[] \| undefined`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `availableBalance` | `number \| undefined` | Optional | The available balance for the account |
| `currentBalance` | `number \| undefined` | Optional | Current balance of the account |
| `beginningBalance` | `number \| undefined` | Optional | Beginning balance of account per the time period in the report |
| `miscDeposits` | [`ReportTransaction[] \| undefined`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null,
  "balance": null,
  "averageMonthlyBalance": null,
  "transactions": null,
  "availableBalance": null,
  "currentBalance": null,
  "beginningBalance": null,
  "miscDeposits": null
}
```

