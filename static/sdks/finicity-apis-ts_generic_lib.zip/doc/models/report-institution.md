
# Report Institution

## Structure

`ReportInstitution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint` | Required | The ID of a financial institution, represented as a number |
| `name` | `string` | Required | Finicity institution name |
| `urlHomeApp` | `string` | Required | The URL of the Financial Institution |
| `accounts` | [`ReportInstitutionAccount[]`](../../doc/models/report-institution-account.md) | Required | A list of account records |

## Example (as JSON)

```json
{
  "id": 4222,
  "name": "FinBank Profiles",
  "urlHomeApp": "http://www.finbank.com",
  "accounts": {
    "id": "6681984",
    "ownerName": "PATRICK & LORRAINE PURCHASER",
    "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
    "name": "Checking",
    "number": "XX1111",
    "type": "checking",
    "aggregationStatusCode": "0",
    "availableBalance": 1000,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    },
    "balance": 501.24,
    "averageMonthlyBalance": 501.02,
    "incomeStreams": {
      "id": "dens28i3vsch-voah",
      "name": "none",
      "status": null,
      "estimateInclusion": null,
      "confidence": 70,
      "cadence": null,
      "netMonthly": [
        {
          "month": 1522562400,
          "net": 2004.77
        }
      ],
      "netAnnual": 110475.7,
      "projectedNetAnnual": 0,
      "estimatedGrossAnnual": 12321.1,
      "projectedGrossAnnual": 151609,
      "averageMonthlyIncomeNet": 9206.31,
      "incomeStreamMonths": 18,
      "transactions": {
        "id": 21284820852,
        "postedDate": 1571313600,
        "description": "ATM CHECK DEPOSIT mm/dd",
        "normalizedPayee": "T-Mobile",
        "institutionTransactionId": "0000000000",
        "category": "Income"
      },
      "daysSinceLastTransaction": 15,
      "nextExpectedTransactionDate": 1572625469
    }
  }
}
```

