
# VOA With Income Report Account

## Structure

`VOAWithIncomeReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint \| undefined` | Optional | The ID of the account |
| `number` | `string \| undefined` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `ownerName` | `string \| undefined` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `ownerAddress` | `string \| undefined` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `name` | `string \| undefined` | Optional | The account name from the institution |
| `type` | `string \| undefined` | Optional | One of the values from account types |
| `availableBalance` | `number \| undefined` | Optional | The available balance for the account |
| `aggregationStatusCode` | `number \| undefined` | Optional | The status of the most recent aggregation attempt |
| `balance` | `number \| undefined` | Optional | The cleared balance of the account as-of balanceDate |
| `balanceDate` | `bigint \| undefined` | Optional | A timestamp showing when the balance was captured |
| `averageMonthlyBalance` | `number \| undefined` | Optional | The average monthly balance of this account |
| `totNumberInsufficientFundsFeeDebitTxAccount` | `bigint \| undefined` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report. |
| `totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `bigint \| undefined` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. |
| `totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `bigint \| undefined` | Optional | The number of days since the most recent insufficient funds transaction, based on the `fromDate` of the report. |
| `transactions` | [`ReportTransaction[] \| undefined`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `details` | [`AccountDetails \| undefined`](../../doc/models/account-details.md) | Optional | - |
| `asset` | [`PrequalificationReportAssetSummary \| undefined`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `incomeStreams` | [`VOAIReportIncomeStream[] \| undefined`](../../doc/models/voai-report-income-stream.md) | Optional | A list of income stream records |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "availableBalance": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "details": null,
  "asset": null,
  "incomeStreams": null
}
```

