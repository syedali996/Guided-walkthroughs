
# Obb Account Details

## Structure

`ObbAccountDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accountNumberDisplay` | `string \| undefined` | Optional | The account number from a financial institution in truncated format<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` |
| `accountOwner` | [`ObbAccountOwner`](../../doc/models/obb-account-owner.md) | Required | Details about who is on record as the owner of the account. May be the business name, the business owner name, or otherwise |
| `aggregationAttemptDate` | `string \| undefined` | Optional | A timestamp showing the last aggregation attempt. This will not be present until you have run your first aggregation for the account.<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `aggregationStatusCode` | `number \| undefined` | Optional | The status of the most recent aggregation attempt. This will not be present until you have run your first aggregation for the account |
| `aggregationSuccessDate` | `string \| undefined` | Optional | A timestamp showing the last successful aggregation of the account. This will not be present until you have run your first aggregation for the account.<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `currency` | `string \| undefined` | Optional | The currency of the account<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `5` |
| `currentBalance` | `number \| undefined` | Optional | Current reported balance of the account |
| `id` | `bigint` | Required | An account ID represented as a number |
| `institution` | [`ObbInstitution`](../../doc/models/obb-institution.md) | Required | Details of the financial institution this account is home to |
| `institutionLoginId` | `bigint \| undefined` | Optional | An institution login ID (from the account record), represented as a number |
| `name` | `string \| undefined` | Optional | The account name from the institution<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` |
| `realAccountNumberLast4` | `number \| undefined` | Optional | The last 4 digits of the ACH account number |
| `status` | `string \| undefined` | Optional | pending during account discovery, always active following successful account activation<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` |
| `type` | `string \| undefined` | Optional | Account type, e.g. checking/saving<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `50` |

## Example (as JSON)

```json
{
  "accountOwner": {
    "address": "123 Main St, Portland, OR 12345",
    "name": "Johnny Appleseed"
  },
  "id": 5011648377,
  "institution": {
    "institutionId": 12345
  }
}
```

