
# Customer Account Position

Details for investment account holdings

## Structure

`CustomerAccountPosition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint \| undefined` | Optional | The id of the investment position |
| `description` | `string \| undefined` | Optional | The description of the holding |
| `symbol` | `string \| undefined` | Optional | The investment position's market ticker symbol |
| `units` | `number \| undefined` | Optional | The number of units of the holding |
| `currentPrice` | `number \| undefined` | Optional | The current price of the investment holding |
| `securityName` | `string \| undefined` | Optional | The security name for the investment holding |
| `transactionType` | `string \| undefined` | Optional | The transaction type of the holding, such as cash, margin, and more |
| `marketValue` | `number \| undefined` | Optional | Market value of an investment position at the time of retrieval |
| `costBasis` | `number \| undefined` | Optional | The total cost of acquiring the security |
| `status` | `string \| undefined` | Optional | The status of the holding |
| `currentPriceDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `securityType` | `string \| undefined` | Optional | Type of security for the investment position |
| `mfType` | `string \| undefined` | Optional | Type of mutual fund, such as open ended |
| `posType` | `string \| undefined` | Optional | Fund type assigned by the FI (long or short) |
| `totalGLDollar` | `number \| undefined` | Optional | Total gain and loss of the position at the time of aggregation in dollars |
| `totalGLPercent` | `number \| undefined` | Optional | Total gain and loss of the position at the time of aggregation in percentage |
| `optionStrikePrice` | `number \| undefined` | Optional | The strike price of the option contract |
| `optionType` | `string \| undefined` | Optional | The type of option contract (PUT or CALL) |
| `optionSharesPerContract` | `number \| undefined` | Optional | The number of shares per option contract |
| `optionExpireDate` | `string \| undefined` | Optional | Expiration date of option |
| `fiAssetClass` | `string \| undefined` | Optional | Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS) |
| `assetClass` | `string \| undefined` | Optional | An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER) |
| `currencyRate` | `number \| undefined` | Optional | Currency rate, ratio of currency to original currency |
| `securityId` | `string \| undefined` | Optional | The security ID of the transaction |
| `securityIdType` | `string \| undefined` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" |
| `costBasisPerShare` | `number \| undefined` | Optional | The per share cost of acquiring the security |
| `subAccountType` | `string \| undefined` | Optional | The subaccount's type, such as cash |
| `securityCurrency` | `string \| undefined` | Optional | Symbol for the currency that the account is being converted into |
| `todayGLDollar` | `number \| undefined` | Optional | The current day's gain and loss of the position at the time of aggregation in dollars |
| `todayGLPercent` | `number \| undefined` | Optional | The current day's gain and loss of the position at the time of aggregation in percentage |

## Example (as JSON)

```json
{
  "id": null,
  "description": null,
  "symbol": null,
  "units": null,
  "currentPrice": null,
  "securityName": null,
  "transactionType": null,
  "marketValue": null,
  "costBasis": null,
  "status": null,
  "currentPriceDate": null,
  "securityType": null,
  "mfType": null,
  "posType": null,
  "totalGLDollar": null,
  "totalGLPercent": null,
  "optionStrikePrice": null,
  "optionType": null,
  "optionSharesPerContract": null,
  "optionExpireDate": null,
  "fiAssetClass": null,
  "assetClass": null,
  "currencyRate": null,
  "securityId": null,
  "securityIdType": null,
  "costBasisPerShare": null,
  "subAccountType": null,
  "securityCurrency": null,
  "todayGLDollar": null,
  "todayGLPercent": null
}
```

