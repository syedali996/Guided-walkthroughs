
# Cash Flow Inflow Attributes

## Structure

`CashFlowInflowAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `averageDepositByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[] \| undefined`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of deposits during periods in the report |
| `countDepositsByMonthForTheReportTimePeriod` | [`ObbDateRangeAndCount[]`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all deposits during periods in the report |
| `historicCountOfDepositTransactions` | `number` | Required | Count of ALL deposits over entire known history of the account (may exceed requested length of report) |
| `historicSumOfDeposits` | `number \| undefined` | Optional | Sum of ALL deposits over entire known history of the account (may exceed requested length of report) |
| `maximumDepositByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum deposit value for different periods in the report |
| `minimumDepositByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum deposit value for different periods in the report |
| `sumDepositsByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[]`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all deposits during periods in the report |

## Example (as JSON)

```json
{
  "countDepositsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfDepositTransactions": 20,
  "maximumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumDepositsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

