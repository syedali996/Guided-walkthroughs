
# VOI Report Constraints

## Structure

`VOIReportConstraints`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accountIds` | `string \| undefined` | Optional | A whitespace-separated list of account IDs to be included in the report (all accounts will be included if not set) |
| `reportCustomFields` | [`ReportCustomField[] \| undefined`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. |
| `fromDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `incomeStreamConfidenceMinimum` | `number \| undefined` | Optional | Include income streams in the report, based on the income stream's confidence score. For example, Use the value 50 to include only income streams with a confidence score of 50 or higher. |

## Example (as JSON)

```json
{
  "accountIds": null,
  "reportCustomFields": null,
  "fromDate": null,
  "incomeStreamConfidenceMinimum": null
}
```

