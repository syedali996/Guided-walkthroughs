
# VOIE Pay Statement 2

## Structure

`VOIEPayStatement2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payPeriod` | `string` | Required | The pay period of the pay statement |
| `billable` | `boolean` | Required | Designates whether the pay statement is billable |
| `assetId` | `string` | Required | The asset ID of the stored pay statement |
| `payDate` | `bigint` | Required | The listed pay date for the pay statement |
| `startDate` | `bigint` | Required | The beginning of the pay period |
| `endDate` | `bigint` | Required | The end of the pay period |
| `netPayCurrent` | `number` | Required | The total pay after deductions for the employee for the current pay period |
| `netPayYTD` | `number` | Required | The total accumulation of pay after deductions for the employee for the current pay year |
| `grossPayCurrent` | `number` | Required | The total pay before deductions for the employee for the current pay period |
| `grossPayYTD` | `number` | Required | The total accumulation of pay before deductions for the employee for the current pay year |
| `payrollProvider` | `string \| undefined` | Optional | The company that provides the pay stub. |
| `employer` | [`Employer`](../../doc/models/employer.md) | Required | - |
| `employee` | [`Employee`](../../doc/models/employee.md) | Required | - |
| `payStat` | [`PayStat[]`](../../doc/models/pay-stat.md) | Required | Information pertaining to the earnings on the pay statement |
| `deductions` | [`Deduction[] \| undefined`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement |
| `directDeposits` | [`DirectDeposit[]`](../../doc/models/direct-deposit.md) | Required | Information pertaining to direct deposits on the pay statement |
| `monthlyIncome` | [`PaystubMonthlyIncomeRecord`](../../doc/models/paystub-monthly-income-record.md) | Required | - |
| `institutions` | `string[]` | Required | Not populated for the voieWithStatement style of paystub report. For the VOIE - Paystub (with TXVerify) reports this would include details of the financial institution accounts and income streams with matching transactions to the pay statement. |
| `errorCode` | `number \| undefined` | Optional | Error code for the asset |
| `errorMessage` | `string \| undefined` | Optional | Error message for the asset |

## Example (as JSON)

```json
{
  "payPeriod": "LastPayPeriod",
  "billable": true,
  "assetId": "6f8fb0a0-e882-4f57-b672-cf53f1397581",
  "payDate": 1559241000,
  "startDate": 1557513000,
  "endDate": 1558722600,
  "netPayCurrent": 1802.22,
  "netPayYTD": 36000,
  "grossPayCurrent": 24200,
  "grossPayYTD": 72600,
  "employer": null,
  "employee": null,
  "payStat": null,
  "directDeposits": null,
  "monthlyIncome": null,
  "institutions": []
}
```

