
# Transaction

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint` | Required | A transaction ID |
| `amount` | `number` | Required | The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values. |
| `accountId` | `bigint` | Required | An account ID represented as a number |
| `customerId` | `bigint` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `status` | `string` | Required | One of "active", "pending", or "shadow" (see [Pending and Shadow Transactions](https://docs.finicity.com/pending-and-shadow-transactions/)) |
| `description` | `string` | Required | The description value is from the financial institution (FI), often known as the payee. The value "No description provided by institution" is returned when the FI doesn't provide one |
| `memo` | `string \| undefined` | Optional | The institution must provide either a description, a memo, or both. We recommended concatenating the two fields into a single value. |
| `type` | `string \| undefined` | Optional | If provided by the institution, the following values may be returned in the field of a record:<br><br>* "atm"<br><br>* "cash"<br><br>* "check"<br><br>* "credit"<br><br>* "debit"<br><br>* "deposit"<br><br>* "directDebit"<br><br>* "directDeposit"<br><br>* "dividend"<br><br>* "fee"<br><br>* "interest"<br><br>* "other"<br><br>* "payment"<br><br>* "pointOfSale"<br><br>* "repeatPayment"<br><br>* "serviceCharge"<br><br>* "transfer" |
| `transactionDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it occurred. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `postedDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it was posted or cleared by the institution. This value isn't required for student loan transaction data. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `createdDate` | `bigint` | Required | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it was added to our platform. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `firstEffectiveDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). Represents the first timestamp of the transaction recorded in the `effectiveDate` field. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `effectiveDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction when it became effective on an account by an institution. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `optionExpireDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). Represents the timestamp of the transaction expiration date when it became expires on an account by an institution. See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `checkNum` | `number \| undefined` | Optional | The check number of the transaction |
| `escrowAmount` | `number \| undefined` | Optional | The portion of the transaction allocated to escrow |
| `feeAmount` | `number \| undefined` | Optional | The portion of the overall transaction amount applied to fees |
| `suspenseAmount` | `number \| undefined` | Optional | Temporarily hold funds if you overpay or underpay your monthly payment |
| `interestAmount` | `number \| undefined` | Optional | The portion of the transaction allocated to interest |
| `principalAmount` | `number \| undefined` | Optional | The portion of the transaction allocated to principal |
| `optionStrikePrice` | `number \| undefined` | Optional | The strike price of the option contract |
| `unitQuantity` | `number \| undefined` | Optional | The number of units (individual shares) in the transaction |
| `unitPrice` | `number \| undefined` | Optional | Share price for the investment unit: stocks, mutual funds, ETFs |
| `categorization` | [`Categorization`](../../doc/models/categorization.md) | Required | Categorization Record |
| `runningBalanceAmount` | `number \| undefined` | Optional | The ending balance after the transaction was posted |
| `subaccountSecurityType` | `string \| undefined` | Optional | The type of sub account the funds came from |
| `commissionAmount` | `number \| undefined` | Optional | Transaction commission |
| `ticker` | `string \| undefined` | Optional | Ticker symbol for the investment related to the transaction |
| `investmentTransactionType` | `string \| undefined` | Optional | Keywords in the `description` and `memo` fields were used to translate investment transactions into these types.<br><br>Possible values:<br><br>* "cancel"<br><br>* "purchaseToClose"<br><br>* "purchaseToCover"<br><br>* "contribution"<br><br>* "optionExercise"<br><br>* "optionExpiration"<br><br>* "fee"<br><br>* "soldToClose"<br><br>* "soldToOpen"<br><br>* "split"<br><br>* "transfer"<br><br>* "returnOfCapital"<br><br>* "income"<br><br>* "purchased"<br><br>* "sold"<br><br>* "dividendreInvest"<br><br>* "tax"<br><br>* "dividend"<br><br>* "reinvestOfIncome"<br><br>* "interest"<br><br>* "deposit"<br><br>* "otherInfo" |
| `taxesAmount` | `number \| undefined` | Optional | Taxes applicable to the investment trade |
| `currencySymbol` | `string \| undefined` | Optional | If the foreign amount value is present then this is the currency code of that foreign amount |
| `incomeType` | `string \| undefined` | Optional | Capital gains applied in short, long, or miscellaneous terms for tax purposes |
| `splitDenominator` | `number \| undefined` | Optional | Denominator of the stock split for the transaction |
| `splitNumerator` | `number \| undefined` | Optional | Numerator of the stock split for the transaction |
| `sharesPerContract` | `number \| undefined` | Optional | Shares per contract of the underlying stock option |
| `subAccountFund` | `string \| undefined` | Optional | The sub account where the funds came from |
| `securityId` | `string \| undefined` | Optional | The security ID of the transaction |
| `securityIdType` | `string \| undefined` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" |

## Example (as JSON)

```json
{
  "id": 21284820852,
  "amount": -828.9,
  "accountId": 5011648377,
  "customerId": 1005061234,
  "status": "active",
  "description": "Buy Stock",
  "createdDate": 1607450357,
  "categorization": {
    "normalizedPayeeName": "Mad Science Research",
    "category": "ATM Fee",
    "country": "USA"
  }
}
```

