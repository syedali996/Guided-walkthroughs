
# Institutions

A list of financial institutions from the Get Institutions API

## Structure

`Institutions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `found` | `number` | Required | The total number of results matching search criteria |
| `displaying` | `number` | Required | The number of results returned |
| `moreAvailable` | `boolean` | Required | If the value of `moreAvailable` is "true", you can retrieve the next page of results by increasing the value of the start parameter in your next request:"...&start=6&limit=5" |
| `createdDate` | `bigint` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `institutions` | [`Institution[]`](../../doc/models/institution.md) | Required | A list of institutions<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `1000` |

## Example (as JSON)

```json
{
  "found": 200,
  "displaying": 2,
  "moreAvailable": true,
  "createdDate": 1607450357,
  "institutions": {
    "id": 4222,
    "transAgg": true,
    "ach": true,
    "stateAgg": false,
    "voi": true,
    "voa": true,
    "aha": false,
    "availBalance": false,
    "accountOwner": true,
    "oauthEnabled": true,
    "currency": "USD",
    "status": "online"
  }
}
```

