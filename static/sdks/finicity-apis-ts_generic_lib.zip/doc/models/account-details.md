
# Account Details

## Structure

`AccountDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `interestMarginBalance` | `number \| undefined` | Optional | Only available for investment accounts. Net interest earned after deducting interest paid out. |
| `availableCashBalance` | `number \| undefined` | Optional | Only available for investment accounts. Amount available for cash withdrawal. |
| `vestedBalance` | `number \| undefined` | Optional | Only available for investment accounts. Vested amount in account. |
| `currentLoanBalance` | `number \| undefined` | Optional | Only available for investment accounts. Current loan balance. |
| `availableBalanceAmount` | `number \| undefined` | Optional | The available balance for the account |

## Example (as JSON)

```json
{
  "interestMarginBalance": null,
  "availableCashBalance": null,
  "vestedBalance": null,
  "currentLoanBalance": null,
  "availableBalanceAmount": null
}
```

