
# Institution Wrapper

## Structure

`InstitutionWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution` | [`Institution`](../../doc/models/institution.md) | Required | A financial institution |

## Example (as JSON)

```json
{
  "institution": {
    "id": 4222,
    "transAgg": true,
    "ach": true,
    "stateAgg": false,
    "voi": true,
    "voa": true,
    "aha": false,
    "availBalance": false,
    "accountOwner": true,
    "oauthEnabled": true,
    "currency": "USD",
    "status": "online"
  }
}
```

