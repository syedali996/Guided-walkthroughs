
# Cash Flow Analytics Metrics

## Structure

`CashFlowAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `inflow` | [`CashFlowInflowAttributes \| undefined`](../../doc/models/cash-flow-inflow-attributes.md) | Optional | Inflow Attributes |
| `negativeTriggers` | [`CashFlowNegativeTriggers \| undefined`](../../doc/models/cash-flow-negative-triggers.md) | Optional | Details of transactions that may be warning signs of bad creditworthiness |
| `outflow` | [`CashFlowOutflowAttributes \| undefined`](../../doc/models/cash-flow-outflow-attributes.md) | Optional | Outflow attributes |
| `revenueByMonthForTheReportTimePeriod` | [`ObbDateRangeAndAmount[] \| undefined`](../../doc/models/obb-date-range-and-amount.md) | Optional | Sum of all transactions categorized as revenue, split by months |
| `revenueForTheReportTimePeriod` | `number \| undefined` | Optional | Sum of all transactions categorized as revenue |
| `transactionAnalytics` | [`CashFlowTransactionAnalyticsAttributes \| undefined`](../../doc/models/cash-flow-transaction-analytics-attributes.md) | Optional | Transaction Analytics Attributes |

## Example (as JSON)

```json
{
  "inflow": null,
  "negativeTriggers": null,
  "outflow": null,
  "revenueByMonthForTheReportTimePeriod": null,
  "revenueForTheReportTimePeriod": null,
  "transactionAnalytics": null
}
```

