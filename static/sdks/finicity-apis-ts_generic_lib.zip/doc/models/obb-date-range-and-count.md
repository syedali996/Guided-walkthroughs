
# Obb Date Range and Count

## Structure

`ObbDateRangeAndCount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `count` | `number` | Required | Count of occurrences for the given period |
| `period` | `string` | Required | Period represented by this metric<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `12` |
| `periodBeginDate` | `string` | Required | Begin date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `periodEndDate` | `string` | Required | End date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |

## Example (as JSON)

```json
{
  "count": 5,
  "period": "last30to1",
  "periodBeginDate": "2022-03-01",
  "periodEndDate": "2022-03-30"
}
```

