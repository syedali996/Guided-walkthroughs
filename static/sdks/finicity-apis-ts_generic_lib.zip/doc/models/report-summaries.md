
# Report Summaries

## Structure

`ReportSummaries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reports` | [`ReportSummary[]`](../../doc/models/report-summary.md) | Required | Data pertaining to each report |

## Example (as JSON)

```json
{
  "reports": {
    "id": "u4hstnnak45g",
    "requestId": "cjqm4wtdcn",
    "requesterName": "Finicity Test API",
    "createdDate": 1607450357,
    "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
    "consumerSsn": "9999",
    "type": "voi",
    "status": "inProgress"
  }
}
```

