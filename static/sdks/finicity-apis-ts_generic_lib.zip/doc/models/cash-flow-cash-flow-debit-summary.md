
# Cash Flow Cash Flow Debit Summary

## Structure

`CashFlowCashFlowDebitSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthlyCashFlowDebitSummaries` | [`CashFlowMonthlyCashFlowDebitSummaries[]`](../../doc/models/cash-flow-monthly-cash-flow-debit-summaries.md) | Required | List of attributes for each month |
| `twelveMonthDebitTotal` | `number` | Required | Sum of all monthly debit transactions for each month by account |
| `twelveMonthDebitTotalLessTransfers` | `number` | Required | Sum of all monthly debit transactions without transfers for the account |
| `sixMonthDebitTotal` | `number` | Required | Six month sum of all debit transactions by account |
| `sixMonthDebitTotalLessTransfers` | `number` | Required | Six month sum of all debit transactions without transfers for the account |
| `twoMonthDebitTotal` | `number` | Required | Two month sum of all debit transactions by account |
| `twoMonthDebitTotalLessTransfers` | `number` | Required | Two month sum of all debit transactions without transfers for the account |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebitSummaries": {
    "month": 1512111600,
    "numberOfDebits": "1500",
    "totalDebitsAmount": -12345.46,
    "largestDebit": -20000,
    "numberOfDebitsLessTransfers": "5",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": -1200,
  "twelveMonthDebitTotalLessTransfers": -1000,
  "sixMonthDebitTotal": -750,
  "sixMonthDebitTotalLessTransfers": -500,
  "twoMonthDebitTotal": -150,
  "twoMonthDebitTotalLessTransfers": -100
}
```

