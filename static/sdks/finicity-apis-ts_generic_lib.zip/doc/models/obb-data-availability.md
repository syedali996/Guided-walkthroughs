
# Obb Data Availability

## Structure

`ObbDataAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `historicAvailabilityBeginDate` | `string` | Required | Begin date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `historicAvailabilityEndDate` | `string` | Required | End date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `historicAvailableDays` | `number` | Required | Days for which transaction details are available |
| `historicDataAvailability` | `string` | Required | Description of historic data availability<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "historicAvailabilityBeginDate": "2022-03-01",
  "historicAvailabilityEndDate": "2022-03-30",
  "historicAvailableDays": 30,
  "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
}
```

