
# Prequalification Report Account

## Structure

`PrequalificationReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint \| undefined` | Optional | The ID of the account |
| `number` | `string \| undefined` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `ownerName` | `string \| undefined` | Optional | The name of the account owner. If no owner information is available, this field won't appear in the report. |
| `ownerAddress` | `string \| undefined` | Optional | The mailing address of the account owner. If no owner information is available, this field won't appear in the report. |
| `name` | `string \| undefined` | Optional | The account name from the institution |
| `type` | `string \| undefined` | Optional | One of the values from account types |
| `aggregationStatusCode` | `number \| undefined` | Optional | The status of the most recent aggregation attempt |
| `balance` | `number \| undefined` | Optional | The cleared balance of the account as-of `balanceDate` |
| `balanceDate` | `bigint \| undefined` | Optional | A timestamp of the balance |
| `availableBalance` | `number \| undefined` | Optional | Available balance |
| `averageMonthlyBalance` | `number \| undefined` | Optional | The average monthly balance of the account |
| `totNumberInsufficientFundsFeeDebitTxAccount` | `number \| undefined` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report |
| `totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `number \| undefined` | Optional | The total number of  insufficient funds fees for the account over six months |
| `totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `bigint \| undefined` | Optional | The total number of days since the most recent insufficient funds fee for the account |
| `transactions` | [`ReportTransaction[] \| undefined`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `asset` | [`PrequalificationReportAssetSummary \| undefined`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `details` | [`AccountDetails \| undefined`](../../doc/models/account-details.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "availableBalance": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "asset": null,
  "details": null
}
```

