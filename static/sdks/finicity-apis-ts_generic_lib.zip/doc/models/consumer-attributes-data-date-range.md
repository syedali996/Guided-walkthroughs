
# Consumer Attributes Data Date Range

## Structure

`ConsumerAttributesDataDateRange`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `from` | `string` | Required | A 'YYYY-MM-DD' date notation as defined by [RFC 3339, section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) |
| `to` | `string` | Required | A 'YYYY-MM-DD' date notation as defined by [RFC 3339, section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6) |

## Example (as JSON)

```json
{
  "From": "2022-04-12",
  "To": "2022-04-12"
}
```

