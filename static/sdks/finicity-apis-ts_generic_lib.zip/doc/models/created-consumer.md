
# Created Consumer

A consumer that was just created

## Structure

`CreatedConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `createdDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `customerId` | `bigint \| undefined` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |

## Example (as JSON)

```json
{
  "id": null,
  "createdDate": null,
  "customerId": null
}
```

