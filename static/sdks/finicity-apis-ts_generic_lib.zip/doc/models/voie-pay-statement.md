
# VOIE Pay Statement

## Structure

`VOIEPayStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payPeriod` | `string \| undefined` | Optional | The pay period of the pay statement |
| `billable` | `boolean \| undefined` | Optional | Designates whether the pay statement is billable |
| `assetId` | `string \| undefined` | Optional | The asset ID of the stored pay statement |
| `payDate` | `bigint \| undefined` | Optional | The listed pay date for the pay statement |
| `startDate` | `bigint \| undefined` | Optional | The beginning of the pay period |
| `endDate` | `bigint \| undefined` | Optional | The end of the pay period |
| `netPayCurrent` | `number \| undefined` | Optional | The total pay after deductions for the employee for the current pay period |
| `netPayYTD` | `number \| undefined` | Optional | The total accumulation of pay after deductions for the employee for the current pay year |
| `grossPayCurrent` | `number \| undefined` | Optional | The total pay before deductions for the employee for the current pay period |
| `grossPayYTD` | `number \| undefined` | Optional | The total accumulation of pay before deductions for the employee for the current pay year |
| `payrollProvider` | `string \| undefined` | Optional | The company that provides the pay stub. |
| `employer` | [`Employer \| undefined`](../../doc/models/employer.md) | Optional | - |
| `employee` | [`Employee \| undefined`](../../doc/models/employee.md) | Optional | - |
| `payStat` | [`PayStat[] \| undefined`](../../doc/models/pay-stat.md) | Optional | Information pertaining to the earnings on the pay statement |
| `deductions` | [`Deduction[] \| undefined`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement |
| `directDeposits` | [`DirectDeposit[] \| undefined`](../../doc/models/direct-deposit.md) | Optional | Information pertaining to direct deposits on the pay statement |

## Example (as JSON)

```json
{
  "payPeriod": null,
  "billable": null,
  "assetId": null,
  "payDate": null,
  "startDate": null,
  "endDate": null,
  "netPayCurrent": null,
  "netPayYTD": null,
  "grossPayCurrent": null,
  "grossPayYTD": null,
  "payrollProvider": null,
  "employer": null,
  "employee": null,
  "payStat": null,
  "deductions": null,
  "directDeposits": null
}
```

