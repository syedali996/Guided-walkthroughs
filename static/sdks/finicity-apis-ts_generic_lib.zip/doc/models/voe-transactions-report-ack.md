
# VOE Transactions Report Ack

## Structure

`VOETransactionsReportAck`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | A report ID |
| `customerType` | `string` | Required | The type of customer ("active" or "testing" or "" for all types) |
| `customerId` | `bigint` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `requestId` | `string` | Required | Finicity indicator to track all activity associated with this report |
| `requesterName` | `string` | Required | Name of a Finicity partner |
| `createdDate` | `bigint` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `title` | `string` | Required | Title of the report |
| `consumerId` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `consumerSsn` | `string` | Required | Last 4 digits of a SSN |
| `type` | `string` | Required | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" |
| `status` | `string` | Required | A report generation status. Possible values: "inProgress", "success", "failure". |
| `errors` | [`ErrorMessage[] \| undefined`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation |
| `portfolioId` | `string` | Required | A unique identifier that will be consistent across all reports created for the same customer |
| `constraints` | [`VOETransactionsReportConstraintsOut`](../../doc/models/voe-transactions-report-constraints-out.md) | Required | - |

## Example (as JSON)

```json
{
  "id": "u4hstnnak45g",
  "customerType": "active",
  "customerId": 1005061234,
  "requestId": "cjqm4wtdcn",
  "requesterName": "Finicity Test API",
  "createdDate": 1607450357,
  "title": "Finicity Asset Ready Report (CRA)",
  "consumerId": "0bf46322c167b562e6cbed9d40e19a4c",
  "consumerSsn": "9999",
  "type": "voi",
  "status": "inProgress",
  "portfolioId": "y4zsgccj4xpw-6-port",
  "constraints": null
}
```

