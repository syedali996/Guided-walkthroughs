
# VOA Report

A VOA report

## Structure

`VOAReport`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | A report ID |
| `customerType` | `string \| undefined` | Optional | The type of customer ("active" or "testing" or "" for all types) |
| `customerId` | `bigint \| undefined` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `requestId` | `string \| undefined` | Optional | Finicity indicator to track all activity associated with this report |
| `requesterName` | `string \| undefined` | Optional | Name of a Finicity partner |
| `createdDate` | `bigint \| undefined` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `title` | `string \| undefined` | Optional | Title of the report |
| `consumerId` | `string \| undefined` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `consumerSsn` | `string \| undefined` | Optional | Last 4 digits of a SSN |
| `type` | `string \| undefined` | Optional | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" |
| `status` | `string \| undefined` | Optional | A report generation status. Possible values: "inProgress", "success", "failure". |
| `errors` | [`ErrorMessage[] \| undefined`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation |
| `portfolioId` | `string \| undefined` | Optional | A unique identifier that will be consistent across all reports created for the same customer |
| `startDate` | `bigint \| undefined` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `endDate` | `bigint \| undefined` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `days` | `number \| undefined` | Optional | Number of days covered by the report |
| `seasoned` | `boolean \| undefined` | Optional | "true" if the report covers more than 180 days |
| `consolidatedAvailableBalance` | `number \| undefined` | Optional | The sum of available balance for all of the accounts included in the report |
| `institutions` | [`ReportInstitution[] \| undefined`](../../doc/models/report-institution.md) | Optional | A list of institution records |
| `assets` | [`PrequalificationReportAssetSummary \| undefined`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "customerType": null,
  "customerId": null,
  "requestId": null,
  "requesterName": null,
  "createdDate": null,
  "title": null,
  "consumerId": null,
  "consumerSsn": null,
  "type": null,
  "status": null,
  "errors": null,
  "portfolioId": null,
  "startDate": null,
  "endDate": null,
  "days": null,
  "seasoned": null,
  "consolidatedAvailableBalance": null,
  "institutions": null,
  "assets": null
}
```

