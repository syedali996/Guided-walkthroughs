
# Cash Flow Cash Flow Characteristic

## Structure

`CashFlowCashFlowCharacteristic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `monthlyCashFlowCharacteristics` | [`CashFlowMonthlyCashFlowCharacteristics[]`](../../doc/models/cash-flow-monthly-cash-flow-characteristics.md) | Required | List of attributes for each month |
| `averageMonthlyNet` | `number` | Required | Average (Total Credits - Total Debits) for the account |
| `averageMonthlyNetLessTransfers` | `number` | Required | Average (Total Credits - Total Debits) without transfers for the account |
| `twelveMonthTotalNet` | `number` | Required | Sum of all monthly (Total Credits - Total Debits) each month for the account |
| `twelveMonthTotalNetLessTransfers` | `number` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers for the account |
| `sixMonthAverageTotalCreditsLessTotalDebits` | `number` | Required | 6 Month Average (Total Credits - Total Debits) |
| `sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `number` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) |
| `twoMonthAverageTotalCreditsLessTotalDebits` | `number` | Required | 2 Month Average (Total Credits - Total Debits) |
| `twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `number` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristics": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 2350,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

