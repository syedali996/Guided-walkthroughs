# Payments

Fetch ACH details and account balances

```ts
const paymentsController = new PaymentsController(client);
```

## Class Name

`PaymentsController`

## Methods

* [Get Account Owner](../../doc/controllers/payments.md#get-account-owner)
* [Get Loan Payment Details](../../doc/controllers/payments.md#get-loan-payment-details)
* [Get Account ACH Details](../../doc/controllers/payments.md#get-account-ach-details)
* [Get Available Balance Live](../../doc/controllers/payments.md#get-available-balance-live)
* [Get Available Balance](../../doc/controllers/payments.md#get-available-balance)


# Get Account Owner

Retrieve the names and addresses of the account owner from a financial institution.

Note: this is a premium service, billable per every successful API call.

This service retrieves account data from the institution. This usually returns quickly, but in some scenarios may take a few minutes to complete. In the event of a timeout condition, retry the call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getAccountOwner(
  customerId: string,
  accountId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<AccountOwner>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`AccountOwner`](../../doc/models/account-owner.md)

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
try {
  const { result, ...httpResponse } = await paymentsController.getAccountOwner(customerId, accountId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get Loan Payment Details

Return the loan payment details of the customer for a loan-type account.

Note: this is a premium service, billable per every successful API call.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getLoanPaymentDetails(
  customerId: string,
  accountId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<LoanPaymentDetails>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`LoanPaymentDetails`](../../doc/models/loan-payment-details.md)

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
try {
  const { result, ...httpResponse } = await paymentsController.getLoanPaymentDetails(customerId, accountId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get Account ACH Details

Return the real account number and routing number details for an ACH payment.

Note: this is a premium service, billable per every successful API call.

_Supported account types_: "checking", "savings", "moneyMarket", "loan"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getAccountACHDetails(
  customerId: string,
  accountId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ACHDetails>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`ACHDetails`](../../doc/models/ach-details.md)

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
try {
  const { result, ...httpResponse } = await paymentsController.getAccountACHDetails(customerId, accountId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get Available Balance Live

Retrieve the available and cleared account balances for a single account in real-time directly from a financial institution.

Note: this is a premium service, billable per every successful API call.

_Supported account types_: "checking", "savings", "moneyMarket", "cd"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getAvailableBalanceLive(
  customerId: string,
  accountId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<AvailableBalance>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`AvailableBalance`](../../doc/models/available-balance.md)

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
try {
  const { result, ...httpResponse } = await paymentsController.getAvailableBalanceLive(customerId, accountId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get Available Balance

Retrieve the latest cached available and cleared account balances for a customer. Since we update and store balances throughout the day, this is the most accurate balance information available when a connection to a financial institution is unavailable or when a faster response is needed. Only deposit account types are supported: Checking, Savings, Money Market, and CD.

Note: this is a premium service, billable per every successful API call. Enrollment is required.

_Supported account types_: "checking", "savings", "moneyMarket", "cd"

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getAvailableBalance(
  customerId: string,
  accountId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<AvailableBalance>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`AvailableBalance`](../../doc/models/available-balance.md)

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
try {
  const { result, ...httpResponse } = await paymentsController.getAvailableBalance(customerId, accountId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |

