# Bank Statements

```ts
const bankStatementsController = new BankStatementsController(client);
```

## Class Name

`BankStatementsController`

## Methods

* [Get Customer Account Statement](../../doc/controllers/bank-statements.md#get-customer-account-statement)
* [Generate Statement Report](../../doc/controllers/bank-statements.md#generate-statement-report)


# Get Customer Account Statement

Retrieve the customer's bank statements in PDF format. Up to 24 months of history is available depending on the financial institution. Since this is a premium service, charges incur per each successful statement retrieved.

For certified financial institutions, statements are available for the following account types:

* Checking
* Savings
* Money market
* CDs
* Investments
* Mortgage
* Credit cards
* Loans
* Line of credit
* Student Loans

Note: setting the timeout to 180 seconds is recommended to allow enough time for a response.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getCustomerAccountStatement(
  customerId: string,
  accountId: string,
  index?: number,
  type?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<NodeJS.ReadableStream | Blob>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `index` | `number \| undefined` | Query, Optional | Request statements from 1-24. By default, 1 is the most recent statement. Increase the index value to count back (by month) and retrieve its most recent statement.<br>**Default**: `1`<br>**Constraints**: `<= 24` |
| `type` | `string \| undefined` | Query, Optional | The type of statement to retrieve |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`NodeJS.ReadableStream | Blob`

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
const index = 1;
const type = 'taxStatement';
try {
  const { result, ...httpResponse } = await bankStatementsController.getCustomerAccountStatement(customerId, accountId, index, type);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Generate Statement Report

Generate a Statement Report report for the given accounts under the given customer.

This is a premium service. A billable event will be created upon the successful generation of the Statement Report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async generateStatementReport(
  customerId: string,
  body: StatementReportConstraints,
  callbackUrl?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<StatementReportAck>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`StatementReportConstraints`](../../doc/models/statement-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `string \| undefined` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`StatementReportAck`](../../doc/models/statement-report-ack.md)

## Example Usage

```ts
const customerId = '1005061234';
const contentType = null;
const bodyStatementReportData: StatementData = {
  accountId: BigInt(1000076901),
};
bodyStatementReportData.index = 1;

const bodyReportCustomFields: ReportCustomField[] = [];

const bodyreportCustomFields0: ReportCustomField = {};
bodyreportCustomFields0.label = 'loanID';
bodyreportCustomFields0.value = '123456';
bodyreportCustomFields0.shown = true;

bodyReportCustomFields[0] = bodyreportCustomFields0;

const body: StatementReportConstraints = {
  statementReportData: bodyStatementReportData,
};
body.reportCustomFields = bodyReportCustomFields;

const callbackUrl = 'https://finicity-test/webhook';
try {
  const { result, ...httpResponse } = await bankStatementsController.generateStatementReport(customerId, body, callbackUrl);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as JSON)*

```json
{
  "id": "38dknche83oh-statement",
  "portfolioId": "sy7aa68w2ugx-1-port",
  "customerType": "active",
  "customerId": 1010560999,
  "requestId": "ny7x32stfq",
  "requesterName": "Demo",
  "createdDate": 1596226182,
  "title": "Finicity Statement Report",
  "consumerId": "555595ec74c8ec57adf44dadddb6a35",
  "consumerSsn": "1234",
  "constraints": {
    "statementReportData": {
      "accountId": 1000076901,
      "index": 1
    },
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "123456",
        "shown": true
      }
    ]
  },
  "type": "statement",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |

