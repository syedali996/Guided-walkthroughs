# Transactions

Fetch customer and account transactions and generate reports asynchronously

```ts
const transactionsController = new TransactionsController(client);
```

## Class Name

`TransactionsController`

## Methods

* [Load Historic Transactions for Customer Account](../../doc/controllers/transactions.md#load-historic-transactions-for-customer-account)
* [Get All Customer Transactions](../../doc/controllers/transactions.md#get-all-customer-transactions)
* [Get Customer Transaction](../../doc/controllers/transactions.md#get-customer-transaction)
* [Get Customer Account Transactions](../../doc/controllers/transactions.md#get-customer-account-transactions)
* [Generate Transactions Report](../../doc/controllers/transactions.md#generate-transactions-report)


# Load Historic Transactions for Customer Account

Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.

This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.)

The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.

In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:

* The institution's policy has changed, making more transactions available
* Finicity has now added a longer transaction history support for the institution
* The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team

In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async loadHistoricTransactionsForCustomerAccount(
  customerId: string,
  accountId: string,
  body?: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `body` | `unknown \| undefined` | Body, Optional | No payload expected |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
const contentType = null;
try {
  const { result, ...httpResponse } = await transactionsController.loadHistoricTransactionsForCustomerAccount(customerId, accountId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get All Customer Transactions

Get all transactions available for this customer within the given date range, across all accounts. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.

Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the service Load Historic Transactions for Account.

There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getAllCustomerTransactions(
  customerId: string,
  fromDate: bigint,
  toDate: bigint,
  start?: number,
  limit?: number,
  sort?: string,
  includePending?: boolean,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Transactions>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `fromDate` | `bigint` | Query, Required | A start date |
| `toDate` | `bigint` | Query, Required | A end date |
| `start` | `number \| undefined` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `number \| undefined` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `sort` | `string \| undefined` | Query, Optional | Date sort order: "asc" for ascending, "desc" for descending<br>**Default**: `'desc'` |
| `includePending` | `boolean \| undefined` | Query, Optional | If pending transactions must be included<br>**Default**: `false` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`Transactions`](../../doc/models/transactions.md)

## Example Usage

```ts
const customerId = '1005061234';
const fromDate = BigInt(1607450357);
const toDate = BigInt(1607450357);
const start = 1;
const limit = 25;
const sort = 'desc';
const includePending = false;
try {
  const { result, ...httpResponse } = await transactionsController.getAllCustomerTransactions(customerId, fromDate, toDate, start, limit, sort, includePending);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get Customer Transaction

Get details for the given transaction.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getCustomerTransaction(
  customerId: string,
  transactionId: bigint,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Transaction>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `transactionId` | `bigint` | Template, Required | A transaction ID |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`Transaction`](../../doc/models/transaction.md)

## Example Usage

```ts
const customerId = '1005061234';
const transactionId = BigInt(21284820852);
try {
  const { result, ...httpResponse } = await transactionsController.getCustomerTransaction(customerId, transactionId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Get Customer Account Transactions

Get all transactions available for this customer account within the given date range. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.

Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the Cash Flow Verification service Load Historic Transactions for Account.

There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async getCustomerAccountTransactions(
  customerId: string,
  accountId: string,
  fromDate: bigint,
  toDate: bigint,
  start?: number,
  limit?: number,
  sort?: string,
  includePending?: boolean,
  requestOptions?: RequestOptions
): Promise<ApiResponse<Transactions>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `fromDate` | `bigint` | Query, Required | A start date |
| `toDate` | `bigint` | Query, Required | A end date |
| `start` | `number \| undefined` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `number \| undefined` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `sort` | `string \| undefined` | Query, Optional | Date sort order: "asc" for ascending, "desc" for descending<br>**Default**: `'desc'` |
| `includePending` | `boolean \| undefined` | Query, Optional | If pending transactions must be included<br>**Default**: `false` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`Transactions`](../../doc/models/transactions.md)

## Example Usage

```ts
const customerId = '1005061234';
const accountId = '5011648377';
const fromDate = BigInt(1607450357);
const toDate = BigInt(1607450357);
const start = 1;
const limit = 25;
const sort = 'desc';
const includePending = false;
try {
  const { result, ...httpResponse } = await transactionsController.getCustomerAccountTransactions(customerId, accountId, fromDate, toDate, start, limit, sort, includePending);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |


# Generate Transactions Report

Generate a Transaction Report for the given accounts under the given customer. This service retrieves up to 24 months of transaction history for the given customer. It then uses this information to generate the Transaction Report.

This is a premium service. A billable event will be created upon the successful generation of the Transactions Report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

There cannot be more than 24 months between `fromDate` and `toDate`.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```ts
async generateTransactionsReport(
  customerId: string,
  toDate: bigint,
  body: TransactionsReportConstraints,
  callbackUrl?: string,
  includePending?: boolean,
  requestOptions?: RequestOptions
): Promise<ApiResponse<TransactionsReportAck>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `toDate` | `bigint` | Query, Required | A end date |
| `body` | [`TransactionsReportConstraints`](../../doc/models/transactions-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `string \| undefined` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |
| `includePending` | `boolean \| undefined` | Query, Optional | If pending transactions must be included<br>**Default**: `false` |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`TransactionsReportAck`](../../doc/models/transactions-report-ack.md)

## Example Usage

```ts
const customerId = '1005061234';
const toDate = BigInt(1607450357);
const contentType = null;
const bodyReportCustomFields: ReportCustomField[] = [];

const bodyreportCustomFields0: ReportCustomField = {};
bodyreportCustomFields0.label = 'loanID';
bodyreportCustomFields0.value = '12345';
bodyreportCustomFields0.shown = true;

bodyReportCustomFields[0] = bodyreportCustomFields0;

const bodyreportCustomFields1: ReportCustomField = {};
bodyreportCustomFields1.label = 'trackingID';
bodyreportCustomFields1.value = '5555';
bodyreportCustomFields1.shown = true;

bodyReportCustomFields[1] = bodyreportCustomFields1;

const bodyreportCustomFields2: ReportCustomField = {};
bodyreportCustomFields2.label = 'loanType';
bodyreportCustomFields2.value = 'car';
bodyreportCustomFields2.shown = false;

bodyReportCustomFields[2] = bodyreportCustomFields2;

const bodyreportCustomFields3: ReportCustomField = {};
bodyreportCustomFields3.label = 'vendorID';
bodyreportCustomFields3.value = '1613aa23';
bodyreportCustomFields3.shown = true;

bodyReportCustomFields[3] = bodyreportCustomFields3;

const bodyreportCustomFields4: ReportCustomField = {};
bodyreportCustomFields4.label = 'vendorName';
bodyreportCustomFields4.value = 'PSC Finance';
bodyreportCustomFields4.shown = false;

bodyReportCustomFields[4] = bodyreportCustomFields4;

const body: TransactionsReportConstraints = {};
body.accountIds = '1027339038 1027339039';
body.fromDate = BigInt(1580558400);
body.reportCustomFields = bodyReportCustomFields;

const callbackUrl = 'https://finicity-test/webhook';
const includePending = false;
try {
  const { result, ...httpResponse } = await transactionsController.generateTransactionsReport(customerId, toDate, body, callbackUrl, includePending);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch(error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageError`](../../doc/models/error-message-error.md) |
| 404 | The resource doesn't exist | [`ErrorMessageError`](../../doc/models/error-message-error.md) |

