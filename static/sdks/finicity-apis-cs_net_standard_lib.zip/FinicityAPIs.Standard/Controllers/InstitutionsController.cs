// <copyright file="InstitutionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// InstitutionsController.
    /// </summary>
    public class InstitutionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InstitutionsController"/> class.
        /// </summary>
        internal InstitutionsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Search for certified financial institutions w/RSSD.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="search">Optional parameter: Search term (financial institution `name` field). Leave empty for all FIs..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="type">Optional parameter: A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner".</param>
        /// <returns>Returns the Models.CertifiedInstitutions response from the API call.</returns>
        public Models.CertifiedInstitutions GetCertifiedInstitutionsWithRSSD(
                string search = null,
                int? start = 1,
                int? limit = 25,
                string type = null)
            => CoreHelper.RunTask(GetCertifiedInstitutionsWithRSSDAsync(search, start, limit, type));

        /// <summary>
        /// Search for certified financial institutions w/RSSD.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="search">Optional parameter: Search term (financial institution `name` field). Leave empty for all FIs..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="type">Optional parameter: A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner".</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CertifiedInstitutions response from the API call.</returns>
        public async Task<Models.CertifiedInstitutions> GetCertifiedInstitutionsWithRSSDAsync(
                string search = null,
                int? start = 1,
                int? limit = 25,
                string type = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CertifiedInstitutions>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/institution/v2/certifiedInstitutions/rssd")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Query(_query => _query.Setup("search", search))
                      .Query(_query => _query.Setup("start", (start != null) ? start : 1))
                      .Query(_query => _query.Setup("limit", (limit != null) ? limit : 25))
                      .Query(_query => _query.Setup("type", type))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CertifiedInstitutions>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Search for financial institutions.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="search">Optional parameter: Search term (financial institution `name` field). Leave empty for all FIs..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="type">Optional parameter: A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner".</param>
        /// <returns>Returns the Models.Institutions response from the API call.</returns>
        public Models.Institutions GetInstitutions(
                string search = null,
                int? start = 1,
                int? limit = 25,
                string type = null)
            => CoreHelper.RunTask(GetInstitutionsAsync(search, start, limit, type));

        /// <summary>
        /// Search for financial institutions.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="search">Optional parameter: Search term (financial institution `name` field). Leave empty for all FIs..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="type">Optional parameter: A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner".</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Institutions response from the API call.</returns>
        public async Task<Models.Institutions> GetInstitutionsAsync(
                string search = null,
                int? start = 1,
                int? limit = 25,
                string type = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Institutions>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/institution/v2/institutions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Query(_query => _query.Setup("search", search))
                      .Query(_query => _query.Setup("start", (start != null) ? start : 1))
                      .Query(_query => _query.Setup("limit", (limit != null) ? limit : 25))
                      .Query(_query => _query.Setup("type", type))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.Institutions>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Search for financial institutions by certified product.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="search">Optional parameter: Search term (financial institution `name` field). Leave empty for all FIs..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="type">Optional parameter: A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner".</param>
        /// <returns>Returns the Models.CertifiedInstitutions response from the API call.</returns>
        public Models.CertifiedInstitutions GetCertifiedInstitutions(
                string search = null,
                int? start = 1,
                int? limit = 25,
                string type = null)
            => CoreHelper.RunTask(GetCertifiedInstitutionsAsync(search, start, limit, type));

        /// <summary>
        /// Search for financial institutions by certified product.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="search">Optional parameter: Search term (financial institution `name` field). Leave empty for all FIs..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="type">Optional parameter: A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner".</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CertifiedInstitutions response from the API call.</returns>
        public async Task<Models.CertifiedInstitutions> GetCertifiedInstitutionsAsync(
                string search = null,
                int? start = 1,
                int? limit = 25,
                string type = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CertifiedInstitutions>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/institution/v2/certifiedInstitutions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Query(_query => _query.Setup("search", search))
                      .Query(_query => _query.Setup("start", (start != null) ? start : 1))
                      .Query(_query => _query.Setup("limit", (limit != null) ? limit : 25))
                      .Query(_query => _query.Setup("type", type))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CertifiedInstitutions>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get financial institution details by ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="institutionId">Required parameter: The institution ID.</param>
        /// <returns>Returns the Models.InstitutionWrapper response from the API call.</returns>
        public Models.InstitutionWrapper GetInstitution(
                long institutionId)
            => CoreHelper.RunTask(GetInstitutionAsync(institutionId));

        /// <summary>
        /// Get financial institution details by ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="institutionId">Required parameter: The institution ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.InstitutionWrapper response from the API call.</returns>
        public async Task<Models.InstitutionWrapper> GetInstitutionAsync(
                long institutionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.InstitutionWrapper>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/institution/v2/institutions/{institutionId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("institutionId", institutionId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.InstitutionWrapper>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Return the branding information for a financial institution.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="institutionId">Required parameter: The institution ID.</param>
        /// <returns>Returns the Models.BrandingWrapper response from the API call.</returns>
        public Models.BrandingWrapper GetInstitutionBranding(
                long institutionId)
            => CoreHelper.RunTask(GetInstitutionBrandingAsync(institutionId));

        /// <summary>
        /// Return the branding information for a financial institution.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="institutionId">Required parameter: The institution ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BrandingWrapper response from the API call.</returns>
        public async Task<Models.BrandingWrapper> GetInstitutionBrandingAsync(
                long institutionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.BrandingWrapper>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/institution/v2/institutions/{institutionId}/branding")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("institutionId", institutionId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.BrandingWrapper>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}