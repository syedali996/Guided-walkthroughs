// <copyright file="BalanceAnalyticsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// BalanceAnalyticsController.
    /// </summary>
    public class BalanceAnalyticsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAnalyticsController"/> class.
        /// </summary>
        internal BalanceAnalyticsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Balance Analytics for Business analyzes bank balances over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Current/available account balances.
        /// * Minimum/maximum/average account balances over the requested time.
        ///   period and broken down by month.
        /// * Daily ending balance of accounts for each day in the requested time.
        ///   period.
        /// * Propensity of the customer's account balances to increase week over.
        ///   week.
        /// * Number of days in the requested time period ending with a negative.
        ///   balance.
        /// This version of the API is intended for piloting and integration testing your application with the Balance Analytics product. It does not adhere to FCRA requirements, and should not be used for production/lending purposes. See _Generate Balance Analytics - FCRA_ for the FCRA compliant version of this API.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Balance Analytics Report_ (operation: _GetObbAnalyticsReport_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public Models.BalanceAndCashFlowAnalyticsReportAck GenerateBalanceAnalytics(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null)
            => CoreHelper.RunTask(GenerateBalanceAnalyticsAsync(customerId, body, referenceNumber));

        /// <summary>
        /// Balance Analytics for Business analyzes bank balances over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Current/available account balances.
        /// * Minimum/maximum/average account balances over the requested time.
        ///   period and broken down by month.
        /// * Daily ending balance of accounts for each day in the requested time.
        ///   period.
        /// * Propensity of the customer's account balances to increase week over.
        ///   week.
        /// * Number of days in the requested time period ending with a negative.
        ///   balance.
        /// This version of the API is intended for piloting and integration testing your application with the Balance Analytics product. It does not adhere to FCRA requirements, and should not be used for production/lending purposes. See _Generate Balance Analytics - FCRA_ for the FCRA compliant version of this API.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Balance Analytics Report_ (operation: _GetObbAnalyticsReport_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public async Task<Models.BalanceAndCashFlowAnalyticsReportAck> GenerateBalanceAnalyticsAsync(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.BalanceAndCashFlowAnalyticsReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/analytics/balance/v1/customer/{customerId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("reference-number", referenceNumber))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("A bad request was provided", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized request", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Access forbidden", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Resource not found", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("Resource conflict", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.BalanceAndCashFlowAnalyticsReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Balance Analytics for Business analyzes bank balances over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Current/available account balances.
        /// * Minimum/maximum/average account balances over the requested time.
        ///   period and broken down by month.
        /// * Daily ending balance of accounts for each day in the requested time.
        ///   period.
        /// * Propensity of the customer's account balances to increase week over.
        ///   week.
        /// * Number of days in the requested time period ending with a negative.
        ///   balance.
        /// This version of the API is intended for production use. It maintains and enforces all compliance with FCRA rules and requirements.
        /// *Note:* this is a premium service, billable per every successful API call for non-testing customers.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Balance Analytics Report - FCRA_ (operation: _GetObbAnalyticsReportFCRA_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public Models.BalanceAndCashFlowAnalyticsReportAck GenerateBalanceAnalyticsFcra(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null)
            => CoreHelper.RunTask(GenerateBalanceAnalyticsFcraAsync(customerId, body, referenceNumber));

        /// <summary>
        /// Balance Analytics for Business analyzes bank balances over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Current/available account balances.
        /// * Minimum/maximum/average account balances over the requested time.
        ///   period and broken down by month.
        /// * Daily ending balance of accounts for each day in the requested time.
        ///   period.
        /// * Propensity of the customer's account balances to increase week over.
        ///   week.
        /// * Number of days in the requested time period ending with a negative.
        ///   balance.
        /// This version of the API is intended for production use. It maintains and enforces all compliance with FCRA rules and requirements.
        /// *Note:* this is a premium service, billable per every successful API call for non-testing customers.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Balance Analytics Report - FCRA_ (operation: _GetObbAnalyticsReportFCRA_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public async Task<Models.BalanceAndCashFlowAnalyticsReportAck> GenerateBalanceAnalyticsFcraAsync(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.BalanceAndCashFlowAnalyticsReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/analytics/balance/v1/customer/{customerId}/fcra")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("reference-number", referenceNumber))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("A bad request was provided", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized request", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Access forbidden", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Resource not found", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("Resource conflict", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.BalanceAndCashFlowAnalyticsReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve the report saved by _Generate Balance Analytics_ or _Generate Cash Flow Analytics_. Requires the report ID generated by the previous call.
        /// Report data can either be retrieved as a JSON document or PDF file.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="obbReportId">Required parameter: Report ID generated and returned by OBB products.</param>
        /// <returns>Returns the Models.GetObbAnalyticsReportResponse response from the API call.</returns>
        public Models.GetObbAnalyticsReportResponse GetObbAnalyticsReport(
                string obbReportId)
            => CoreHelper.RunTask(GetObbAnalyticsReportAsync(obbReportId));

        /// <summary>
        /// Retrieve the report saved by _Generate Balance Analytics_ or _Generate Cash Flow Analytics_. Requires the report ID generated by the previous call.
        /// Report data can either be retrieved as a JSON document or PDF file.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="obbReportId">Required parameter: Report ID generated and returned by OBB products.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetObbAnalyticsReportResponse response from the API call.</returns>
        public async Task<Models.GetObbAnalyticsReportResponse> GetObbAnalyticsReportAsync(
                string obbReportId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetObbAnalyticsReportResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/analytics/data/v1/{obb_report_id}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("obb_report_id", obbReportId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetObbAnalyticsReportResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve the report saved by _Generate Balance Analytics - FCRA_ or _Generate Cash Flow Analytics - FCRA_. Requires the report ID generated by the previous call.
        /// Report data can either be retrieved as a JSON document or PDF file.
        /// *Note:* this is a premium service, billable per every successful API call for non-testing customers.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="obbReportId">Required parameter: Report ID generated and returned by OBB products.</param>
        /// <param name="purpose">Required parameter: 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports..</param>
        /// <returns>Returns the Models.GetObbAnalyticsReportFcraResponse response from the API call.</returns>
        public Models.GetObbAnalyticsReportFcraResponse GetObbAnalyticsReportFcra(
                string obbReportId,
                string purpose)
            => CoreHelper.RunTask(GetObbAnalyticsReportFcraAsync(obbReportId, purpose));

        /// <summary>
        /// Retrieve the report saved by _Generate Balance Analytics - FCRA_ or _Generate Cash Flow Analytics - FCRA_. Requires the report ID generated by the previous call.
        /// Report data can either be retrieved as a JSON document or PDF file.
        /// *Note:* this is a premium service, billable per every successful API call for non-testing customers.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="obbReportId">Required parameter: Report ID generated and returned by OBB products.</param>
        /// <param name="purpose">Required parameter: 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetObbAnalyticsReportFcraResponse response from the API call.</returns>
        public async Task<Models.GetObbAnalyticsReportFcraResponse> GetObbAnalyticsReportFcraAsync(
                string obbReportId,
                string purpose,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetObbAnalyticsReportFcraResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/analytics/data/v1/{obb_report_id}/fcra")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("obb_report_id", obbReportId))
                      .Query(_query => _query.Setup("purpose", purpose))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetObbAnalyticsReportFcraResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}