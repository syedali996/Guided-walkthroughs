// <copyright file="CashFlowController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// CashFlowController.
    /// </summary>
    public class CashFlowController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowController"/> class.
        /// </summary>
        internal CashFlowController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.
        /// This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.
        /// If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.CashFlowReportAck response from the API call.</returns>
        public Models.CashFlowReportAck GenerateCashFlowBusinessReport(
                string customerId,
                Models.CashFlowReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateCashFlowBusinessReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.
        /// This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.
        /// If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CashFlowReportAck response from the API call.</returns>
        public async Task<Models.CashFlowReportAck> GenerateCashFlowBusinessReportAsync(
                string customerId,
                Models.CashFlowReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CashFlowReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/cashFlowBusiness")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CashFlowReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.
        /// This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.CashFlowReportAck response from the API call.</returns>
        public Models.CashFlowReportAck GenerateCashFlowPersonalReport(
                string customerId,
                Models.CashFlowReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateCashFlowPersonalReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.
        /// This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CashFlowReportAck response from the API call.</returns>
        public async Task<Models.CashFlowReportAck> GenerateCashFlowPersonalReportAsync(
                string customerId,
                Models.CashFlowReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CashFlowReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/cashFlowPersonal")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CashFlowReportAck>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}