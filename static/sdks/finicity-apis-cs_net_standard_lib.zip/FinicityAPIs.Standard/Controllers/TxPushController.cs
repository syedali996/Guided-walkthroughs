// <copyright file="TxPushController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// TxPushController.
    /// </summary>
    public class TxPushController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TxPushController"/> class.
        /// </summary>
        internal TxPushController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Register a client app's TxPush Listener to receive TxPush notifications related to the given account.
        /// Each call to this service will return two records, one with class account and one with class transaction. Account events are sent when values change in the account's fields (such as `balance` or `interestRate`). Transaction events are sent whenever a new transaction is posted for the account. For institutions that do not provide TxPush services, notifications are sent as soon as Finicity finds a new transaction or new account data through regular aggregation processes.
        /// The listener's URL must be secure (HTTPS) for any real-world account. In addition, the client's TxPush Listener will need to be verified. HTTP and HTTPS connections are only allowed on the standard ports 80 (HTTP) and 443 (HTTPS). The use of other ports will result with the call failing.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.TxPushSubscriptions response from the API call.</returns>
        public Models.TxPushSubscriptions SubscribeToTxPushNotifications(
                string customerId,
                string accountId,
                Models.TxPushSubscriptionParameters body)
            => CoreHelper.RunTask(SubscribeToTxPushNotificationsAsync(customerId, accountId, body));

        /// <summary>
        /// Register a client app's TxPush Listener to receive TxPush notifications related to the given account.
        /// Each call to this service will return two records, one with class account and one with class transaction. Account events are sent when values change in the account's fields (such as `balance` or `interestRate`). Transaction events are sent whenever a new transaction is posted for the account. For institutions that do not provide TxPush services, notifications are sent as soon as Finicity finds a new transaction or new account data through regular aggregation processes.
        /// The listener's URL must be secure (HTTPS) for any real-world account. In addition, the client's TxPush Listener will need to be verified. HTTP and HTTPS connections are only allowed on the standard ports 80 (HTTP) and 443 (HTTPS). The use of other ports will result with the call failing.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TxPushSubscriptions response from the API call.</returns>
        public async Task<Models.TxPushSubscriptions> SubscribeToTxPushNotificationsAsync(
                string customerId,
                string accountId,
                Models.TxPushSubscriptionParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.TxPushSubscriptions>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v1/customers/{customerId}/accounts/{accountId}/txpush")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.TxPushSubscriptions>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Delete all TxPush subscriptions with their notifications for the given account. No more notifications will be sent for account or transaction events.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        public void DisableTxPushNotifications(
                string customerId,
                string accountId)
            => CoreHelper.RunVoidTask(DisableTxPushNotificationsAsync(customerId, accountId));

        /// <summary>
        /// Delete all TxPush subscriptions with their notifications for the given account. No more notifications will be sent for account or transaction events.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DisableTxPushNotificationsAsync(
                string customerId,
                string accountId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/aggregation/v1/customers/{customerId}/accounts/{accountId}/txpush")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Inject a transaction into the transaction list for a testing account. This allows an app to trigger TxPush notifications for the account in order to test the app's TxPush Listener service. This causes the platform to send one transaction event and one account event (showing that the account balance has changed). This service is only supported for testing accounts.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.CreatedTestTxPushTransaction response from the API call.</returns>
        public Models.CreatedTestTxPushTransaction CreateTxPushTestTransaction(
                string customerId,
                string accountId,
                Models.TestTxPushTransaction body)
            => CoreHelper.RunTask(CreateTxPushTestTransactionAsync(customerId, accountId, body));

        /// <summary>
        /// Inject a transaction into the transaction list for a testing account. This allows an app to trigger TxPush notifications for the account in order to test the app's TxPush Listener service. This causes the platform to send one transaction event and one account event (showing that the account balance has changed). This service is only supported for testing accounts.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CreatedTestTxPushTransaction response from the API call.</returns>
        public async Task<Models.CreatedTestTxPushTransaction> CreateTxPushTestTransactionAsync(
                string customerId,
                string accountId,
                Models.TestTxPushTransaction body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CreatedTestTxPushTransaction>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v1/customers/{customerId}/accounts/{accountId}/transactions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CreatedTestTxPushTransaction>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Delete a specific subscription to TxPush notifications for the given account. This could be individual deleting the account or transactions events. No more events will be sent for that specific subscription.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="subscriptionId">Required parameter: The subscription ID.</param>
        public void DeleteTxPushSubscription(
                string customerId,
                long subscriptionId)
            => CoreHelper.RunVoidTask(DeleteTxPushSubscriptionAsync(customerId, subscriptionId));

        /// <summary>
        /// Delete a specific subscription to TxPush notifications for the given account. This could be individual deleting the account or transactions events. No more events will be sent for that specific subscription.
        /// For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="subscriptionId">Required parameter: The subscription ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteTxPushSubscriptionAsync(
                string customerId,
                long subscriptionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/aggregation/v1/customers/{customerId}/subscriptions/{subscriptionId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("subscriptionId", subscriptionId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);
    }
}