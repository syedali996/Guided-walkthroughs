// <copyright file="ConnectController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ConnectController.
    /// </summary>
    public class ConnectController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectController"/> class.
        /// </summary>
        internal ConnectController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Generate a Connect 2.0 URL link to add within your own applications.
        /// In option, use the `experience` parameter to call Connect (per session) in the body of the request. Configure the `experience` parameter to change the brand color, logo, icon, which credit decisioning report to generate when the Connect application completes, and more.
        /// Note: contact your Sales Account Team to set up the `experience` parameter.
        /// MVS Developers: You can pre-populate the consumer's SSN on the "Find employment records" page at the beginning of the MVS payroll app. Pass the SSN value for the consumer in the body of the request call.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public Models.ConnectUrl GenerateConnectUrl(
                Models.ConnectParameters body)
            => CoreHelper.RunTask(GenerateConnectUrlAsync(body));

        /// <summary>
        /// Generate a Connect 2.0 URL link to add within your own applications.
        /// In option, use the `experience` parameter to call Connect (per session) in the body of the request. Configure the `experience` parameter to change the brand color, logo, icon, which credit decisioning report to generate when the Connect application completes, and more.
        /// Note: contact your Sales Account Team to set up the `experience` parameter.
        /// MVS Developers: You can pre-populate the consumer's SSN on the "Find employment records" page at the beginning of the MVS payroll app. Pass the SSN value for the consumer in the body of the request call.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public async Task<Models.ConnectUrl> GenerateConnectUrlAsync(
                Models.ConnectParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConnectUrl>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/connect/v2/generate")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConnectUrl>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Connect Lite is a variation of Connect Full (`POST /connect/v2/generate`), which has a limited set of features.
        /// * Sign in, user's credentials, and Multi-Factor Authentication (MFA).
        /// * No user account management.
        /// The Connect Web SDK isn't a requirement when using Connect lite. However, if you want to use the SDK events, routes, and user events, then you must integrate with the Connect Web SDK.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public Models.ConnectUrl GenerateLiteConnectUrl(
                Models.LiteConnectParameters body)
            => CoreHelper.RunTask(GenerateLiteConnectUrlAsync(body));

        /// <summary>
        /// Connect Lite is a variation of Connect Full (`POST /connect/v2/generate`), which has a limited set of features.
        /// * Sign in, user's credentials, and Multi-Factor Authentication (MFA).
        /// * No user account management.
        /// The Connect Web SDK isn't a requirement when using Connect lite. However, if you want to use the SDK events, routes, and user events, then you must integrate with the Connect Web SDK.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public async Task<Models.ConnectUrl> GenerateLiteConnectUrlAsync(
                Models.LiteConnectParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConnectUrl>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/connect/v2/generate/lite")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConnectUrl>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Use the Connect Fix API when the following conditions occur:.
        /// * The connection to the user's financial institution is lost.
        /// * The user's credentials were updated (for any number of reasons).
        /// * The user's MFA challenge has expired.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public Models.ConnectUrl GenerateFixConnectUrl(
                Models.FixConnectParameters body)
            => CoreHelper.RunTask(GenerateFixConnectUrlAsync(body));

        /// <summary>
        /// Use the Connect Fix API when the following conditions occur:.
        /// * The connection to the user's financial institution is lost.
        /// * The user's credentials were updated (for any number of reasons).
        /// * The user's MFA challenge has expired.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public async Task<Models.ConnectUrl> GenerateFixConnectUrlAsync(
                Models.FixConnectParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConnectUrl>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/connect/v2/generate/fix")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConnectUrl>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Same as Connect Full (`POST /connect/v2/generate`) but send a Connect email to a consumer.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConnectEmailUrl response from the API call.</returns>
        public Models.ConnectEmailUrl SendConnectEmail(
                Models.ConnectEmailParameters body)
            => CoreHelper.RunTask(SendConnectEmailAsync(body));

        /// <summary>
        /// Same as Connect Full (`POST /connect/v2/generate`) but send a Connect email to a consumer.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConnectEmailUrl response from the API call.</returns>
        public async Task<Models.ConnectEmailUrl> SendConnectEmailAsync(
                Models.ConnectEmailParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConnectEmailUrl>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/connect/v2/send/email")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConnectEmailUrl>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Same as Connect Full (`POST /connect/v2/generate`) but for joint borrowers.
        /// MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public Models.ConnectUrl GenerateJointBorrowerConnectUrl(
                Models.ConnectJointBorrowerParameters body)
            => CoreHelper.RunTask(GenerateJointBorrowerConnectUrlAsync(body));

        /// <summary>
        /// Same as Connect Full (`POST /connect/v2/generate`) but for joint borrowers.
        /// MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConnectUrl response from the API call.</returns>
        public async Task<Models.ConnectUrl> GenerateJointBorrowerConnectUrlAsync(
                Models.ConnectJointBorrowerParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConnectUrl>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/connect/v2/generate/jointBorrower")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConnectUrl>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Same as Connect Joint Borrower (`POST /connect/v2/generate/jointBorrower`) but send a Connect email  to at least one of the joint borrower's email addresses. .
        /// When the consumer opens the email, MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ConnectEmailUrl response from the API call.</returns>
        public Models.ConnectEmailUrl SendJointBorrowerConnectEmail(
                Models.ConnectJointBorrowerEmailParameters body)
            => CoreHelper.RunTask(SendJointBorrowerConnectEmailAsync(body));

        /// <summary>
        /// Same as Connect Joint Borrower (`POST /connect/v2/generate/jointBorrower`) but send a Connect email  to at least one of the joint borrower's email addresses. .
        /// When the consumer opens the email, MVS prompts both the primary and joint borrower to enter each of their financial, payroll, and paystub information in the same Connect session.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConnectEmailUrl response from the API call.</returns>
        public async Task<Models.ConnectEmailUrl> SendJointBorrowerConnectEmailAsync(
                Models.ConnectJointBorrowerEmailParameters body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConnectEmailUrl>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/connect/v2/send/email/jointBorrower")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConnectEmailUrl>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}