// <copyright file="AppRegistrationController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// AppRegistrationController.
    /// </summary>
    public class AppRegistrationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppRegistrationController"/> class.
        /// </summary>
        internal AppRegistrationController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Register a new application to access financial institutions using OAuth connections.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.RegisteredApplication response from the API call.</returns>
        public Models.RegisteredApplication RegisterApp(
                Models.Application body)
            => CoreHelper.RunTask(RegisterAppAsync(body));

        /// <summary>
        /// Register a new application to access financial institutions using OAuth connections.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RegisteredApplication response from the API call.</returns>
        public async Task<Models.RegisteredApplication> RegisterAppAsync(
                Models.Application body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.RegisteredApplication>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v1/partners/applications")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.RegisteredApplication>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Update a registered application.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="preAppId">Required parameter: The application registration tracking ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.RegisteredApplication response from the API call.</returns>
        public Models.RegisteredApplication ModifyAppRegistration(
                string preAppId,
                Models.Application body)
            => CoreHelper.RunTask(ModifyAppRegistrationAsync(preAppId, body));

        /// <summary>
        /// Update a registered application.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="preAppId">Required parameter: The application registration tracking ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RegisteredApplication response from the API call.</returns>
        public async Task<Models.RegisteredApplication> ModifyAppRegistrationAsync(
                string preAppId,
                Models.Application body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.RegisteredApplication>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/aggregation/v1/partners/applications/{preAppId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("preAppId", preAppId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.RegisteredApplication>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the status of your application registration(s).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="preAppId">Optional parameter: The application registration tracking ID.</param>
        /// <param name="applicationId">Optional parameter: The application ID.</param>
        /// <param name="status">Optional parameter: Look up app registration requests by status.</param>
        /// <param name="appName">Optional parameter: Look up app registration requests by app name.</param>
        /// <param name="submittedDate">Optional parameter: Look up app registration requests by the date they were submitted.</param>
        /// <param name="modifiedDate">Optional parameter: Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R"..</param>
        /// <param name="page">Optional parameter: Index of the page of results to return.</param>
        /// <param name="pageSize">Optional parameter: Maximum number of results per page.</param>
        /// <returns>Returns the Models.AppStatuses response from the API call.</returns>
        public Models.AppStatuses GetAppRegistrationStatus(
                string preAppId = null,
                string applicationId = null,
                string status = null,
                string appName = null,
                long? submittedDate = null,
                long? modifiedDate = null,
                int? page = 1,
                int? pageSize = 1)
            => CoreHelper.RunTask(GetAppRegistrationStatusAsync(preAppId, applicationId, status, appName, submittedDate, modifiedDate, page, pageSize));

        /// <summary>
        /// Get the status of your application registration(s).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="preAppId">Optional parameter: The application registration tracking ID.</param>
        /// <param name="applicationId">Optional parameter: The application ID.</param>
        /// <param name="status">Optional parameter: Look up app registration requests by status.</param>
        /// <param name="appName">Optional parameter: Look up app registration requests by app name.</param>
        /// <param name="submittedDate">Optional parameter: Look up app registration requests by the date they were submitted.</param>
        /// <param name="modifiedDate">Optional parameter: Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R"..</param>
        /// <param name="page">Optional parameter: Index of the page of results to return.</param>
        /// <param name="pageSize">Optional parameter: Maximum number of results per page.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AppStatuses response from the API call.</returns>
        public async Task<Models.AppStatuses> GetAppRegistrationStatusAsync(
                string preAppId = null,
                string applicationId = null,
                string status = null,
                string appName = null,
                long? submittedDate = null,
                long? modifiedDate = null,
                int? page = 1,
                int? pageSize = 1,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AppStatuses>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v2/partners/applications")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Query(_query => _query.Setup("preAppId", preAppId))
                      .Query(_query => _query.Setup("applicationId", applicationId))
                      .Query(_query => _query.Setup("status", status))
                      .Query(_query => _query.Setup("appName", appName))
                      .Query(_query => _query.Setup("submittedDate", submittedDate))
                      .Query(_query => _query.Setup("modifiedDate", modifiedDate))
                      .Query(_query => _query.Setup("page", (page != null) ? page : 1))
                      .Query(_query => _query.Setup("pageSize", (pageSize != null) ? pageSize : 1))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.AppStatuses>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="applicationId">Required parameter: The application ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        public void SetCustomerAppID(
                string customerId,
                string applicationId,
                object body = null)
            => CoreHelper.RunVoidTask(SetCustomerAppIDAsync(customerId, applicationId, body));

        /// <summary>
        /// If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="applicationId">Required parameter: The application ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task SetCustomerAppIDAsync(
                string customerId,
                string applicationId,
                object body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/aggregation/v1/customers/{customerId}/applications/{applicationId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("applicationId", applicationId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.
        /// This API returns a list of accounts for the given institution login ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <param name="body">Required parameter: No payload expected.</param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public Models.CustomerAccounts MigrateInstitutionLoginAccounts(
                string customerId,
                string institutionLoginId,
                object body)
            => CoreHelper.RunTask(MigrateInstitutionLoginAccountsAsync(customerId, institutionLoginId, body));

        /// <summary>
        /// The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.
        /// This API returns a list of accounts for the given institution login ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <param name="body">Required parameter: No payload expected.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public async Task<Models.CustomerAccounts> MigrateInstitutionLoginAccountsAsync(
                string customerId,
                string institutionLoginId,
                object body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccounts>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/aggregation/v2/customers/{customerId}/institutionLogins/{institutionLoginId}/migration")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("institutionLoginId", institutionLoginId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccounts>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}