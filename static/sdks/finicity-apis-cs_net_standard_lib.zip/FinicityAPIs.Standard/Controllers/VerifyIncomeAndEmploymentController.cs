// <copyright file="VerifyIncomeAndEmploymentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// VerifyIncomeAndEmploymentController.
    /// </summary>
    public class VerifyIncomeAndEmploymentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VerifyIncomeAndEmploymentController"/> class.
        /// </summary>
        internal VerifyIncomeAndEmploymentController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Generate a Verification of Income (VOI) report for all checking, savings, and money market accounts for the given customer. This service retrieves up to two years of transaction history for each account and uses this information to generate the VOI report.
        /// This is a premium service. The billing rate is the variable rate for Verification of Income under the current subscription plan. The billable event is the successful generation of a VOI report.
        /// If no account of type checking, savings, or money market is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.VOIReportAck response from the API call.</returns>
        public Models.VOIReportAck GenerateVOIReport(
                string customerId,
                Models.VOIReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOIReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a Verification of Income (VOI) report for all checking, savings, and money market accounts for the given customer. This service retrieves up to two years of transaction history for each account and uses this information to generate the VOI report.
        /// This is a premium service. The billing rate is the variable rate for Verification of Income under the current subscription plan. The billable event is the successful generation of a VOI report.
        /// If no account of type checking, savings, or money market is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VOIReportAck response from the API call.</returns>
        public async Task<Models.VOIReportAck> GenerateVOIReportAsync(
                string customerId,
                Models.VOIReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.VOIReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voi")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.VOIReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Premium Service: A billable event when the API response is successful. .
        /// MVS Implementation Options: Direct API Integration.
        /// Used as a complementary report to the VOIE-Payroll report. This report is used to fulfill the pre-close VOE requirements. It retrieves the customer's employment details and employment status through the payroll source without any income information. .
        /// To generate this report, pass the values from the customer SSN, DOB, and the report ID from the first VOIE-Payroll report generated after the Connect session.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.PayrollReportAck response from the API call.</returns>
        public Models.PayrollReportAck GenerateVOEPayrollReport(
                string customerId,
                Models.PayrollReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOEPayrollReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Premium Service: A billable event when the API response is successful. .
        /// MVS Implementation Options: Direct API Integration.
        /// Used as a complementary report to the VOIE-Payroll report. This report is used to fulfill the pre-close VOE requirements. It retrieves the customer's employment details and employment status through the payroll source without any income information. .
        /// To generate this report, pass the values from the customer SSN, DOB, and the report ID from the first VOIE-Payroll report generated after the Connect session.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PayrollReportAck response from the API call.</returns>
        public async Task<Models.PayrollReportAck> GenerateVOEPayrollReportAsync(
                string customerId,
                Models.PayrollReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PayrollReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voePayroll")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PayrollReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Premium Service: A billable event when the API response is successful.
        /// MVS-Direct integration developers only.
        /// Used as a complimentary report to the VOA with Income and VOIE - Paystub (with TXVerify) reports and used to fulfill the pre-close VOE requirements. .
        /// Retrieve the latest credit transaction information from the borrower's connected bank accounts and groups them into income streams so that you can view their payment history to ensure a direct deport was made within the expected cadence. The report displays transaction descriptions without any dollar amounts so that income re-verification isn't necessary.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.VOETransactionsReportAck response from the API call.</returns>
        public Models.VOETransactionsReportAck GenerateVOETransactionsReport(
                string customerId,
                Models.VOETransactionsReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOETransactionsReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Premium Service: A billable event when the API response is successful.
        /// MVS-Direct integration developers only.
        /// Used as a complimentary report to the VOA with Income and VOIE - Paystub (with TXVerify) reports and used to fulfill the pre-close VOE requirements. .
        /// Retrieve the latest credit transaction information from the borrower's connected bank accounts and groups them into income streams so that you can view their payment history to ensure a direct deport was made within the expected cadence. The report displays transaction descriptions without any dollar amounts so that income re-verification isn't necessary.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VOETransactionsReportAck response from the API call.</returns>
        public async Task<Models.VOETransactionsReportAck> GenerateVOETransactionsReportAsync(
                string customerId,
                Models.VOETransactionsReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.VOETransactionsReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voeTransactions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.VOETransactionsReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate Pay Statement Extraction Report for the given customer. This service accepts asset IDs of the stored pay statements to generate a Pay Statement Extraction Report. .
        /// This is a premium service. The billing rate is the variable rate for Pay Statement Extraction Report under the current subscription plan. The billable event is the successful generation of a Pay Statement Extraction Report.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.PayStatementReportAck response from the API call.</returns>
        public Models.PayStatementReportAck GeneratePayStatementReport(
                string customerId,
                Models.PayStatementReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GeneratePayStatementReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate Pay Statement Extraction Report for the given customer. This service accepts asset IDs of the stored pay statements to generate a Pay Statement Extraction Report. .
        /// This is a premium service. The billing rate is the variable rate for Pay Statement Extraction Report under the current subscription plan. The billable event is the successful generation of a Pay Statement Extraction Report.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PayStatementReportAck response from the API call.</returns>
        public async Task<Models.PayStatementReportAck> GeneratePayStatementReportAsync(
                string customerId,
                Models.PayStatementReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PayStatementReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/payStatement")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PayStatementReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate a VOIE - Paystub (with TXVerify) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given accounts. It then uses this information as well as the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub (with TXVerify) report.
        /// Note: if you are using this API to refresh the bank transactions, use the same asset ID from the first report. A new paystub is not required unless the paystub is too old for underwriting requirements. Using the same asset ID that was on the original report and the previously extracted details will be used to speed up report generation response time.
        /// This is a premium service. The billing rate is the variable rate for VOIE TXVerify under the current subscription plan. The billable event is the successful generation of a VOIE TXVerify Report.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.VOIEPaystubWithTXVerifyReportAck response from the API call.</returns>
        public Models.VOIEPaystubWithTXVerifyReportAck GenerateVOIEPaystubWithTXVerifyReport(
                string customerId,
                Models.VOIEWithTXVerifyReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOIEPaystubWithTXVerifyReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a VOIE - Paystub (with TXVerify) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given accounts. It then uses this information as well as the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub (with TXVerify) report.
        /// Note: if you are using this API to refresh the bank transactions, use the same asset ID from the first report. A new paystub is not required unless the paystub is too old for underwriting requirements. Using the same asset ID that was on the original report and the previously extracted details will be used to speed up report generation response time.
        /// This is a premium service. The billing rate is the variable rate for VOIE TXVerify under the current subscription plan. The billable event is the successful generation of a VOIE TXVerify Report.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VOIEPaystubWithTXVerifyReportAck response from the API call.</returns>
        public async Task<Models.VOIEPaystubWithTXVerifyReportAck> GenerateVOIEPaystubWithTXVerifyReportAsync(
                string customerId,
                Models.VOIEWithTXVerifyReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.VOIEPaystubWithTXVerifyReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voieTxVerify/withInterview")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.VOIEPaystubWithTXVerifyReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate a VOIE - Paystub report. This service uses the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub report with digitized paystub details.
        /// This is a premium service. The billing rate is the variable rate for VOIE - Paystub under the current subscription plan. The billable event is the successful generation of a VOIE - Paystub Report.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.VOIEPaystubReportAck response from the API call.</returns>
        public Models.VOIEPaystubReportAck GenerateVOIEPaystubReport(
                string customerId,
                Models.VOIEReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOIEPaystubReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a VOIE - Paystub report. This service uses the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub report with digitized paystub details.
        /// This is a premium service. The billing rate is the variable rate for VOIE - Paystub under the current subscription plan. The billable event is the successful generation of a VOIE - Paystub Report.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VOIEPaystubReportAck response from the API call.</returns>
        public async Task<Models.VOIEPaystubReportAck> GenerateVOIEPaystubReportAsync(
                string customerId,
                Models.VOIEReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.VOIEPaystubReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voieTxVerify/withStatement")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.VOIEPaystubReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The VOIE – Payroll report generates when the customer completes Connect. Lenders, who commonly use this report for pre-close verification employment check, can refresh this report by passing the consumer's SSN, DOB, and the report ID from the first VOIE – Payroll report they received.
        /// We'll refresh this report and update any new pay histories since the first report generated, including borrower's employment status as active or not.
        /// Note: lenders can only refresh this report one time in a 60-day period starting from the date of the first report. Any further report refreshes will incur additional charges.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.PayrollReportAck response from the API call.</returns>
        public Models.PayrollReportAck RefreshVOIEPayrollReport(
                string customerId,
                Models.PayrollReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(RefreshVOIEPayrollReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// The VOIE – Payroll report generates when the customer completes Connect. Lenders, who commonly use this report for pre-close verification employment check, can refresh this report by passing the consumer's SSN, DOB, and the report ID from the first VOIE – Payroll report they received.
        /// We'll refresh this report and update any new pay histories since the first report generated, including borrower's employment status as active or not.
        /// Note: lenders can only refresh this report one time in a 60-day period starting from the date of the first report. Any further report refreshes will incur additional charges.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PayrollReportAck response from the API call.</returns>
        public async Task<Models.PayrollReportAck> RefreshVOIEPayrollReportAsync(
                string customerId,
                Models.PayrollReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PayrollReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voiePayroll")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PayrollReportAck>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}