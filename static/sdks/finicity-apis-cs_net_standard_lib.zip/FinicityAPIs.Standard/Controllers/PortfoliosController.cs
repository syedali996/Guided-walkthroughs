// <copyright file="PortfoliosController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// PortfoliosController.
    /// </summary>
    public class PortfoliosController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PortfoliosController"/> class.
        /// </summary>
        internal PortfoliosController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Return a portfolio of most recently generated reports for each report type for the given customer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="portfolioId">Required parameter: A portfolio ID with the portfolio version number. Using the portfolio number without a version number will return the most recently generated reports..</param>
        /// <returns>Returns the Models.PortfolioSummary response from the API call.</returns>
        public Models.PortfolioSummary GetPortfolioByCustomer(
                string customerId,
                string portfolioId)
            => CoreHelper.RunTask(GetPortfolioByCustomerAsync(customerId, portfolioId));

        /// <summary>
        /// Return a portfolio of most recently generated reports for each report type for the given customer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="portfolioId">Required parameter: A portfolio ID with the portfolio version number. Using the portfolio number without a version number will return the most recently generated reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PortfolioSummary response from the API call.</returns>
        public async Task<Models.PortfolioSummary> GetPortfolioByCustomerAsync(
                string customerId,
                string portfolioId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PortfolioSummary>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/decisioning/v1/customers/{customerId}/portfolios/{portfolioId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("portfolioId", portfolioId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PortfolioSummary>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Return a portfolio of most recently generated reports for each report type for a given consumer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="consumerId">Required parameter: The consumer ID.</param>
        /// <param name="portfolioId">Required parameter: A portfolio ID with the portfolio version number. Using the portfolio number without a version number will return the most recently generated reports..</param>
        /// <returns>Returns the Models.PortfolioWithConsumerSummary response from the API call.</returns>
        public Models.PortfolioWithConsumerSummary GetPortfolioByConsumer(
                string consumerId,
                string portfolioId)
            => CoreHelper.RunTask(GetPortfolioByConsumerAsync(consumerId, portfolioId));

        /// <summary>
        /// Return a portfolio of most recently generated reports for each report type for a given consumer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="consumerId">Required parameter: The consumer ID.</param>
        /// <param name="portfolioId">Required parameter: A portfolio ID with the portfolio version number. Using the portfolio number without a version number will return the most recently generated reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PortfolioWithConsumerSummary response from the API call.</returns>
        public async Task<Models.PortfolioWithConsumerSummary> GetPortfolioByConsumerAsync(
                string consumerId,
                string portfolioId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PortfolioWithConsumerSummary>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/decisioning/v1/consumers/{consumerId}/portfolios/{portfolioId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("consumerId", consumerId))
                      .Template(_template => _template.Setup("portfolioId", portfolioId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PortfolioWithConsumerSummary>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}