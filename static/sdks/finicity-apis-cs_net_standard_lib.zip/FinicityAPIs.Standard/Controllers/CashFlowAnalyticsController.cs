// <copyright file="CashFlowAnalyticsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// CashFlowAnalyticsController.
    /// </summary>
    public class CashFlowAnalyticsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsController"/> class.
        /// </summary>
        internal CashFlowAnalyticsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Cash Flow Analytics for Business analyzes cash flow over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Average transaction value by month over the requested time period.
        /// * Net cash flow over the requested time period and broken down by month.
        /// * Count and report of weeks in the requested time period where there.
        ///   were zero transactions posted to the customer's accounts.
        /// * Minimum/maximum/average/sum/count of deposits by month.
        /// * Minimum/maximum/average/sum/count of withdrawals by month.
        /// * Estimated amount of deposits that can be classified as business.
        ///   revenue.
        /// * Number of transactions posted incurring a non-sufficient funds (NSF).
        ///   fee, and net amount charged in NSF fees.
        /// This version of the API is intended for piloting and integration testing your application with the Cash Flow Analytics product. It does not adhere to FCRA requirements, and should not be used for production/lending purposes. See _Generate Cash Flow Analytics - FCRA_ for the FCRA compliant version of this API.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Cash Flow Analytics Report_ (operation: _GetCashFlowAnalyticsReport_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public Models.BalanceAndCashFlowAnalyticsReportAck GenerateCashFlowAnalytics(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null)
            => CoreHelper.RunTask(GenerateCashFlowAnalyticsAsync(customerId, body, referenceNumber));

        /// <summary>
        /// Cash Flow Analytics for Business analyzes cash flow over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Average transaction value by month over the requested time period.
        /// * Net cash flow over the requested time period and broken down by month.
        /// * Count and report of weeks in the requested time period where there.
        ///   were zero transactions posted to the customer's accounts.
        /// * Minimum/maximum/average/sum/count of deposits by month.
        /// * Minimum/maximum/average/sum/count of withdrawals by month.
        /// * Estimated amount of deposits that can be classified as business.
        ///   revenue.
        /// * Number of transactions posted incurring a non-sufficient funds (NSF).
        ///   fee, and net amount charged in NSF fees.
        /// This version of the API is intended for piloting and integration testing your application with the Cash Flow Analytics product. It does not adhere to FCRA requirements, and should not be used for production/lending purposes. See _Generate Cash Flow Analytics - FCRA_ for the FCRA compliant version of this API.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Cash Flow Analytics Report_ (operation: _GetCashFlowAnalyticsReport_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public async Task<Models.BalanceAndCashFlowAnalyticsReportAck> GenerateCashFlowAnalyticsAsync(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.BalanceAndCashFlowAnalyticsReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/analytics/cashflow/v1/customer/{customerId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("reference-number", referenceNumber))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("A bad request was provided", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized request", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Access forbidden", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Resource not found", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("Resource conflict", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.BalanceAndCashFlowAnalyticsReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Cash Flow Analytics for Business analyzes cash flow over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Average transaction value by month over the requested time period.
        /// * Net cash flow over the requested time period and broken down by month.
        /// * Count and report of weeks in the requested time period where there.
        ///   were zero transactions posted to the customer's accounts.
        /// * Minimum/maximum/average/sum/count of deposits by month.
        /// * Minimum/maximum/average/sum/count of withdrawals by month.
        /// * Estimated amount of deposits that can be classified as business.
        ///   revenue.
        /// * Number of transactions posted incurring a non-sufficient funds (NSF).
        ///   fee, and net amount charged in NSF fees.
        /// This version of the API is intended for production use. It maintains and enforces all compliance with FCRA rules and requirements.
        /// *Note:* this is a premium service, billable per every successful API call for non-testing customers.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Cash Flow Analytics Report - FCRA_ (operation: _GetCashFlowAnalyticsReportFCRA_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public Models.BalanceAndCashFlowAnalyticsReportAck GenerateCashFlowAnalyticsFcra(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null)
            => CoreHelper.RunTask(GenerateCashFlowAnalyticsFcraAsync(customerId, body, referenceNumber));

        /// <summary>
        /// Cash Flow Analytics for Business analyzes cash flow over time to report metrics and identify behavior that may indicate risk.
        /// Calculated metrics include:.
        /// * Average transaction value by month over the requested time period.
        /// * Net cash flow over the requested time period and broken down by month.
        /// * Count and report of weeks in the requested time period where there.
        ///   were zero transactions posted to the customer's accounts.
        /// * Minimum/maximum/average/sum/count of deposits by month.
        /// * Minimum/maximum/average/sum/count of withdrawals by month.
        /// * Estimated amount of deposits that can be classified as business.
        ///   revenue.
        /// * Number of transactions posted incurring a non-sufficient funds (NSF).
        ///   fee, and net amount charged in NSF fees.
        /// This version of the API is intended for production use. It maintains and enforces all compliance with FCRA rules and requirements.
        /// *Note:* this is a premium service, billable per every successful API call for non-testing customers.
        /// A successful call to this API will generate analytics and store a report within Finicity. The report can be retrieved via _Get Cash Flow Analytics Report - FCRA_ (operation: _GetCashFlowAnalyticsReportFCRA_).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="referenceNumber">Optional parameter: Partner-provided reference number to correlate reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BalanceAndCashFlowAnalyticsReportAck response from the API call.</returns>
        public async Task<Models.BalanceAndCashFlowAnalyticsReportAck> GenerateCashFlowAnalyticsFcraAsync(
                string customerId,
                Models.BalanceAndCashFlowAnalyticsReportConstraints body,
                string referenceNumber = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.BalanceAndCashFlowAnalyticsReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/analytics/cashflow/v1/customer/{customerId}/fcra")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("reference-number", referenceNumber))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("A bad request was provided", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized request", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Access forbidden", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Resource not found", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("Resource conflict", (_reason, _context) => new ObbErrorMessageException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.BalanceAndCashFlowAnalyticsReportAck>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}