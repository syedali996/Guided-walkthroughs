// <copyright file="AnalyticsAndAttributesController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// AnalyticsAndAttributesController.
    /// </summary>
    public class AnalyticsAndAttributesController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AnalyticsAndAttributesController"/> class.
        /// </summary>
        internal AnalyticsAndAttributesController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Generate a Consumer Attributes report for the given customer. The "to" and "from" date range is the last 12 months of consumer data, based on the date at which the report was generated.
        /// An analytic ID is created and associated with the customer's ID. If you generate multiple Consumer Attributes reports for the same customer, then each report will have its own analytic ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ConsumerAttributesAnalyticId response from the API call.</returns>
        public Models.ConsumerAttributesAnalyticId GenerateConsumerAttributes(
                string customerId,
                Models.ConsumerAttributeAccountIDs body = null)
            => CoreHelper.RunTask(GenerateConsumerAttributesAsync(customerId, body));

        /// <summary>
        /// Generate a Consumer Attributes report for the given customer. The "to" and "from" date range is the last 12 months of consumer data, based on the date at which the report was generated.
        /// An analytic ID is created and associated with the customer's ID. If you generate multiple Consumer Attributes reports for the same customer, then each report will have its own analytic ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConsumerAttributesAnalyticId response from the API call.</returns>
        public async Task<Models.ConsumerAttributesAnalyticId> GenerateConsumerAttributesAsync(
                string customerId,
                Models.ConsumerAttributeAccountIDs body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConsumerAttributesAnalyticId>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/analytics/ca360/v1/customers/{customerId}/analytics")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConsumerAttributesAnalyticId>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve a list of all analytic IDs previously created for a customer using the Generate Consumer Attributes APIs.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <returns>Returns the Models.ConsumerAttributeList response from the API call.</returns>
        public Models.ConsumerAttributeList ListConsumerAttributes(
                string customerId)
            => CoreHelper.RunTask(ListConsumerAttributesAsync(customerId));

        /// <summary>
        /// Retrieve a list of all analytic IDs previously created for a customer using the Generate Consumer Attributes APIs.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConsumerAttributeList response from the API call.</returns>
        public async Task<Models.ConsumerAttributeList> ListConsumerAttributesAsync(
                string customerId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConsumerAttributeList>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/analytics/ca360/v1/customers/{customerId}/analytics")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConsumerAttributeList>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <returns>Returns the Models.ConsumerAttributesAnalyticId response from the API call.</returns>
        public Models.ConsumerAttributesAnalyticId GenerateFCRAConsumerAttributes(
                string customerId,
                Models.ConsumerAttributeAccountIDs body = null)
            => CoreHelper.RunTask(GenerateFCRAConsumerAttributesAsync(customerId, body));

        /// <summary>
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Optional parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConsumerAttributesAnalyticId response from the API call.</returns>
        public async Task<Models.ConsumerAttributesAnalyticId> GenerateFCRAConsumerAttributesAsync(
                string customerId,
                Models.ConsumerAttributeAccountIDs body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConsumerAttributesAnalyticId>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/analytics/ca360/v1/customers/{customerId}/analytics/fcra")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConsumerAttributesAnalyticId>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve a Consumer Attributes report for a customer.
        /// Use the analytic and customer IDs to retrieve 12 months of data attributes according to the "to" and "from" date range of the report at the time it was created. .
        /// If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="analyticsId">Required parameter: The analytic ID.</param>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <returns>Returns the Models.ConsumerAttributes response from the API call.</returns>
        public Models.ConsumerAttributes GetConsumerAttributesByID(
                string analyticsId,
                string customerId)
            => CoreHelper.RunTask(GetConsumerAttributesByIDAsync(analyticsId, customerId));

        /// <summary>
        /// Retrieve a Consumer Attributes report for a customer.
        /// Use the analytic and customer IDs to retrieve 12 months of data attributes according to the "to" and "from" date range of the report at the time it was created. .
        /// If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="analyticsId">Required parameter: The analytic ID.</param>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConsumerAttributes response from the API call.</returns>
        public async Task<Models.ConsumerAttributes> GetConsumerAttributesByIDAsync(
                string analyticsId,
                string customerId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConsumerAttributes>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/analytics/ca360/v1/customers/{customerId}/analytics/{analyticsId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("analyticsId", analyticsId))
                      .Template(_template => _template.Setup("customerId", customerId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConsumerAttributes>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve a FCRA Consumer Attributes report for a customer.
        /// Use the analytic and customer IDs to retrieve 12 months of FCRA data attributes according to the `To` and `From` date range of the report at the time it was created. .
        /// If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="analyticsId">Required parameter: The analytic ID.</param>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="purpose">Optional parameter: 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports..</param>
        /// <returns>Returns the Models.ConsumerAttributes response from the API call.</returns>
        public Models.ConsumerAttributes GetFCRAConsumerAttributesByID(
                string analyticsId,
                string customerId,
                string purpose = null)
            => CoreHelper.RunTask(GetFCRAConsumerAttributesByIDAsync(analyticsId, customerId, purpose));

        /// <summary>
        /// Retrieve a FCRA Consumer Attributes report for a customer.
        /// Use the analytic and customer IDs to retrieve 12 months of FCRA data attributes according to the `To` and `From` date range of the report at the time it was created. .
        /// If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="analyticsId">Required parameter: The analytic ID.</param>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="purpose">Optional parameter: 2-digit code from [Permissible Purpose Codes](https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report. Required for retrieving some reports..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ConsumerAttributes response from the API call.</returns>
        public async Task<Models.ConsumerAttributes> GetFCRAConsumerAttributesByIDAsync(
                string analyticsId,
                string customerId,
                string purpose = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ConsumerAttributes>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/analytics/ca360/v1/customers/{customerId}/analytics/{analyticsId}/fcra")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("analyticsId", analyticsId))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Query(_query => _query.Setup("purpose", purpose))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.ConsumerAttributes>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}