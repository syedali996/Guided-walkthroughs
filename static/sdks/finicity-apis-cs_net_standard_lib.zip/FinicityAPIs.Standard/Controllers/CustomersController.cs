// <copyright file="CustomersController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// CustomersController.
    /// </summary>
    public class CustomersController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomersController"/> class.
        /// </summary>
        internal CustomersController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Enroll a testing customer ([Test Drive](https://signup.finicity.com/) accounts).
        /// For using testing customers with FinBank OAuth, you must register a test application with your systems engineer or account manager. Then, use that testing `applicationId` when creating testing customers.
        /// Testing Customers can access FinBank profiles (except "FinBank Billable" profiles), and cannot access live financial institutions.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.CreatedCustomer response from the API call.</returns>
        public Models.CreatedCustomer AddTestingCustomer(
                Models.NewCustomer body)
            => CoreHelper.RunTask(AddTestingCustomerAsync(body));

        /// <summary>
        /// Enroll a testing customer ([Test Drive](https://signup.finicity.com/) accounts).
        /// For using testing customers with FinBank OAuth, you must register a test application with your systems engineer or account manager. Then, use that testing `applicationId` when creating testing customers.
        /// Testing Customers can access FinBank profiles (except "FinBank Billable" profiles), and cannot access live financial institutions.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CreatedCustomer response from the API call.</returns>
        public async Task<Models.CreatedCustomer> AddTestingCustomerAsync(
                Models.NewCustomer body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CreatedCustomer>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v2/customers/testing")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CreatedCustomer>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Enroll an active customer, which is the actual owner of one or more real-world accounts. This is a billable customer.
        /// Active customers must use the "FinBank Billable" profiles for testing purposes. .
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.CreatedCustomer response from the API call.</returns>
        public Models.CreatedCustomer AddCustomer(
                Models.NewCustomer body)
            => CoreHelper.RunTask(AddCustomerAsync(body));

        /// <summary>
        /// Enroll an active customer, which is the actual owner of one or more real-world accounts. This is a billable customer.
        /// Active customers must use the "FinBank Billable" profiles for testing purposes. .
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CreatedCustomer response from the API call.</returns>
        public async Task<Models.CreatedCustomer> AddCustomerAsync(
                Models.NewCustomer body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CreatedCustomer>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v2/customers/active")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("429", CreateErrorCase("The service can't accept more requests or is not available from the [Test Drive](https://signup.finicity.com/).", (_reason, _context) => new ApiException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CreatedCustomer>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Find all customers enrolled by the current partner, where the search text is found in the customer's username or any combination of `firstName` and `lastName` fields. If no search text is provided, all customers will be returned.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="username">Optional parameter: Username for exact match (will return 0 or 1 record).</param>
        /// <param name="type">Optional parameter: "testing" or "active" to return only customers of that type, or leave empty to return all customers.</param>
        /// <param name="search">Optional parameter: The text you wish to match. Leave this empty if you wish to return all customers. Must be URL-encoded (see: [Handling Spaces in Queries](https://docs.finicity.com/endpoint-syntax-and-format/))..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <returns>Returns the Models.Customers response from the API call.</returns>
        public Models.Customers GetCustomers(
                string username = null,
                string type = null,
                string search = null,
                int? start = 1,
                int? limit = 25)
            => CoreHelper.RunTask(GetCustomersAsync(username, type, search, start, limit));

        /// <summary>
        /// Find all customers enrolled by the current partner, where the search text is found in the customer's username or any combination of `firstName` and `lastName` fields. If no search text is provided, all customers will be returned.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="username">Optional parameter: Username for exact match (will return 0 or 1 record).</param>
        /// <param name="type">Optional parameter: "testing" or "active" to return only customers of that type, or leave empty to return all customers.</param>
        /// <param name="search">Optional parameter: The text you wish to match. Leave this empty if you wish to return all customers. Must be URL-encoded (see: [Handling Spaces in Queries](https://docs.finicity.com/endpoint-syntax-and-format/))..</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Customers response from the API call.</returns>
        public async Task<Models.Customers> GetCustomersAsync(
                string username = null,
                string type = null,
                string search = null,
                int? start = 1,
                int? limit = 25,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Customers>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Query(_query => _query.Setup("username", username))
                      .Query(_query => _query.Setup("type", type))
                      .Query(_query => _query.Setup("search", search))
                      .Query(_query => _query.Setup("start", (start != null) ? start : 1))
                      .Query(_query => _query.Setup("limit", (limit != null) ? limit : 25))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.Customers>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve a customer along with additional details about the OAuth application.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <returns>Returns the Models.CustomerWithAppData response from the API call.</returns>
        public Models.CustomerWithAppData GetCustomerWithAppData(
                string customerId)
            => CoreHelper.RunTask(GetCustomerWithAppDataAsync(customerId));

        /// <summary>
        /// Retrieve a customer along with additional details about the OAuth application.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerWithAppData response from the API call.</returns>
        public async Task<Models.CustomerWithAppData> GetCustomerWithAppDataAsync(
                string customerId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerWithAppData>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers/{customerId}/application")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerWithAppData>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve a customer by ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <returns>Returns the Models.Customer response from the API call.</returns>
        public Models.Customer GetCustomer(
                string customerId)
            => CoreHelper.RunTask(GetCustomerAsync(customerId));

        /// <summary>
        /// Retrieve a customer by ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Customer response from the API call.</returns>
        public async Task<Models.Customer> GetCustomerAsync(
                string customerId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Customer>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers/{customerId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.Customer>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Modify an enrolled customer by ID.
        /// You must specify either `firstName`, `lastName`, or both in the request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        public void ModifyCustomer(
                string customerId,
                Models.CustomerUpdate body)
            => CoreHelper.RunVoidTask(ModifyCustomerAsync(customerId, body));

        /// <summary>
        /// Modify an enrolled customer by ID.
        /// You must specify either `firstName`, `lastName`, or both in the request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ModifyCustomerAsync(
                string customerId,
                Models.CustomerUpdate body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/aggregation/v1/customers/{customerId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Completely remove a customer from the system. This will remove the customer and all associated accounts and transactions.
        /// ⚠️ Use this service carefully! It will not pause for confirmation before performing the operation!.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        public void DeleteCustomer(
                string customerId)
            => CoreHelper.RunVoidTask(DeleteCustomerAsync(customerId));

        /// <summary>
        /// Completely remove a customer from the system. This will remove the customer and all associated accounts and transactions.
        /// ⚠️ Use this service carefully! It will not pause for confirmation before performing the operation!.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteCustomerAsync(
                string customerId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/aggregation/v1/customers/{customerId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);
    }
}