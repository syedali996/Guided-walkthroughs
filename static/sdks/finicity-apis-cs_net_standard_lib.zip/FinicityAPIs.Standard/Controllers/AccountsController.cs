// <copyright file="AccountsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// AccountsController.
    /// </summary>
    public class AccountsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountsController"/> class.
        /// </summary>
        internal AccountsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Get all accounts associated with the given institution login. All accounts returned are accessible by a single set of credentials on a single institution.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public Models.CustomerAccounts GetCustomerAccountsByInstitutionLogin(
                string customerId,
                string institutionLoginId)
            => CoreHelper.RunTask(GetCustomerAccountsByInstitutionLoginAsync(customerId, institutionLoginId));

        /// <summary>
        /// Get all accounts associated with the given institution login. All accounts returned are accessible by a single set of credentials on a single institution.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public async Task<Models.CustomerAccounts> GetCustomerAccountsByInstitutionLoginAsync(
                string customerId,
                string institutionLoginId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccounts>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers/{customerId}/institutionLogins/{institutionLoginId}/accounts")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("institutionLoginId", institutionLoginId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccounts>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Refresh account and transaction data for all accounts associated with a given `institutionLoginId` with a connection to the institution.
        /// Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.
        /// Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.
        /// The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public Models.CustomerAccounts RefreshCustomerAccountsByInstitutionLogin(
                string customerId,
                string institutionLoginId,
                object body = null)
            => CoreHelper.RunTask(RefreshCustomerAccountsByInstitutionLoginAsync(customerId, institutionLoginId, body));

        /// <summary>
        /// Refresh account and transaction data for all accounts associated with a given `institutionLoginId` with a connection to the institution.
        /// Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.
        /// Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.
        /// The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public async Task<Models.CustomerAccounts> RefreshCustomerAccountsByInstitutionLoginAsync(
                string customerId,
                string institutionLoginId,
                object body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccounts>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v1/customers/{customerId}/institutionLogins/{institutionLoginId}/accounts")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("institutionLoginId", institutionLoginId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccounts>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Remove from Finicity aggregation the set of accounts matching the institution login ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        public void DeleteCustomerAccountsByInstitutionLogin(
                string customerId,
                string institutionLoginId)
            => CoreHelper.RunVoidTask(DeleteCustomerAccountsByInstitutionLoginAsync(customerId, institutionLoginId));

        /// <summary>
        /// Remove from Finicity aggregation the set of accounts matching the institution login ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionLoginId">Required parameter: The institution login ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteCustomerAccountsByInstitutionLoginAsync(
                string customerId,
                string institutionLoginId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/aggregation/v1/customers/{customerId}/institutionLogins/{institutionLoginId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("institutionLoginId", institutionLoginId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get a customer account by ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <returns>Returns the Models.CustomerAccount response from the API call.</returns>
        public Models.CustomerAccount GetCustomerAccount(
                string customerId,
                string accountId)
            => CoreHelper.RunTask(GetCustomerAccountAsync(customerId, accountId));

        /// <summary>
        /// Get a customer account by ID.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccount response from the API call.</returns>
        public async Task<Models.CustomerAccount> GetCustomerAccountAsync(
                string customerId,
                string accountId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccount>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v2/customers/{customerId}/accounts/{accountId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccount>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Remove the given account from Finicity aggregation.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        public void DeleteCustomerAccount(
                string customerId,
                string accountId)
            => CoreHelper.RunVoidTask(DeleteCustomerAccountAsync(customerId, accountId));

        /// <summary>
        /// Remove the given account from Finicity aggregation.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteCustomerAccountAsync(
                string customerId,
                string accountId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/aggregation/v1/customers/{customerId}/accounts/{accountId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get all accounts owned by the given customer.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="status">Optional parameter: A filter to fetch account in the given status.</param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public Models.CustomerAccounts GetCustomerAccounts(
                string customerId,
                string status = null)
            => CoreHelper.RunTask(GetCustomerAccountsAsync(customerId, status));

        /// <summary>
        /// Get all accounts owned by the given customer.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="status">Optional parameter: A filter to fetch account in the given status.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public async Task<Models.CustomerAccounts> GetCustomerAccountsAsync(
                string customerId,
                string status = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccounts>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers/{customerId}/accounts")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Query(_query => _query.Setup("status", status))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccounts>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Refresh account and transaction data for all accounts associated with the  given `customerId` with a connection to the institution.
        /// Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.
        /// Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.
        /// The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public Models.CustomerAccounts RefreshCustomerAccounts(
                string customerId,
                object body = null)
            => CoreHelper.RunTask(RefreshCustomerAccountsAsync(customerId, body));

        /// <summary>
        /// Refresh account and transaction data for all accounts associated with the  given `customerId` with a connection to the institution.
        /// Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.
        /// Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.
        /// The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public async Task<Models.CustomerAccounts> RefreshCustomerAccountsAsync(
                string customerId,
                object body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccounts>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v1/customers/{customerId}/accounts")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccounts>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get all active accounts owned by the given customer at the given institution.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionId">Required parameter: The institution ID.</param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public Models.CustomerAccounts GetCustomerAccountsByInstitution(
                string customerId,
                long institutionId)
            => CoreHelper.RunTask(GetCustomerAccountsByInstitutionAsync(customerId, institutionId));

        /// <summary>
        /// Get all active accounts owned by the given customer at the given institution.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="institutionId">Required parameter: The institution ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CustomerAccounts response from the API call.</returns>
        public async Task<Models.CustomerAccounts> GetCustomerAccountsByInstitutionAsync(
                string customerId,
                long institutionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CustomerAccounts>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers/{customerId}/institutions/{institutionId}/accounts")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("institutionId", institutionId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CustomerAccounts>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}