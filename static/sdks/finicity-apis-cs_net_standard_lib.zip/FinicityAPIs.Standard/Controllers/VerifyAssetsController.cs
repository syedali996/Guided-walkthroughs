// <copyright file="VerifyAssetsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// VerifyAssetsController.
    /// </summary>
    public class VerifyAssetsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VerifyAssetsController"/> class.
        /// </summary>
        internal VerifyAssetsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Generate a Verification of Assets (VOA) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to twelve months of transaction history for each account and uses this information to generate the VOA report.
        /// This is a premium service. The billing rate is the variable rate for Verification of Assets under the current subscription plan. The billable event is the successful generation of a VOA report.
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.VOAReportAck response from the API call.</returns>
        public Models.VOAReportAck GenerateVOAReport(
                string customerId,
                Models.VOAReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOAReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a Verification of Assets (VOA) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to twelve months of transaction history for each account and uses this information to generate the VOA report.
        /// This is a premium service. The billing rate is the variable rate for Verification of Assets under the current subscription plan. The billable event is the successful generation of a VOA report.
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VOAReportAck response from the API call.</returns>
        public async Task<Models.VOAReportAck> GenerateVOAReportAsync(
                string customerId,
                Models.VOAReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.VOAReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voa")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.VOAReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate a Verification of Assets with Income (VOAI) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to 24 months of transaction history for each account and uses this information to generate the VOAI report. The report includes 1 - 6 months of all debit and credit transactions for asset verification. By default, the history is set to 61 days, however, you can change the transaction history in this section by setting the `fromDate` parameter. The report also includes up to 24 months of income credit transactions (ordered by account and confidence level) regardless of `fromDate` for income verification.
        /// This is a premium service. The billable event is the successful generation of a VOAI report.
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.VOAWithIncomeReportAck response from the API call.</returns>
        public Models.VOAWithIncomeReportAck GenerateVOAWithIncomeReport(
                string customerId,
                Models.VOAWithIncomeReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateVOAWithIncomeReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a Verification of Assets with Income (VOAI) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to 24 months of transaction history for each account and uses this information to generate the VOAI report. The report includes 1 - 6 months of all debit and credit transactions for asset verification. By default, the history is set to 61 days, however, you can change the transaction history in this section by setting the `fromDate` parameter. The report also includes up to 24 months of income credit transactions (ordered by account and confidence level) regardless of `fromDate` for income verification.
        /// This is a premium service. The billable event is the successful generation of a VOAI report.
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VOAWithIncomeReportAck response from the API call.</returns>
        public async Task<Models.VOAWithIncomeReportAck> GenerateVOAWithIncomeReportAsync(
                string customerId,
                Models.VOAWithIncomeReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.VOAWithIncomeReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/voaHistory")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.VOAWithIncomeReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve all checking, savings, money market, and investment accounts for a consumer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.
        /// If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.PrequalificationReportAck response from the API call.</returns>
        public Models.PrequalificationReportAck GeneratePrequalificationCRAReport(
                string customerId,
                Models.PrequalificationReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GeneratePrequalificationCRAReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Retrieve all checking, savings, money market, and investment accounts for a consumer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.
        /// If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PrequalificationReportAck response from the API call.</returns>
        public async Task<Models.PrequalificationReportAck> GeneratePrequalificationCRAReportAsync(
                string customerId,
                Models.PrequalificationReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PrequalificationReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/preQualVoa")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PrequalificationReportAck>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieve all checking, savings, money market, and investment accounts for a customer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.
        /// If no account type of checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.PrequalificationReportAck response from the API call.</returns>
        public Models.PrequalificationReportAck GeneratePrequalificationNonCRAReport(
                string customerId,
                Models.PrequalificationReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GeneratePrequalificationNonCRAReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Retrieve all checking, savings, money market, and investment accounts for a customer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.
        /// If no account type of checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PrequalificationReportAck response from the API call.</returns>
        public async Task<Models.PrequalificationReportAck> GeneratePrequalificationNonCRAReportAsync(
                string customerId,
                Models.PrequalificationReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PrequalificationReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/assetSummary")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.PrequalificationReportAck>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}