// <copyright file="BankStatementsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// BankStatementsController.
    /// </summary>
    public class BankStatementsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BankStatementsController"/> class.
        /// </summary>
        internal BankStatementsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Retrieve the customer's bank statements in PDF format. Up to 24 months of history is available depending on the financial institution. Since this is a premium service, charges incur per each successful statement retrieved. .
        /// For certified financial institutions, statements are available for the following account types:.
        /// * Checking.
        /// * Savings.
        /// * Money market.
        /// * CDs.
        /// * Investments.
        /// * Mortgage.
        /// * Credit cards.
        /// * Loans.
        /// * Line of credit.
        /// * Student Loans.
        /// Note: setting the timeout to 180 seconds is recommended to allow enough time for a response.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="index">Optional parameter: Request statements from 1-24. By default, 1 is the most recent statement. Increase the index value to count back (by month) and retrieve its most recent statement..</param>
        /// <param name="type">Optional parameter: The type of statement to retrieve.</param>
        /// <returns>Returns the Stream response from the API call.</returns>
        public Stream GetCustomerAccountStatement(
                string customerId,
                string accountId,
                int? index = 1,
                string type = null)
            => CoreHelper.RunTask(GetCustomerAccountStatementAsync(customerId, accountId, index, type));

        /// <summary>
        /// Retrieve the customer's bank statements in PDF format. Up to 24 months of history is available depending on the financial institution. Since this is a premium service, charges incur per each successful statement retrieved. .
        /// For certified financial institutions, statements are available for the following account types:.
        /// * Checking.
        /// * Savings.
        /// * Money market.
        /// * CDs.
        /// * Investments.
        /// * Mortgage.
        /// * Credit cards.
        /// * Loans.
        /// * Line of credit.
        /// * Student Loans.
        /// Note: setting the timeout to 180 seconds is recommended to allow enough time for a response.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="index">Optional parameter: Request statements from 1-24. By default, 1 is the most recent statement. Increase the index value to count back (by month) and retrieve its most recent statement..</param>
        /// <param name="type">Optional parameter: The type of statement to retrieve.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Stream response from the API call.</returns>
        public async Task<Stream> GetCustomerAccountStatementAsync(
                string customerId,
                string accountId,
                int? index = 1,
                string type = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Stream>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v1/customers/{customerId}/accounts/{accountId}/statement")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))
                      .Query(_query => _query.Setup("index", (index != null) ? index : 1))
                      .Query(_query => _query.Setup("type", type))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate a Statement Report report for the given accounts under the given customer.
        /// This is a premium service. A billable event will be created upon the successful generation of the Statement Report. .
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <returns>Returns the Models.StatementReportAck response from the API call.</returns>
        public Models.StatementReportAck GenerateStatementReport(
                string customerId,
                Models.StatementReportConstraints body,
                string callbackUrl = null)
            => CoreHelper.RunTask(GenerateStatementReportAsync(customerId, body, callbackUrl));

        /// <summary>
        /// Generate a Statement Report report for the given accounts under the given customer.
        /// This is a premium service. A billable event will be created upon the successful generation of the Statement Report. .
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.StatementReportAck response from the API call.</returns>
        public async Task<Models.StatementReportAck> GenerateStatementReportAsync(
                string customerId,
                Models.StatementReportConstraints body,
                string callbackUrl = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.StatementReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/statement")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.StatementReportAck>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}