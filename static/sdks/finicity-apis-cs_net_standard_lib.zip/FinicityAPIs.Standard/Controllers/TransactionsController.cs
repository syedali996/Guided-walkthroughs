// <copyright file="TransactionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// TransactionsController.
    /// </summary>
    public class TransactionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TransactionsController"/> class.
        /// </summary>
        internal TransactionsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.
        /// This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.).
        /// The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        /// The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.
        /// In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:.
        /// * The institution's policy has changed, making more transactions available.
        /// * Finicity has now added a longer transaction history support for the institution.
        /// * The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team.
        /// In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        public void LoadHistoricTransactionsForCustomerAccount(
                string customerId,
                string accountId,
                object body = null)
            => CoreHelper.RunVoidTask(LoadHistoricTransactionsForCustomerAccountAsync(customerId, accountId, body));

        /// <summary>
        /// Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.
        /// This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.).
        /// The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        /// The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.
        /// In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:.
        /// * The institution's policy has changed, making more transactions available.
        /// * Finicity has now added a longer transaction history support for the institution.
        /// * The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team.
        /// In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="body">Optional parameter: No payload expected.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task LoadHistoricTransactionsForCustomerAccountAsync(
                string customerId,
                string accountId,
                object body = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/aggregation/v1/customers/{customerId}/accounts/{accountId}/transactions/historic")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
)
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get all transactions available for this customer within the given date range, across all accounts. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.
        /// Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the service Load Historic Transactions for Account.
        /// There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="fromDate">Required parameter: A start date.</param>
        /// <param name="toDate">Required parameter: A end date.</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="sort">Optional parameter: Date sort order: "asc" for ascending, "desc" for descending.</param>
        /// <param name="includePending">Optional parameter: If pending transactions must be included.</param>
        /// <returns>Returns the Models.Transactions response from the API call.</returns>
        public Models.Transactions GetAllCustomerTransactions(
                string customerId,
                long fromDate,
                long toDate,
                int? start = 1,
                int? limit = 25,
                string sort = "desc",
                bool? includePending = false)
            => CoreHelper.RunTask(GetAllCustomerTransactionsAsync(customerId, fromDate, toDate, start, limit, sort, includePending));

        /// <summary>
        /// Get all transactions available for this customer within the given date range, across all accounts. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.
        /// Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the service Load Historic Transactions for Account.
        /// There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="fromDate">Required parameter: A start date.</param>
        /// <param name="toDate">Required parameter: A end date.</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="sort">Optional parameter: Date sort order: "asc" for ascending, "desc" for descending.</param>
        /// <param name="includePending">Optional parameter: If pending transactions must be included.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Transactions response from the API call.</returns>
        public async Task<Models.Transactions> GetAllCustomerTransactionsAsync(
                string customerId,
                long fromDate,
                long toDate,
                int? start = 1,
                int? limit = 25,
                string sort = "desc",
                bool? includePending = false,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Transactions>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v3/customers/{customerId}/transactions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Query(_query => _query.Setup("fromDate", fromDate))
                      .Query(_query => _query.Setup("toDate", toDate))
                      .Query(_query => _query.Setup("start", (start != null) ? start : 1))
                      .Query(_query => _query.Setup("limit", (limit != null) ? limit : 25))
                      .Query(_query => _query.Setup("sort", (sort != null) ? sort : "desc"))
                      .Query(_query => _query.Setup("includePending", (includePending != null) ? includePending : false))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.Transactions>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get details for the given transaction.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="transactionId">Required parameter: A transaction ID.</param>
        /// <returns>Returns the Models.Transaction response from the API call.</returns>
        public Models.Transaction GetCustomerTransaction(
                string customerId,
                long transactionId)
            => CoreHelper.RunTask(GetCustomerTransactionAsync(customerId, transactionId));

        /// <summary>
        /// Get details for the given transaction.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="transactionId">Required parameter: A transaction ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Transaction response from the API call.</returns>
        public async Task<Models.Transaction> GetCustomerTransactionAsync(
                string customerId,
                long transactionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Transaction>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v2/customers/{customerId}/transactions/{transactionId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("transactionId", transactionId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.Transaction>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get all transactions available for this customer account within the given date range. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.
        /// Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the Cash Flow Verification service Load Historic Transactions for Account.
        /// There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="fromDate">Required parameter: A start date.</param>
        /// <param name="toDate">Required parameter: A end date.</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="sort">Optional parameter: Date sort order: "asc" for ascending, "desc" for descending.</param>
        /// <param name="includePending">Optional parameter: If pending transactions must be included.</param>
        /// <returns>Returns the Models.Transactions response from the API call.</returns>
        public Models.Transactions GetCustomerAccountTransactions(
                string customerId,
                string accountId,
                long fromDate,
                long toDate,
                int? start = 1,
                int? limit = 25,
                string sort = "desc",
                bool? includePending = false)
            => CoreHelper.RunTask(GetCustomerAccountTransactionsAsync(customerId, accountId, fromDate, toDate, start, limit, sort, includePending));

        /// <summary>
        /// Get all transactions available for this customer account within the given date range. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.
        /// Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the Cash Flow Verification service Load Historic Transactions for Account.
        /// There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="accountId">Required parameter: The account ID.</param>
        /// <param name="fromDate">Required parameter: A start date.</param>
        /// <param name="toDate">Required parameter: A end date.</param>
        /// <param name="start">Optional parameter: Index of the page of results to return.</param>
        /// <param name="limit">Optional parameter: Maximum number of results per page.</param>
        /// <param name="sort">Optional parameter: Date sort order: "asc" for ascending, "desc" for descending.</param>
        /// <param name="includePending">Optional parameter: If pending transactions must be included.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Transactions response from the API call.</returns>
        public async Task<Models.Transactions> GetCustomerAccountTransactionsAsync(
                string customerId,
                string accountId,
                long fromDate,
                long toDate,
                int? start = 1,
                int? limit = 25,
                string sort = "desc",
                bool? includePending = false,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Transactions>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/aggregation/v4/customers/{customerId}/accounts/{accountId}/transactions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Template(_template => _template.Setup("accountId", accountId))
                      .Query(_query => _query.Setup("fromDate", fromDate))
                      .Query(_query => _query.Setup("toDate", toDate))
                      .Query(_query => _query.Setup("start", (start != null) ? start : 1))
                      .Query(_query => _query.Setup("limit", (limit != null) ? limit : 25))
                      .Query(_query => _query.Setup("sort", (sort != null) ? sort : "desc"))
                      .Query(_query => _query.Setup("includePending", (includePending != null) ? includePending : false))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.Transactions>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Generate a Transaction Report for the given accounts under the given customer. This service retrieves up to 24 months of transaction history for the given customer. It then uses this information to generate the Transaction Report.
        /// This is a premium service. A billable event will be created upon the successful generation of the Transactions Report. .
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// There cannot be more than 24 months between `fromDate` and `toDate`.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="toDate">Required parameter: A end date.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="includePending">Optional parameter: If pending transactions must be included.</param>
        /// <returns>Returns the Models.TransactionsReportAck response from the API call.</returns>
        public Models.TransactionsReportAck GenerateTransactionsReport(
                string customerId,
                long toDate,
                Models.TransactionsReportConstraints body,
                string callbackUrl = null,
                bool? includePending = false)
            => CoreHelper.RunTask(GenerateTransactionsReportAsync(customerId, toDate, body, callbackUrl, includePending));

        /// <summary>
        /// Generate a Transaction Report for the given accounts under the given customer. This service retrieves up to 24 months of transaction history for the given customer. It then uses this information to generate the Transaction Report.
        /// This is a premium service. A billable event will be created upon the successful generation of the Transactions Report. .
        /// Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        /// There cannot be more than 24 months between `fromDate` and `toDate`.
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <param name="customerId">Required parameter: A customer ID.</param>
        /// <param name="toDate">Required parameter: A end date.</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="callbackUrl">Optional parameter: A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code..</param>
        /// <param name="includePending">Optional parameter: If pending transactions must be included.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TransactionsReportAck response from the API call.</returns>
        public async Task<Models.TransactionsReportAck> GenerateTransactionsReportAsync(
                string customerId,
                long toDate,
                Models.TransactionsReportConstraints body,
                string callbackUrl = null,
                bool? includePending = false,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.TransactionsReportAck>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/decisioning/v2/customers/{customerId}/transactions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("customerId", customerId))
                      .Query(_query => _query.Setup("toDate", toDate))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Query(_query => _query.Setup("callbackUrl", callbackUrl))
                      .Query(_query => _query.Setup("includePending", (includePending != null) ? includePending : false))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("The request was rejected", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("The request lacks valid authentication credentials. Check \"Finicity-App-Key\" or \"Finicity-App-Token\".", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("The resource doesn't exist", (_reason, _context) => new ErrorMessageErrorException(_reason, _context)))
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.TransactionsReportAck>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}