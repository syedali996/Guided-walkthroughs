// <copyright file="ObbErrorMessageException.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Models;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbErrorMessageException.
    /// </summary>
    public class ObbErrorMessageException : ApiException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbErrorMessageException"/> class.
        /// </summary>
        /// <param name="reason"> The reason for throwing exception.</param>
        /// <param name="context"> The HTTP context that encapsulates request and response objects.</param>
        public ObbErrorMessageException(string reason, HttpContext context)
            : base(reason, context)
        {
        }

        /// <summary>
        /// Error code
        /// </summary>
        [JsonProperty("errorCode")]
        public int ErrorCode { get; set; }

        /// <summary>
        /// Detailed reason about the source of the error
        /// </summary>
        [JsonProperty("message")]
        public new string Message { get; set; }
    }
}