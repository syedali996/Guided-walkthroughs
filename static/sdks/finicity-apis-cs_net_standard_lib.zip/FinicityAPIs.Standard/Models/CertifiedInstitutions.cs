// <copyright file="CertifiedInstitutions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CertifiedInstitutions.
    /// </summary>
    public class CertifiedInstitutions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CertifiedInstitutions"/> class.
        /// </summary>
        public CertifiedInstitutions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CertifiedInstitutions"/> class.
        /// </summary>
        /// <param name="found">found.</param>
        /// <param name="displaying">displaying.</param>
        /// <param name="moreAvailable">moreAvailable.</param>
        /// <param name="requestedDate">requestedDate.</param>
        /// <param name="institutions">institutions.</param>
        public CertifiedInstitutions(
            int found,
            int displaying,
            bool moreAvailable,
            long requestedDate,
            List<Models.CertifiedInstitution> institutions)
        {
            this.Found = found;
            this.Displaying = displaying;
            this.MoreAvailable = moreAvailable;
            this.RequestedDate = requestedDate;
            this.Institutions = institutions;
        }

        /// <summary>
        /// The total number of results matching search criteria
        /// </summary>
        [JsonProperty("found")]
        public int Found { get; set; }

        /// <summary>
        /// The number of results returned
        /// </summary>
        [JsonProperty("displaying")]
        public int Displaying { get; set; }

        /// <summary>
        /// If the value of `moreAvailable` is "true", you can retrieve the next page of results by increasing the value of the start parameter in your next request:"...&start=6&limit=5"
        /// </summary>
        [JsonProperty("moreAvailable")]
        public bool MoreAvailable { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("requestedDate")]
        public long RequestedDate { get; set; }

        /// <summary>
        /// A list of institutions
        /// </summary>
        [JsonProperty("institutions")]
        public List<Models.CertifiedInstitution> Institutions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CertifiedInstitutions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CertifiedInstitutions other &&
                this.Found.Equals(other.Found) &&
                this.Displaying.Equals(other.Displaying) &&
                this.MoreAvailable.Equals(other.MoreAvailable) &&
                this.RequestedDate.Equals(other.RequestedDate) &&
                ((this.Institutions == null && other.Institutions == null) || (this.Institutions?.Equals(other.Institutions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Found = {this.Found}");
            toStringOutput.Add($"this.Displaying = {this.Displaying}");
            toStringOutput.Add($"this.MoreAvailable = {this.MoreAvailable}");
            toStringOutput.Add($"this.RequestedDate = {this.RequestedDate}");
            toStringOutput.Add($"this.Institutions = {(this.Institutions == null ? "null" : $"[{string.Join(", ", this.Institutions)} ]")}");
        }
    }
}