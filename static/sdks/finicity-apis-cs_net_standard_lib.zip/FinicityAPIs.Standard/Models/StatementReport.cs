// <copyright file="StatementReport.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// StatementReport.
    /// </summary>
    public class StatementReport
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatementReport"/> class.
        /// </summary>
        public StatementReport()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="StatementReport"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="customerType">customerType.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="requestId">requestId.</param>
        /// <param name="requesterName">requesterName.</param>
        /// <param name="createdDate">createdDate.</param>
        /// <param name="title">title.</param>
        /// <param name="consumerId">consumerId.</param>
        /// <param name="consumerSsn">consumerSsn.</param>
        /// <param name="type">type.</param>
        /// <param name="status">status.</param>
        /// <param name="errors">errors.</param>
        /// <param name="assetId">assetId.</param>
        public StatementReport(
            string id = null,
            string customerType = null,
            long? customerId = null,
            string requestId = null,
            string requesterName = null,
            long? createdDate = null,
            string title = null,
            string consumerId = null,
            string consumerSsn = null,
            string type = null,
            string status = null,
            List<Models.ErrorMessage> errors = null,
            string assetId = null)
        {
            this.Id = id;
            this.CustomerType = customerType;
            this.CustomerId = customerId;
            this.RequestId = requestId;
            this.RequesterName = requesterName;
            this.CreatedDate = createdDate;
            this.Title = title;
            this.ConsumerId = consumerId;
            this.ConsumerSsn = consumerSsn;
            this.Type = type;
            this.Status = status;
            this.Errors = errors;
            this.AssetId = assetId;
        }

        /// <summary>
        /// A report ID
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// The type of customer ("active" or "testing" or "" for all types)
        /// </summary>
        [JsonProperty("customerType", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomerType { get; set; }

        /// <summary>
        /// A customer ID represented as a number. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId", NullValueHandling = NullValueHandling.Ignore)]
        public long? CustomerId { get; set; }

        /// <summary>
        /// Finicity indicator to track all activity associated with this report
        /// </summary>
        [JsonProperty("requestId", NullValueHandling = NullValueHandling.Ignore)]
        public string RequestId { get; set; }

        /// <summary>
        /// Name of a Finicity partner
        /// </summary>
        [JsonProperty("requesterName", NullValueHandling = NullValueHandling.Ignore)]
        public string RequesterName { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? CreatedDate { get; set; }

        /// <summary>
        /// Title of the report
        /// </summary>
        [JsonProperty("title", NullValueHandling = NullValueHandling.Ignore)]
        public string Title { get; set; }

        /// <summary>
        /// A consumer ID. See Create Consumer API for how to create a consumer ID.
        /// </summary>
        [JsonProperty("consumerId", NullValueHandling = NullValueHandling.Ignore)]
        public string ConsumerId { get; set; }

        /// <summary>
        /// Last 4 digits of a SSN
        /// </summary>
        [JsonProperty("consumerSsn", NullValueHandling = NullValueHandling.Ignore)]
        public string ConsumerSsn { get; set; }

        /// <summary>
        /// A report type. Possible values:
        ///   * "voi"
        ///   * "voa"
        ///   * "voaHistory"
        ///   * "history"
        ///   * "voieTxVerify"
        ///   * "voieWithReport"
        ///   * "voieWithInterview"
        ///   * "paystatement"
        ///   * "preQualVoa"
        ///   * "assetSummary"
        ///   * "voie"
        ///   * "transactions"
        ///   * "statement"
        ///   * "voiePayroll"
        ///   * "voeTransactions"
        ///   * "voePayroll"
        ///   * "cfrp"
        ///   * "cfrb"
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// A report generation status. Possible values: "inProgress", "success", "failure".
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// In case errors occurred during the report generation
        /// </summary>
        [JsonProperty("errors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ErrorMessage> Errors { get; set; }

        /// <summary>
        /// An asset ID. Generated by Connect or by using the Store Customer Pay Statement API.
        /// </summary>
        [JsonProperty("assetId", NullValueHandling = NullValueHandling.Ignore)]
        public string AssetId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"StatementReport : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is StatementReport other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.CustomerType == null && other.CustomerType == null) || (this.CustomerType?.Equals(other.CustomerType) == true)) &&
                ((this.CustomerId == null && other.CustomerId == null) || (this.CustomerId?.Equals(other.CustomerId) == true)) &&
                ((this.RequestId == null && other.RequestId == null) || (this.RequestId?.Equals(other.RequestId) == true)) &&
                ((this.RequesterName == null && other.RequesterName == null) || (this.RequesterName?.Equals(other.RequesterName) == true)) &&
                ((this.CreatedDate == null && other.CreatedDate == null) || (this.CreatedDate?.Equals(other.CreatedDate) == true)) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true)) &&
                ((this.ConsumerId == null && other.ConsumerId == null) || (this.ConsumerId?.Equals(other.ConsumerId) == true)) &&
                ((this.ConsumerSsn == null && other.ConsumerSsn == null) || (this.ConsumerSsn?.Equals(other.ConsumerSsn) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Errors == null && other.Errors == null) || (this.Errors?.Equals(other.Errors) == true)) &&
                ((this.AssetId == null && other.AssetId == null) || (this.AssetId?.Equals(other.AssetId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.CustomerType = {(this.CustomerType == null ? "null" : this.CustomerType == string.Empty ? "" : this.CustomerType)}");
            toStringOutput.Add($"this.CustomerId = {(this.CustomerId == null ? "null" : this.CustomerId.ToString())}");
            toStringOutput.Add($"this.RequestId = {(this.RequestId == null ? "null" : this.RequestId == string.Empty ? "" : this.RequestId)}");
            toStringOutput.Add($"this.RequesterName = {(this.RequesterName == null ? "null" : this.RequesterName == string.Empty ? "" : this.RequesterName)}");
            toStringOutput.Add($"this.CreatedDate = {(this.CreatedDate == null ? "null" : this.CreatedDate.ToString())}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title == string.Empty ? "" : this.Title)}");
            toStringOutput.Add($"this.ConsumerId = {(this.ConsumerId == null ? "null" : this.ConsumerId == string.Empty ? "" : this.ConsumerId)}");
            toStringOutput.Add($"this.ConsumerSsn = {(this.ConsumerSsn == null ? "null" : this.ConsumerSsn == string.Empty ? "" : this.ConsumerSsn)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.Errors = {(this.Errors == null ? "null" : $"[{string.Join(", ", this.Errors)} ]")}");
            toStringOutput.Add($"this.AssetId = {(this.AssetId == null ? "null" : this.AssetId == string.Empty ? "" : this.AssetId)}");
        }
    }
}