// <copyright file="ConsumerAttributesAnalyticId.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesAnalyticId.
    /// </summary>
    public class ConsumerAttributesAnalyticId
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesAnalyticId"/> class.
        /// </summary>
        public ConsumerAttributesAnalyticId()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesAnalyticId"/> class.
        /// </summary>
        /// <param name="analyticId">analytic_id.</param>
        /// <param name="createdDate">created_date.</param>
        public ConsumerAttributesAnalyticId(
            string analyticId,
            string createdDate)
        {
            this.AnalyticId = analyticId;
            this.CreatedDate = createdDate;
        }

        /// <summary>
        /// An ID for a Consumer Attributes report
        /// </summary>
        [JsonProperty("analytic_id")]
        public string AnalyticId { get; set; }

        /// <summary>
        /// A date-time without time zone
        /// </summary>
        [JsonProperty("created_date")]
        public string CreatedDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesAnalyticId : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesAnalyticId other &&
                ((this.AnalyticId == null && other.AnalyticId == null) || (this.AnalyticId?.Equals(other.AnalyticId) == true)) &&
                ((this.CreatedDate == null && other.CreatedDate == null) || (this.CreatedDate?.Equals(other.CreatedDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AnalyticId = {(this.AnalyticId == null ? "null" : this.AnalyticId == string.Empty ? "" : this.AnalyticId)}");
            toStringOutput.Add($"this.CreatedDate = {(this.CreatedDate == null ? "null" : this.CreatedDate == string.Empty ? "" : this.CreatedDate)}");
        }
    }
}