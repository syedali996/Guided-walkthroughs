// <copyright file="ReportInstitution2.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReportInstitution2.
    /// </summary>
    public class ReportInstitution2
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportInstitution2"/> class.
        /// </summary>
        public ReportInstitution2()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportInstitution2"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="urlHomeApp">urlHomeApp.</param>
        /// <param name="accounts">accounts.</param>
        public ReportInstitution2(
            long id,
            string name,
            string urlHomeApp,
            List<Models.Account> accounts)
        {
            this.Id = id;
            this.Name = name;
            this.UrlHomeApp = urlHomeApp;
            this.Accounts = accounts;
        }

        /// <summary>
        /// The ID of a financial institution, represented as a number
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// Finicity institution name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// The URL of the Financial Institution
        /// </summary>
        [JsonProperty("urlHomeApp")]
        public string UrlHomeApp { get; set; }

        /// <summary>
        /// A list of account records
        /// </summary>
        [JsonProperty("accounts")]
        public List<Models.Account> Accounts { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReportInstitution2 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReportInstitution2 other &&
                this.Id.Equals(other.Id) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.UrlHomeApp == null && other.UrlHomeApp == null) || (this.UrlHomeApp?.Equals(other.UrlHomeApp) == true)) &&
                ((this.Accounts == null && other.Accounts == null) || (this.Accounts?.Equals(other.Accounts) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.UrlHomeApp = {(this.UrlHomeApp == null ? "null" : this.UrlHomeApp == string.Empty ? "" : this.UrlHomeApp)}");
            toStringOutput.Add($"this.Accounts = {(this.Accounts == null ? "null" : $"[{string.Join(", ", this.Accounts)} ]")}");
        }
    }
}