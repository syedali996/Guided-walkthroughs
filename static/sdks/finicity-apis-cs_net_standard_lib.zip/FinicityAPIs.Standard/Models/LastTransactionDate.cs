// <copyright file="LastTransactionDate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// LastTransactionDate.
    /// </summary>
    public class LastTransactionDate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LastTransactionDate"/> class.
        /// </summary>
        public LastTransactionDate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LastTransactionDate"/> class.
        /// </summary>
        /// <param name="date">date.</param>
        /// <param name="depositsCredits">depositsCredits.</param>
        /// <param name="withdrawalsDebits">withdrawalsDebits.</param>
        /// <param name="zeroAmountTransaction">zeroAmountTransaction.</param>
        /// <param name="transactionDescription">transactionDescription.</param>
        public LastTransactionDate(
            string date,
            double? depositsCredits = null,
            double? withdrawalsDebits = null,
            double? zeroAmountTransaction = null,
            string transactionDescription = null)
        {
            this.Date = date;
            this.DepositsCredits = depositsCredits;
            this.WithdrawalsDebits = withdrawalsDebits;
            this.ZeroAmountTransaction = zeroAmountTransaction;
            this.TransactionDescription = transactionDescription;
        }

        /// <summary>
        /// Date the deposit transaction was posted
        /// </summary>
        [JsonProperty("date")]
        public string Date { get; set; }

        /// <summary>
        /// Amount of transaction if deposit, otherwise null
        /// </summary>
        [JsonProperty("depositsCredits", NullValueHandling = NullValueHandling.Ignore)]
        public double? DepositsCredits { get; set; }

        /// <summary>
        /// Amount of transaction if withdrawal, otherwise null
        /// </summary>
        [JsonProperty("withdrawalsDebits", NullValueHandling = NullValueHandling.Ignore)]
        public double? WithdrawalsDebits { get; set; }

        /// <summary>
        /// Amount of transaction if zero, otherwise null
        /// </summary>
        [JsonProperty("zeroAmountTransaction", NullValueHandling = NullValueHandling.Ignore)]
        public double? ZeroAmountTransaction { get; set; }

        /// <summary>
        /// Description of transaction
        /// </summary>
        [JsonProperty("transactionDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LastTransactionDate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LastTransactionDate other &&
                ((this.Date == null && other.Date == null) || (this.Date?.Equals(other.Date) == true)) &&
                ((this.DepositsCredits == null && other.DepositsCredits == null) || (this.DepositsCredits?.Equals(other.DepositsCredits) == true)) &&
                ((this.WithdrawalsDebits == null && other.WithdrawalsDebits == null) || (this.WithdrawalsDebits?.Equals(other.WithdrawalsDebits) == true)) &&
                ((this.ZeroAmountTransaction == null && other.ZeroAmountTransaction == null) || (this.ZeroAmountTransaction?.Equals(other.ZeroAmountTransaction) == true)) &&
                ((this.TransactionDescription == null && other.TransactionDescription == null) || (this.TransactionDescription?.Equals(other.TransactionDescription) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Date = {(this.Date == null ? "null" : this.Date == string.Empty ? "" : this.Date)}");
            toStringOutput.Add($"this.DepositsCredits = {(this.DepositsCredits == null ? "null" : this.DepositsCredits.ToString())}");
            toStringOutput.Add($"this.WithdrawalsDebits = {(this.WithdrawalsDebits == null ? "null" : this.WithdrawalsDebits.ToString())}");
            toStringOutput.Add($"this.ZeroAmountTransaction = {(this.ZeroAmountTransaction == null ? "null" : this.ZeroAmountTransaction.ToString())}");
            toStringOutput.Add($"this.TransactionDescription = {(this.TransactionDescription == null ? "null" : this.TransactionDescription == string.Empty ? "" : this.TransactionDescription)}");
        }
    }
}