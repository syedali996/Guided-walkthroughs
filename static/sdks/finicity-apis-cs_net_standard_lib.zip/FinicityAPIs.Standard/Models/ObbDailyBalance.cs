// <copyright file="ObbDailyBalance.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbDailyBalance.
    /// </summary>
    public class ObbDailyBalance
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDailyBalance"/> class.
        /// </summary>
        public ObbDailyBalance()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDailyBalance"/> class.
        /// </summary>
        /// <param name="date">date.</param>
        /// <param name="dayOfWeek">dayOfWeek.</param>
        /// <param name="endingBalance">endingBalance.</param>
        public ObbDailyBalance(
            string date,
            string dayOfWeek,
            double endingBalance)
        {
            this.Date = date;
            this.DayOfWeek = dayOfWeek;
            this.EndingBalance = endingBalance;
        }

        /// <summary>
        /// Date of balance information
        /// </summary>
        [JsonProperty("date")]
        public string Date { get; set; }

        /// <summary>
        /// Day of the week for which balance information available
        /// </summary>
        [JsonProperty("dayOfWeek")]
        public string DayOfWeek { get; set; }

        /// <summary>
        /// End of day balance
        /// </summary>
        [JsonProperty("endingBalance")]
        public double EndingBalance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbDailyBalance : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbDailyBalance other &&
                ((this.Date == null && other.Date == null) || (this.Date?.Equals(other.Date) == true)) &&
                ((this.DayOfWeek == null && other.DayOfWeek == null) || (this.DayOfWeek?.Equals(other.DayOfWeek) == true)) &&
                this.EndingBalance.Equals(other.EndingBalance);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Date = {(this.Date == null ? "null" : this.Date == string.Empty ? "" : this.Date)}");
            toStringOutput.Add($"this.DayOfWeek = {(this.DayOfWeek == null ? "null" : this.DayOfWeek == string.Empty ? "" : this.DayOfWeek)}");
            toStringOutput.Add($"this.EndingBalance = {this.EndingBalance}");
        }
    }
}