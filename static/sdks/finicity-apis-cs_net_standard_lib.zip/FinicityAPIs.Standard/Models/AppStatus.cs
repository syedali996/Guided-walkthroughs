// <copyright file="AppStatus.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AppStatus.
    /// </summary>
    public class AppStatus
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppStatus"/> class.
        /// </summary>
        public AppStatus()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AppStatus"/> class.
        /// </summary>
        /// <param name="partnerId">partnerId.</param>
        /// <param name="preAppId">preAppId.</param>
        /// <param name="appName">appName.</param>
        /// <param name="submittedDate">submittedDate.</param>
        /// <param name="modifiedDate">modifiedDate.</param>
        /// <param name="status">status.</param>
        /// <param name="note">note.</param>
        /// <param name="applicationId">applicationId.</param>
        /// <param name="scopes">scopes.</param>
        /// <param name="institutionDetails">institutionDetails.</param>
        public AppStatus(
            string partnerId,
            string preAppId,
            string appName,
            long submittedDate,
            long modifiedDate,
            string status,
            string note = null,
            string applicationId = null,
            string scopes = null,
            List<Models.AppFinancialInstitutionStatus> institutionDetails = null)
        {
            this.PartnerId = partnerId;
            this.PreAppId = preAppId;
            this.Note = note;
            this.ApplicationId = applicationId;
            this.AppName = appName;
            this.SubmittedDate = submittedDate;
            this.ModifiedDate = modifiedDate;
            this.Status = status;
            this.Scopes = scopes;
            this.InstitutionDetails = institutionDetails;
        }

        /// <summary>
        /// Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerId")]
        public string PartnerId { get; set; }

        /// <summary>
        /// Identifier to track the application registration from the App Registration and Get App Registration Status APIs
        /// </summary>
        [JsonProperty("preAppId")]
        public string PreAppId { get; set; }

        /// <summary>
        /// A note on the registration. Typically used to indicate reasons for rejected apps.
        /// </summary>
        [JsonProperty("note", NullValueHandling = NullValueHandling.Ignore)]
        public string Note { get; set; }

        /// <summary>
        /// `applicationId` value returned from the Get App Registration Status API and the partner assign the customers to. This cannot be changed once set. Only applicable in cases of partners with multiple registered applications. If the partner only has one app, this can usually be omitted. This field is populated after the app is in a status approved.
        /// </summary>
        [JsonProperty("applicationId", NullValueHandling = NullValueHandling.Ignore)]
        public string ApplicationId { get; set; }

        /// <summary>
        /// The name of the application assigned to the customer
        /// </summary>
        [JsonProperty("appName")]
        public string AppName { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("submittedDate")]
        public long SubmittedDate { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("modifiedDate")]
        public long ModifiedDate { get; set; }

        /// <summary>
        /// The status of an app registration request. "A" means approved. "P" means pending which is the status when initially submitted or when the app is modified and awaiting approval. "R" means rejected. If it is rejected there will be a note with the rejected reason.
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <summary>
        /// Indicates scopes of data accessible to the app
        /// </summary>
        [JsonProperty("scopes", NullValueHandling = NullValueHandling.Ignore)]
        public string Scopes { get; set; }

        /// <summary>
        /// A list of the registration status for each FI for the application
        /// </summary>
        [JsonProperty("institutionDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AppFinancialInstitutionStatus> InstitutionDetails { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AppStatus : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AppStatus other &&
                ((this.PartnerId == null && other.PartnerId == null) || (this.PartnerId?.Equals(other.PartnerId) == true)) &&
                ((this.PreAppId == null && other.PreAppId == null) || (this.PreAppId?.Equals(other.PreAppId) == true)) &&
                ((this.Note == null && other.Note == null) || (this.Note?.Equals(other.Note) == true)) &&
                ((this.ApplicationId == null && other.ApplicationId == null) || (this.ApplicationId?.Equals(other.ApplicationId) == true)) &&
                ((this.AppName == null && other.AppName == null) || (this.AppName?.Equals(other.AppName) == true)) &&
                this.SubmittedDate.Equals(other.SubmittedDate) &&
                this.ModifiedDate.Equals(other.ModifiedDate) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Scopes == null && other.Scopes == null) || (this.Scopes?.Equals(other.Scopes) == true)) &&
                ((this.InstitutionDetails == null && other.InstitutionDetails == null) || (this.InstitutionDetails?.Equals(other.InstitutionDetails) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PartnerId = {(this.PartnerId == null ? "null" : this.PartnerId == string.Empty ? "" : this.PartnerId)}");
            toStringOutput.Add($"this.PreAppId = {(this.PreAppId == null ? "null" : this.PreAppId == string.Empty ? "" : this.PreAppId)}");
            toStringOutput.Add($"this.Note = {(this.Note == null ? "null" : this.Note == string.Empty ? "" : this.Note)}");
            toStringOutput.Add($"this.ApplicationId = {(this.ApplicationId == null ? "null" : this.ApplicationId == string.Empty ? "" : this.ApplicationId)}");
            toStringOutput.Add($"this.AppName = {(this.AppName == null ? "null" : this.AppName == string.Empty ? "" : this.AppName)}");
            toStringOutput.Add($"this.SubmittedDate = {this.SubmittedDate}");
            toStringOutput.Add($"this.ModifiedDate = {this.ModifiedDate}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.Scopes = {(this.Scopes == null ? "null" : this.Scopes == string.Empty ? "" : this.Scopes)}");
            toStringOutput.Add($"this.InstitutionDetails = {(this.InstitutionDetails == null ? "null" : $"[{string.Join(", ", this.InstitutionDetails)} ]")}");
        }
    }
}