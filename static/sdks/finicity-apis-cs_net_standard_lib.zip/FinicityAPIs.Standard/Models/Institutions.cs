// <copyright file="Institutions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Institutions.
    /// </summary>
    public class Institutions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Institutions"/> class.
        /// </summary>
        public Institutions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Institutions"/> class.
        /// </summary>
        /// <param name="found">found.</param>
        /// <param name="displaying">displaying.</param>
        /// <param name="moreAvailable">moreAvailable.</param>
        /// <param name="createdDate">createdDate.</param>
        /// <param name="institutionsProp">institutions.</param>
        public Institutions(
            int found,
            int displaying,
            bool moreAvailable,
            long createdDate,
            List<Models.Institution> institutionsProp)
        {
            this.Found = found;
            this.Displaying = displaying;
            this.MoreAvailable = moreAvailable;
            this.CreatedDate = createdDate;
            this.InstitutionsProp = institutionsProp;
        }

        /// <summary>
        /// The total number of results matching search criteria
        /// </summary>
        [JsonProperty("found")]
        public int Found { get; set; }

        /// <summary>
        /// The number of results returned
        /// </summary>
        [JsonProperty("displaying")]
        public int Displaying { get; set; }

        /// <summary>
        /// If the value of `moreAvailable` is "true", you can retrieve the next page of results by increasing the value of the start parameter in your next request:"...&start=6&limit=5"
        /// </summary>
        [JsonProperty("moreAvailable")]
        public bool MoreAvailable { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate")]
        public long CreatedDate { get; set; }

        /// <summary>
        /// A list of institutions
        /// </summary>
        [JsonProperty("institutions")]
        public List<Models.Institution> InstitutionsProp { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Institutions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Institutions other &&
                this.Found.Equals(other.Found) &&
                this.Displaying.Equals(other.Displaying) &&
                this.MoreAvailable.Equals(other.MoreAvailable) &&
                this.CreatedDate.Equals(other.CreatedDate) &&
                ((this.InstitutionsProp == null && other.InstitutionsProp == null) || (this.InstitutionsProp?.Equals(other.InstitutionsProp) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Found = {this.Found}");
            toStringOutput.Add($"this.Displaying = {this.Displaying}");
            toStringOutput.Add($"this.MoreAvailable = {this.MoreAvailable}");
            toStringOutput.Add($"this.CreatedDate = {this.CreatedDate}");
            toStringOutput.Add($"this.InstitutionsProp = {(this.InstitutionsProp == null ? "null" : $"[{string.Join(", ", this.InstitutionsProp)} ]")}");
        }
    }
}