// <copyright file="AccountOwner.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AccountOwner.
    /// </summary>
    public class AccountOwner
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountOwner"/> class.
        /// </summary>
        public AccountOwner()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountOwner"/> class.
        /// </summary>
        /// <param name="ownerName">ownerName.</param>
        /// <param name="ownerAddress">ownerAddress.</param>
        /// <param name="asOfDate">asOfDate.</param>
        public AccountOwner(
            string ownerName,
            string ownerAddress,
            long? asOfDate = null)
        {
            this.OwnerName = ownerName;
            this.OwnerAddress = ownerAddress;
            this.AsOfDate = asOfDate;
        }

        /// <summary>
        /// The name of the account owner. Can be multiple account owners in one string. This is how the source data is returned from the institution.
        /// </summary>
        [JsonProperty("ownerName")]
        public string OwnerName { get; set; }

        /// <summary>
        /// A street address
        /// </summary>
        [JsonProperty("ownerAddress")]
        public string OwnerAddress { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("asOfDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? AsOfDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AccountOwner : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AccountOwner other &&
                ((this.OwnerName == null && other.OwnerName == null) || (this.OwnerName?.Equals(other.OwnerName) == true)) &&
                ((this.OwnerAddress == null && other.OwnerAddress == null) || (this.OwnerAddress?.Equals(other.OwnerAddress) == true)) &&
                ((this.AsOfDate == null && other.AsOfDate == null) || (this.AsOfDate?.Equals(other.AsOfDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.OwnerName = {(this.OwnerName == null ? "null" : this.OwnerName == string.Empty ? "" : this.OwnerName)}");
            toStringOutput.Add($"this.OwnerAddress = {(this.OwnerAddress == null ? "null" : this.OwnerAddress == string.Empty ? "" : this.OwnerAddress)}");
            toStringOutput.Add($"this.AsOfDate = {(this.AsOfDate == null ? "null" : this.AsOfDate.ToString())}");
        }
    }
}