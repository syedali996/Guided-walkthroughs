// <copyright file="CashFlowPossibleLoanDepositsAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowPossibleLoanDepositsAccount.
    /// </summary>
    public class CashFlowPossibleLoanDepositsAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowPossibleLoanDepositsAccount"/> class.
        /// </summary>
        public CashFlowPossibleLoanDepositsAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowPossibleLoanDepositsAccount"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="ownerName">ownerName.</param>
        /// <param name="ownerAddress">ownerAddress.</param>
        /// <param name="name">name.</param>
        /// <param name="number">number.</param>
        /// <param name="type">type.</param>
        /// <param name="aggregationStatusCode">aggregationStatusCode.</param>
        /// <param name="currentBalance">currentBalance.</param>
        /// <param name="availableBalance">availableBalance.</param>
        /// <param name="balanceDate">balanceDate.</param>
        /// <param name="transactions">transactions.</param>
        public CashFlowPossibleLoanDepositsAccount(
            string id,
            string ownerName,
            string ownerAddress,
            string name,
            string number,
            string type,
            string aggregationStatusCode,
            double currentBalance,
            double availableBalance,
            long balanceDate,
            List<Models.ReportTransaction> transactions)
        {
            this.Id = id;
            this.OwnerName = ownerName;
            this.OwnerAddress = ownerAddress;
            this.Name = name;
            this.Number = number;
            this.Type = type;
            this.AggregationStatusCode = aggregationStatusCode;
            this.CurrentBalance = currentBalance;
            this.AvailableBalance = availableBalance;
            this.BalanceDate = balanceDate;
            this.Transactions = transactions;
        }

        /// <summary>
        /// Finicity account ID
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// The name(s) of the account owner(s), retrieved from the institution.
        /// </summary>
        [JsonProperty("ownerName")]
        public string OwnerName { get; set; }

        /// <summary>
        /// The mailing address of the account owner, retrieved from the institution.
        /// </summary>
        [JsonProperty("ownerAddress")]
        public string OwnerAddress { get; set; }

        /// <summary>
        /// The account name from the institution
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// The account number from the institution (obfuscated)
        /// </summary>
        [JsonProperty("number")]
        public string Number { get; set; }

        /// <summary>
        /// CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...)
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable)
        /// </summary>
        [JsonProperty("aggregationStatusCode")]
        public string AggregationStatusCode { get; set; }

        /// <summary>
        /// The cleared balance of the account as-of `balanceDate`
        /// </summary>
        [JsonProperty("currentBalance")]
        public double CurrentBalance { get; set; }

        /// <summary>
        /// Available balance
        /// </summary>
        [JsonProperty("availableBalance")]
        public double AvailableBalance { get; set; }

        /// <summary>
        /// A timestamp showing when the `balance` was captured
        /// </summary>
        [JsonProperty("balanceDate")]
        public long BalanceDate { get; set; }

        /// <summary>
        /// a list of transaction records
        /// </summary>
        [JsonProperty("transactions")]
        public List<Models.ReportTransaction> Transactions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowPossibleLoanDepositsAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowPossibleLoanDepositsAccount other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.OwnerName == null && other.OwnerName == null) || (this.OwnerName?.Equals(other.OwnerName) == true)) &&
                ((this.OwnerAddress == null && other.OwnerAddress == null) || (this.OwnerAddress?.Equals(other.OwnerAddress) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Number == null && other.Number == null) || (this.Number?.Equals(other.Number) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.AggregationStatusCode == null && other.AggregationStatusCode == null) || (this.AggregationStatusCode?.Equals(other.AggregationStatusCode) == true)) &&
                this.CurrentBalance.Equals(other.CurrentBalance) &&
                this.AvailableBalance.Equals(other.AvailableBalance) &&
                this.BalanceDate.Equals(other.BalanceDate) &&
                ((this.Transactions == null && other.Transactions == null) || (this.Transactions?.Equals(other.Transactions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.OwnerName = {(this.OwnerName == null ? "null" : this.OwnerName == string.Empty ? "" : this.OwnerName)}");
            toStringOutput.Add($"this.OwnerAddress = {(this.OwnerAddress == null ? "null" : this.OwnerAddress == string.Empty ? "" : this.OwnerAddress)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Number = {(this.Number == null ? "null" : this.Number == string.Empty ? "" : this.Number)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.AggregationStatusCode = {(this.AggregationStatusCode == null ? "null" : this.AggregationStatusCode == string.Empty ? "" : this.AggregationStatusCode)}");
            toStringOutput.Add($"this.CurrentBalance = {this.CurrentBalance}");
            toStringOutput.Add($"this.AvailableBalance = {this.AvailableBalance}");
            toStringOutput.Add($"this.BalanceDate = {this.BalanceDate}");
            toStringOutput.Add($"this.Transactions = {(this.Transactions == null ? "null" : $"[{string.Join(", ", this.Transactions)} ]")}");
        }
    }
}