// <copyright file="ObbDateRangeAndAmount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbDateRangeAndAmount.
    /// </summary>
    public class ObbDateRangeAndAmount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDateRangeAndAmount"/> class.
        /// </summary>
        public ObbDateRangeAndAmount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDateRangeAndAmount"/> class.
        /// </summary>
        /// <param name="period">period.</param>
        /// <param name="periodBeginDate">periodBeginDate.</param>
        /// <param name="periodEndDate">periodEndDate.</param>
        /// <param name="amount">amount.</param>
        public ObbDateRangeAndAmount(
            string period,
            string periodBeginDate,
            string periodEndDate,
            double? amount = null)
        {
            this.Amount = amount;
            this.Period = period;
            this.PeriodBeginDate = periodBeginDate;
            this.PeriodEndDate = periodEndDate;
        }

        /// <summary>
        /// Metric value for the given period
        /// </summary>
        [JsonProperty("amount", NullValueHandling = NullValueHandling.Ignore)]
        public double? Amount { get; set; }

        /// <summary>
        /// Period represented by this metric
        /// </summary>
        [JsonProperty("period")]
        public string Period { get; set; }

        /// <summary>
        /// Begin date of the period being reported
        /// </summary>
        [JsonProperty("periodBeginDate")]
        public string PeriodBeginDate { get; set; }

        /// <summary>
        /// End date of the period being reported
        /// </summary>
        [JsonProperty("periodEndDate")]
        public string PeriodEndDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbDateRangeAndAmount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbDateRangeAndAmount other &&
                ((this.Amount == null && other.Amount == null) || (this.Amount?.Equals(other.Amount) == true)) &&
                ((this.Period == null && other.Period == null) || (this.Period?.Equals(other.Period) == true)) &&
                ((this.PeriodBeginDate == null && other.PeriodBeginDate == null) || (this.PeriodBeginDate?.Equals(other.PeriodBeginDate) == true)) &&
                ((this.PeriodEndDate == null && other.PeriodEndDate == null) || (this.PeriodEndDate?.Equals(other.PeriodEndDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Amount = {(this.Amount == null ? "null" : this.Amount.ToString())}");
            toStringOutput.Add($"this.Period = {(this.Period == null ? "null" : this.Period == string.Empty ? "" : this.Period)}");
            toStringOutput.Add($"this.PeriodBeginDate = {(this.PeriodBeginDate == null ? "null" : this.PeriodBeginDate == string.Empty ? "" : this.PeriodBeginDate)}");
            toStringOutput.Add($"this.PeriodEndDate = {(this.PeriodEndDate == null ? "null" : this.PeriodEndDate == string.Empty ? "" : this.PeriodEndDate)}");
        }
    }
}