// <copyright file="Application.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Application.
    /// </summary>
    public class Application
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Application"/> class.
        /// </summary>
        public Application()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Application"/> class.
        /// </summary>
        /// <param name="appDescription">appDescription.</param>
        /// <param name="appName">appName.</param>
        /// <param name="appUrl">appUrl.</param>
        /// <param name="ownerAddressLine1">ownerAddressLine1.</param>
        /// <param name="ownerAddressLine2">ownerAddressLine2.</param>
        /// <param name="ownerCity">ownerCity.</param>
        /// <param name="ownerCountry">ownerCountry.</param>
        /// <param name="ownerName">ownerName.</param>
        /// <param name="ownerPostalCode">ownerPostalCode.</param>
        /// <param name="ownerState">ownerState.</param>
        /// <param name="image">image.</param>
        public Application(
            string appDescription,
            string appName,
            string appUrl,
            string ownerAddressLine1,
            string ownerAddressLine2,
            string ownerCity,
            string ownerCountry,
            string ownerName,
            string ownerPostalCode,
            string ownerState,
            string image)
        {
            this.AppDescription = appDescription;
            this.AppName = appName;
            this.AppUrl = appUrl;
            this.OwnerAddressLine1 = ownerAddressLine1;
            this.OwnerAddressLine2 = ownerAddressLine2;
            this.OwnerCity = ownerCity;
            this.OwnerCountry = ownerCountry;
            this.OwnerName = ownerName;
            this.OwnerPostalCode = ownerPostalCode;
            this.OwnerState = ownerState;
            this.Image = image;
        }

        /// <summary>
        /// A short description of the app. This will be visible to end users in the FI interface.
        /// </summary>
        [JsonProperty("appDescription")]
        public string AppDescription { get; set; }

        /// <summary>
        /// The name of the application assigned to the customer
        /// </summary>
        [JsonProperty("appName")]
        public string AppName { get; set; }

        /// <summary>
        /// An URL for the app. This will be visible to end users in the FI interface.
        /// </summary>
        [JsonProperty("appUrl")]
        public string AppUrl { get; set; }

        /// <summary>
        /// An address line 1
        /// </summary>
        [JsonProperty("ownerAddressLine1")]
        public string OwnerAddressLine1 { get; set; }

        /// <summary>
        /// An address line 2
        /// </summary>
        [JsonProperty("ownerAddressLine2")]
        public string OwnerAddressLine2 { get; set; }

        /// <summary>
        /// City for the business entity that owns the app. Information for registration purposes only and not given to the end user.
        /// </summary>
        [JsonProperty("ownerCity")]
        public string OwnerCity { get; set; }

        /// <summary>
        /// Country for the  business entity that owns the app. Information for registration purposes only and not given to the end user.
        /// </summary>
        [JsonProperty("ownerCountry")]
        public string OwnerCountry { get; set; }

        /// <summary>
        /// Business name for the business entity that owns the app. Information for registration purposes only and not given to the end user.
        /// </summary>
        [JsonProperty("ownerName")]
        public string OwnerName { get; set; }

        /// <summary>
        /// Zip code for the business entity that owns the app. Information for registration purposes only and not given to the end user.
        /// </summary>
        [JsonProperty("ownerPostalCode")]
        public string OwnerPostalCode { get; set; }

        /// <summary>
        /// State for the business entity that owns the app. Information for registration purposes only and not given to the end user.
        /// </summary>
        [JsonProperty("ownerState")]
        public string OwnerState { get; set; }

        /// <summary>
        /// An app logo passed as a Base64 encoded image (1:1 SVG file, must be less than 50KB)
        /// </summary>
        [JsonProperty("image")]
        public string Image { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Application : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Application other &&
                ((this.AppDescription == null && other.AppDescription == null) || (this.AppDescription?.Equals(other.AppDescription) == true)) &&
                ((this.AppName == null && other.AppName == null) || (this.AppName?.Equals(other.AppName) == true)) &&
                ((this.AppUrl == null && other.AppUrl == null) || (this.AppUrl?.Equals(other.AppUrl) == true)) &&
                ((this.OwnerAddressLine1 == null && other.OwnerAddressLine1 == null) || (this.OwnerAddressLine1?.Equals(other.OwnerAddressLine1) == true)) &&
                ((this.OwnerAddressLine2 == null && other.OwnerAddressLine2 == null) || (this.OwnerAddressLine2?.Equals(other.OwnerAddressLine2) == true)) &&
                ((this.OwnerCity == null && other.OwnerCity == null) || (this.OwnerCity?.Equals(other.OwnerCity) == true)) &&
                ((this.OwnerCountry == null && other.OwnerCountry == null) || (this.OwnerCountry?.Equals(other.OwnerCountry) == true)) &&
                ((this.OwnerName == null && other.OwnerName == null) || (this.OwnerName?.Equals(other.OwnerName) == true)) &&
                ((this.OwnerPostalCode == null && other.OwnerPostalCode == null) || (this.OwnerPostalCode?.Equals(other.OwnerPostalCode) == true)) &&
                ((this.OwnerState == null && other.OwnerState == null) || (this.OwnerState?.Equals(other.OwnerState) == true)) &&
                ((this.Image == null && other.Image == null) || (this.Image?.Equals(other.Image) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AppDescription = {(this.AppDescription == null ? "null" : this.AppDescription == string.Empty ? "" : this.AppDescription)}");
            toStringOutput.Add($"this.AppName = {(this.AppName == null ? "null" : this.AppName == string.Empty ? "" : this.AppName)}");
            toStringOutput.Add($"this.AppUrl = {(this.AppUrl == null ? "null" : this.AppUrl == string.Empty ? "" : this.AppUrl)}");
            toStringOutput.Add($"this.OwnerAddressLine1 = {(this.OwnerAddressLine1 == null ? "null" : this.OwnerAddressLine1 == string.Empty ? "" : this.OwnerAddressLine1)}");
            toStringOutput.Add($"this.OwnerAddressLine2 = {(this.OwnerAddressLine2 == null ? "null" : this.OwnerAddressLine2 == string.Empty ? "" : this.OwnerAddressLine2)}");
            toStringOutput.Add($"this.OwnerCity = {(this.OwnerCity == null ? "null" : this.OwnerCity == string.Empty ? "" : this.OwnerCity)}");
            toStringOutput.Add($"this.OwnerCountry = {(this.OwnerCountry == null ? "null" : this.OwnerCountry == string.Empty ? "" : this.OwnerCountry)}");
            toStringOutput.Add($"this.OwnerName = {(this.OwnerName == null ? "null" : this.OwnerName == string.Empty ? "" : this.OwnerName)}");
            toStringOutput.Add($"this.OwnerPostalCode = {(this.OwnerPostalCode == null ? "null" : this.OwnerPostalCode == string.Empty ? "" : this.OwnerPostalCode)}");
            toStringOutput.Add($"this.OwnerState = {(this.OwnerState == null ? "null" : this.OwnerState == string.Empty ? "" : this.OwnerState)}");
            toStringOutput.Add($"this.Image = {(this.Image == null ? "null" : this.Image == string.Empty ? "" : this.Image)}");
        }
    }
}