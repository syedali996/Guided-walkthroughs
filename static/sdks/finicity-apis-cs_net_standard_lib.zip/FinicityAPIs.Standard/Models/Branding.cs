// <copyright file="Branding.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Branding.
    /// </summary>
    public class Branding
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Branding"/> class.
        /// </summary>
        public Branding()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Branding"/> class.
        /// </summary>
        /// <param name="logo">logo.</param>
        /// <param name="alternateLogo">alternateLogo.</param>
        /// <param name="icon">icon.</param>
        /// <param name="primaryColor">primaryColor.</param>
        /// <param name="tile">tile.</param>
        public Branding(
            string logo = null,
            string alternateLogo = null,
            string icon = null,
            string primaryColor = null,
            string tile = null)
        {
            this.Logo = logo;
            this.AlternateLogo = alternateLogo;
            this.Icon = icon;
            this.PrimaryColor = primaryColor;
            this.Tile = tile;
        }

        /// <summary>
        /// File path of the institution's logo. For white backgrounds designed at 375 x 72, has built in spacing around it to normalize brand sizing.
        /// </summary>
        [JsonProperty("logo", NullValueHandling = NullValueHandling.Ignore)]
        public string Logo { get; set; }

        /// <summary>
        /// File path of the institution's alternate logo. For colored backgrounds designed at 375 x 72 has built in spacing around it to normalize brand sizing.
        /// </summary>
        [JsonProperty("alternateLogo", NullValueHandling = NullValueHandling.Ignore)]
        public string AlternateLogo { get; set; }

        /// <summary>
        /// File path of the institution's icon. For search results designed at 40 x 40.
        /// </summary>
        [JsonProperty("icon", NullValueHandling = NullValueHandling.Ignore)]
        public string Icon { get; set; }

        /// <summary>
        /// Hex code for the institution's primary color
        /// </summary>
        [JsonProperty("primaryColor", NullValueHandling = NullValueHandling.Ignore)]
        public string PrimaryColor { get; set; }

        /// <summary>
        /// File path of institution name logo. For popular banks designed at 160 x 72.
        /// </summary>
        [JsonProperty("tile", NullValueHandling = NullValueHandling.Ignore)]
        public string Tile { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Branding : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Branding other &&
                ((this.Logo == null && other.Logo == null) || (this.Logo?.Equals(other.Logo) == true)) &&
                ((this.AlternateLogo == null && other.AlternateLogo == null) || (this.AlternateLogo?.Equals(other.AlternateLogo) == true)) &&
                ((this.Icon == null && other.Icon == null) || (this.Icon?.Equals(other.Icon) == true)) &&
                ((this.PrimaryColor == null && other.PrimaryColor == null) || (this.PrimaryColor?.Equals(other.PrimaryColor) == true)) &&
                ((this.Tile == null && other.Tile == null) || (this.Tile?.Equals(other.Tile) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Logo = {(this.Logo == null ? "null" : this.Logo == string.Empty ? "" : this.Logo)}");
            toStringOutput.Add($"this.AlternateLogo = {(this.AlternateLogo == null ? "null" : this.AlternateLogo == string.Empty ? "" : this.AlternateLogo)}");
            toStringOutput.Add($"this.Icon = {(this.Icon == null ? "null" : this.Icon == string.Empty ? "" : this.Icon)}");
            toStringOutput.Add($"this.PrimaryColor = {(this.PrimaryColor == null ? "null" : this.PrimaryColor == string.Empty ? "" : this.PrimaryColor)}");
            toStringOutput.Add($"this.Tile = {(this.Tile == null ? "null" : this.Tile == string.Empty ? "" : this.Tile)}");
        }
    }
}