// <copyright file="AvailableBalance.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AvailableBalance.
    /// </summary>
    public class AvailableBalance
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AvailableBalance"/> class.
        /// </summary>
        public AvailableBalance()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AvailableBalance"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="realAccountNumberLast4">realAccountNumberLast4.</param>
        /// <param name="availableBalanceProp">availableBalance.</param>
        /// <param name="availableBalanceDate">availableBalanceDate.</param>
        /// <param name="clearedBalance">clearedBalance.</param>
        /// <param name="clearedBalanceDate">clearedBalanceDate.</param>
        /// <param name="aggregationStatusCode">aggregationStatusCode.</param>
        /// <param name="currency">currency.</param>
        public AvailableBalance(
            long id,
            string realAccountNumberLast4,
            double availableBalanceProp,
            long availableBalanceDate,
            double clearedBalance,
            long clearedBalanceDate,
            int aggregationStatusCode,
            string currency)
        {
            this.Id = id;
            this.RealAccountNumberLast4 = realAccountNumberLast4;
            this.AvailableBalanceProp = availableBalanceProp;
            this.AvailableBalanceDate = availableBalanceDate;
            this.ClearedBalance = clearedBalance;
            this.ClearedBalanceDate = clearedBalanceDate;
            this.AggregationStatusCode = aggregationStatusCode;
            this.Currency = currency;
        }

        /// <summary>
        /// A customer ID represented as a number. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// The last 4 digits of the ACH account number
        /// </summary>
        [JsonProperty("realAccountNumberLast4")]
        public string RealAccountNumberLast4 { get; set; }

        /// <summary>
        /// The available balance of the account
        /// </summary>
        [JsonProperty("availableBalance")]
        public double AvailableBalanceProp { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("availableBalanceDate")]
        public long AvailableBalanceDate { get; set; }

        /// <summary>
        /// The cleared balance of the account. Also referred as posted balance, current balance, ledger balance
        /// </summary>
        [JsonProperty("clearedBalance")]
        public double ClearedBalance { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("clearedBalanceDate")]
        public long ClearedBalanceDate { get; set; }

        /// <summary>
        /// The status of the most recent aggregation attempt (see [Aggregation Status Codes](https://docs.finicity.com/aggregation-status-codes/)). Won't be present until you have run your first aggregation for the account.
        /// </summary>
        [JsonProperty("aggregationStatusCode")]
        public int AggregationStatusCode { get; set; }

        /// <summary>
        /// A currency code
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AvailableBalance : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AvailableBalance other &&
                this.Id.Equals(other.Id) &&
                ((this.RealAccountNumberLast4 == null && other.RealAccountNumberLast4 == null) || (this.RealAccountNumberLast4?.Equals(other.RealAccountNumberLast4) == true)) &&
                this.AvailableBalanceProp.Equals(other.AvailableBalanceProp) &&
                this.AvailableBalanceDate.Equals(other.AvailableBalanceDate) &&
                this.ClearedBalance.Equals(other.ClearedBalance) &&
                this.ClearedBalanceDate.Equals(other.ClearedBalanceDate) &&
                this.AggregationStatusCode.Equals(other.AggregationStatusCode) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.RealAccountNumberLast4 = {(this.RealAccountNumberLast4 == null ? "null" : this.RealAccountNumberLast4 == string.Empty ? "" : this.RealAccountNumberLast4)}");
            toStringOutput.Add($"this.AvailableBalanceProp = {this.AvailableBalanceProp}");
            toStringOutput.Add($"this.AvailableBalanceDate = {this.AvailableBalanceDate}");
            toStringOutput.Add($"this.ClearedBalance = {this.ClearedBalance}");
            toStringOutput.Add($"this.ClearedBalanceDate = {this.ClearedBalanceDate}");
            toStringOutput.Add($"this.AggregationStatusCode = {this.AggregationStatusCode}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
        }
    }
}