// <copyright file="ObbDateRangeAndCount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbDateRangeAndCount.
    /// </summary>
    public class ObbDateRangeAndCount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDateRangeAndCount"/> class.
        /// </summary>
        public ObbDateRangeAndCount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDateRangeAndCount"/> class.
        /// </summary>
        /// <param name="count">count.</param>
        /// <param name="period">period.</param>
        /// <param name="periodBeginDate">periodBeginDate.</param>
        /// <param name="periodEndDate">periodEndDate.</param>
        public ObbDateRangeAndCount(
            int count,
            string period,
            string periodBeginDate,
            string periodEndDate)
        {
            this.Count = count;
            this.Period = period;
            this.PeriodBeginDate = periodBeginDate;
            this.PeriodEndDate = periodEndDate;
        }

        /// <summary>
        /// Count of occurrences for the given period
        /// </summary>
        [JsonProperty("count")]
        public int Count { get; set; }

        /// <summary>
        /// Period represented by this metric
        /// </summary>
        [JsonProperty("period")]
        public string Period { get; set; }

        /// <summary>
        /// Begin date of the period being reported
        /// </summary>
        [JsonProperty("periodBeginDate")]
        public string PeriodBeginDate { get; set; }

        /// <summary>
        /// End date of the period being reported
        /// </summary>
        [JsonProperty("periodEndDate")]
        public string PeriodEndDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbDateRangeAndCount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbDateRangeAndCount other &&
                this.Count.Equals(other.Count) &&
                ((this.Period == null && other.Period == null) || (this.Period?.Equals(other.Period) == true)) &&
                ((this.PeriodBeginDate == null && other.PeriodBeginDate == null) || (this.PeriodBeginDate?.Equals(other.PeriodBeginDate) == true)) &&
                ((this.PeriodEndDate == null && other.PeriodEndDate == null) || (this.PeriodEndDate?.Equals(other.PeriodEndDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Count = {this.Count}");
            toStringOutput.Add($"this.Period = {(this.Period == null ? "null" : this.Period == string.Empty ? "" : this.Period)}");
            toStringOutput.Add($"this.PeriodBeginDate = {(this.PeriodBeginDate == null ? "null" : this.PeriodBeginDate == string.Empty ? "" : this.PeriodBeginDate)}");
            toStringOutput.Add($"this.PeriodEndDate = {(this.PeriodEndDate == null ? "null" : this.PeriodEndDate == string.Empty ? "" : this.PeriodEndDate)}");
        }
    }
}