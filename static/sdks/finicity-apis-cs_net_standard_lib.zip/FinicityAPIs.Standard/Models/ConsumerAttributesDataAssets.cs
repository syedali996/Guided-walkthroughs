// <copyright file="ConsumerAttributesDataAssets.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesDataAssets.
    /// </summary>
    public class ConsumerAttributesDataAssets
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataAssets"/> class.
        /// </summary>
        public ConsumerAttributesDataAssets()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataAssets"/> class.
        /// </summary>
        /// <param name="customer">customer.</param>
        /// <param name="account">account.</param>
        public ConsumerAttributesDataAssets(
            Models.ConsumerAttributesAssetsCustomer customer,
            Models.ConsumerAttributesAssetsAccount account)
        {
            this.Customer = customer;
            this.Account = account;
        }

        /// <summary>
        /// Gets or sets Customer.
        /// </summary>
        [JsonProperty("customer")]
        public Models.ConsumerAttributesAssetsCustomer Customer { get; set; }

        /// <summary>
        /// Gets or sets Account.
        /// </summary>
        [JsonProperty("account")]
        public Models.ConsumerAttributesAssetsAccount Account { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesDataAssets : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesDataAssets other &&
                ((this.Customer == null && other.Customer == null) || (this.Customer?.Equals(other.Customer) == true)) &&
                ((this.Account == null && other.Account == null) || (this.Account?.Equals(other.Account) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Customer = {(this.Customer == null ? "null" : this.Customer.ToString())}");
            toStringOutput.Add($"this.Account = {(this.Account == null ? "null" : this.Account.ToString())}");
        }
    }
}