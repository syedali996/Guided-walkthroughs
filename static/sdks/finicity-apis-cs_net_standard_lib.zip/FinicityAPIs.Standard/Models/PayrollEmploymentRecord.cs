// <copyright file="PayrollEmploymentRecord.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollEmploymentRecord.
    /// </summary>
    public class PayrollEmploymentRecord
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollEmploymentRecord"/> class.
        /// </summary>
        public PayrollEmploymentRecord()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollEmploymentRecord"/> class.
        /// </summary>
        /// <param name="employerName">employerName.</param>
        /// <param name="latestPayDate">latestPayDate.</param>
        /// <param name="daysSinceLastPay">daysSinceLastPay.</param>
        /// <param name="numberPayCadenceWithoutPay">numberPayCadenceWithoutPay.</param>
        /// <param name="employmentStatusCode">employmentStatusCode.</param>
        /// <param name="employmentStatusName">employmentStatusName.</param>
        /// <param name="workLevelStatus">workLevelStatus.</param>
        /// <param name="legalEntityId">legalEntityId.</param>
        /// <param name="originalHireDate">originalHireDate.</param>
        /// <param name="latestHireDate">latestHireDate.</param>
        /// <param name="employmentEndDate">employmentEndDate.</param>
        /// <param name="employmentDuration">employmentDuration.</param>
        /// <param name="employerAddress">employerAddress.</param>
        /// <param name="workLevelCode">workLevelCode.</param>
        /// <param name="workLevelName">workLevelName.</param>
        /// <param name="positionTitle">positionTitle.</param>
        /// <param name="positionDuration">positionDuration.</param>
        public PayrollEmploymentRecord(
            string employerName,
            long latestPayDate,
            int daysSinceLastPay,
            int numberPayCadenceWithoutPay,
            string employmentStatusCode,
            string employmentStatusName,
            string workLevelStatus,
            string legalEntityId = null,
            long? originalHireDate = null,
            long? latestHireDate = null,
            long? employmentEndDate = null,
            string employmentDuration = null,
            List<Models.PayrollEmployerAddress> employerAddress = null,
            string workLevelCode = null,
            string workLevelName = null,
            string positionTitle = null,
            string positionDuration = null)
        {
            this.EmployerName = employerName;
            this.LegalEntityId = legalEntityId;
            this.OriginalHireDate = originalHireDate;
            this.LatestHireDate = latestHireDate;
            this.LatestPayDate = latestPayDate;
            this.DaysSinceLastPay = daysSinceLastPay;
            this.NumberPayCadenceWithoutPay = numberPayCadenceWithoutPay;
            this.EmploymentEndDate = employmentEndDate;
            this.EmploymentDuration = employmentDuration;
            this.EmployerAddress = employerAddress;
            this.EmploymentStatusCode = employmentStatusCode;
            this.EmploymentStatusName = employmentStatusName;
            this.WorkLevelCode = workLevelCode;
            this.WorkLevelName = workLevelName;
            this.WorkLevelStatus = workLevelStatus;
            this.PositionTitle = positionTitle;
            this.PositionDuration = positionDuration;
        }

        /// <summary>
        /// Name of the employer as stated by the employer in the payroll system
        /// </summary>
        [JsonProperty("employerName")]
        public string EmployerName { get; set; }

        /// <summary>
        /// Employer identification number (EIN)
        /// </summary>
        [JsonProperty("legalEntityId", NullValueHandling = NullValueHandling.Ignore)]
        public string LegalEntityId { get; set; }

        /// <summary>
        /// The original hired date of an employee at the company
        /// </summary>
        [JsonProperty("originalHireDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? OriginalHireDate { get; set; }

        /// <summary>
        /// If an employee leaves the company and returns later, then the employer states the latest hire date at the company
        /// </summary>
        [JsonProperty("latestHireDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LatestHireDate { get; set; }

        /// <summary>
        /// The most recent pay date from an employer
        /// </summary>
        [JsonProperty("latestPayDate")]
        public long LatestPayDate { get; set; }

        /// <summary>
        /// The number of days since an employee was last paid
        /// </summary>
        [JsonProperty("daysSinceLastPay")]
        public int DaysSinceLastPay { get; set; }

        /// <summary>
        /// The number of pay cadences an employee has not been paid; determined by the pay frequency
        /// </summary>
        [JsonProperty("numberPayCadenceWithoutPay")]
        public int NumberPayCadenceWithoutPay { get; set; }

        /// <summary>
        /// The date an employee ended their employment at the company
        /// </summary>
        [JsonProperty("employmentEndDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? EmploymentEndDate { get; set; }

        /// <summary>
        /// The length of time an employee has been employed with that employer in ISO 8601 format (eg P1Y6M0D)
        /// </summary>
        [JsonProperty("employmentDuration", NullValueHandling = NullValueHandling.Ignore)]
        public string EmploymentDuration { get; set; }

        /// <summary>
        /// Array of addresses
        /// </summary>
        [JsonProperty("employerAddress", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PayrollEmployerAddress> EmployerAddress { get; set; }

        /// <summary>
        /// Status codes: `A` - Active, `NLE` - No Longer Employed, `L` - Leave
        /// </summary>
        [JsonProperty("employmentStatusCode")]
        public string EmploymentStatusCode { get; set; }

        /// <summary>
        /// Status name: `Active`, `No Longer Employed`, or `Leave`
        /// </summary>
        [JsonProperty("employmentStatusName")]
        public string EmploymentStatusName { get; set; }

        /// <summary>
        /// The abbreviate code for the employment level names (workLevelName) that we receive from the employer
        /// </summary>
        [JsonProperty("workLevelCode", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkLevelCode { get; set; }

        /// <summary>
        /// The employment level name is whatever we receive from the employer, such as full time, part time, temp, contractor, and more
        /// </summary>
        [JsonProperty("workLevelName", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkLevelName { get; set; }

        /// <summary>
        /// The categorized work level status. Enumerations are: <br> * `Temporary` <br> * `Seasonal` <br> * `Retired` <br> * `Student` <br> * `Full Time` <br> * `Part Time` <br> * `Unspecified` <br> This is a new field, currently enabled only for testing reports. It will be added for all reports in August 2021.
        /// </summary>
        [JsonProperty("workLevelStatus")]
        public string WorkLevelStatus { get; set; }

        /// <summary>
        /// Employee job title
        /// </summary>
        [JsonProperty("positionTitle", NullValueHandling = NullValueHandling.Ignore)]
        public string PositionTitle { get; set; }

        /// <summary>
        /// The length of time an employee has been employed at their current or latest position for this employment in ISO 8601 format (eg P1Y6M0D)
        /// </summary>
        [JsonProperty("positionDuration", NullValueHandling = NullValueHandling.Ignore)]
        public string PositionDuration { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollEmploymentRecord : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollEmploymentRecord other &&
                ((this.EmployerName == null && other.EmployerName == null) || (this.EmployerName?.Equals(other.EmployerName) == true)) &&
                ((this.LegalEntityId == null && other.LegalEntityId == null) || (this.LegalEntityId?.Equals(other.LegalEntityId) == true)) &&
                ((this.OriginalHireDate == null && other.OriginalHireDate == null) || (this.OriginalHireDate?.Equals(other.OriginalHireDate) == true)) &&
                ((this.LatestHireDate == null && other.LatestHireDate == null) || (this.LatestHireDate?.Equals(other.LatestHireDate) == true)) &&
                this.LatestPayDate.Equals(other.LatestPayDate) &&
                this.DaysSinceLastPay.Equals(other.DaysSinceLastPay) &&
                this.NumberPayCadenceWithoutPay.Equals(other.NumberPayCadenceWithoutPay) &&
                ((this.EmploymentEndDate == null && other.EmploymentEndDate == null) || (this.EmploymentEndDate?.Equals(other.EmploymentEndDate) == true)) &&
                ((this.EmploymentDuration == null && other.EmploymentDuration == null) || (this.EmploymentDuration?.Equals(other.EmploymentDuration) == true)) &&
                ((this.EmployerAddress == null && other.EmployerAddress == null) || (this.EmployerAddress?.Equals(other.EmployerAddress) == true)) &&
                ((this.EmploymentStatusCode == null && other.EmploymentStatusCode == null) || (this.EmploymentStatusCode?.Equals(other.EmploymentStatusCode) == true)) &&
                ((this.EmploymentStatusName == null && other.EmploymentStatusName == null) || (this.EmploymentStatusName?.Equals(other.EmploymentStatusName) == true)) &&
                ((this.WorkLevelCode == null && other.WorkLevelCode == null) || (this.WorkLevelCode?.Equals(other.WorkLevelCode) == true)) &&
                ((this.WorkLevelName == null && other.WorkLevelName == null) || (this.WorkLevelName?.Equals(other.WorkLevelName) == true)) &&
                ((this.WorkLevelStatus == null && other.WorkLevelStatus == null) || (this.WorkLevelStatus?.Equals(other.WorkLevelStatus) == true)) &&
                ((this.PositionTitle == null && other.PositionTitle == null) || (this.PositionTitle?.Equals(other.PositionTitle) == true)) &&
                ((this.PositionDuration == null && other.PositionDuration == null) || (this.PositionDuration?.Equals(other.PositionDuration) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EmployerName = {(this.EmployerName == null ? "null" : this.EmployerName == string.Empty ? "" : this.EmployerName)}");
            toStringOutput.Add($"this.LegalEntityId = {(this.LegalEntityId == null ? "null" : this.LegalEntityId == string.Empty ? "" : this.LegalEntityId)}");
            toStringOutput.Add($"this.OriginalHireDate = {(this.OriginalHireDate == null ? "null" : this.OriginalHireDate.ToString())}");
            toStringOutput.Add($"this.LatestHireDate = {(this.LatestHireDate == null ? "null" : this.LatestHireDate.ToString())}");
            toStringOutput.Add($"this.LatestPayDate = {this.LatestPayDate}");
            toStringOutput.Add($"this.DaysSinceLastPay = {this.DaysSinceLastPay}");
            toStringOutput.Add($"this.NumberPayCadenceWithoutPay = {this.NumberPayCadenceWithoutPay}");
            toStringOutput.Add($"this.EmploymentEndDate = {(this.EmploymentEndDate == null ? "null" : this.EmploymentEndDate.ToString())}");
            toStringOutput.Add($"this.EmploymentDuration = {(this.EmploymentDuration == null ? "null" : this.EmploymentDuration == string.Empty ? "" : this.EmploymentDuration)}");
            toStringOutput.Add($"this.EmployerAddress = {(this.EmployerAddress == null ? "null" : $"[{string.Join(", ", this.EmployerAddress)} ]")}");
            toStringOutput.Add($"this.EmploymentStatusCode = {(this.EmploymentStatusCode == null ? "null" : this.EmploymentStatusCode == string.Empty ? "" : this.EmploymentStatusCode)}");
            toStringOutput.Add($"this.EmploymentStatusName = {(this.EmploymentStatusName == null ? "null" : this.EmploymentStatusName == string.Empty ? "" : this.EmploymentStatusName)}");
            toStringOutput.Add($"this.WorkLevelCode = {(this.WorkLevelCode == null ? "null" : this.WorkLevelCode == string.Empty ? "" : this.WorkLevelCode)}");
            toStringOutput.Add($"this.WorkLevelName = {(this.WorkLevelName == null ? "null" : this.WorkLevelName == string.Empty ? "" : this.WorkLevelName)}");
            toStringOutput.Add($"this.WorkLevelStatus = {(this.WorkLevelStatus == null ? "null" : this.WorkLevelStatus == string.Empty ? "" : this.WorkLevelStatus)}");
            toStringOutput.Add($"this.PositionTitle = {(this.PositionTitle == null ? "null" : this.PositionTitle == string.Empty ? "" : this.PositionTitle)}");
            toStringOutput.Add($"this.PositionDuration = {(this.PositionDuration == null ? "null" : this.PositionDuration == string.Empty ? "" : this.PositionDuration)}");
        }
    }
}