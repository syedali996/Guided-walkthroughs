// <copyright file="PrequalificationReportAssetSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PrequalificationReportAssetSummary.
    /// </summary>
    public class PrequalificationReportAssetSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportAssetSummary"/> class.
        /// </summary>
        public PrequalificationReportAssetSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportAssetSummary"/> class.
        /// </summary>
        /// <param name="currentBalance">currentBalance.</param>
        /// <param name="twoMonthAverage">twoMonthAverage.</param>
        /// <param name="sixMonthAverage">sixMonthAverage.</param>
        /// <param name="beginningBalance">beginningBalance.</param>
        /// <param name="type">type.</param>
        /// <param name="availableBalance">availableBalance.</param>
        public PrequalificationReportAssetSummary(
            double currentBalance,
            double twoMonthAverage,
            double sixMonthAverage,
            double beginningBalance,
            string type = null,
            double? availableBalance = null)
        {
            this.Type = type;
            this.AvailableBalance = availableBalance;
            this.CurrentBalance = currentBalance;
            this.TwoMonthAverage = twoMonthAverage;
            this.SixMonthAverage = sixMonthAverage;
            this.BeginningBalance = beginningBalance;
        }

        /// <summary>
        /// The asset type: "checking", "savings", "moneyMarket", "cd", "investment"
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// The available balance for the account
        /// </summary>
        [JsonProperty("availableBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AvailableBalance { get; set; }

        /// <summary>
        /// The current balance of the account
        /// </summary>
        [JsonProperty("currentBalance")]
        public double CurrentBalance { get; set; }

        /// <summary>
        /// The two month average daily balance of the account
        /// </summary>
        [JsonProperty("twoMonthAverage")]
        public double TwoMonthAverage { get; set; }

        /// <summary>
        /// The six month average daily balance of the account
        /// </summary>
        [JsonProperty("sixMonthAverage")]
        public double SixMonthAverage { get; set; }

        /// <summary>
        /// The beginning balance of the account per the time period of the report
        /// </summary>
        [JsonProperty("beginningBalance")]
        public double BeginningBalance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrequalificationReportAssetSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrequalificationReportAssetSummary other &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.AvailableBalance == null && other.AvailableBalance == null) || (this.AvailableBalance?.Equals(other.AvailableBalance) == true)) &&
                this.CurrentBalance.Equals(other.CurrentBalance) &&
                this.TwoMonthAverage.Equals(other.TwoMonthAverage) &&
                this.SixMonthAverage.Equals(other.SixMonthAverage) &&
                this.BeginningBalance.Equals(other.BeginningBalance);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.AvailableBalance = {(this.AvailableBalance == null ? "null" : this.AvailableBalance.ToString())}");
            toStringOutput.Add($"this.CurrentBalance = {this.CurrentBalance}");
            toStringOutput.Add($"this.TwoMonthAverage = {this.TwoMonthAverage}");
            toStringOutput.Add($"this.SixMonthAverage = {this.SixMonthAverage}");
            toStringOutput.Add($"this.BeginningBalance = {this.BeginningBalance}");
        }
    }
}