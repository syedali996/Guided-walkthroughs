// <copyright file="CashFlowPossibleLoanDeposits.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowPossibleLoanDeposits.
    /// </summary>
    public class CashFlowPossibleLoanDeposits
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowPossibleLoanDeposits"/> class.
        /// </summary>
        public CashFlowPossibleLoanDeposits()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowPossibleLoanDeposits"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="urlHomeApp">urlHomeApp.</param>
        /// <param name="accounts">accounts.</param>
        public CashFlowPossibleLoanDeposits(
            string id,
            string name,
            string urlHomeApp,
            List<Models.CashFlowPossibleLoanDepositsAccount> accounts)
        {
            this.Id = id;
            this.Name = name;
            this.UrlHomeApp = urlHomeApp;
            this.Accounts = accounts;
        }

        /// <summary>
        /// Finicity institution ID
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// Finicity institution name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// The URL of the Financial Institution
        /// </summary>
        [JsonProperty("urlHomeApp")]
        public string UrlHomeApp { get; set; }

        /// <summary>
        /// A list of account records
        /// </summary>
        [JsonProperty("accounts")]
        public List<Models.CashFlowPossibleLoanDepositsAccount> Accounts { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowPossibleLoanDeposits : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowPossibleLoanDeposits other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.UrlHomeApp == null && other.UrlHomeApp == null) || (this.UrlHomeApp?.Equals(other.UrlHomeApp) == true)) &&
                ((this.Accounts == null && other.Accounts == null) || (this.Accounts?.Equals(other.Accounts) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.UrlHomeApp = {(this.UrlHomeApp == null ? "null" : this.UrlHomeApp == string.Empty ? "" : this.UrlHomeApp)}");
            toStringOutput.Add($"this.Accounts = {(this.Accounts == null ? "null" : $"[{string.Join(", ", this.Accounts)} ]")}");
        }
    }
}