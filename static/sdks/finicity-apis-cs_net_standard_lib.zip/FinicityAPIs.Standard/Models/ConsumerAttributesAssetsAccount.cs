// <copyright file="ConsumerAttributesAssetsAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesAssetsAccount.
    /// </summary>
    public class ConsumerAttributesAssetsAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesAssetsAccount"/> class.
        /// </summary>
        public ConsumerAttributesAssetsAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesAssetsAccount"/> class.
        /// </summary>
        /// <param name="monthlyClosingBalance">monthlyClosingBalance.</param>
        /// <param name="monthlyMinimumBalance">monthlyMinimumBalance.</param>
        /// <param name="monthlyMaximumBalance">monthlyMaximumBalance.</param>
        /// <param name="monthlyAverageBalance">monthlyAverageBalance.</param>
        /// <param name="monthlyStandardDeviationOfBalance">monthlyStandardDeviationOfBalance.</param>
        /// <param name="monthlyDaysWithPositiveBalance">monthlyDaysWithPositiveBalance.</param>
        /// <param name="monthlyDaysWithNegativeBalance">monthlyDaysWithNegativeBalance.</param>
        /// <param name="monthlyTwoMonthAverageBalance">monthlyTwoMonthAverageBalance.</param>
        /// <param name="monthlySixMonthAverageBalance">monthlySixMonthAverageBalance.</param>
        /// <param name="twelveMonthAverageBalance">twelveMonthAverageBalance.</param>
        /// <param name="twoMonthStandardDeviationOfBalance">twoMonthStandardDeviationOfBalance.</param>
        /// <param name="sixMonthStandardDeviationOfBalance">sixMonthStandardDeviationOfBalance.</param>
        /// <param name="twelveMonthStandardDeviationOfBalance">twelveMonthStandardDeviationOfBalance.</param>
        public ConsumerAttributesAssetsAccount(
            object monthlyClosingBalance,
            object monthlyMinimumBalance,
            object monthlyMaximumBalance,
            object monthlyAverageBalance,
            object monthlyStandardDeviationOfBalance,
            object monthlyDaysWithPositiveBalance,
            object monthlyDaysWithNegativeBalance,
            object monthlyTwoMonthAverageBalance,
            object monthlySixMonthAverageBalance,
            object twelveMonthAverageBalance,
            object twoMonthStandardDeviationOfBalance,
            object sixMonthStandardDeviationOfBalance,
            object twelveMonthStandardDeviationOfBalance)
        {
            this.MonthlyClosingBalance = monthlyClosingBalance;
            this.MonthlyMinimumBalance = monthlyMinimumBalance;
            this.MonthlyMaximumBalance = monthlyMaximumBalance;
            this.MonthlyAverageBalance = monthlyAverageBalance;
            this.MonthlyStandardDeviationOfBalance = monthlyStandardDeviationOfBalance;
            this.MonthlyDaysWithPositiveBalance = monthlyDaysWithPositiveBalance;
            this.MonthlyDaysWithNegativeBalance = monthlyDaysWithNegativeBalance;
            this.MonthlyTwoMonthAverageBalance = monthlyTwoMonthAverageBalance;
            this.MonthlySixMonthAverageBalance = monthlySixMonthAverageBalance;
            this.TwelveMonthAverageBalance = twelveMonthAverageBalance;
            this.TwoMonthStandardDeviationOfBalance = twoMonthStandardDeviationOfBalance;
            this.SixMonthStandardDeviationOfBalance = sixMonthStandardDeviationOfBalance;
            this.TwelveMonthStandardDeviationOfBalance = twelveMonthStandardDeviationOfBalance;
        }

        /// <summary>
        /// Account closing balance by month
        /// </summary>
        [JsonProperty("monthlyClosingBalance")]
        public object MonthlyClosingBalance { get; set; }

        /// <summary>
        /// Account minimum balance by month
        /// </summary>
        [JsonProperty("monthlyMinimumBalance")]
        public object MonthlyMinimumBalance { get; set; }

        /// <summary>
        /// Account maximum balance by month
        /// </summary>
        [JsonProperty("monthlyMaximumBalance")]
        public object MonthlyMaximumBalance { get; set; }

        /// <summary>
        /// Account average balance by month
        /// </summary>
        [JsonProperty("monthlyAverageBalance")]
        public object MonthlyAverageBalance { get; set; }

        /// <summary>
        /// Standard deviation of balance by account
        /// </summary>
        [JsonProperty("monthlyStandardDeviationOfBalance")]
        public object MonthlyStandardDeviationOfBalance { get; set; }

        /// <summary>
        /// Number of days in a month with a positive account balance
        /// </summary>
        [JsonProperty("monthlyDaysWithPositiveBalance")]
        public object MonthlyDaysWithPositiveBalance { get; set; }

        /// <summary>
        /// Number of days in a month with a negative account balance
        /// </summary>
        [JsonProperty("monthlyDaysWithNegativeBalance")]
        public object MonthlyDaysWithNegativeBalance { get; set; }

        /// <summary>
        /// Two month average balance by account
        /// </summary>
        [JsonProperty("monthlyTwoMonthAverageBalance")]
        public object MonthlyTwoMonthAverageBalance { get; set; }

        /// <summary>
        /// Six month average balance by account
        /// </summary>
        [JsonProperty("monthlySixMonthAverageBalance")]
        public object MonthlySixMonthAverageBalance { get; set; }

        /// <summary>
        /// Twelve month average balance by account
        /// </summary>
        [JsonProperty("twelveMonthAverageBalance")]
        public object TwelveMonthAverageBalance { get; set; }

        /// <summary>
        /// Standard deviation of account balance across two months
        /// </summary>
        [JsonProperty("twoMonthStandardDeviationOfBalance")]
        public object TwoMonthStandardDeviationOfBalance { get; set; }

        /// <summary>
        /// Standard deviation of account balance across six months
        /// </summary>
        [JsonProperty("sixMonthStandardDeviationOfBalance")]
        public object SixMonthStandardDeviationOfBalance { get; set; }

        /// <summary>
        /// Standard deviation of account balance across twelve months
        /// </summary>
        [JsonProperty("twelveMonthStandardDeviationOfBalance")]
        public object TwelveMonthStandardDeviationOfBalance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesAssetsAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesAssetsAccount other &&
                ((this.MonthlyClosingBalance == null && other.MonthlyClosingBalance == null) || (this.MonthlyClosingBalance?.Equals(other.MonthlyClosingBalance) == true)) &&
                ((this.MonthlyMinimumBalance == null && other.MonthlyMinimumBalance == null) || (this.MonthlyMinimumBalance?.Equals(other.MonthlyMinimumBalance) == true)) &&
                ((this.MonthlyMaximumBalance == null && other.MonthlyMaximumBalance == null) || (this.MonthlyMaximumBalance?.Equals(other.MonthlyMaximumBalance) == true)) &&
                ((this.MonthlyAverageBalance == null && other.MonthlyAverageBalance == null) || (this.MonthlyAverageBalance?.Equals(other.MonthlyAverageBalance) == true)) &&
                ((this.MonthlyStandardDeviationOfBalance == null && other.MonthlyStandardDeviationOfBalance == null) || (this.MonthlyStandardDeviationOfBalance?.Equals(other.MonthlyStandardDeviationOfBalance) == true)) &&
                ((this.MonthlyDaysWithPositiveBalance == null && other.MonthlyDaysWithPositiveBalance == null) || (this.MonthlyDaysWithPositiveBalance?.Equals(other.MonthlyDaysWithPositiveBalance) == true)) &&
                ((this.MonthlyDaysWithNegativeBalance == null && other.MonthlyDaysWithNegativeBalance == null) || (this.MonthlyDaysWithNegativeBalance?.Equals(other.MonthlyDaysWithNegativeBalance) == true)) &&
                ((this.MonthlyTwoMonthAverageBalance == null && other.MonthlyTwoMonthAverageBalance == null) || (this.MonthlyTwoMonthAverageBalance?.Equals(other.MonthlyTwoMonthAverageBalance) == true)) &&
                ((this.MonthlySixMonthAverageBalance == null && other.MonthlySixMonthAverageBalance == null) || (this.MonthlySixMonthAverageBalance?.Equals(other.MonthlySixMonthAverageBalance) == true)) &&
                ((this.TwelveMonthAverageBalance == null && other.TwelveMonthAverageBalance == null) || (this.TwelveMonthAverageBalance?.Equals(other.TwelveMonthAverageBalance) == true)) &&
                ((this.TwoMonthStandardDeviationOfBalance == null && other.TwoMonthStandardDeviationOfBalance == null) || (this.TwoMonthStandardDeviationOfBalance?.Equals(other.TwoMonthStandardDeviationOfBalance) == true)) &&
                ((this.SixMonthStandardDeviationOfBalance == null && other.SixMonthStandardDeviationOfBalance == null) || (this.SixMonthStandardDeviationOfBalance?.Equals(other.SixMonthStandardDeviationOfBalance) == true)) &&
                ((this.TwelveMonthStandardDeviationOfBalance == null && other.TwelveMonthStandardDeviationOfBalance == null) || (this.TwelveMonthStandardDeviationOfBalance?.Equals(other.TwelveMonthStandardDeviationOfBalance) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"MonthlyClosingBalance = {(this.MonthlyClosingBalance == null ? "null" : this.MonthlyClosingBalance.ToString())}");
            toStringOutput.Add($"MonthlyMinimumBalance = {(this.MonthlyMinimumBalance == null ? "null" : this.MonthlyMinimumBalance.ToString())}");
            toStringOutput.Add($"MonthlyMaximumBalance = {(this.MonthlyMaximumBalance == null ? "null" : this.MonthlyMaximumBalance.ToString())}");
            toStringOutput.Add($"MonthlyAverageBalance = {(this.MonthlyAverageBalance == null ? "null" : this.MonthlyAverageBalance.ToString())}");
            toStringOutput.Add($"MonthlyStandardDeviationOfBalance = {(this.MonthlyStandardDeviationOfBalance == null ? "null" : this.MonthlyStandardDeviationOfBalance.ToString())}");
            toStringOutput.Add($"MonthlyDaysWithPositiveBalance = {(this.MonthlyDaysWithPositiveBalance == null ? "null" : this.MonthlyDaysWithPositiveBalance.ToString())}");
            toStringOutput.Add($"MonthlyDaysWithNegativeBalance = {(this.MonthlyDaysWithNegativeBalance == null ? "null" : this.MonthlyDaysWithNegativeBalance.ToString())}");
            toStringOutput.Add($"MonthlyTwoMonthAverageBalance = {(this.MonthlyTwoMonthAverageBalance == null ? "null" : this.MonthlyTwoMonthAverageBalance.ToString())}");
            toStringOutput.Add($"MonthlySixMonthAverageBalance = {(this.MonthlySixMonthAverageBalance == null ? "null" : this.MonthlySixMonthAverageBalance.ToString())}");
            toStringOutput.Add($"TwelveMonthAverageBalance = {(this.TwelveMonthAverageBalance == null ? "null" : this.TwelveMonthAverageBalance.ToString())}");
            toStringOutput.Add($"TwoMonthStandardDeviationOfBalance = {(this.TwoMonthStandardDeviationOfBalance == null ? "null" : this.TwoMonthStandardDeviationOfBalance.ToString())}");
            toStringOutput.Add($"SixMonthStandardDeviationOfBalance = {(this.SixMonthStandardDeviationOfBalance == null ? "null" : this.SixMonthStandardDeviationOfBalance.ToString())}");
            toStringOutput.Add($"TwelveMonthStandardDeviationOfBalance = {(this.TwelveMonthStandardDeviationOfBalance == null ? "null" : this.TwelveMonthStandardDeviationOfBalance.ToString())}");
        }
    }
}