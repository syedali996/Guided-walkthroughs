// <copyright file="CashFlowAnalyticsReport.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowAnalyticsReport.
    /// </summary>
    public class CashFlowAnalyticsReport
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsReport"/> class.
        /// </summary>
        public CashFlowAnalyticsReport()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsReport"/> class.
        /// </summary>
        /// <param name="customerId">customerId.</param>
        /// <param name="reportHeader">reportHeader.</param>
        /// <param name="title">title.</param>
        /// <param name="accountResults">accountResults.</param>
        /// <param name="businessId">businessId.</param>
        /// <param name="businessSummary">businessSummary.</param>
        /// <param name="requesterName">requesterName.</param>
        /// <param name="totalRevenue">totalRevenue.</param>
        public CashFlowAnalyticsReport(
            long customerId,
            Models.ObbReportHeader reportHeader,
            string title,
            List<Models.CashFlowAnalyticsAccountResult> accountResults = null,
            int? businessId = null,
            Models.CashFlowAnalyticsBusinessSummary businessSummary = null,
            string requesterName = null,
            double? totalRevenue = null)
        {
            this.AccountResults = accountResults;
            this.BusinessId = businessId;
            this.BusinessSummary = businessSummary;
            this.CustomerId = customerId;
            this.ReportHeader = reportHeader;
            this.RequesterName = requesterName;
            this.Title = title;
            this.TotalRevenue = totalRevenue;
        }

        /// <summary>
        /// Cash flow results per account
        /// </summary>
        [JsonProperty("accountResults", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CashFlowAnalyticsAccountResult> AccountResults { get; set; }

        /// <summary>
        /// Business ID
        /// </summary>
        [JsonProperty("businessId", NullValueHandling = NullValueHandling.Ignore)]
        public int? BusinessId { get; set; }

        /// <summary>
        /// Cash flow analytics summarized across all accounts in the report
        /// </summary>
        [JsonProperty("businessSummary", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowAnalyticsBusinessSummary BusinessSummary { get; set; }

        /// <summary>
        /// A customer ID represented as a number. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public long CustomerId { get; set; }

        /// <summary>
        /// Customer and report metadata
        /// </summary>
        [JsonProperty("reportHeader")]
        public Models.ObbReportHeader ReportHeader { get; set; }

        /// <summary>
        /// Name of requester
        /// </summary>
        [JsonProperty("requesterName", NullValueHandling = NullValueHandling.Ignore)]
        public string RequesterName { get; set; }

        /// <summary>
        /// Title of the report
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <summary>
        /// The total revenue
        /// </summary>
        [JsonProperty("totalRevenue", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalRevenue { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowAnalyticsReport : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowAnalyticsReport other &&
                ((this.AccountResults == null && other.AccountResults == null) || (this.AccountResults?.Equals(other.AccountResults) == true)) &&
                ((this.BusinessId == null && other.BusinessId == null) || (this.BusinessId?.Equals(other.BusinessId) == true)) &&
                ((this.BusinessSummary == null && other.BusinessSummary == null) || (this.BusinessSummary?.Equals(other.BusinessSummary) == true)) &&
                this.CustomerId.Equals(other.CustomerId) &&
                ((this.ReportHeader == null && other.ReportHeader == null) || (this.ReportHeader?.Equals(other.ReportHeader) == true)) &&
                ((this.RequesterName == null && other.RequesterName == null) || (this.RequesterName?.Equals(other.RequesterName) == true)) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true)) &&
                ((this.TotalRevenue == null && other.TotalRevenue == null) || (this.TotalRevenue?.Equals(other.TotalRevenue) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountResults = {(this.AccountResults == null ? "null" : $"[{string.Join(", ", this.AccountResults)} ]")}");
            toStringOutput.Add($"this.BusinessId = {(this.BusinessId == null ? "null" : this.BusinessId.ToString())}");
            toStringOutput.Add($"this.BusinessSummary = {(this.BusinessSummary == null ? "null" : this.BusinessSummary.ToString())}");
            toStringOutput.Add($"this.CustomerId = {this.CustomerId}");
            toStringOutput.Add($"this.ReportHeader = {(this.ReportHeader == null ? "null" : this.ReportHeader.ToString())}");
            toStringOutput.Add($"this.RequesterName = {(this.RequesterName == null ? "null" : this.RequesterName == string.Empty ? "" : this.RequesterName)}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title == string.Empty ? "" : this.Title)}");
            toStringOutput.Add($"this.TotalRevenue = {(this.TotalRevenue == null ? "null" : this.TotalRevenue.ToString())}");
        }
    }
}