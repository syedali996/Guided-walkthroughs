// <copyright file="PayStatementData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayStatementData.
    /// </summary>
    public class PayStatementData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayStatementData"/> class.
        /// </summary>
        public PayStatementData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayStatementData"/> class.
        /// </summary>
        /// <param name="assetIds">assetIds.</param>
        /// <param name="extractEarnings">extractEarnings.</param>
        /// <param name="extractDeductions">extractDeductions.</param>
        /// <param name="extractDirectDeposit">extractDirectDeposit.</param>
        public PayStatementData(
            List<string> assetIds,
            bool? extractEarnings = true,
            bool? extractDeductions = false,
            bool? extractDirectDeposit = true)
        {
            this.AssetIds = assetIds;
            this.ExtractEarnings = extractEarnings;
            this.ExtractDeductions = extractDeductions;
            this.ExtractDirectDeposit = extractDirectDeposit;
        }

        /// <summary>
        /// A list of pay statement asset IDs
        /// </summary>
        [JsonProperty("assetIds")]
        public List<string> AssetIds { get; set; }

        /// <summary>
        /// Field to indicate whether to extract the earnings on all pay statements
        /// </summary>
        [JsonProperty("extractEarnings", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ExtractEarnings { get; set; }

        /// <summary>
        /// Field to indicate whether to extract the deductions on all pay statements
        /// </summary>
        [JsonProperty("extractDeductions", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ExtractDeductions { get; set; }

        /// <summary>
        /// Field to indicate whether to extract the direct deposits on all pay statements
        /// </summary>
        [JsonProperty("extractDirectDeposit", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ExtractDirectDeposit { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayStatementData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayStatementData other &&
                ((this.AssetIds == null && other.AssetIds == null) || (this.AssetIds?.Equals(other.AssetIds) == true)) &&
                ((this.ExtractEarnings == null && other.ExtractEarnings == null) || (this.ExtractEarnings?.Equals(other.ExtractEarnings) == true)) &&
                ((this.ExtractDeductions == null && other.ExtractDeductions == null) || (this.ExtractDeductions?.Equals(other.ExtractDeductions) == true)) &&
                ((this.ExtractDirectDeposit == null && other.ExtractDirectDeposit == null) || (this.ExtractDirectDeposit?.Equals(other.ExtractDirectDeposit) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AssetIds = {(this.AssetIds == null ? "null" : $"[{string.Join(", ", this.AssetIds)} ]")}");
            toStringOutput.Add($"this.ExtractEarnings = {(this.ExtractEarnings == null ? "null" : this.ExtractEarnings.ToString())}");
            toStringOutput.Add($"this.ExtractDeductions = {(this.ExtractDeductions == null ? "null" : this.ExtractDeductions.ToString())}");
            toStringOutput.Add($"this.ExtractDirectDeposit = {(this.ExtractDirectDeposit == null ? "null" : this.ExtractDirectDeposit.ToString())}");
        }
    }
}