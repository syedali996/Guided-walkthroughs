// <copyright file="ConsumerAttributeList.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributeList.
    /// </summary>
    public class ConsumerAttributeList
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributeList"/> class.
        /// </summary>
        public ConsumerAttributeList()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributeList"/> class.
        /// </summary>
        /// <param name="analyticIds">analytic_ids.</param>
        public ConsumerAttributeList(
            List<Models.ConsumerAttributesAnalyticId> analyticIds)
        {
            this.AnalyticIds = analyticIds;
        }

        /// <summary>
        /// A list of analytic IDs
        /// </summary>
        [JsonProperty("analytic_ids")]
        public List<Models.ConsumerAttributesAnalyticId> AnalyticIds { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributeList : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributeList other &&
                ((this.AnalyticIds == null && other.AnalyticIds == null) || (this.AnalyticIds?.Equals(other.AnalyticIds) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AnalyticIds = {(this.AnalyticIds == null ? "null" : $"[{string.Join(", ", this.AnalyticIds)} ]")}");
        }
    }
}