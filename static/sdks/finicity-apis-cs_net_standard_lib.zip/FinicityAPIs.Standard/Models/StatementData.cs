// <copyright file="StatementData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// StatementData.
    /// </summary>
    public class StatementData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatementData"/> class.
        /// </summary>
        public StatementData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="StatementData"/> class.
        /// </summary>
        /// <param name="accountId">accountId.</param>
        /// <param name="index">index.</param>
        public StatementData(
            long accountId,
            int? index = 1)
        {
            this.AccountId = accountId;
            this.Index = index;
        }

        /// <summary>
        /// An account ID represented as a number
        /// </summary>
        [JsonProperty("accountId")]
        public long AccountId { get; set; }

        /// <summary>
        /// Index of the statement to retrieve
        /// </summary>
        [JsonProperty("index", NullValueHandling = NullValueHandling.Ignore)]
        public int? Index { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"StatementData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is StatementData other &&
                this.AccountId.Equals(other.AccountId) &&
                ((this.Index == null && other.Index == null) || (this.Index?.Equals(other.Index) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountId = {this.AccountId}");
            toStringOutput.Add($"this.Index = {(this.Index == null ? "null" : this.Index.ToString())}");
        }
    }
}