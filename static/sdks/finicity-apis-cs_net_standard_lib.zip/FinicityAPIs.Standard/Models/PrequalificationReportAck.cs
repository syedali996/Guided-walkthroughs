// <copyright file="PrequalificationReportAck.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PrequalificationReportAck.
    /// </summary>
    public class PrequalificationReportAck
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportAck"/> class.
        /// </summary>
        public PrequalificationReportAck()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportAck"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="customerType">customerType.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="requestId">requestId.</param>
        /// <param name="requesterName">requesterName.</param>
        /// <param name="createdDate">createdDate.</param>
        /// <param name="title">title.</param>
        /// <param name="consumerId">consumerId.</param>
        /// <param name="consumerSsn">consumerSsn.</param>
        /// <param name="type">type.</param>
        /// <param name="status">status.</param>
        /// <param name="portfolioId">portfolioId.</param>
        /// <param name="constraints">constraints.</param>
        /// <param name="errors">errors.</param>
        public PrequalificationReportAck(
            string id,
            string customerType,
            long customerId,
            string requestId,
            string requesterName,
            long createdDate,
            string title,
            string consumerId,
            string consumerSsn,
            string type,
            string status,
            string portfolioId,
            Models.PrequalificationReportConstraintsOut constraints,
            List<Models.ErrorMessage> errors = null)
        {
            this.Id = id;
            this.CustomerType = customerType;
            this.CustomerId = customerId;
            this.RequestId = requestId;
            this.RequesterName = requesterName;
            this.CreatedDate = createdDate;
            this.Title = title;
            this.ConsumerId = consumerId;
            this.ConsumerSsn = consumerSsn;
            this.Type = type;
            this.Status = status;
            this.Errors = errors;
            this.PortfolioId = portfolioId;
            this.Constraints = constraints;
        }

        /// <summary>
        /// A report ID
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// The type of customer ("active" or "testing" or "" for all types)
        /// </summary>
        [JsonProperty("customerType")]
        public string CustomerType { get; set; }

        /// <summary>
        /// A customer ID represented as a number. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public long CustomerId { get; set; }

        /// <summary>
        /// Finicity indicator to track all activity associated with this report
        /// </summary>
        [JsonProperty("requestId")]
        public string RequestId { get; set; }

        /// <summary>
        /// Name of a Finicity partner
        /// </summary>
        [JsonProperty("requesterName")]
        public string RequesterName { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate")]
        public long CreatedDate { get; set; }

        /// <summary>
        /// Title of the report
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <summary>
        /// A consumer ID. See Create Consumer API for how to create a consumer ID.
        /// </summary>
        [JsonProperty("consumerId")]
        public string ConsumerId { get; set; }

        /// <summary>
        /// Last 4 digits of a SSN
        /// </summary>
        [JsonProperty("consumerSsn")]
        public string ConsumerSsn { get; set; }

        /// <summary>
        /// A report type. Possible values:
        ///   * "voi"
        ///   * "voa"
        ///   * "voaHistory"
        ///   * "history"
        ///   * "voieTxVerify"
        ///   * "voieWithReport"
        ///   * "voieWithInterview"
        ///   * "paystatement"
        ///   * "preQualVoa"
        ///   * "assetSummary"
        ///   * "voie"
        ///   * "transactions"
        ///   * "statement"
        ///   * "voiePayroll"
        ///   * "voeTransactions"
        ///   * "voePayroll"
        ///   * "cfrp"
        ///   * "cfrb"
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// A report generation status. Possible values: "inProgress", "success", "failure".
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <summary>
        /// In case errors occurred during the report generation
        /// </summary>
        [JsonProperty("errors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ErrorMessage> Errors { get; set; }

        /// <summary>
        /// A unique identifier that will be consistent across all reports created for the same customer
        /// </summary>
        [JsonProperty("portfolioId")]
        public string PortfolioId { get; set; }

        /// <summary>
        /// Gets or sets Constraints.
        /// </summary>
        [JsonProperty("constraints")]
        public Models.PrequalificationReportConstraintsOut Constraints { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrequalificationReportAck : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrequalificationReportAck other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.CustomerType == null && other.CustomerType == null) || (this.CustomerType?.Equals(other.CustomerType) == true)) &&
                this.CustomerId.Equals(other.CustomerId) &&
                ((this.RequestId == null && other.RequestId == null) || (this.RequestId?.Equals(other.RequestId) == true)) &&
                ((this.RequesterName == null && other.RequesterName == null) || (this.RequesterName?.Equals(other.RequesterName) == true)) &&
                this.CreatedDate.Equals(other.CreatedDate) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true)) &&
                ((this.ConsumerId == null && other.ConsumerId == null) || (this.ConsumerId?.Equals(other.ConsumerId) == true)) &&
                ((this.ConsumerSsn == null && other.ConsumerSsn == null) || (this.ConsumerSsn?.Equals(other.ConsumerSsn) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Errors == null && other.Errors == null) || (this.Errors?.Equals(other.Errors) == true)) &&
                ((this.PortfolioId == null && other.PortfolioId == null) || (this.PortfolioId?.Equals(other.PortfolioId) == true)) &&
                ((this.Constraints == null && other.Constraints == null) || (this.Constraints?.Equals(other.Constraints) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.CustomerType = {(this.CustomerType == null ? "null" : this.CustomerType == string.Empty ? "" : this.CustomerType)}");
            toStringOutput.Add($"this.CustomerId = {this.CustomerId}");
            toStringOutput.Add($"this.RequestId = {(this.RequestId == null ? "null" : this.RequestId == string.Empty ? "" : this.RequestId)}");
            toStringOutput.Add($"this.RequesterName = {(this.RequesterName == null ? "null" : this.RequesterName == string.Empty ? "" : this.RequesterName)}");
            toStringOutput.Add($"this.CreatedDate = {this.CreatedDate}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title == string.Empty ? "" : this.Title)}");
            toStringOutput.Add($"this.ConsumerId = {(this.ConsumerId == null ? "null" : this.ConsumerId == string.Empty ? "" : this.ConsumerId)}");
            toStringOutput.Add($"this.ConsumerSsn = {(this.ConsumerSsn == null ? "null" : this.ConsumerSsn == string.Empty ? "" : this.ConsumerSsn)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.Errors = {(this.Errors == null ? "null" : $"[{string.Join(", ", this.Errors)} ]")}");
            toStringOutput.Add($"this.PortfolioId = {(this.PortfolioId == null ? "null" : this.PortfolioId == string.Empty ? "" : this.PortfolioId)}");
            toStringOutput.Add($"this.Constraints = {(this.Constraints == null ? "null" : this.Constraints.ToString())}");
        }
    }
}