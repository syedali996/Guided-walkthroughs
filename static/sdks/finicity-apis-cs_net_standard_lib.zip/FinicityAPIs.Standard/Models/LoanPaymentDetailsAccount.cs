// <copyright file="LoanPaymentDetailsAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// LoanPaymentDetailsAccount.
    /// </summary>
    public class LoanPaymentDetailsAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetailsAccount"/> class.
        /// </summary>
        public LoanPaymentDetailsAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetailsAccount"/> class.
        /// </summary>
        /// <param name="accountId">accountId.</param>
        /// <param name="accountNumber">accountNumber.</param>
        /// <param name="accountPaymentNumber">accountPaymentNumber.</param>
        /// <param name="accountPaymentAddress">accountPaymentAddress.</param>
        /// <param name="accountFuturePayoffAmount">accountFuturePayoffAmount.</param>
        /// <param name="accountFuturePayoffDate">accountFuturePayoffDate.</param>
        /// <param name="groupDetail">groupDetail.</param>
        /// <param name="loanDetail">loanDetail.</param>
        public LoanPaymentDetailsAccount(
            string accountId,
            string accountNumber,
            string accountPaymentNumber,
            string accountPaymentAddress,
            double? accountFuturePayoffAmount = null,
            DateTime? accountFuturePayoffDate = null,
            List<Models.LoanPaymentDetailsGroup> groupDetail = null,
            List<Models.LoanPaymentDetailsLoan> loanDetail = null)
        {
            this.AccountId = accountId;
            this.AccountNumber = accountNumber;
            this.AccountPaymentNumber = accountPaymentNumber;
            this.AccountPaymentAddress = accountPaymentAddress;
            this.AccountFuturePayoffAmount = accountFuturePayoffAmount;
            this.AccountFuturePayoffDate = accountFuturePayoffDate;
            this.GroupDetail = groupDetail;
            this.LoanDetail = loanDetail;
        }

        /// <summary>
        /// An account ID
        /// </summary>
        [JsonProperty("accountId")]
        public string AccountId { get; set; }

        /// <summary>
        /// Institution's ID of the Student Loan Account
        /// </summary>
        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number.
        /// </summary>
        [JsonProperty("accountPaymentNumber")]
        public string AccountPaymentNumber { get; set; }

        /// <summary>
        /// The payment address to which send manual payments should be sent
        /// </summary>
        [JsonProperty("accountPaymentAddress")]
        public string AccountPaymentAddress { get; set; }

        /// <summary>
        /// The payoff amount for the account
        /// </summary>
        [JsonProperty("accountFuturePayoffAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? AccountFuturePayoffAmount { get; set; }

        /// <summary>
        /// The date to which the "Future Payoff Amount" applies
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("accountFuturePayoffDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? AccountFuturePayoffDate { get; set; }

        /// <summary>
        /// Group details
        /// </summary>
        [JsonProperty("groupDetail", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LoanPaymentDetailsGroup> GroupDetail { get; set; }

        /// <summary>
        /// Loan details
        /// </summary>
        [JsonProperty("loanDetail", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LoanPaymentDetailsLoan> LoanDetail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LoanPaymentDetailsAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LoanPaymentDetailsAccount other &&
                ((this.AccountId == null && other.AccountId == null) || (this.AccountId?.Equals(other.AccountId) == true)) &&
                ((this.AccountNumber == null && other.AccountNumber == null) || (this.AccountNumber?.Equals(other.AccountNumber) == true)) &&
                ((this.AccountPaymentNumber == null && other.AccountPaymentNumber == null) || (this.AccountPaymentNumber?.Equals(other.AccountPaymentNumber) == true)) &&
                ((this.AccountPaymentAddress == null && other.AccountPaymentAddress == null) || (this.AccountPaymentAddress?.Equals(other.AccountPaymentAddress) == true)) &&
                ((this.AccountFuturePayoffAmount == null && other.AccountFuturePayoffAmount == null) || (this.AccountFuturePayoffAmount?.Equals(other.AccountFuturePayoffAmount) == true)) &&
                ((this.AccountFuturePayoffDate == null && other.AccountFuturePayoffDate == null) || (this.AccountFuturePayoffDate?.Equals(other.AccountFuturePayoffDate) == true)) &&
                ((this.GroupDetail == null && other.GroupDetail == null) || (this.GroupDetail?.Equals(other.GroupDetail) == true)) &&
                ((this.LoanDetail == null && other.LoanDetail == null) || (this.LoanDetail?.Equals(other.LoanDetail) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountId = {(this.AccountId == null ? "null" : this.AccountId == string.Empty ? "" : this.AccountId)}");
            toStringOutput.Add($"this.AccountNumber = {(this.AccountNumber == null ? "null" : this.AccountNumber == string.Empty ? "" : this.AccountNumber)}");
            toStringOutput.Add($"this.AccountPaymentNumber = {(this.AccountPaymentNumber == null ? "null" : this.AccountPaymentNumber == string.Empty ? "" : this.AccountPaymentNumber)}");
            toStringOutput.Add($"this.AccountPaymentAddress = {(this.AccountPaymentAddress == null ? "null" : this.AccountPaymentAddress == string.Empty ? "" : this.AccountPaymentAddress)}");
            toStringOutput.Add($"this.AccountFuturePayoffAmount = {(this.AccountFuturePayoffAmount == null ? "null" : this.AccountFuturePayoffAmount.ToString())}");
            toStringOutput.Add($"this.AccountFuturePayoffDate = {(this.AccountFuturePayoffDate == null ? "null" : this.AccountFuturePayoffDate.ToString())}");
            toStringOutput.Add($"this.GroupDetail = {(this.GroupDetail == null ? "null" : $"[{string.Join(", ", this.GroupDetail)} ]")}");
            toStringOutput.Add($"this.LoanDetail = {(this.LoanDetail == null ? "null" : $"[{string.Join(", ", this.LoanDetail)} ]")}");
        }
    }
}