// <copyright file="ObbInstitution.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbInstitution.
    /// </summary>
    public class ObbInstitution
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbInstitution"/> class.
        /// </summary>
        public ObbInstitution()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbInstitution"/> class.
        /// </summary>
        /// <param name="institutionId">institutionId.</param>
        /// <param name="institutionIconUrl">institutionIconUrl.</param>
        /// <param name="institutionName">institutionName.</param>
        /// <param name="institutionPrimaryColor">institutionPrimaryColor.</param>
        public ObbInstitution(
            int institutionId,
            string institutionIconUrl = null,
            string institutionName = null,
            string institutionPrimaryColor = null)
        {
            this.InstitutionIconUrl = institutionIconUrl;
            this.InstitutionId = institutionId;
            this.InstitutionName = institutionName;
            this.InstitutionPrimaryColor = institutionPrimaryColor;
        }

        /// <summary>
        /// URL of the institution logo icon for reporting
        /// </summary>
        [JsonProperty("institutionIconUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string InstitutionIconUrl { get; set; }

        /// <summary>
        /// ID of the financial institution
        /// </summary>
        [JsonProperty("institutionId")]
        public int InstitutionId { get; set; }

        /// <summary>
        /// Name of the financial institution
        /// </summary>
        [JsonProperty("institutionName", NullValueHandling = NullValueHandling.Ignore)]
        public string InstitutionName { get; set; }

        /// <summary>
        /// Primary branding color of the institution, in hex color format
        /// </summary>
        [JsonProperty("institutionPrimaryColor", NullValueHandling = NullValueHandling.Ignore)]
        public string InstitutionPrimaryColor { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbInstitution : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbInstitution other &&
                ((this.InstitutionIconUrl == null && other.InstitutionIconUrl == null) || (this.InstitutionIconUrl?.Equals(other.InstitutionIconUrl) == true)) &&
                this.InstitutionId.Equals(other.InstitutionId) &&
                ((this.InstitutionName == null && other.InstitutionName == null) || (this.InstitutionName?.Equals(other.InstitutionName) == true)) &&
                ((this.InstitutionPrimaryColor == null && other.InstitutionPrimaryColor == null) || (this.InstitutionPrimaryColor?.Equals(other.InstitutionPrimaryColor) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.InstitutionIconUrl = {(this.InstitutionIconUrl == null ? "null" : this.InstitutionIconUrl == string.Empty ? "" : this.InstitutionIconUrl)}");
            toStringOutput.Add($"this.InstitutionId = {this.InstitutionId}");
            toStringOutput.Add($"this.InstitutionName = {(this.InstitutionName == null ? "null" : this.InstitutionName == string.Empty ? "" : this.InstitutionName)}");
            toStringOutput.Add($"this.InstitutionPrimaryColor = {(this.InstitutionPrimaryColor == null ? "null" : this.InstitutionPrimaryColor == string.Empty ? "" : this.InstitutionPrimaryColor)}");
        }
    }
}