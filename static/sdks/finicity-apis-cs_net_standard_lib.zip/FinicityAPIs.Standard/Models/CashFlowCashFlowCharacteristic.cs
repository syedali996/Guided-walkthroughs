// <copyright file="CashFlowCashFlowCharacteristic.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowCashFlowCharacteristic.
    /// </summary>
    public class CashFlowCashFlowCharacteristic
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCharacteristic"/> class.
        /// </summary>
        public CashFlowCashFlowCharacteristic()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCharacteristic"/> class.
        /// </summary>
        /// <param name="monthlyCashFlowCharacteristics">monthlyCashFlowCharacteristics.</param>
        /// <param name="averageMonthlyNet">averageMonthlyNet.</param>
        /// <param name="averageMonthlyNetLessTransfers">averageMonthlyNetLessTransfers.</param>
        /// <param name="twelveMonthTotalNet">twelveMonthTotalNet.</param>
        /// <param name="twelveMonthTotalNetLessTransfers">twelveMonthTotalNetLessTransfers.</param>
        /// <param name="sixMonthAverageTotalCreditsLessTotalDebits">sixMonthAverageTotalCreditsLessTotalDebits.</param>
        /// <param name="sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers">sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers.</param>
        /// <param name="twoMonthAverageTotalCreditsLessTotalDebits">twoMonthAverageTotalCreditsLessTotalDebits.</param>
        /// <param name="twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers">twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers.</param>
        public CashFlowCashFlowCharacteristic(
            List<Models.CashFlowMonthlyCashFlowCharacteristics> monthlyCashFlowCharacteristics,
            double averageMonthlyNet,
            double averageMonthlyNetLessTransfers,
            double twelveMonthTotalNet,
            double twelveMonthTotalNetLessTransfers,
            double sixMonthAverageTotalCreditsLessTotalDebits,
            double sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers,
            double twoMonthAverageTotalCreditsLessTotalDebits,
            double twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers)
        {
            this.MonthlyCashFlowCharacteristics = monthlyCashFlowCharacteristics;
            this.AverageMonthlyNet = averageMonthlyNet;
            this.AverageMonthlyNetLessTransfers = averageMonthlyNetLessTransfers;
            this.TwelveMonthTotalNet = twelveMonthTotalNet;
            this.TwelveMonthTotalNetLessTransfers = twelveMonthTotalNetLessTransfers;
            this.SixMonthAverageTotalCreditsLessTotalDebits = sixMonthAverageTotalCreditsLessTotalDebits;
            this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers = sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers;
            this.TwoMonthAverageTotalCreditsLessTotalDebits = twoMonthAverageTotalCreditsLessTotalDebits;
            this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers = twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers;
        }

        /// <summary>
        /// List of attributes for each month
        /// </summary>
        [JsonProperty("monthlyCashFlowCharacteristics")]
        public List<Models.CashFlowMonthlyCashFlowCharacteristics> MonthlyCashFlowCharacteristics { get; set; }

        /// <summary>
        /// Average (Total Credits - Total Debits) for the account
        /// </summary>
        [JsonProperty("averageMonthlyNet")]
        public double AverageMonthlyNet { get; set; }

        /// <summary>
        /// Average (Total Credits - Total Debits) without transfers for the account
        /// </summary>
        [JsonProperty("averageMonthlyNetLessTransfers")]
        public double AverageMonthlyNetLessTransfers { get; set; }

        /// <summary>
        /// Sum of all monthly (Total Credits - Total Debits) each month for the account
        /// </summary>
        [JsonProperty("twelveMonthTotalNet")]
        public double TwelveMonthTotalNet { get; set; }

        /// <summary>
        /// Sum of all monthly (Total Credits - Total Debits) without transfers for the account
        /// </summary>
        [JsonProperty("twelveMonthTotalNetLessTransfers")]
        public double TwelveMonthTotalNetLessTransfers { get; set; }

        /// <summary>
        /// 6 Month Average (Total Credits - Total Debits)
        /// </summary>
        [JsonProperty("sixMonthAverageTotalCreditsLessTotalDebits")]
        public double SixMonthAverageTotalCreditsLessTotalDebits { get; set; }

        /// <summary>
        /// 6 Month Average (Total Credits - Total Debits) - (Without Transfers)
        /// </summary>
        [JsonProperty("sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers")]
        public double SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers { get; set; }

        /// <summary>
        /// 2 Month Average (Total Credits - Total Debits)
        /// </summary>
        [JsonProperty("twoMonthAverageTotalCreditsLessTotalDebits")]
        public double TwoMonthAverageTotalCreditsLessTotalDebits { get; set; }

        /// <summary>
        /// 2 Month Average (Total Credits - Total Debits) - (Without Transfers)
        /// </summary>
        [JsonProperty("twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers")]
        public double TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowCashFlowCharacteristic : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowCashFlowCharacteristic other &&
                ((this.MonthlyCashFlowCharacteristics == null && other.MonthlyCashFlowCharacteristics == null) || (this.MonthlyCashFlowCharacteristics?.Equals(other.MonthlyCashFlowCharacteristics) == true)) &&
                this.AverageMonthlyNet.Equals(other.AverageMonthlyNet) &&
                this.AverageMonthlyNetLessTransfers.Equals(other.AverageMonthlyNetLessTransfers) &&
                this.TwelveMonthTotalNet.Equals(other.TwelveMonthTotalNet) &&
                this.TwelveMonthTotalNetLessTransfers.Equals(other.TwelveMonthTotalNetLessTransfers) &&
                this.SixMonthAverageTotalCreditsLessTotalDebits.Equals(other.SixMonthAverageTotalCreditsLessTotalDebits) &&
                this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers.Equals(other.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers) &&
                this.TwoMonthAverageTotalCreditsLessTotalDebits.Equals(other.TwoMonthAverageTotalCreditsLessTotalDebits) &&
                this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers.Equals(other.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MonthlyCashFlowCharacteristics = {(this.MonthlyCashFlowCharacteristics == null ? "null" : $"[{string.Join(", ", this.MonthlyCashFlowCharacteristics)} ]")}");
            toStringOutput.Add($"this.AverageMonthlyNet = {this.AverageMonthlyNet}");
            toStringOutput.Add($"this.AverageMonthlyNetLessTransfers = {this.AverageMonthlyNetLessTransfers}");
            toStringOutput.Add($"this.TwelveMonthTotalNet = {this.TwelveMonthTotalNet}");
            toStringOutput.Add($"this.TwelveMonthTotalNetLessTransfers = {this.TwelveMonthTotalNetLessTransfers}");
            toStringOutput.Add($"this.SixMonthAverageTotalCreditsLessTotalDebits = {this.SixMonthAverageTotalCreditsLessTotalDebits}");
            toStringOutput.Add($"this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers = {this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers}");
            toStringOutput.Add($"this.TwoMonthAverageTotalCreditsLessTotalDebits = {this.TwoMonthAverageTotalCreditsLessTotalDebits}");
            toStringOutput.Add($"this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers = {this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers}");
        }
    }
}