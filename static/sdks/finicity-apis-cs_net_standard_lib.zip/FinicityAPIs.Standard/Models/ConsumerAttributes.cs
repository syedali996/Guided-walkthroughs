// <copyright file="ConsumerAttributes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributes.
    /// </summary>
    public class ConsumerAttributes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributes"/> class.
        /// </summary>
        public ConsumerAttributes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributes"/> class.
        /// </summary>
        /// <param name="analyticsId">analytics_id.</param>
        /// <param name="ca360Data">ca360_data.</param>
        public ConsumerAttributes(
            string analyticsId,
            Models.ConsumerAttributesData ca360Data)
        {
            this.AnalyticsId = analyticsId;
            this.Ca360Data = ca360Data;
        }

        /// <summary>
        /// An ID for a Consumer Attributes report
        /// </summary>
        [JsonProperty("analytics_id")]
        public string AnalyticsId { get; set; }

        /// <summary>
        /// Gets or sets Ca360Data.
        /// </summary>
        [JsonProperty("ca360_data")]
        public Models.ConsumerAttributesData Ca360Data { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributes other &&
                ((this.AnalyticsId == null && other.AnalyticsId == null) || (this.AnalyticsId?.Equals(other.AnalyticsId) == true)) &&
                ((this.Ca360Data == null && other.Ca360Data == null) || (this.Ca360Data?.Equals(other.Ca360Data) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AnalyticsId = {(this.AnalyticsId == null ? "null" : this.AnalyticsId == string.Empty ? "" : this.AnalyticsId)}");
            toStringOutput.Add($"this.Ca360Data = {(this.Ca360Data == null ? "null" : this.Ca360Data.ToString())}");
        }
    }
}