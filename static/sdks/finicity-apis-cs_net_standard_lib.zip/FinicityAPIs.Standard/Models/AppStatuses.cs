// <copyright file="AppStatuses.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AppStatuses.
    /// </summary>
    public class AppStatuses
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppStatuses"/> class.
        /// </summary>
        public AppStatuses()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AppStatuses"/> class.
        /// </summary>
        /// <param name="totalRecords">totalRecords.</param>
        /// <param name="totalPages">totalPages.</param>
        /// <param name="pageNumber">pageNumber.</param>
        /// <param name="numberOfRecordsPerPage">numberOfRecordsPerPage.</param>
        /// <param name="applications">applications.</param>
        public AppStatuses(
            long totalRecords,
            long totalPages,
            long pageNumber,
            long numberOfRecordsPerPage,
            List<Models.AppStatus> applications)
        {
            this.TotalRecords = totalRecords;
            this.TotalPages = totalPages;
            this.PageNumber = pageNumber;
            this.NumberOfRecordsPerPage = numberOfRecordsPerPage;
            this.Applications = applications;
        }

        /// <summary>
        /// The total number of results
        /// </summary>
        [JsonProperty("totalRecords")]
        public long TotalRecords { get; set; }

        /// <summary>
        /// The total number of pages
        /// </summary>
        [JsonProperty("totalPages")]
        public long TotalPages { get; set; }

        /// <summary>
        /// The current page number
        /// </summary>
        [JsonProperty("pageNumber")]
        public long PageNumber { get; set; }

        /// <summary>
        /// The number of results per page
        /// </summary>
        [JsonProperty("numberOfRecordsPerPage")]
        public long NumberOfRecordsPerPage { get; set; }

        /// <summary>
        /// A list of applications with their statuses
        /// </summary>
        [JsonProperty("applications")]
        public List<Models.AppStatus> Applications { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AppStatuses : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AppStatuses other &&
                this.TotalRecords.Equals(other.TotalRecords) &&
                this.TotalPages.Equals(other.TotalPages) &&
                this.PageNumber.Equals(other.PageNumber) &&
                this.NumberOfRecordsPerPage.Equals(other.NumberOfRecordsPerPage) &&
                ((this.Applications == null && other.Applications == null) || (this.Applications?.Equals(other.Applications) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.TotalRecords = {this.TotalRecords}");
            toStringOutput.Add($"this.TotalPages = {this.TotalPages}");
            toStringOutput.Add($"this.PageNumber = {this.PageNumber}");
            toStringOutput.Add($"this.NumberOfRecordsPerPage = {this.NumberOfRecordsPerPage}");
            toStringOutput.Add($"this.Applications = {(this.Applications == null ? "null" : $"[{string.Join(", ", this.Applications)} ]")}");
        }
    }
}