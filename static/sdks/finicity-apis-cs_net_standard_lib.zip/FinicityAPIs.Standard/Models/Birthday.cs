// <copyright file="Birthday.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Birthday.
    /// </summary>
    public class Birthday
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Birthday"/> class.
        /// </summary>
        public Birthday()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Birthday"/> class.
        /// </summary>
        /// <param name="year">year.</param>
        /// <param name="month">month.</param>
        /// <param name="dayOfMonth">dayOfMonth.</param>
        public Birthday(
            int? year = null,
            int? month = null,
            int? dayOfMonth = null)
        {
            this.Year = year;
            this.Month = month;
            this.DayOfMonth = dayOfMonth;
        }

        /// <summary>
        /// The birthday 4-digit year
        /// </summary>
        [JsonProperty("year", NullValueHandling = NullValueHandling.Ignore)]
        public int? Year { get; set; }

        /// <summary>
        /// The birthday 2-digit month (1 is January)
        /// </summary>
        [JsonProperty("month", NullValueHandling = NullValueHandling.Ignore)]
        public int? Month { get; set; }

        /// <summary>
        /// The birthday 2-digit day-of-month
        /// </summary>
        [JsonProperty("dayOfMonth", NullValueHandling = NullValueHandling.Ignore)]
        public int? DayOfMonth { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Birthday : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Birthday other &&
                ((this.Year == null && other.Year == null) || (this.Year?.Equals(other.Year) == true)) &&
                ((this.Month == null && other.Month == null) || (this.Month?.Equals(other.Month) == true)) &&
                ((this.DayOfMonth == null && other.DayOfMonth == null) || (this.DayOfMonth?.Equals(other.DayOfMonth) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Year = {(this.Year == null ? "null" : this.Year.ToString())}");
            toStringOutput.Add($"this.Month = {(this.Month == null ? "null" : this.Month.ToString())}");
            toStringOutput.Add($"this.DayOfMonth = {(this.DayOfMonth == null ? "null" : this.DayOfMonth.ToString())}");
        }
    }
}