// <copyright file="LoanPaymentDetailsLoan.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// LoanPaymentDetailsLoan.
    /// </summary>
    public class LoanPaymentDetailsLoan
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetailsLoan"/> class.
        /// </summary>
        public LoanPaymentDetailsLoan()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetailsLoan"/> class.
        /// </summary>
        /// <param name="accountId">accountId.</param>
        /// <param name="loanNumber">loanNumber.</param>
        /// <param name="loanPaymentNumber">loanPaymentNumber.</param>
        /// <param name="loanPaymentAddress">loanPaymentAddress.</param>
        /// <param name="loanFuturePayoffAmount">loanFuturePayoffAmount.</param>
        /// <param name="loanFuturePayoffDate">loanFuturePayoffDate.</param>
        public LoanPaymentDetailsLoan(
            string accountId,
            string loanNumber,
            string loanPaymentNumber,
            string loanPaymentAddress,
            double? loanFuturePayoffAmount = null,
            DateTime? loanFuturePayoffDate = null)
        {
            this.AccountId = accountId;
            this.LoanNumber = loanNumber;
            this.LoanPaymentNumber = loanPaymentNumber;
            this.LoanPaymentAddress = loanPaymentAddress;
            this.LoanFuturePayoffAmount = loanFuturePayoffAmount;
            this.LoanFuturePayoffDate = loanFuturePayoffDate;
        }

        /// <summary>
        /// An account ID
        /// </summary>
        [JsonProperty("accountId")]
        public string AccountId { get; set; }

        /// <summary>
        /// Institution's ID of the Student Loan
        /// </summary>
        [JsonProperty("loanNumber")]
        public string LoanNumber { get; set; }

        /// <summary>
        /// The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number.
        /// </summary>
        [JsonProperty("loanPaymentNumber")]
        public string LoanPaymentNumber { get; set; }

        /// <summary>
        /// The payment address to which send manual payments should be sent
        /// </summary>
        [JsonProperty("loanPaymentAddress")]
        public string LoanPaymentAddress { get; set; }

        /// <summary>
        /// The payoff amount for the loan
        /// </summary>
        [JsonProperty("loanFuturePayoffAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LoanFuturePayoffAmount { get; set; }

        /// <summary>
        /// The date to which the "Future Payoff Amount" applies
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("loanFuturePayoffDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LoanFuturePayoffDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LoanPaymentDetailsLoan : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LoanPaymentDetailsLoan other &&
                ((this.AccountId == null && other.AccountId == null) || (this.AccountId?.Equals(other.AccountId) == true)) &&
                ((this.LoanNumber == null && other.LoanNumber == null) || (this.LoanNumber?.Equals(other.LoanNumber) == true)) &&
                ((this.LoanPaymentNumber == null && other.LoanPaymentNumber == null) || (this.LoanPaymentNumber?.Equals(other.LoanPaymentNumber) == true)) &&
                ((this.LoanPaymentAddress == null && other.LoanPaymentAddress == null) || (this.LoanPaymentAddress?.Equals(other.LoanPaymentAddress) == true)) &&
                ((this.LoanFuturePayoffAmount == null && other.LoanFuturePayoffAmount == null) || (this.LoanFuturePayoffAmount?.Equals(other.LoanFuturePayoffAmount) == true)) &&
                ((this.LoanFuturePayoffDate == null && other.LoanFuturePayoffDate == null) || (this.LoanFuturePayoffDate?.Equals(other.LoanFuturePayoffDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountId = {(this.AccountId == null ? "null" : this.AccountId == string.Empty ? "" : this.AccountId)}");
            toStringOutput.Add($"this.LoanNumber = {(this.LoanNumber == null ? "null" : this.LoanNumber == string.Empty ? "" : this.LoanNumber)}");
            toStringOutput.Add($"this.LoanPaymentNumber = {(this.LoanPaymentNumber == null ? "null" : this.LoanPaymentNumber == string.Empty ? "" : this.LoanPaymentNumber)}");
            toStringOutput.Add($"this.LoanPaymentAddress = {(this.LoanPaymentAddress == null ? "null" : this.LoanPaymentAddress == string.Empty ? "" : this.LoanPaymentAddress)}");
            toStringOutput.Add($"this.LoanFuturePayoffAmount = {(this.LoanFuturePayoffAmount == null ? "null" : this.LoanFuturePayoffAmount.ToString())}");
            toStringOutput.Add($"this.LoanFuturePayoffDate = {(this.LoanFuturePayoffDate == null ? "null" : this.LoanFuturePayoffDate.ToString())}");
        }
    }
}