// <copyright file="InstitutionWrapper.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InstitutionWrapper.
    /// </summary>
    public class InstitutionWrapper
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InstitutionWrapper"/> class.
        /// </summary>
        public InstitutionWrapper()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InstitutionWrapper"/> class.
        /// </summary>
        /// <param name="institution">institution.</param>
        public InstitutionWrapper(
            Models.Institution institution)
        {
            this.Institution = institution;
        }

        /// <summary>
        /// A financial institution
        /// </summary>
        [JsonProperty("institution")]
        public Models.Institution Institution { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InstitutionWrapper : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is InstitutionWrapper other &&
                ((this.Institution == null && other.Institution == null) || (this.Institution?.Equals(other.Institution) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Institution = {(this.Institution == null ? "null" : this.Institution.ToString())}");
        }
    }
}