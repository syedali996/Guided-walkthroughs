// <copyright file="CashFlowAnalyticsAccountResult.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowAnalyticsAccountResult.
    /// </summary>
    public class CashFlowAnalyticsAccountResult
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsAccountResult"/> class.
        /// </summary>
        public CashFlowAnalyticsAccountResult()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsAccountResult"/> class.
        /// </summary>
        /// <param name="accountDetails">accountDetails.</param>
        /// <param name="accountId">accountId.</param>
        /// <param name="currentReportRequest">currentReportRequest.</param>
        /// <param name="historicDataAvailability">historicDataAvailability.</param>
        /// <param name="cashflowAnalyticsMetrics">cashflowAnalyticsMetrics.</param>
        public CashFlowAnalyticsAccountResult(
            Models.ObbAccountDetails accountDetails,
            long accountId,
            Models.ObbCurrentReportRequestDetails currentReportRequest,
            Models.ObbDataAvailability historicDataAvailability,
            Models.CashFlowAnalyticsMetrics cashflowAnalyticsMetrics = null)
        {
            this.AccountDetails = accountDetails;
            this.AccountId = accountId;
            this.CashflowAnalyticsMetrics = cashflowAnalyticsMetrics;
            this.CurrentReportRequest = currentReportRequest;
            this.HistoricDataAvailability = historicDataAvailability;
        }

        /// <summary>
        /// Details of the account and financial institution
        /// </summary>
        [JsonProperty("accountDetails")]
        public Models.ObbAccountDetails AccountDetails { get; set; }

        /// <summary>
        /// An account ID represented as a number
        /// </summary>
        [JsonProperty("accountId")]
        public long AccountId { get; set; }

        /// <summary>
        /// Generated cashflow calculations/metrics
        /// </summary>
        [JsonProperty("cashflowAnalyticsMetrics", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowAnalyticsMetrics CashflowAnalyticsMetrics { get; set; }

        /// <summary>
        /// Describes the requested attributes of the report
        /// </summary>
        [JsonProperty("currentReportRequest")]
        public Models.ObbCurrentReportRequestDetails CurrentReportRequest { get; set; }

        /// <summary>
        /// Describes the availability of data at the time the report was requested
        /// </summary>
        [JsonProperty("historicDataAvailability")]
        public Models.ObbDataAvailability HistoricDataAvailability { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowAnalyticsAccountResult : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowAnalyticsAccountResult other &&
                ((this.AccountDetails == null && other.AccountDetails == null) || (this.AccountDetails?.Equals(other.AccountDetails) == true)) &&
                this.AccountId.Equals(other.AccountId) &&
                ((this.CashflowAnalyticsMetrics == null && other.CashflowAnalyticsMetrics == null) || (this.CashflowAnalyticsMetrics?.Equals(other.CashflowAnalyticsMetrics) == true)) &&
                ((this.CurrentReportRequest == null && other.CurrentReportRequest == null) || (this.CurrentReportRequest?.Equals(other.CurrentReportRequest) == true)) &&
                ((this.HistoricDataAvailability == null && other.HistoricDataAvailability == null) || (this.HistoricDataAvailability?.Equals(other.HistoricDataAvailability) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountDetails = {(this.AccountDetails == null ? "null" : this.AccountDetails.ToString())}");
            toStringOutput.Add($"this.AccountId = {this.AccountId}");
            toStringOutput.Add($"this.CashflowAnalyticsMetrics = {(this.CashflowAnalyticsMetrics == null ? "null" : this.CashflowAnalyticsMetrics.ToString())}");
            toStringOutput.Add($"this.CurrentReportRequest = {(this.CurrentReportRequest == null ? "null" : this.CurrentReportRequest.ToString())}");
            toStringOutput.Add($"this.HistoricDataAvailability = {(this.HistoricDataAvailability == null ? "null" : this.HistoricDataAvailability.ToString())}");
        }
    }
}