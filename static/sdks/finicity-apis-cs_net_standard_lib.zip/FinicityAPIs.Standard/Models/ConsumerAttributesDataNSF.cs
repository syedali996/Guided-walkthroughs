// <copyright file="ConsumerAttributesDataNSF.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesDataNSF.
    /// </summary>
    public class ConsumerAttributesDataNSF
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataNSF"/> class.
        /// </summary>
        public ConsumerAttributesDataNSF()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataNSF"/> class.
        /// </summary>
        /// <param name="monthlyNSFOccurrences">monthlyNSFOccurrences.</param>
        /// <param name="monthlyLateFeeOccurrences">monthlyLateFeeOccurrences.</param>
        public ConsumerAttributesDataNSF(
            object monthlyNSFOccurrences,
            object monthlyLateFeeOccurrences)
        {
            this.MonthlyNSFOccurrences = monthlyNSFOccurrences;
            this.MonthlyLateFeeOccurrences = monthlyLateFeeOccurrences;
        }

        /// <summary>
        /// The number of non-sufficient funds occurrences per calendar month
        /// </summary>
        [JsonProperty("monthlyNSFOccurrences")]
        public object MonthlyNSFOccurrences { get; set; }

        /// <summary>
        /// The number of late fee occurrences
        /// </summary>
        [JsonProperty("monthlyLateFeeOccurrences")]
        public object MonthlyLateFeeOccurrences { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesDataNSF : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesDataNSF other &&
                ((this.MonthlyNSFOccurrences == null && other.MonthlyNSFOccurrences == null) || (this.MonthlyNSFOccurrences?.Equals(other.MonthlyNSFOccurrences) == true)) &&
                ((this.MonthlyLateFeeOccurrences == null && other.MonthlyLateFeeOccurrences == null) || (this.MonthlyLateFeeOccurrences?.Equals(other.MonthlyLateFeeOccurrences) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"MonthlyNSFOccurrences = {(this.MonthlyNSFOccurrences == null ? "null" : this.MonthlyNSFOccurrences.ToString())}");
            toStringOutput.Add($"MonthlyLateFeeOccurrences = {(this.MonthlyLateFeeOccurrences == null ? "null" : this.MonthlyLateFeeOccurrences.ToString())}");
        }
    }
}