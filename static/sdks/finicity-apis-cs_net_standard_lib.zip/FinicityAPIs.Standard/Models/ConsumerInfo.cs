// <copyright file="ConsumerInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerInfo.
    /// </summary>
    public class ConsumerInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerInfo"/> class.
        /// </summary>
        public ConsumerInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerInfo"/> class.
        /// </summary>
        /// <param name="ssn">ssn.</param>
        /// <param name="dob">dob.</param>
        public ConsumerInfo(
            string ssn,
            long? dob = null)
        {
            this.Ssn = ssn;
            this.Dob = dob;
        }

        /// <summary>
        /// A full SSN without hyphens
        /// </summary>
        [JsonProperty("ssn")]
        public string Ssn { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("dob", NullValueHandling = NullValueHandling.Ignore)]
        public long? Dob { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerInfo other &&
                ((this.Ssn == null && other.Ssn == null) || (this.Ssn?.Equals(other.Ssn) == true)) &&
                ((this.Dob == null && other.Dob == null) || (this.Dob?.Equals(other.Dob) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Ssn = {(this.Ssn == null ? "null" : this.Ssn == string.Empty ? "" : this.Ssn)}");
            toStringOutput.Add($"this.Dob = {(this.Dob == null ? "null" : this.Dob.ToString())}");
        }
    }
}