// <copyright file="CashFlowMonthlyCashFlowDebitSummaries.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowMonthlyCashFlowDebitSummaries.
    /// </summary>
    public class CashFlowMonthlyCashFlowDebitSummaries
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowDebitSummaries"/> class.
        /// </summary>
        public CashFlowMonthlyCashFlowDebitSummaries()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowDebitSummaries"/> class.
        /// </summary>
        /// <param name="month">month.</param>
        /// <param name="numberOfDebits">numberOfDebits.</param>
        /// <param name="totalDebitsAmount">totalDebitsAmount.</param>
        /// <param name="largestDebit">largestDebit.</param>
        /// <param name="numberOfDebitsLessTransfers">numberOfDebitsLessTransfers.</param>
        /// <param name="totalDebitsAmountLessTransfers">totalDebitsAmountLessTransfers.</param>
        /// <param name="averageDebitAmount">averageDebitAmount.</param>
        public CashFlowMonthlyCashFlowDebitSummaries(
            long month,
            string numberOfDebits,
            double totalDebitsAmount,
            double largestDebit,
            string numberOfDebitsLessTransfers,
            double totalDebitsAmountLessTransfers,
            double averageDebitAmount)
        {
            this.Month = month;
            this.NumberOfDebits = numberOfDebits;
            this.TotalDebitsAmount = totalDebitsAmount;
            this.LargestDebit = largestDebit;
            this.NumberOfDebitsLessTransfers = numberOfDebitsLessTransfers;
            this.TotalDebitsAmountLessTransfers = totalDebitsAmountLessTransfers;
            this.AverageDebitAmount = averageDebitAmount;
        }

        /// <summary>
        /// One instance for each complete calendar month in the report
        /// </summary>
        [JsonProperty("month")]
        public long Month { get; set; }

        /// <summary>
        /// Number of Debits by month across all accounts
        /// </summary>
        [JsonProperty("numberOfDebits")]
        public string NumberOfDebits { get; set; }

        /// <summary>
        /// Total Amount of Debits by month across all accounts
        /// </summary>
        [JsonProperty("totalDebitsAmount")]
        public double TotalDebitsAmount { get; set; }

        /// <summary>
        /// Largest Debit by month
        /// </summary>
        [JsonProperty("largestDebit")]
        public double LargestDebit { get; set; }

        /// <summary>
        /// Number of Debits by month (less transfers)
        /// </summary>
        [JsonProperty("numberOfDebitsLessTransfers")]
        public string NumberOfDebitsLessTransfers { get; set; }

        /// <summary>
        /// Total amount of debits by month (less transfers)
        /// </summary>
        [JsonProperty("totalDebitsAmountLessTransfers")]
        public double TotalDebitsAmountLessTransfers { get; set; }

        /// <summary>
        /// The average debit amount
        /// </summary>
        [JsonProperty("averageDebitAmount")]
        public double AverageDebitAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowMonthlyCashFlowDebitSummaries : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowMonthlyCashFlowDebitSummaries other &&
                this.Month.Equals(other.Month) &&
                ((this.NumberOfDebits == null && other.NumberOfDebits == null) || (this.NumberOfDebits?.Equals(other.NumberOfDebits) == true)) &&
                this.TotalDebitsAmount.Equals(other.TotalDebitsAmount) &&
                this.LargestDebit.Equals(other.LargestDebit) &&
                ((this.NumberOfDebitsLessTransfers == null && other.NumberOfDebitsLessTransfers == null) || (this.NumberOfDebitsLessTransfers?.Equals(other.NumberOfDebitsLessTransfers) == true)) &&
                this.TotalDebitsAmountLessTransfers.Equals(other.TotalDebitsAmountLessTransfers) &&
                this.AverageDebitAmount.Equals(other.AverageDebitAmount);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Month = {this.Month}");
            toStringOutput.Add($"this.NumberOfDebits = {(this.NumberOfDebits == null ? "null" : this.NumberOfDebits == string.Empty ? "" : this.NumberOfDebits)}");
            toStringOutput.Add($"this.TotalDebitsAmount = {this.TotalDebitsAmount}");
            toStringOutput.Add($"this.LargestDebit = {this.LargestDebit}");
            toStringOutput.Add($"this.NumberOfDebitsLessTransfers = {(this.NumberOfDebitsLessTransfers == null ? "null" : this.NumberOfDebitsLessTransfers == string.Empty ? "" : this.NumberOfDebitsLessTransfers)}");
            toStringOutput.Add($"this.TotalDebitsAmountLessTransfers = {this.TotalDebitsAmountLessTransfers}");
            toStringOutput.Add($"this.AverageDebitAmount = {this.AverageDebitAmount}");
        }
    }
}