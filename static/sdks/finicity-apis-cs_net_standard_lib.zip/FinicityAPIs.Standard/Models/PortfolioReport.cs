// <copyright file="PortfolioReport.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PortfolioReport.
    /// </summary>
    public class PortfolioReport
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PortfolioReport"/> class.
        /// </summary>
        public PortfolioReport()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PortfolioReport"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="portfolioId">portfolioId.</param>
        /// <param name="type">type.</param>
        /// <param name="status">status.</param>
        /// <param name="createdDate">createdDate.</param>
        public PortfolioReport(
            string id,
            string portfolioId,
            string type,
            string status,
            long createdDate)
        {
            this.Id = id;
            this.PortfolioId = portfolioId;
            this.Type = type;
            this.Status = status;
            this.CreatedDate = createdDate;
        }

        /// <summary>
        /// A report ID
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// A unique identifier that will be consistent across all reports created for the same customer
        /// </summary>
        [JsonProperty("portfolioId")]
        public string PortfolioId { get; set; }

        /// <summary>
        /// A report type. Possible values:
        ///   * "voi"
        ///   * "voa"
        ///   * "voaHistory"
        ///   * "history"
        ///   * "voieTxVerify"
        ///   * "voieWithReport"
        ///   * "voieWithInterview"
        ///   * "paystatement"
        ///   * "preQualVoa"
        ///   * "assetSummary"
        ///   * "voie"
        ///   * "transactions"
        ///   * "statement"
        ///   * "voiePayroll"
        ///   * "voeTransactions"
        ///   * "voePayroll"
        ///   * "cfrp"
        ///   * "cfrb"
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// A report generation status. Possible values: "inProgress", "success", "failure".
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate")]
        public long CreatedDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PortfolioReport : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PortfolioReport other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.PortfolioId == null && other.PortfolioId == null) || (this.PortfolioId?.Equals(other.PortfolioId) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                this.CreatedDate.Equals(other.CreatedDate);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.PortfolioId = {(this.PortfolioId == null ? "null" : this.PortfolioId == string.Empty ? "" : this.PortfolioId)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.CreatedDate = {this.CreatedDate}");
        }
    }
}