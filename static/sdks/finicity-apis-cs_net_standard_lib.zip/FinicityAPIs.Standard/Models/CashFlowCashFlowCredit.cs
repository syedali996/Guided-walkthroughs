// <copyright file="CashFlowCashFlowCredit.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowCashFlowCredit.
    /// </summary>
    public class CashFlowCashFlowCredit
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCredit"/> class.
        /// </summary>
        public CashFlowCashFlowCredit()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCredit"/> class.
        /// </summary>
        /// <param name="monthlyCashFlowCredits">monthlyCashFlowCredits.</param>
        /// <param name="twelveMonthCreditTotal">twelveMonthCreditTotal.</param>
        /// <param name="twelveMonthCreditTotalLessTransfers">twelveMonthCreditTotalLessTransfers.</param>
        /// <param name="sixMonthCreditTotal">sixMonthCreditTotal.</param>
        /// <param name="sixMonthCreditTotalLessTransfers">sixMonthCreditTotalLessTransfers.</param>
        /// <param name="twoMonthCreditTotal">twoMonthCreditTotal.</param>
        /// <param name="twoMonthCreditTotalLessTransfers">twoMonthCreditTotalLessTransfers.</param>
        public CashFlowCashFlowCredit(
            List<Models.CashFlowMonthlyCashFlowCredits> monthlyCashFlowCredits,
            double twelveMonthCreditTotal,
            double twelveMonthCreditTotalLessTransfers,
            double sixMonthCreditTotal,
            double sixMonthCreditTotalLessTransfers,
            double twoMonthCreditTotal,
            double twoMonthCreditTotalLessTransfers)
        {
            this.MonthlyCashFlowCredits = monthlyCashFlowCredits;
            this.TwelveMonthCreditTotal = twelveMonthCreditTotal;
            this.TwelveMonthCreditTotalLessTransfers = twelveMonthCreditTotalLessTransfers;
            this.SixMonthCreditTotal = sixMonthCreditTotal;
            this.SixMonthCreditTotalLessTransfers = sixMonthCreditTotalLessTransfers;
            this.TwoMonthCreditTotal = twoMonthCreditTotal;
            this.TwoMonthCreditTotalLessTransfers = twoMonthCreditTotalLessTransfers;
        }

        /// <summary>
        /// List of attributes for each month
        /// </summary>
        [JsonProperty("monthlyCashFlowCredits")]
        public List<Models.CashFlowMonthlyCashFlowCredits> MonthlyCashFlowCredits { get; set; }

        /// <summary>
        /// Sum of all credit transactions for each month by account
        /// </summary>
        [JsonProperty("twelveMonthCreditTotal")]
        public double TwelveMonthCreditTotal { get; set; }

        /// <summary>
        /// Sum of all monthly credit transactions without transfers for the account
        /// </summary>
        [JsonProperty("twelveMonthCreditTotalLessTransfers")]
        public double TwelveMonthCreditTotalLessTransfers { get; set; }

        /// <summary>
        /// Sum of six month credit transactions
        /// </summary>
        [JsonProperty("sixMonthCreditTotal")]
        public double SixMonthCreditTotal { get; set; }

        /// <summary>
        /// Sum of six month credit transactions without transfers
        /// </summary>
        [JsonProperty("sixMonthCreditTotalLessTransfers")]
        public double SixMonthCreditTotalLessTransfers { get; set; }

        /// <summary>
        /// Sum of two month credit transactions
        /// </summary>
        [JsonProperty("twoMonthCreditTotal")]
        public double TwoMonthCreditTotal { get; set; }

        /// <summary>
        /// Sum of two month credit transactions without transfers
        /// </summary>
        [JsonProperty("twoMonthCreditTotalLessTransfers")]
        public double TwoMonthCreditTotalLessTransfers { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowCashFlowCredit : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowCashFlowCredit other &&
                ((this.MonthlyCashFlowCredits == null && other.MonthlyCashFlowCredits == null) || (this.MonthlyCashFlowCredits?.Equals(other.MonthlyCashFlowCredits) == true)) &&
                this.TwelveMonthCreditTotal.Equals(other.TwelveMonthCreditTotal) &&
                this.TwelveMonthCreditTotalLessTransfers.Equals(other.TwelveMonthCreditTotalLessTransfers) &&
                this.SixMonthCreditTotal.Equals(other.SixMonthCreditTotal) &&
                this.SixMonthCreditTotalLessTransfers.Equals(other.SixMonthCreditTotalLessTransfers) &&
                this.TwoMonthCreditTotal.Equals(other.TwoMonthCreditTotal) &&
                this.TwoMonthCreditTotalLessTransfers.Equals(other.TwoMonthCreditTotalLessTransfers);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MonthlyCashFlowCredits = {(this.MonthlyCashFlowCredits == null ? "null" : $"[{string.Join(", ", this.MonthlyCashFlowCredits)} ]")}");
            toStringOutput.Add($"this.TwelveMonthCreditTotal = {this.TwelveMonthCreditTotal}");
            toStringOutput.Add($"this.TwelveMonthCreditTotalLessTransfers = {this.TwelveMonthCreditTotalLessTransfers}");
            toStringOutput.Add($"this.SixMonthCreditTotal = {this.SixMonthCreditTotal}");
            toStringOutput.Add($"this.SixMonthCreditTotalLessTransfers = {this.SixMonthCreditTotalLessTransfers}");
            toStringOutput.Add($"this.TwoMonthCreditTotal = {this.TwoMonthCreditTotal}");
            toStringOutput.Add($"this.TwoMonthCreditTotalLessTransfers = {this.TwoMonthCreditTotalLessTransfers}");
        }
    }
}