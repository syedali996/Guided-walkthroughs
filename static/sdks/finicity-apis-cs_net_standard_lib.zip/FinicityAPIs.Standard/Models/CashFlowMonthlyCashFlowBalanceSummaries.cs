// <copyright file="CashFlowMonthlyCashFlowBalanceSummaries.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowMonthlyCashFlowBalanceSummaries.
    /// </summary>
    public class CashFlowMonthlyCashFlowBalanceSummaries
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowBalanceSummaries"/> class.
        /// </summary>
        public CashFlowMonthlyCashFlowBalanceSummaries()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowBalanceSummaries"/> class.
        /// </summary>
        /// <param name="month">month.</param>
        /// <param name="minDailyBalance">minDailyBalance.</param>
        /// <param name="maxDailyBalance">maxDailyBalance.</param>
        /// <param name="averageDailyBalance">averageDailyBalance.</param>
        /// <param name="standardDeviationOfDailyBalance">standardDeviationOfDailyBalance.</param>
        /// <param name="numberOfDaysNegativeBalance">numberOfDaysNegativeBalance.</param>
        /// <param name="numberOfDaysPositiveBalance">numberOfDaysPositiveBalance.</param>
        public CashFlowMonthlyCashFlowBalanceSummaries(
            long month,
            double minDailyBalance,
            double maxDailyBalance,
            double averageDailyBalance,
            string standardDeviationOfDailyBalance,
            string numberOfDaysNegativeBalance,
            string numberOfDaysPositiveBalance)
        {
            this.Month = month;
            this.MinDailyBalance = minDailyBalance;
            this.MaxDailyBalance = maxDailyBalance;
            this.AverageDailyBalance = averageDailyBalance;
            this.StandardDeviationOfDailyBalance = standardDeviationOfDailyBalance;
            this.NumberOfDaysNegativeBalance = numberOfDaysNegativeBalance;
            this.NumberOfDaysPositiveBalance = numberOfDaysPositiveBalance;
        }

        /// <summary>
        /// One instance for each complete calendar month in the report
        /// </summary>
        [JsonProperty("month")]
        public long Month { get; set; }

        /// <summary>
        /// Min Daily Balance for each month for all accounts
        /// </summary>
        [JsonProperty("minDailyBalance")]
        public double MinDailyBalance { get; set; }

        /// <summary>
        /// Max Daily Balance for each month for all accounts
        /// </summary>
        [JsonProperty("maxDailyBalance")]
        public double MaxDailyBalance { get; set; }

        /// <summary>
        /// Average Daily Balance for each month for all accounts
        /// </summary>
        [JsonProperty("averageDailyBalance")]
        public double AverageDailyBalance { get; set; }

        /// <summary>
        /// Standard Deviation of Daily Balance for each month for all accounts
        /// </summary>
        [JsonProperty("standardDeviationOfDailyBalance")]
        public string StandardDeviationOfDailyBalance { get; set; }

        /// <summary>
        /// Number of Days Negative Balance for each month for all accounts
        /// </summary>
        [JsonProperty("numberOfDaysNegativeBalance")]
        public string NumberOfDaysNegativeBalance { get; set; }

        /// <summary>
        /// Number of Days Positive Balance for each month for all accounts
        /// </summary>
        [JsonProperty("numberOfDaysPositiveBalance")]
        public string NumberOfDaysPositiveBalance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowMonthlyCashFlowBalanceSummaries : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowMonthlyCashFlowBalanceSummaries other &&
                this.Month.Equals(other.Month) &&
                this.MinDailyBalance.Equals(other.MinDailyBalance) &&
                this.MaxDailyBalance.Equals(other.MaxDailyBalance) &&
                this.AverageDailyBalance.Equals(other.AverageDailyBalance) &&
                ((this.StandardDeviationOfDailyBalance == null && other.StandardDeviationOfDailyBalance == null) || (this.StandardDeviationOfDailyBalance?.Equals(other.StandardDeviationOfDailyBalance) == true)) &&
                ((this.NumberOfDaysNegativeBalance == null && other.NumberOfDaysNegativeBalance == null) || (this.NumberOfDaysNegativeBalance?.Equals(other.NumberOfDaysNegativeBalance) == true)) &&
                ((this.NumberOfDaysPositiveBalance == null && other.NumberOfDaysPositiveBalance == null) || (this.NumberOfDaysPositiveBalance?.Equals(other.NumberOfDaysPositiveBalance) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Month = {this.Month}");
            toStringOutput.Add($"this.MinDailyBalance = {this.MinDailyBalance}");
            toStringOutput.Add($"this.MaxDailyBalance = {this.MaxDailyBalance}");
            toStringOutput.Add($"this.AverageDailyBalance = {this.AverageDailyBalance}");
            toStringOutput.Add($"this.StandardDeviationOfDailyBalance = {(this.StandardDeviationOfDailyBalance == null ? "null" : this.StandardDeviationOfDailyBalance == string.Empty ? "" : this.StandardDeviationOfDailyBalance)}");
            toStringOutput.Add($"this.NumberOfDaysNegativeBalance = {(this.NumberOfDaysNegativeBalance == null ? "null" : this.NumberOfDaysNegativeBalance == string.Empty ? "" : this.NumberOfDaysNegativeBalance)}");
            toStringOutput.Add($"this.NumberOfDaysPositiveBalance = {(this.NumberOfDaysPositiveBalance == null ? "null" : this.NumberOfDaysPositiveBalance == string.Empty ? "" : this.NumberOfDaysPositiveBalance)}");
        }
    }
}