// <copyright file="PaystubMonthlyIncomeRecord.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PaystubMonthlyIncomeRecord.
    /// </summary>
    public class PaystubMonthlyIncomeRecord
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaystubMonthlyIncomeRecord"/> class.
        /// </summary>
        public PaystubMonthlyIncomeRecord()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaystubMonthlyIncomeRecord"/> class.
        /// </summary>
        /// <param name="estimatedMonthlyBasePay">estimatedMonthlyBasePay.</param>
        /// <param name="estimatedMonthlyOvertimePay">estimatedMonthlyOvertimePay.</param>
        /// <param name="estimatedMonthlyBonusPay">estimatedMonthlyBonusPay.</param>
        /// <param name="estimatedMonthlyCommissionPay">estimatedMonthlyCommissionPay.</param>
        public PaystubMonthlyIncomeRecord(
            double? estimatedMonthlyBasePay = null,
            double? estimatedMonthlyOvertimePay = null,
            double? estimatedMonthlyBonusPay = null,
            double? estimatedMonthlyCommissionPay = null)
        {
            this.EstimatedMonthlyBasePay = estimatedMonthlyBasePay;
            this.EstimatedMonthlyOvertimePay = estimatedMonthlyOvertimePay;
            this.EstimatedMonthlyBonusPay = estimatedMonthlyBonusPay;
            this.EstimatedMonthlyCommissionPay = estimatedMonthlyCommissionPay;
        }

        /// <summary>
        /// The estimated monthly base pay amount for the employment from the paystub, calculated by Finicity
        /// </summary>
        [JsonProperty("estimatedMonthlyBasePay", NullValueHandling = NullValueHandling.Ignore)]
        public double? EstimatedMonthlyBasePay { get; set; }

        /// <summary>
        /// The estimated monthly overtime pay amount for the employment from the paystub, calculated by Finicity
        /// </summary>
        [JsonProperty("estimatedMonthlyOvertimePay", NullValueHandling = NullValueHandling.Ignore)]
        public double? EstimatedMonthlyOvertimePay { get; set; }

        /// <summary>
        /// The estimated monthly bonus pay amount for the employment from the paystub, calculated by Finicity
        /// </summary>
        [JsonProperty("estimatedMonthlyBonusPay", NullValueHandling = NullValueHandling.Ignore)]
        public double? EstimatedMonthlyBonusPay { get; set; }

        /// <summary>
        /// The estimated commission bonus pay amount for the employment from the paystub, calculated by Finicity
        /// </summary>
        [JsonProperty("estimatedMonthlyCommissionPay", NullValueHandling = NullValueHandling.Ignore)]
        public double? EstimatedMonthlyCommissionPay { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PaystubMonthlyIncomeRecord : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PaystubMonthlyIncomeRecord other &&
                ((this.EstimatedMonthlyBasePay == null && other.EstimatedMonthlyBasePay == null) || (this.EstimatedMonthlyBasePay?.Equals(other.EstimatedMonthlyBasePay) == true)) &&
                ((this.EstimatedMonthlyOvertimePay == null && other.EstimatedMonthlyOvertimePay == null) || (this.EstimatedMonthlyOvertimePay?.Equals(other.EstimatedMonthlyOvertimePay) == true)) &&
                ((this.EstimatedMonthlyBonusPay == null && other.EstimatedMonthlyBonusPay == null) || (this.EstimatedMonthlyBonusPay?.Equals(other.EstimatedMonthlyBonusPay) == true)) &&
                ((this.EstimatedMonthlyCommissionPay == null && other.EstimatedMonthlyCommissionPay == null) || (this.EstimatedMonthlyCommissionPay?.Equals(other.EstimatedMonthlyCommissionPay) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EstimatedMonthlyBasePay = {(this.EstimatedMonthlyBasePay == null ? "null" : this.EstimatedMonthlyBasePay.ToString())}");
            toStringOutput.Add($"this.EstimatedMonthlyOvertimePay = {(this.EstimatedMonthlyOvertimePay == null ? "null" : this.EstimatedMonthlyOvertimePay.ToString())}");
            toStringOutput.Add($"this.EstimatedMonthlyBonusPay = {(this.EstimatedMonthlyBonusPay == null ? "null" : this.EstimatedMonthlyBonusPay.ToString())}");
            toStringOutput.Add($"this.EstimatedMonthlyCommissionPay = {(this.EstimatedMonthlyCommissionPay == null ? "null" : this.EstimatedMonthlyCommissionPay.ToString())}");
        }
    }
}