// <copyright file="CashFlowInsufficientFundsFees.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowInsufficientFundsFees.
    /// </summary>
    public class CashFlowInsufficientFundsFees
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowInsufficientFundsFees"/> class.
        /// </summary>
        public CashFlowInsufficientFundsFees()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowInsufficientFundsFees"/> class.
        /// </summary>
        /// <param name="countOfTransactionsForTheReportTimePeriod">countOfTransactionsForTheReportTimePeriod.</param>
        /// <param name="sumOfTransactionsForTheReportTimePeriod">sumOfTransactionsForTheReportTimePeriod.</param>
        /// <param name="transactions">transactions.</param>
        public CashFlowInsufficientFundsFees(
            int? countOfTransactionsForTheReportTimePeriod = null,
            double? sumOfTransactionsForTheReportTimePeriod = null,
            List<Models.InsufficientFundsTransaction> transactions = null)
        {
            this.CountOfTransactionsForTheReportTimePeriod = countOfTransactionsForTheReportTimePeriod;
            this.SumOfTransactionsForTheReportTimePeriod = sumOfTransactionsForTheReportTimePeriod;
            this.Transactions = transactions;
        }

        /// <summary>
        /// Count of all NSF transactions during the report
        /// </summary>
        [JsonProperty("countOfTransactionsForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public int? CountOfTransactionsForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Sum of all NSF transactions during the report
        /// </summary>
        [JsonProperty("sumOfTransactionsForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? SumOfTransactionsForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Transactions categorized as NSF
        /// </summary>
        [JsonProperty("transactions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.InsufficientFundsTransaction> Transactions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowInsufficientFundsFees : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowInsufficientFundsFees other &&
                ((this.CountOfTransactionsForTheReportTimePeriod == null && other.CountOfTransactionsForTheReportTimePeriod == null) || (this.CountOfTransactionsForTheReportTimePeriod?.Equals(other.CountOfTransactionsForTheReportTimePeriod) == true)) &&
                ((this.SumOfTransactionsForTheReportTimePeriod == null && other.SumOfTransactionsForTheReportTimePeriod == null) || (this.SumOfTransactionsForTheReportTimePeriod?.Equals(other.SumOfTransactionsForTheReportTimePeriod) == true)) &&
                ((this.Transactions == null && other.Transactions == null) || (this.Transactions?.Equals(other.Transactions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CountOfTransactionsForTheReportTimePeriod = {(this.CountOfTransactionsForTheReportTimePeriod == null ? "null" : this.CountOfTransactionsForTheReportTimePeriod.ToString())}");
            toStringOutput.Add($"this.SumOfTransactionsForTheReportTimePeriod = {(this.SumOfTransactionsForTheReportTimePeriod == null ? "null" : this.SumOfTransactionsForTheReportTimePeriod.ToString())}");
            toStringOutput.Add($"this.Transactions = {(this.Transactions == null ? "null" : $"[{string.Join(", ", this.Transactions)} ]")}");
        }
    }
}