// <copyright file="BalanceAnalyticsAccountResult1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BalanceAnalyticsAccountResult1.
    /// </summary>
    public class BalanceAnalyticsAccountResult1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAnalyticsAccountResult1"/> class.
        /// </summary>
        public BalanceAnalyticsAccountResult1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAnalyticsAccountResult1"/> class.
        /// </summary>
        /// <param name="accountDetails">accountDetails.</param>
        /// <param name="accountId">accountId.</param>
        /// <param name="currentReportRequest">currentReportRequest.</param>
        /// <param name="historicDataAvailability">historicDataAvailability.</param>
        /// <param name="balanceAnalyticsMetrics">balanceAnalyticsMetrics.</param>
        /// <param name="cashflowAnalyticsMetrics">cashflowAnalyticsMetrics.</param>
        public BalanceAnalyticsAccountResult1(
            Models.AccountDetails1 accountDetails,
            long accountId,
            Models.ObbCurrentReportRequestDetails currentReportRequest,
            Models.ObbDataAvailability historicDataAvailability,
            Models.BalanceAnalyticsMetrics balanceAnalyticsMetrics = null,
            Models.CashFlowAnalyticsMetrics cashflowAnalyticsMetrics = null)
        {
            this.AccountDetails = accountDetails;
            this.AccountId = accountId;
            this.BalanceAnalyticsMetrics = balanceAnalyticsMetrics;
            this.CurrentReportRequest = currentReportRequest;
            this.HistoricDataAvailability = historicDataAvailability;
            this.CashflowAnalyticsMetrics = cashflowAnalyticsMetrics;
        }

        /// <summary>
        /// Gets or sets AccountDetails.
        /// </summary>
        [JsonProperty("accountDetails")]
        public Models.AccountDetails1 AccountDetails { get; set; }

        /// <summary>
        /// An account ID represented as a number
        /// </summary>
        [JsonProperty("accountId")]
        public long AccountId { get; set; }

        /// <summary>
        /// Balance analytics metrics and calculations
        /// </summary>
        [JsonProperty("balanceAnalyticsMetrics", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BalanceAnalyticsMetrics BalanceAnalyticsMetrics { get; set; }

        /// <summary>
        /// Gets or sets CurrentReportRequest.
        /// </summary>
        [JsonProperty("currentReportRequest")]
        public Models.ObbCurrentReportRequestDetails CurrentReportRequest { get; set; }

        /// <summary>
        /// Gets or sets HistoricDataAvailability.
        /// </summary>
        [JsonProperty("historicDataAvailability")]
        public Models.ObbDataAvailability HistoricDataAvailability { get; set; }

        /// <summary>
        /// Generated cashflow calculations/metrics
        /// </summary>
        [JsonProperty("cashflowAnalyticsMetrics", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowAnalyticsMetrics CashflowAnalyticsMetrics { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BalanceAnalyticsAccountResult1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BalanceAnalyticsAccountResult1 other &&
                ((this.AccountDetails == null && other.AccountDetails == null) || (this.AccountDetails?.Equals(other.AccountDetails) == true)) &&
                this.AccountId.Equals(other.AccountId) &&
                ((this.BalanceAnalyticsMetrics == null && other.BalanceAnalyticsMetrics == null) || (this.BalanceAnalyticsMetrics?.Equals(other.BalanceAnalyticsMetrics) == true)) &&
                ((this.CurrentReportRequest == null && other.CurrentReportRequest == null) || (this.CurrentReportRequest?.Equals(other.CurrentReportRequest) == true)) &&
                ((this.HistoricDataAvailability == null && other.HistoricDataAvailability == null) || (this.HistoricDataAvailability?.Equals(other.HistoricDataAvailability) == true)) &&
                ((this.CashflowAnalyticsMetrics == null && other.CashflowAnalyticsMetrics == null) || (this.CashflowAnalyticsMetrics?.Equals(other.CashflowAnalyticsMetrics) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountDetails = {(this.AccountDetails == null ? "null" : this.AccountDetails.ToString())}");
            toStringOutput.Add($"this.AccountId = {this.AccountId}");
            toStringOutput.Add($"this.BalanceAnalyticsMetrics = {(this.BalanceAnalyticsMetrics == null ? "null" : this.BalanceAnalyticsMetrics.ToString())}");
            toStringOutput.Add($"this.CurrentReportRequest = {(this.CurrentReportRequest == null ? "null" : this.CurrentReportRequest.ToString())}");
            toStringOutput.Add($"this.HistoricDataAvailability = {(this.HistoricDataAvailability == null ? "null" : this.HistoricDataAvailability.ToString())}");
            toStringOutput.Add($"this.CashflowAnalyticsMetrics = {(this.CashflowAnalyticsMetrics == null ? "null" : this.CashflowAnalyticsMetrics.ToString())}");
        }
    }
}