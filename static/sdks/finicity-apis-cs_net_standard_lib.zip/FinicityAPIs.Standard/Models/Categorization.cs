// <copyright file="Categorization.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Categorization.
    /// </summary>
    public class Categorization
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Categorization"/> class.
        /// </summary>
        public Categorization()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Categorization"/> class.
        /// </summary>
        /// <param name="normalizedPayeeName">normalizedPayeeName.</param>
        /// <param name="category">category.</param>
        /// <param name="country">country.</param>
        /// <param name="city">city.</param>
        /// <param name="state">state.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="bestRepresentation">bestRepresentation.</param>
        public Categorization(
            string normalizedPayeeName,
            string category,
            string country,
            string city = null,
            string state = null,
            string postalCode = null,
            string bestRepresentation = null)
        {
            this.NormalizedPayeeName = normalizedPayeeName;
            this.Category = category;
            this.City = city;
            this.State = state;
            this.PostalCode = postalCode;
            this.Country = country;
            this.BestRepresentation = bestRepresentation;
        }

        /// <summary>
        /// A normalized payee, derived from the transaction's description and memo fields
        /// </summary>
        [JsonProperty("normalizedPayeeName")]
        public string NormalizedPayeeName { get; set; }

        /// <summary>
        /// The different categories for transactions.
        /// * "ATM Fee"
        /// * "Advertising"
        /// * "Air Travel"
        /// * "Alcohol & Bars"
        /// * "Allowance"
        /// * "Amusement"
        /// * "Arts"
        /// * "Auto & Transport"
        /// * "Auto Insurance"
        /// * "Auto Payment"
        /// * "Baby Supplies"
        /// * "Babysitter & Daycare"
        /// * "Bank Fee"
        /// * "Bills & Utilities"
        /// * "Bonus"
        /// * "Books"
        /// * "Books & Supplies"
        /// * "Business Services"
        /// * "Buy"
        /// * "Cash & ATM"
        /// * "Charity"
        /// * "Check"
        /// * "Child Support"
        /// * "Clothing"
        /// * "Coffee Shops"
        /// * "Credit Card Payment"
        /// * "Dentist"
        /// * "Deposit"
        /// * "Dividend & Cap Gains"
        /// * "Doctor"
        /// * "Education"
        /// * "Electronics & Software"
        /// * "Entertainment"
        /// * "Eyecare"
        /// * "Fast Food"
        /// * "Federal Tax"
        /// * "Fees & Charges"
        /// * "Finance Charge"
        /// * "Financial"
        /// * "Financial Advisor"
        /// * "Food & Dining"
        /// * "Furnishings"
        /// * "Gas & Fuel"
        /// * "Gift"
        /// * "Gifts & Donations"
        /// * "Groceries"
        /// * "Gym"
        /// * "Hair"
        /// * "Health & Fitness"
        /// * "Health Insurance"
        /// * "Hobbies"
        /// * "Home"
        /// * "Home Improvement"
        /// * "Home Insurance"
        /// * "Home Phone"
        /// * "Home Services"
        /// * "Home Supplies"
        /// * "Hotel"
        /// * "Income"
        /// * "Interest Income"
        /// * "Internet"
        /// * "Investments"
        /// * "Kids"
        /// * "Kids Activities"
        /// * "Late Fee"
        /// * "Laundry"
        /// * "Lawn & Garden"
        /// * "Legal"
        /// * "Life Insurance"
        /// * "Loan Fees and Charges"
        /// * "Loan Insurance"
        /// * "Loan Interest"
        /// * "Loan Payment"
        /// * "Loan Principal"
        /// * "Loans"
        /// * "Local Tax"
        /// * "Low Balance"
        /// * "Mobile Phone"
        /// * "Mortgage & Rent"
        /// * "Movies & DVDs"
        /// * "Music"
        /// * "Newspapers & Magazines"
        /// * "Office Supplies"
        /// * "Parking"
        /// * "Paycheck"
        /// * "Personal Care"
        /// * "Pet Food & Supplies"
        /// * "Pet Grooming"
        /// * "Pets"
        /// * "Pharmacy"
        /// * "Printing"
        /// * "Property Tax"
        /// * "Public Transportation"
        /// * "Reimbursement"
        /// * "Rental Car & Taxi"
        /// * "Restaurants"
        /// * "Sales Tax"
        /// * "Sell"
        /// * "Services & Parts"
        /// * "Service Fee"
        /// * "Shipping"
        /// * "Shopping"
        /// * "Spa & Massage"
        /// * "Sporting Goods"
        /// * "Sports"
        /// * "State Tax"
        /// * "Streaming Services"
        /// * "Student Loan"
        /// * "Taxes"
        /// * "Television"
        /// * "Toys"
        /// * "Trade Commissions"
        /// * "Transfer"
        /// * "Transfer for Cash Spending"
        /// * "Travel"
        /// * "Tuition"
        /// * "Uncategorized"
        /// * "Utilities"
        /// * "Vacation"
        /// * "Veterinary"
        /// * "Internet / Broadband Charges"
        /// </summary>
        [JsonProperty("category")]
        public string Category { get; set; }

        /// <summary>
        /// A city
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// A state
        /// </summary>
        [JsonProperty("state", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// A ZIP code
        /// </summary>
        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// A country code
        /// </summary>
        [JsonProperty("country")]
        public string Country { get; set; }

        /// <summary>
        /// Combines the `description` and `memo` data together, removing duplicated information and numbers and special characters
        /// </summary>
        [JsonProperty("bestRepresentation", NullValueHandling = NullValueHandling.Ignore)]
        public string BestRepresentation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Categorization : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Categorization other &&
                ((this.NormalizedPayeeName == null && other.NormalizedPayeeName == null) || (this.NormalizedPayeeName?.Equals(other.NormalizedPayeeName) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.BestRepresentation == null && other.BestRepresentation == null) || (this.BestRepresentation?.Equals(other.BestRepresentation) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.NormalizedPayeeName = {(this.NormalizedPayeeName == null ? "null" : this.NormalizedPayeeName == string.Empty ? "" : this.NormalizedPayeeName)}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category == string.Empty ? "" : this.Category)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.BestRepresentation = {(this.BestRepresentation == null ? "null" : this.BestRepresentation == string.Empty ? "" : this.BestRepresentation)}");
        }
    }
}