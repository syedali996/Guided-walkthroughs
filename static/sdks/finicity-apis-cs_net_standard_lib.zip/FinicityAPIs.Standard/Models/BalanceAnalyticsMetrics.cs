// <copyright file="BalanceAnalyticsMetrics.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BalanceAnalyticsMetrics.
    /// </summary>
    public class BalanceAnalyticsMetrics
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAnalyticsMetrics"/> class.
        /// </summary>
        public BalanceAnalyticsMetrics()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAnalyticsMetrics"/> class.
        /// </summary>
        /// <param name="availableBalance">availableBalance.</param>
        /// <param name="availableBalanceDate">availableBalanceDate.</param>
        /// <param name="averageDailyBalanceByMonthForTheReportTimePeriod">averageDailyBalanceByMonthForTheReportTimePeriod.</param>
        /// <param name="averageDailyBalanceForTheReportTimePeriod">averageDailyBalanceForTheReportTimePeriod.</param>
        /// <param name="averageWeekdayBalanceForTheReportTimePeriod">averageWeekdayBalanceForTheReportTimePeriod.</param>
        /// <param name="countDailyNegativeBalancesByMonthForTheReportTimePeriod">countDailyNegativeBalancesByMonthForTheReportTimePeriod.</param>
        /// <param name="currentRunningBalance">currentRunningBalance.</param>
        /// <param name="currentRunningBalanceDate">currentRunningBalanceDate.</param>
        /// <param name="dailyBalancesByWeekdayForTheReportTimePeriod">dailyBalancesByWeekdayForTheReportTimePeriod.</param>
        /// <param name="dailyBalancesForTheReportTimePeriod">dailyBalancesForTheReportTimePeriod.</param>
        /// <param name="historicNumberOfWeeksAverageBalanceIncreasing">historicNumberOfWeeksAverageBalanceIncreasing.</param>
        /// <param name="maximumDailyBalanceByMonthForTheReportTimePeriod">maximumDailyBalanceByMonthForTheReportTimePeriod.</param>
        /// <param name="maximumRunningBalanceForTheReportTimePeriod">maximumRunningBalanceForTheReportTimePeriod.</param>
        /// <param name="minimumDailyBalanceByMonthForTheReportTimePeriod">minimumDailyBalanceByMonthForTheReportTimePeriod.</param>
        /// <param name="minimumRunningBalanceForTheReportTimePeriod">minimumRunningBalanceForTheReportTimePeriod.</param>
        public BalanceAnalyticsMetrics(
            double? availableBalance = null,
            string availableBalanceDate = null,
            List<Models.ObbDateRangeAndAmount> averageDailyBalanceByMonthForTheReportTimePeriod = null,
            double? averageDailyBalanceForTheReportTimePeriod = null,
            double? averageWeekdayBalanceForTheReportTimePeriod = null,
            List<Models.ObbDateRangeAndCount> countDailyNegativeBalancesByMonthForTheReportTimePeriod = null,
            double? currentRunningBalance = null,
            string currentRunningBalanceDate = null,
            List<Models.ObbDailyBalance> dailyBalancesByWeekdayForTheReportTimePeriod = null,
            List<Models.ObbDailyBalance> dailyBalancesForTheReportTimePeriod = null,
            Models.ObbNumWeeksAverageBalanceIncreasing historicNumberOfWeeksAverageBalanceIncreasing = null,
            List<Models.ObbDateRangeAndAmount> maximumDailyBalanceByMonthForTheReportTimePeriod = null,
            double? maximumRunningBalanceForTheReportTimePeriod = null,
            List<Models.ObbDateRangeAndAmount> minimumDailyBalanceByMonthForTheReportTimePeriod = null,
            double? minimumRunningBalanceForTheReportTimePeriod = null)
        {
            this.AvailableBalance = availableBalance;
            this.AvailableBalanceDate = availableBalanceDate;
            this.AverageDailyBalanceByMonthForTheReportTimePeriod = averageDailyBalanceByMonthForTheReportTimePeriod;
            this.AverageDailyBalanceForTheReportTimePeriod = averageDailyBalanceForTheReportTimePeriod;
            this.AverageWeekdayBalanceForTheReportTimePeriod = averageWeekdayBalanceForTheReportTimePeriod;
            this.CountDailyNegativeBalancesByMonthForTheReportTimePeriod = countDailyNegativeBalancesByMonthForTheReportTimePeriod;
            this.CurrentRunningBalance = currentRunningBalance;
            this.CurrentRunningBalanceDate = currentRunningBalanceDate;
            this.DailyBalancesByWeekdayForTheReportTimePeriod = dailyBalancesByWeekdayForTheReportTimePeriod;
            this.DailyBalancesForTheReportTimePeriod = dailyBalancesForTheReportTimePeriod;
            this.HistoricNumberOfWeeksAverageBalanceIncreasing = historicNumberOfWeeksAverageBalanceIncreasing;
            this.MaximumDailyBalanceByMonthForTheReportTimePeriod = maximumDailyBalanceByMonthForTheReportTimePeriod;
            this.MaximumRunningBalanceForTheReportTimePeriod = maximumRunningBalanceForTheReportTimePeriod;
            this.MinimumDailyBalanceByMonthForTheReportTimePeriod = minimumDailyBalanceByMonthForTheReportTimePeriod;
            this.MinimumRunningBalanceForTheReportTimePeriod = minimumRunningBalanceForTheReportTimePeriod;
        }

        /// <summary>
        /// Available Balance
        /// </summary>
        [JsonProperty("availableBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AvailableBalance { get; set; }

        /// <summary>
        /// Available Balance date
        /// </summary>
        [JsonProperty("availableBalanceDate", NullValueHandling = NullValueHandling.Ignore)]
        public string AvailableBalanceDate { get; set; }

        /// <summary>
        /// Average daily ending balance each month over the report time period
        /// </summary>
        [JsonProperty("averageDailyBalanceByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> AverageDailyBalanceByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Average Daily Balance
        /// </summary>
        [JsonProperty("averageDailyBalanceForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? AverageDailyBalanceForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Average Weekday Balance
        /// </summary>
        [JsonProperty("averageWeekdayBalanceForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? AverageWeekdayBalanceForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Number of negative daily ending balances each month over the report time period
        /// </summary>
        [JsonProperty("countDailyNegativeBalancesByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndCount> CountDailyNegativeBalancesByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Current Running Balance Date
        /// </summary>
        [JsonProperty("currentRunningBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentRunningBalance { get; set; }

        /// <summary>
        /// Current Running Balance date
        /// </summary>
        [JsonProperty("currentRunningBalanceDate", NullValueHandling = NullValueHandling.Ignore)]
        public string CurrentRunningBalanceDate { get; set; }

        /// <summary>
        /// Daily balance of the account during weekdays over the length of the report
        /// </summary>
        [JsonProperty("dailyBalancesByWeekdayForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDailyBalance> DailyBalancesByWeekdayForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Daily balance of the account over the length of the report
        /// </summary>
        [JsonProperty("dailyBalancesForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDailyBalance> DailyBalancesForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Report of average account balance week over week and count of weeks where the average balance increased
        /// </summary>
        [JsonProperty("historicNumberOfWeeksAverageBalanceIncreasing", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ObbNumWeeksAverageBalanceIncreasing HistoricNumberOfWeeksAverageBalanceIncreasing { get; set; }

        /// <summary>
        /// Maximum daily ending balance each month over the report time period
        /// </summary>
        [JsonProperty("maximumDailyBalanceByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> MaximumDailyBalanceByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Maximum Running Balance
        /// </summary>
        [JsonProperty("maximumRunningBalanceForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? MaximumRunningBalanceForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Minimum daily ending balance each month over the report time period
        /// </summary>
        [JsonProperty("minimumDailyBalanceByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> MinimumDailyBalanceByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Minimum Running Balance
        /// </summary>
        [JsonProperty("minimumRunningBalanceForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? MinimumRunningBalanceForTheReportTimePeriod { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BalanceAnalyticsMetrics : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BalanceAnalyticsMetrics other &&
                ((this.AvailableBalance == null && other.AvailableBalance == null) || (this.AvailableBalance?.Equals(other.AvailableBalance) == true)) &&
                ((this.AvailableBalanceDate == null && other.AvailableBalanceDate == null) || (this.AvailableBalanceDate?.Equals(other.AvailableBalanceDate) == true)) &&
                ((this.AverageDailyBalanceByMonthForTheReportTimePeriod == null && other.AverageDailyBalanceByMonthForTheReportTimePeriod == null) || (this.AverageDailyBalanceByMonthForTheReportTimePeriod?.Equals(other.AverageDailyBalanceByMonthForTheReportTimePeriod) == true)) &&
                ((this.AverageDailyBalanceForTheReportTimePeriod == null && other.AverageDailyBalanceForTheReportTimePeriod == null) || (this.AverageDailyBalanceForTheReportTimePeriod?.Equals(other.AverageDailyBalanceForTheReportTimePeriod) == true)) &&
                ((this.AverageWeekdayBalanceForTheReportTimePeriod == null && other.AverageWeekdayBalanceForTheReportTimePeriod == null) || (this.AverageWeekdayBalanceForTheReportTimePeriod?.Equals(other.AverageWeekdayBalanceForTheReportTimePeriod) == true)) &&
                ((this.CountDailyNegativeBalancesByMonthForTheReportTimePeriod == null && other.CountDailyNegativeBalancesByMonthForTheReportTimePeriod == null) || (this.CountDailyNegativeBalancesByMonthForTheReportTimePeriod?.Equals(other.CountDailyNegativeBalancesByMonthForTheReportTimePeriod) == true)) &&
                ((this.CurrentRunningBalance == null && other.CurrentRunningBalance == null) || (this.CurrentRunningBalance?.Equals(other.CurrentRunningBalance) == true)) &&
                ((this.CurrentRunningBalanceDate == null && other.CurrentRunningBalanceDate == null) || (this.CurrentRunningBalanceDate?.Equals(other.CurrentRunningBalanceDate) == true)) &&
                ((this.DailyBalancesByWeekdayForTheReportTimePeriod == null && other.DailyBalancesByWeekdayForTheReportTimePeriod == null) || (this.DailyBalancesByWeekdayForTheReportTimePeriod?.Equals(other.DailyBalancesByWeekdayForTheReportTimePeriod) == true)) &&
                ((this.DailyBalancesForTheReportTimePeriod == null && other.DailyBalancesForTheReportTimePeriod == null) || (this.DailyBalancesForTheReportTimePeriod?.Equals(other.DailyBalancesForTheReportTimePeriod) == true)) &&
                ((this.HistoricNumberOfWeeksAverageBalanceIncreasing == null && other.HistoricNumberOfWeeksAverageBalanceIncreasing == null) || (this.HistoricNumberOfWeeksAverageBalanceIncreasing?.Equals(other.HistoricNumberOfWeeksAverageBalanceIncreasing) == true)) &&
                ((this.MaximumDailyBalanceByMonthForTheReportTimePeriod == null && other.MaximumDailyBalanceByMonthForTheReportTimePeriod == null) || (this.MaximumDailyBalanceByMonthForTheReportTimePeriod?.Equals(other.MaximumDailyBalanceByMonthForTheReportTimePeriod) == true)) &&
                ((this.MaximumRunningBalanceForTheReportTimePeriod == null && other.MaximumRunningBalanceForTheReportTimePeriod == null) || (this.MaximumRunningBalanceForTheReportTimePeriod?.Equals(other.MaximumRunningBalanceForTheReportTimePeriod) == true)) &&
                ((this.MinimumDailyBalanceByMonthForTheReportTimePeriod == null && other.MinimumDailyBalanceByMonthForTheReportTimePeriod == null) || (this.MinimumDailyBalanceByMonthForTheReportTimePeriod?.Equals(other.MinimumDailyBalanceByMonthForTheReportTimePeriod) == true)) &&
                ((this.MinimumRunningBalanceForTheReportTimePeriod == null && other.MinimumRunningBalanceForTheReportTimePeriod == null) || (this.MinimumRunningBalanceForTheReportTimePeriod?.Equals(other.MinimumRunningBalanceForTheReportTimePeriod) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AvailableBalance = {(this.AvailableBalance == null ? "null" : this.AvailableBalance.ToString())}");
            toStringOutput.Add($"this.AvailableBalanceDate = {(this.AvailableBalanceDate == null ? "null" : this.AvailableBalanceDate == string.Empty ? "" : this.AvailableBalanceDate)}");
            toStringOutput.Add($"this.AverageDailyBalanceByMonthForTheReportTimePeriod = {(this.AverageDailyBalanceByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.AverageDailyBalanceByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.AverageDailyBalanceForTheReportTimePeriod = {(this.AverageDailyBalanceForTheReportTimePeriod == null ? "null" : this.AverageDailyBalanceForTheReportTimePeriod.ToString())}");
            toStringOutput.Add($"this.AverageWeekdayBalanceForTheReportTimePeriod = {(this.AverageWeekdayBalanceForTheReportTimePeriod == null ? "null" : this.AverageWeekdayBalanceForTheReportTimePeriod.ToString())}");
            toStringOutput.Add($"this.CountDailyNegativeBalancesByMonthForTheReportTimePeriod = {(this.CountDailyNegativeBalancesByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.CountDailyNegativeBalancesByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.CurrentRunningBalance = {(this.CurrentRunningBalance == null ? "null" : this.CurrentRunningBalance.ToString())}");
            toStringOutput.Add($"this.CurrentRunningBalanceDate = {(this.CurrentRunningBalanceDate == null ? "null" : this.CurrentRunningBalanceDate == string.Empty ? "" : this.CurrentRunningBalanceDate)}");
            toStringOutput.Add($"this.DailyBalancesByWeekdayForTheReportTimePeriod = {(this.DailyBalancesByWeekdayForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.DailyBalancesByWeekdayForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.DailyBalancesForTheReportTimePeriod = {(this.DailyBalancesForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.DailyBalancesForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.HistoricNumberOfWeeksAverageBalanceIncreasing = {(this.HistoricNumberOfWeeksAverageBalanceIncreasing == null ? "null" : this.HistoricNumberOfWeeksAverageBalanceIncreasing.ToString())}");
            toStringOutput.Add($"this.MaximumDailyBalanceByMonthForTheReportTimePeriod = {(this.MaximumDailyBalanceByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.MaximumDailyBalanceByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.MaximumRunningBalanceForTheReportTimePeriod = {(this.MaximumRunningBalanceForTheReportTimePeriod == null ? "null" : this.MaximumRunningBalanceForTheReportTimePeriod.ToString())}");
            toStringOutput.Add($"this.MinimumDailyBalanceByMonthForTheReportTimePeriod = {(this.MinimumDailyBalanceByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.MinimumDailyBalanceByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.MinimumRunningBalanceForTheReportTimePeriod = {(this.MinimumRunningBalanceForTheReportTimePeriod == null ? "null" : this.MinimumRunningBalanceForTheReportTimePeriod.ToString())}");
        }
    }
}