// <copyright file="CashFlowCashFlowBalanceSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowCashFlowBalanceSummary.
    /// </summary>
    public class CashFlowCashFlowBalanceSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowBalanceSummary"/> class.
        /// </summary>
        public CashFlowCashFlowBalanceSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowBalanceSummary"/> class.
        /// </summary>
        /// <param name="monthlyCashFlowBalanceSummaries">monthlyCashFlowBalanceSummaries.</param>
        /// <param name="minDailyBalance">minDailyBalance.</param>
        /// <param name="maxDailyBalance">maxDailyBalance.</param>
        /// <param name="twelveMonthAverageDailyBalance">twelveMonthAverageDailyBalance.</param>
        /// <param name="sixMonthAverageDailyBalance">sixMonthAverageDailyBalance.</param>
        /// <param name="twoMonthAverageDailyBalance">twoMonthAverageDailyBalance.</param>
        /// <param name="twelveMonthStandardDeviationOfDailyBalance">twelveMonthStandardDeviationOfDailyBalance.</param>
        /// <param name="sixMonthStandardDeviationOfDailyBalance">sixMonthStandardDeviationOfDailyBalance.</param>
        /// <param name="twoMonthStandardDeviationOfDailyBalance">twoMonthStandardDeviationOfDailyBalance.</param>
        /// <param name="numberOfDaysNegativeBalance">numberOfDaysNegativeBalance.</param>
        /// <param name="numberOfDaysPositiveBalance">numberOfDaysPositiveBalance.</param>
        public CashFlowCashFlowBalanceSummary(
            List<Models.CashFlowMonthlyCashFlowBalanceSummaries> monthlyCashFlowBalanceSummaries,
            double minDailyBalance,
            double maxDailyBalance,
            double twelveMonthAverageDailyBalance,
            double sixMonthAverageDailyBalance,
            double twoMonthAverageDailyBalance,
            string twelveMonthStandardDeviationOfDailyBalance,
            string sixMonthStandardDeviationOfDailyBalance,
            string twoMonthStandardDeviationOfDailyBalance,
            string numberOfDaysNegativeBalance,
            string numberOfDaysPositiveBalance)
        {
            this.MonthlyCashFlowBalanceSummaries = monthlyCashFlowBalanceSummaries;
            this.MinDailyBalance = minDailyBalance;
            this.MaxDailyBalance = maxDailyBalance;
            this.TwelveMonthAverageDailyBalance = twelveMonthAverageDailyBalance;
            this.SixMonthAverageDailyBalance = sixMonthAverageDailyBalance;
            this.TwoMonthAverageDailyBalance = twoMonthAverageDailyBalance;
            this.TwelveMonthStandardDeviationOfDailyBalance = twelveMonthStandardDeviationOfDailyBalance;
            this.SixMonthStandardDeviationOfDailyBalance = sixMonthStandardDeviationOfDailyBalance;
            this.TwoMonthStandardDeviationOfDailyBalance = twoMonthStandardDeviationOfDailyBalance;
            this.NumberOfDaysNegativeBalance = numberOfDaysNegativeBalance;
            this.NumberOfDaysPositiveBalance = numberOfDaysPositiveBalance;
        }

        /// <summary>
        /// List of attributes for each month
        /// </summary>
        [JsonProperty("monthlyCashFlowBalanceSummaries")]
        public List<Models.CashFlowMonthlyCashFlowBalanceSummaries> MonthlyCashFlowBalanceSummaries { get; set; }

        /// <summary>
        /// Min Daily Balance across entire transaction history  for all accounts
        /// </summary>
        [JsonProperty("minDailyBalance")]
        public double MinDailyBalance { get; set; }

        /// <summary>
        /// Max Daily Balance across entire transaction history for all accounts
        /// </summary>
        [JsonProperty("maxDailyBalance")]
        public double MaxDailyBalance { get; set; }

        /// <summary>
        /// Average Daily Balance across twelve months for all accounts
        /// </summary>
        [JsonProperty("twelveMonthAverageDailyBalance")]
        public double TwelveMonthAverageDailyBalance { get; set; }

        /// <summary>
        /// Average Daily Balance across six months for all accounts
        /// </summary>
        [JsonProperty("sixMonthAverageDailyBalance")]
        public double SixMonthAverageDailyBalance { get; set; }

        /// <summary>
        /// Average Daily Balance across two months for all accounts
        /// </summary>
        [JsonProperty("twoMonthAverageDailyBalance")]
        public double TwoMonthAverageDailyBalance { get; set; }

        /// <summary>
        /// Standard Deviation of Daily Balance across twelve months for all accounts
        /// </summary>
        [JsonProperty("twelveMonthStandardDeviationOfDailyBalance")]
        public string TwelveMonthStandardDeviationOfDailyBalance { get; set; }

        /// <summary>
        /// Standard Deviation of Daily Balance across six months for all accounts
        /// </summary>
        [JsonProperty("sixMonthStandardDeviationOfDailyBalance")]
        public string SixMonthStandardDeviationOfDailyBalance { get; set; }

        /// <summary>
        /// Standard Deviation of Daily Balance across two months for all accounts
        /// </summary>
        [JsonProperty("twoMonthStandardDeviationOfDailyBalance")]
        public string TwoMonthStandardDeviationOfDailyBalance { get; set; }

        /// <summary>
        /// Number of Days Negative Balance over entire transaction history for all accounts
        /// </summary>
        [JsonProperty("numberOfDaysNegativeBalance")]
        public string NumberOfDaysNegativeBalance { get; set; }

        /// <summary>
        /// Number of Days Positive Balance over entire transaction history for all accounts
        /// </summary>
        [JsonProperty("numberOfDaysPositiveBalance")]
        public string NumberOfDaysPositiveBalance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowCashFlowBalanceSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowCashFlowBalanceSummary other &&
                ((this.MonthlyCashFlowBalanceSummaries == null && other.MonthlyCashFlowBalanceSummaries == null) || (this.MonthlyCashFlowBalanceSummaries?.Equals(other.MonthlyCashFlowBalanceSummaries) == true)) &&
                this.MinDailyBalance.Equals(other.MinDailyBalance) &&
                this.MaxDailyBalance.Equals(other.MaxDailyBalance) &&
                this.TwelveMonthAverageDailyBalance.Equals(other.TwelveMonthAverageDailyBalance) &&
                this.SixMonthAverageDailyBalance.Equals(other.SixMonthAverageDailyBalance) &&
                this.TwoMonthAverageDailyBalance.Equals(other.TwoMonthAverageDailyBalance) &&
                ((this.TwelveMonthStandardDeviationOfDailyBalance == null && other.TwelveMonthStandardDeviationOfDailyBalance == null) || (this.TwelveMonthStandardDeviationOfDailyBalance?.Equals(other.TwelveMonthStandardDeviationOfDailyBalance) == true)) &&
                ((this.SixMonthStandardDeviationOfDailyBalance == null && other.SixMonthStandardDeviationOfDailyBalance == null) || (this.SixMonthStandardDeviationOfDailyBalance?.Equals(other.SixMonthStandardDeviationOfDailyBalance) == true)) &&
                ((this.TwoMonthStandardDeviationOfDailyBalance == null && other.TwoMonthStandardDeviationOfDailyBalance == null) || (this.TwoMonthStandardDeviationOfDailyBalance?.Equals(other.TwoMonthStandardDeviationOfDailyBalance) == true)) &&
                ((this.NumberOfDaysNegativeBalance == null && other.NumberOfDaysNegativeBalance == null) || (this.NumberOfDaysNegativeBalance?.Equals(other.NumberOfDaysNegativeBalance) == true)) &&
                ((this.NumberOfDaysPositiveBalance == null && other.NumberOfDaysPositiveBalance == null) || (this.NumberOfDaysPositiveBalance?.Equals(other.NumberOfDaysPositiveBalance) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MonthlyCashFlowBalanceSummaries = {(this.MonthlyCashFlowBalanceSummaries == null ? "null" : $"[{string.Join(", ", this.MonthlyCashFlowBalanceSummaries)} ]")}");
            toStringOutput.Add($"this.MinDailyBalance = {this.MinDailyBalance}");
            toStringOutput.Add($"this.MaxDailyBalance = {this.MaxDailyBalance}");
            toStringOutput.Add($"this.TwelveMonthAverageDailyBalance = {this.TwelveMonthAverageDailyBalance}");
            toStringOutput.Add($"this.SixMonthAverageDailyBalance = {this.SixMonthAverageDailyBalance}");
            toStringOutput.Add($"this.TwoMonthAverageDailyBalance = {this.TwoMonthAverageDailyBalance}");
            toStringOutput.Add($"this.TwelveMonthStandardDeviationOfDailyBalance = {(this.TwelveMonthStandardDeviationOfDailyBalance == null ? "null" : this.TwelveMonthStandardDeviationOfDailyBalance == string.Empty ? "" : this.TwelveMonthStandardDeviationOfDailyBalance)}");
            toStringOutput.Add($"this.SixMonthStandardDeviationOfDailyBalance = {(this.SixMonthStandardDeviationOfDailyBalance == null ? "null" : this.SixMonthStandardDeviationOfDailyBalance == string.Empty ? "" : this.SixMonthStandardDeviationOfDailyBalance)}");
            toStringOutput.Add($"this.TwoMonthStandardDeviationOfDailyBalance = {(this.TwoMonthStandardDeviationOfDailyBalance == null ? "null" : this.TwoMonthStandardDeviationOfDailyBalance == string.Empty ? "" : this.TwoMonthStandardDeviationOfDailyBalance)}");
            toStringOutput.Add($"this.NumberOfDaysNegativeBalance = {(this.NumberOfDaysNegativeBalance == null ? "null" : this.NumberOfDaysNegativeBalance == string.Empty ? "" : this.NumberOfDaysNegativeBalance)}");
            toStringOutput.Add($"this.NumberOfDaysPositiveBalance = {(this.NumberOfDaysPositiveBalance == null ? "null" : this.NumberOfDaysPositiveBalance == string.Empty ? "" : this.NumberOfDaysPositiveBalance)}");
        }
    }
}