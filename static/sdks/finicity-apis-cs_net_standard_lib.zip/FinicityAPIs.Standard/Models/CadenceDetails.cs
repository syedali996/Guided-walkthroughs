// <copyright file="CadenceDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CadenceDetails.
    /// </summary>
    public class CadenceDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CadenceDetails"/> class.
        /// </summary>
        public CadenceDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CadenceDetails"/> class.
        /// </summary>
        /// <param name="startDate">startDate.</param>
        /// <param name="stopDate">stopDate.</param>
        /// <param name="days">days.</param>
        public CadenceDetails(
            long? startDate = null,
            long? stopDate = null,
            int? days = null)
        {
            this.StartDate = startDate;
            this.StopDate = stopDate;
            this.Days = days;
        }

        /// <summary>
        /// `postedDate` of the first deposit transaction
        /// </summary>
        [JsonProperty("startDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? StartDate { get; set; }

        /// <summary>
        /// `postedDate` of the final deposit transaction (omitted if status is active)
        /// </summary>
        [JsonProperty("stopDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? StopDate { get; set; }

        /// <summary>
        /// Number of days between the recurring deposits
        /// </summary>
        [JsonProperty("days", NullValueHandling = NullValueHandling.Ignore)]
        public int? Days { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CadenceDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CadenceDetails other &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.StopDate == null && other.StopDate == null) || (this.StopDate?.Equals(other.StopDate) == true)) &&
                ((this.Days == null && other.Days == null) || (this.Days?.Equals(other.Days) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.StopDate = {(this.StopDate == null ? "null" : this.StopDate.ToString())}");
            toStringOutput.Add($"this.Days = {(this.Days == null ? "null" : this.Days.ToString())}");
        }
    }
}