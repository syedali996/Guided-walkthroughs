// <copyright file="ConsumerAttributeAccountIDs.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributeAccountIDs.
    /// </summary>
    public class ConsumerAttributeAccountIDs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributeAccountIDs"/> class.
        /// </summary>
        public ConsumerAttributeAccountIDs()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributeAccountIDs"/> class.
        /// </summary>
        /// <param name="accountIds">accountIds.</param>
        public ConsumerAttributeAccountIDs(
            List<string> accountIds)
        {
            this.AccountIds = accountIds;
        }

        /// <summary>
        /// The list of account IDs
        /// </summary>
        [JsonProperty("accountIds")]
        public List<string> AccountIds { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributeAccountIDs : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributeAccountIDs other &&
                ((this.AccountIds == null && other.AccountIds == null) || (this.AccountIds?.Equals(other.AccountIds) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountIds = {(this.AccountIds == null ? "null" : $"[{string.Join(", ", this.AccountIds)} ]")}");
        }
    }
}