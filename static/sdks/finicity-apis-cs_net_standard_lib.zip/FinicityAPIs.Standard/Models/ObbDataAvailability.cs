// <copyright file="ObbDataAvailability.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbDataAvailability.
    /// </summary>
    public class ObbDataAvailability
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDataAvailability"/> class.
        /// </summary>
        public ObbDataAvailability()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbDataAvailability"/> class.
        /// </summary>
        /// <param name="historicAvailabilityBeginDate">historicAvailabilityBeginDate.</param>
        /// <param name="historicAvailabilityEndDate">historicAvailabilityEndDate.</param>
        /// <param name="historicAvailableDays">historicAvailableDays.</param>
        /// <param name="historicDataAvailability">historicDataAvailability.</param>
        public ObbDataAvailability(
            string historicAvailabilityBeginDate,
            string historicAvailabilityEndDate,
            int historicAvailableDays,
            string historicDataAvailability)
        {
            this.HistoricAvailabilityBeginDate = historicAvailabilityBeginDate;
            this.HistoricAvailabilityEndDate = historicAvailabilityEndDate;
            this.HistoricAvailableDays = historicAvailableDays;
            this.HistoricDataAvailability = historicDataAvailability;
        }

        /// <summary>
        /// Begin date for data availability
        /// </summary>
        [JsonProperty("historicAvailabilityBeginDate")]
        public string HistoricAvailabilityBeginDate { get; set; }

        /// <summary>
        /// End date for data availability
        /// </summary>
        [JsonProperty("historicAvailabilityEndDate")]
        public string HistoricAvailabilityEndDate { get; set; }

        /// <summary>
        /// Days for which transaction details are available
        /// </summary>
        [JsonProperty("historicAvailableDays")]
        public int HistoricAvailableDays { get; set; }

        /// <summary>
        /// Description of historic data availability
        /// </summary>
        [JsonProperty("historicDataAvailability")]
        public string HistoricDataAvailability { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbDataAvailability : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbDataAvailability other &&
                ((this.HistoricAvailabilityBeginDate == null && other.HistoricAvailabilityBeginDate == null) || (this.HistoricAvailabilityBeginDate?.Equals(other.HistoricAvailabilityBeginDate) == true)) &&
                ((this.HistoricAvailabilityEndDate == null && other.HistoricAvailabilityEndDate == null) || (this.HistoricAvailabilityEndDate?.Equals(other.HistoricAvailabilityEndDate) == true)) &&
                this.HistoricAvailableDays.Equals(other.HistoricAvailableDays) &&
                ((this.HistoricDataAvailability == null && other.HistoricDataAvailability == null) || (this.HistoricDataAvailability?.Equals(other.HistoricDataAvailability) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.HistoricAvailabilityBeginDate = {(this.HistoricAvailabilityBeginDate == null ? "null" : this.HistoricAvailabilityBeginDate == string.Empty ? "" : this.HistoricAvailabilityBeginDate)}");
            toStringOutput.Add($"this.HistoricAvailabilityEndDate = {(this.HistoricAvailabilityEndDate == null ? "null" : this.HistoricAvailabilityEndDate == string.Empty ? "" : this.HistoricAvailabilityEndDate)}");
            toStringOutput.Add($"this.HistoricAvailableDays = {this.HistoricAvailableDays}");
            toStringOutput.Add($"this.HistoricDataAvailability = {(this.HistoricDataAvailability == null ? "null" : this.HistoricDataAvailability == string.Empty ? "" : this.HistoricDataAvailability)}");
        }
    }
}