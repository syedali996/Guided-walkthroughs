// <copyright file="PayrollData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollData.
    /// </summary>
    public class PayrollData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollData"/> class.
        /// </summary>
        public PayrollData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollData"/> class.
        /// </summary>
        /// <param name="ssn">ssn.</param>
        /// <param name="dob">dob.</param>
        /// <param name="reportId">reportId.</param>
        public PayrollData(
            string ssn,
            long dob,
            string reportId = null)
        {
            this.Ssn = ssn;
            this.Dob = dob;
            this.ReportId = reportId;
        }

        /// <summary>
        /// A full SSN without hyphens
        /// </summary>
        [JsonProperty("ssn")]
        public string Ssn { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("dob")]
        public long Dob { get; set; }

        /// <summary>
        /// A report ID
        /// </summary>
        [JsonProperty("reportId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReportId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollData other &&
                ((this.Ssn == null && other.Ssn == null) || (this.Ssn?.Equals(other.Ssn) == true)) &&
                this.Dob.Equals(other.Dob) &&
                ((this.ReportId == null && other.ReportId == null) || (this.ReportId?.Equals(other.ReportId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Ssn = {(this.Ssn == null ? "null" : this.Ssn == string.Empty ? "" : this.Ssn)}");
            toStringOutput.Add($"this.Dob = {this.Dob}");
            toStringOutput.Add($"this.ReportId = {(this.ReportId == null ? "null" : this.ReportId == string.Empty ? "" : this.ReportId)}");
        }
    }
}