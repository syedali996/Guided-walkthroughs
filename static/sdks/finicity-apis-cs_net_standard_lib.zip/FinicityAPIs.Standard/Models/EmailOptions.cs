// <copyright file="EmailOptions.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// EmailOptions.
    /// </summary>
    public class EmailOptions
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EmailOptions"/> class.
        /// </summary>
        public EmailOptions()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EmailOptions"/> class.
        /// </summary>
        /// <param name="to">to.</param>
        /// <param name="from">from.</param>
        /// <param name="supportPhone">supportPhone.</param>
        /// <param name="subject">subject.</param>
        /// <param name="firstName">firstName.</param>
        /// <param name="institutionName">institutionName.</param>
        /// <param name="institutionAddress">institutionAddress.</param>
        /// <param name="signature">signature.</param>
        public EmailOptions(
            string to,
            string from = null,
            string supportPhone = null,
            string subject = null,
            string firstName = null,
            string institutionName = null,
            string institutionAddress = null,
            List<string> signature = null)
        {
            this.To = to;
            this.From = from;
            this.SupportPhone = supportPhone;
            this.Subject = subject;
            this.FirstName = firstName;
            this.InstitutionName = institutionName;
            this.InstitutionAddress = institutionAddress;
            this.Signature = signature;
        }

        /// <summary>
        /// The email address for the customer receiving the Connect email
        /// </summary>
        [JsonProperty("to")]
        public string To { get; set; }

        /// <summary>
        /// The name of a person or business sending the Connect email
        /// </summary>
        [JsonProperty("from", NullValueHandling = NullValueHandling.Ignore)]
        public string From { get; set; }

        /// <summary>
        /// The support phone number listed in the email
        /// </summary>
        [JsonProperty("supportPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string SupportPhone { get; set; }

        /// <summary>
        /// The subject line of the email. The default is "Verify your Financial Information".
        /// </summary>
        [JsonProperty("subject", NullValueHandling = NullValueHandling.Ignore)]
        public string Subject { get; set; }

        /// <summary>
        /// The first name of the customer or both names of the customers for joint borrowers. Example: "Marvin and Jenny".
        /// </summary>
        [JsonProperty("firstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>
        /// The name of your company
        /// </summary>
        [JsonProperty("institutionName", NullValueHandling = NullValueHandling.Ignore)]
        public string InstitutionName { get; set; }

        /// <summary>
        /// The institution address to appear in the footer of the email
        /// </summary>
        [JsonProperty("institutionAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string InstitutionAddress { get; set; }

        /// <summary>
        /// A signature for the email
        /// </summary>
        [JsonProperty("signature", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> Signature { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"EmailOptions : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is EmailOptions other &&
                ((this.To == null && other.To == null) || (this.To?.Equals(other.To) == true)) &&
                ((this.From == null && other.From == null) || (this.From?.Equals(other.From) == true)) &&
                ((this.SupportPhone == null && other.SupportPhone == null) || (this.SupportPhone?.Equals(other.SupportPhone) == true)) &&
                ((this.Subject == null && other.Subject == null) || (this.Subject?.Equals(other.Subject) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.InstitutionName == null && other.InstitutionName == null) || (this.InstitutionName?.Equals(other.InstitutionName) == true)) &&
                ((this.InstitutionAddress == null && other.InstitutionAddress == null) || (this.InstitutionAddress?.Equals(other.InstitutionAddress) == true)) &&
                ((this.Signature == null && other.Signature == null) || (this.Signature?.Equals(other.Signature) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.To = {(this.To == null ? "null" : this.To == string.Empty ? "" : this.To)}");
            toStringOutput.Add($"this.From = {(this.From == null ? "null" : this.From == string.Empty ? "" : this.From)}");
            toStringOutput.Add($"this.SupportPhone = {(this.SupportPhone == null ? "null" : this.SupportPhone == string.Empty ? "" : this.SupportPhone)}");
            toStringOutput.Add($"this.Subject = {(this.Subject == null ? "null" : this.Subject == string.Empty ? "" : this.Subject)}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.InstitutionName = {(this.InstitutionName == null ? "null" : this.InstitutionName == string.Empty ? "" : this.InstitutionName)}");
            toStringOutput.Add($"this.InstitutionAddress = {(this.InstitutionAddress == null ? "null" : this.InstitutionAddress == string.Empty ? "" : this.InstitutionAddress)}");
            toStringOutput.Add($"this.Signature = {(this.Signature == null ? "null" : $"[{string.Join(", ", this.Signature)} ]")}");
        }
    }
}