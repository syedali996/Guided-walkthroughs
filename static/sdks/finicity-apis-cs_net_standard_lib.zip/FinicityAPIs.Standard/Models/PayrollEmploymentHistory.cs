// <copyright file="PayrollEmploymentHistory.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollEmploymentHistory.
    /// </summary>
    public class PayrollEmploymentHistory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollEmploymentHistory"/> class.
        /// </summary>
        public PayrollEmploymentHistory()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollEmploymentHistory"/> class.
        /// </summary>
        /// <param name="asOfDate">asOfDate.</param>
        /// <param name="employerName">employerName.</param>
        /// <param name="payrollSource">payrollSource.</param>
        /// <param name="employee">employee.</param>
        /// <param name="employment">employment.</param>
        /// <param name="income">income.</param>
        public PayrollEmploymentHistory(
            long asOfDate,
            string employerName,
            string payrollSource,
            Models.PayrollEmployeeRecord employee,
            Models.PayrollEmploymentRecord employment,
            Models.PayrollVOEIncomeRecord income)
        {
            this.AsOfDate = asOfDate;
            this.EmployerName = employerName;
            this.PayrollSource = payrollSource;
            this.Employee = employee;
            this.Employment = employment;
            this.Income = income;
        }

        /// <summary>
        /// The last time the payroll data was updated in the payroll provider's system
        /// </summary>
        [JsonProperty("asOfDate")]
        public long AsOfDate { get; set; }

        /// <summary>
        /// Name of the employer as stated by the employer in the payroll system
        /// </summary>
        [JsonProperty("employerName")]
        public string EmployerName { get; set; }

        /// <summary>
        /// The name of the payroll source where the data was retrieved
        /// </summary>
        [JsonProperty("payrollSource")]
        public string PayrollSource { get; set; }

        /// <summary>
        /// Gets or sets Employee.
        /// </summary>
        [JsonProperty("employee")]
        public Models.PayrollEmployeeRecord Employee { get; set; }

        /// <summary>
        /// Gets or sets Employment.
        /// </summary>
        [JsonProperty("employment")]
        public Models.PayrollEmploymentRecord Employment { get; set; }

        /// <summary>
        /// Gets or sets Income.
        /// </summary>
        [JsonProperty("income")]
        public Models.PayrollVOEIncomeRecord Income { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollEmploymentHistory : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollEmploymentHistory other &&
                this.AsOfDate.Equals(other.AsOfDate) &&
                ((this.EmployerName == null && other.EmployerName == null) || (this.EmployerName?.Equals(other.EmployerName) == true)) &&
                ((this.PayrollSource == null && other.PayrollSource == null) || (this.PayrollSource?.Equals(other.PayrollSource) == true)) &&
                ((this.Employee == null && other.Employee == null) || (this.Employee?.Equals(other.Employee) == true)) &&
                ((this.Employment == null && other.Employment == null) || (this.Employment?.Equals(other.Employment) == true)) &&
                ((this.Income == null && other.Income == null) || (this.Income?.Equals(other.Income) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AsOfDate = {this.AsOfDate}");
            toStringOutput.Add($"this.EmployerName = {(this.EmployerName == null ? "null" : this.EmployerName == string.Empty ? "" : this.EmployerName)}");
            toStringOutput.Add($"this.PayrollSource = {(this.PayrollSource == null ? "null" : this.PayrollSource == string.Empty ? "" : this.PayrollSource)}");
            toStringOutput.Add($"this.Employee = {(this.Employee == null ? "null" : this.Employee.ToString())}");
            toStringOutput.Add($"this.Employment = {(this.Employment == null ? "null" : this.Employment.ToString())}");
            toStringOutput.Add($"this.Income = {(this.Income == null ? "null" : this.Income.ToString())}");
        }
    }
}