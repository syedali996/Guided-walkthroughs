// <copyright file="ConnectUrl.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConnectUrl.
    /// </summary>
    public class ConnectUrl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectUrl"/> class.
        /// </summary>
        public ConnectUrl()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectUrl"/> class.
        /// </summary>
        /// <param name="link">link.</param>
        public ConnectUrl(
            string link)
        {
            this.Link = link;
        }

        /// <summary>
        /// A generated Connect URL
        /// </summary>
        [JsonProperty("link")]
        public string Link { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConnectUrl : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConnectUrl other &&
                ((this.Link == null && other.Link == null) || (this.Link?.Equals(other.Link) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Link = {(this.Link == null ? "null" : this.Link == string.Empty ? "" : this.Link)}");
        }
    }
}