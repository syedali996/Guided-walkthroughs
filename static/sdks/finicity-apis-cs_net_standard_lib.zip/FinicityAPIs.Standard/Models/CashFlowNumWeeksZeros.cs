// <copyright file="CashFlowNumWeeksZeros.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowNumWeeksZeros.
    /// </summary>
    public class CashFlowNumWeeksZeros
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowNumWeeksZeros"/> class.
        /// </summary>
        public CashFlowNumWeeksZeros()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowNumWeeksZeros"/> class.
        /// </summary>
        /// <param name="historicNumberOfWeeksWithDataAvailable">historicNumberOfWeeksWithDataAvailable.</param>
        /// <param name="historicNumberOfWeeksZeroTransactions">historicNumberOfWeeksZeroTransactions.</param>
        /// <param name="historicWeeksWithZeroTransactions">historicWeeksWithZeroTransactions.</param>
        public CashFlowNumWeeksZeros(
            int historicNumberOfWeeksWithDataAvailable,
            int historicNumberOfWeeksZeroTransactions,
            List<Models.ObbWeekOfYear> historicWeeksWithZeroTransactions)
        {
            this.HistoricNumberOfWeeksWithDataAvailable = historicNumberOfWeeksWithDataAvailable;
            this.HistoricNumberOfWeeksZeroTransactions = historicNumberOfWeeksZeroTransactions;
            this.HistoricWeeksWithZeroTransactions = historicWeeksWithZeroTransactions;
        }

        /// <summary>
        /// Number of weeks during known history of account in which data was available
        /// </summary>
        [JsonProperty("historicNumberOfWeeksWithDataAvailable")]
        public int HistoricNumberOfWeeksWithDataAvailable { get; set; }

        /// <summary>
        /// Number of weeks during known history of account where zero transactions were posted
        /// </summary>
        [JsonProperty("historicNumberOfWeeksZeroTransactions")]
        public int HistoricNumberOfWeeksZeroTransactions { get; set; }

        /// <summary>
        /// List of weeks with zero reported transactions
        /// </summary>
        [JsonProperty("historicWeeksWithZeroTransactions")]
        public List<Models.ObbWeekOfYear> HistoricWeeksWithZeroTransactions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowNumWeeksZeros : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowNumWeeksZeros other &&
                this.HistoricNumberOfWeeksWithDataAvailable.Equals(other.HistoricNumberOfWeeksWithDataAvailable) &&
                this.HistoricNumberOfWeeksZeroTransactions.Equals(other.HistoricNumberOfWeeksZeroTransactions) &&
                ((this.HistoricWeeksWithZeroTransactions == null && other.HistoricWeeksWithZeroTransactions == null) || (this.HistoricWeeksWithZeroTransactions?.Equals(other.HistoricWeeksWithZeroTransactions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.HistoricNumberOfWeeksWithDataAvailable = {this.HistoricNumberOfWeeksWithDataAvailable}");
            toStringOutput.Add($"this.HistoricNumberOfWeeksZeroTransactions = {this.HistoricNumberOfWeeksZeroTransactions}");
            toStringOutput.Add($"this.HistoricWeeksWithZeroTransactions = {(this.HistoricWeeksWithZeroTransactions == null ? "null" : $"[{string.Join(", ", this.HistoricWeeksWithZeroTransactions)} ]")}");
        }
    }
}