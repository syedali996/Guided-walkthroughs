// <copyright file="ReportCustomField.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReportCustomField.
    /// </summary>
    public class ReportCustomField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportCustomField"/> class.
        /// </summary>
        public ReportCustomField()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportCustomField"/> class.
        /// </summary>
        /// <param name="label">label.</param>
        /// <param name="mValue">value.</param>
        /// <param name="shown">shown.</param>
        public ReportCustomField(
            string label = null,
            string mValue = null,
            bool? shown = null)
        {
            this.Label = label;
            this.MValue = mValue;
            this.Shown = shown;
        }

        /// <summary>
        /// The name of the custom field
        /// </summary>
        [JsonProperty("label", NullValueHandling = NullValueHandling.Ignore)]
        public string Label { get; set; }

        /// <summary>
        /// The value of the custom field
        /// </summary>
        [JsonProperty("value", NullValueHandling = NullValueHandling.Ignore)]
        public string MValue { get; set; }

        /// <summary>
        /// If the custom field will show on the PDF or not
        /// </summary>
        [JsonProperty("shown", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Shown { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReportCustomField : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReportCustomField other &&
                ((this.Label == null && other.Label == null) || (this.Label?.Equals(other.Label) == true)) &&
                ((this.MValue == null && other.MValue == null) || (this.MValue?.Equals(other.MValue) == true)) &&
                ((this.Shown == null && other.Shown == null) || (this.Shown?.Equals(other.Shown) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Label = {(this.Label == null ? "null" : this.Label == string.Empty ? "" : this.Label)}");
            toStringOutput.Add($"this.MValue = {(this.MValue == null ? "null" : this.MValue == string.Empty ? "" : this.MValue)}");
            toStringOutput.Add($"this.Shown = {(this.Shown == null ? "null" : this.Shown.ToString())}");
        }
    }
}