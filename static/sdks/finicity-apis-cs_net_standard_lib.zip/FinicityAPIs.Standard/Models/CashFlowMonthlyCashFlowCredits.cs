// <copyright file="CashFlowMonthlyCashFlowCredits.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowMonthlyCashFlowCredits.
    /// </summary>
    public class CashFlowMonthlyCashFlowCredits
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowCredits"/> class.
        /// </summary>
        public CashFlowMonthlyCashFlowCredits()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowCredits"/> class.
        /// </summary>
        /// <param name="month">month.</param>
        /// <param name="numberOfCredits">numberOfCredits.</param>
        /// <param name="totalCreditsAmount">totalCreditsAmount.</param>
        /// <param name="largestCredit">largestCredit.</param>
        /// <param name="numberOfCreditsLessTransfers">numberOfCreditsLessTransfers.</param>
        /// <param name="totalCreditsAmountLessTransfers">totalCreditsAmountLessTransfers.</param>
        /// <param name="averageCreditAmount">averageCreditAmount.</param>
        /// <param name="estimatedNumberOfLoanDeposits">estimatedNumberOfLoanDeposits.</param>
        /// <param name="estimatedLoanDepositAmount">estimatedLoanDepositAmount.</param>
        public CashFlowMonthlyCashFlowCredits(
            long month,
            string numberOfCredits,
            double totalCreditsAmount,
            double largestCredit,
            string numberOfCreditsLessTransfers,
            double totalCreditsAmountLessTransfers,
            double averageCreditAmount,
            string estimatedNumberOfLoanDeposits,
            double estimatedLoanDepositAmount)
        {
            this.Month = month;
            this.NumberOfCredits = numberOfCredits;
            this.TotalCreditsAmount = totalCreditsAmount;
            this.LargestCredit = largestCredit;
            this.NumberOfCreditsLessTransfers = numberOfCreditsLessTransfers;
            this.TotalCreditsAmountLessTransfers = totalCreditsAmountLessTransfers;
            this.AverageCreditAmount = averageCreditAmount;
            this.EstimatedNumberOfLoanDeposits = estimatedNumberOfLoanDeposits;
            this.EstimatedLoanDepositAmount = estimatedLoanDepositAmount;
        }

        /// <summary>
        /// One instance for each complete calendar month in the report
        /// </summary>
        [JsonProperty("month")]
        public long Month { get; set; }

        /// <summary>
        /// Number of credits by month
        /// </summary>
        [JsonProperty("numberOfCredits")]
        public string NumberOfCredits { get; set; }

        /// <summary>
        /// Total amount of credits by month
        /// </summary>
        [JsonProperty("totalCreditsAmount")]
        public double TotalCreditsAmount { get; set; }

        /// <summary>
        /// Largest credit by month
        /// </summary>
        [JsonProperty("largestCredit")]
        public double LargestCredit { get; set; }

        /// <summary>
        /// Number of credits by month (less transfers)
        /// </summary>
        [JsonProperty("numberOfCreditsLessTransfers")]
        public string NumberOfCreditsLessTransfers { get; set; }

        /// <summary>
        /// Total amount of credits by month (less transfers)
        /// </summary>
        [JsonProperty("totalCreditsAmountLessTransfers")]
        public double TotalCreditsAmountLessTransfers { get; set; }

        /// <summary>
        /// The average credit amount
        /// </summary>
        [JsonProperty("averageCreditAmount")]
        public double AverageCreditAmount { get; set; }

        /// <summary>
        /// The estimated number of loan deposits
        /// </summary>
        [JsonProperty("estimatedNumberOfLoanDeposits")]
        public string EstimatedNumberOfLoanDeposits { get; set; }

        /// <summary>
        /// The estimated loan deposit amount
        /// </summary>
        [JsonProperty("estimatedLoanDepositAmount")]
        public double EstimatedLoanDepositAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowMonthlyCashFlowCredits : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowMonthlyCashFlowCredits other &&
                this.Month.Equals(other.Month) &&
                ((this.NumberOfCredits == null && other.NumberOfCredits == null) || (this.NumberOfCredits?.Equals(other.NumberOfCredits) == true)) &&
                this.TotalCreditsAmount.Equals(other.TotalCreditsAmount) &&
                this.LargestCredit.Equals(other.LargestCredit) &&
                ((this.NumberOfCreditsLessTransfers == null && other.NumberOfCreditsLessTransfers == null) || (this.NumberOfCreditsLessTransfers?.Equals(other.NumberOfCreditsLessTransfers) == true)) &&
                this.TotalCreditsAmountLessTransfers.Equals(other.TotalCreditsAmountLessTransfers) &&
                this.AverageCreditAmount.Equals(other.AverageCreditAmount) &&
                ((this.EstimatedNumberOfLoanDeposits == null && other.EstimatedNumberOfLoanDeposits == null) || (this.EstimatedNumberOfLoanDeposits?.Equals(other.EstimatedNumberOfLoanDeposits) == true)) &&
                this.EstimatedLoanDepositAmount.Equals(other.EstimatedLoanDepositAmount);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Month = {this.Month}");
            toStringOutput.Add($"this.NumberOfCredits = {(this.NumberOfCredits == null ? "null" : this.NumberOfCredits == string.Empty ? "" : this.NumberOfCredits)}");
            toStringOutput.Add($"this.TotalCreditsAmount = {this.TotalCreditsAmount}");
            toStringOutput.Add($"this.LargestCredit = {this.LargestCredit}");
            toStringOutput.Add($"this.NumberOfCreditsLessTransfers = {(this.NumberOfCreditsLessTransfers == null ? "null" : this.NumberOfCreditsLessTransfers == string.Empty ? "" : this.NumberOfCreditsLessTransfers)}");
            toStringOutput.Add($"this.TotalCreditsAmountLessTransfers = {this.TotalCreditsAmountLessTransfers}");
            toStringOutput.Add($"this.AverageCreditAmount = {this.AverageCreditAmount}");
            toStringOutput.Add($"this.EstimatedNumberOfLoanDeposits = {(this.EstimatedNumberOfLoanDeposits == null ? "null" : this.EstimatedNumberOfLoanDeposits == string.Empty ? "" : this.EstimatedNumberOfLoanDeposits)}");
            toStringOutput.Add($"this.EstimatedLoanDepositAmount = {this.EstimatedLoanDepositAmount}");
        }
    }
}