// <copyright file="CashFlowCashFlowCreditSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowCashFlowCreditSummary.
    /// </summary>
    public class CashFlowCashFlowCreditSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCreditSummary"/> class.
        /// </summary>
        public CashFlowCashFlowCreditSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCreditSummary"/> class.
        /// </summary>
        /// <param name="monthlyCashFlowCreditSummaries">monthlyCashFlowCreditSummaries.</param>
        /// <param name="twelveMonthCreditTotal">twelveMonthCreditTotal.</param>
        /// <param name="twelveMonthCreditTotalLessTransfers">twelveMonthCreditTotalLessTransfers.</param>
        /// <param name="sixMonthCreditTotal">sixMonthCreditTotal.</param>
        /// <param name="sixMonthCreditTotalLessTransfers">sixMonthCreditTotalLessTransfers.</param>
        /// <param name="twoMonthCreditTotal">twoMonthCreditTotal.</param>
        /// <param name="twoMonthCreditTotalLessTransfers">twoMonthCreditTotalLessTransfers.</param>
        public CashFlowCashFlowCreditSummary(
            List<Models.CashFlowMonthlyCashFlowCreditSummaries> monthlyCashFlowCreditSummaries,
            double twelveMonthCreditTotal,
            double twelveMonthCreditTotalLessTransfers,
            double sixMonthCreditTotal,
            double sixMonthCreditTotalLessTransfers,
            double twoMonthCreditTotal,
            double twoMonthCreditTotalLessTransfers)
        {
            this.MonthlyCashFlowCreditSummaries = monthlyCashFlowCreditSummaries;
            this.TwelveMonthCreditTotal = twelveMonthCreditTotal;
            this.TwelveMonthCreditTotalLessTransfers = twelveMonthCreditTotalLessTransfers;
            this.SixMonthCreditTotal = sixMonthCreditTotal;
            this.SixMonthCreditTotalLessTransfers = sixMonthCreditTotalLessTransfers;
            this.TwoMonthCreditTotal = twoMonthCreditTotal;
            this.TwoMonthCreditTotalLessTransfers = twoMonthCreditTotalLessTransfers;
        }

        /// <summary>
        /// List of attributes for each month
        /// </summary>
        [JsonProperty("monthlyCashFlowCreditSummaries")]
        public List<Models.CashFlowMonthlyCashFlowCreditSummaries> MonthlyCashFlowCreditSummaries { get; set; }

        /// <summary>
        /// Sum of all credit transactions for each month for all accounts
        /// </summary>
        [JsonProperty("twelveMonthCreditTotal")]
        public double TwelveMonthCreditTotal { get; set; }

        /// <summary>
        /// Sum of all monthly credit transactions without transfers for all accounts
        /// </summary>
        [JsonProperty("twelveMonthCreditTotalLessTransfers")]
        public double TwelveMonthCreditTotalLessTransfers { get; set; }

        /// <summary>
        /// Six month sum of all credit transactions
        /// </summary>
        [JsonProperty("sixMonthCreditTotal")]
        public double SixMonthCreditTotal { get; set; }

        /// <summary>
        /// Six month sum of all monthly credit transactions without transfers for all accounts
        /// </summary>
        [JsonProperty("sixMonthCreditTotalLessTransfers")]
        public double SixMonthCreditTotalLessTransfers { get; set; }

        /// <summary>
        /// Two month sum of all credit transactions
        /// </summary>
        [JsonProperty("twoMonthCreditTotal")]
        public double TwoMonthCreditTotal { get; set; }

        /// <summary>
        /// Two month sum of all monthly credit transactions without transfers for all accounts
        /// </summary>
        [JsonProperty("twoMonthCreditTotalLessTransfers")]
        public double TwoMonthCreditTotalLessTransfers { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowCashFlowCreditSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowCashFlowCreditSummary other &&
                ((this.MonthlyCashFlowCreditSummaries == null && other.MonthlyCashFlowCreditSummaries == null) || (this.MonthlyCashFlowCreditSummaries?.Equals(other.MonthlyCashFlowCreditSummaries) == true)) &&
                this.TwelveMonthCreditTotal.Equals(other.TwelveMonthCreditTotal) &&
                this.TwelveMonthCreditTotalLessTransfers.Equals(other.TwelveMonthCreditTotalLessTransfers) &&
                this.SixMonthCreditTotal.Equals(other.SixMonthCreditTotal) &&
                this.SixMonthCreditTotalLessTransfers.Equals(other.SixMonthCreditTotalLessTransfers) &&
                this.TwoMonthCreditTotal.Equals(other.TwoMonthCreditTotal) &&
                this.TwoMonthCreditTotalLessTransfers.Equals(other.TwoMonthCreditTotalLessTransfers);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MonthlyCashFlowCreditSummaries = {(this.MonthlyCashFlowCreditSummaries == null ? "null" : $"[{string.Join(", ", this.MonthlyCashFlowCreditSummaries)} ]")}");
            toStringOutput.Add($"this.TwelveMonthCreditTotal = {this.TwelveMonthCreditTotal}");
            toStringOutput.Add($"this.TwelveMonthCreditTotalLessTransfers = {this.TwelveMonthCreditTotalLessTransfers}");
            toStringOutput.Add($"this.SixMonthCreditTotal = {this.SixMonthCreditTotal}");
            toStringOutput.Add($"this.SixMonthCreditTotalLessTransfers = {this.SixMonthCreditTotalLessTransfers}");
            toStringOutput.Add($"this.TwoMonthCreditTotal = {this.TwoMonthCreditTotal}");
            toStringOutput.Add($"this.TwoMonthCreditTotalLessTransfers = {this.TwoMonthCreditTotalLessTransfers}");
        }
    }
}