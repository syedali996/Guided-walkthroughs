// <copyright file="PayrollReportConstraintsOut.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollReportConstraintsOut.
    /// </summary>
    public class PayrollReportConstraintsOut
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollReportConstraintsOut"/> class.
        /// </summary>
        public PayrollReportConstraintsOut()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollReportConstraintsOut"/> class.
        /// </summary>
        /// <param name="payrollData">payrollData.</param>
        /// <param name="reportCustomFields">reportCustomFields.</param>
        /// <param name="payStatementsFromDate">payStatementsFromDate.</param>
        public PayrollReportConstraintsOut(
            Models.PayrollDataOut payrollData,
            List<Models.ReportCustomField> reportCustomFields = null,
            long? payStatementsFromDate = null)
        {
            this.PayrollData = payrollData;
            this.ReportCustomFields = reportCustomFields;
            this.PayStatementsFromDate = payStatementsFromDate;
        }

        /// <summary>
        /// Gets or sets PayrollData.
        /// </summary>
        [JsonProperty("payrollData")]
        public Models.PayrollDataOut PayrollData { get; set; }

        /// <summary>
        /// The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.
        /// Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".
        /// * "true": (default) display the custom field in the PDF report
        /// * "false": don't display the custom field in the PDF report
        /// For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.
        /// All custom fields display in the Reseller Billing API.
        /// </summary>
        [JsonProperty("reportCustomFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportCustomField> ReportCustomFields { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("payStatementsFromDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? PayStatementsFromDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollReportConstraintsOut : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollReportConstraintsOut other &&
                ((this.PayrollData == null && other.PayrollData == null) || (this.PayrollData?.Equals(other.PayrollData) == true)) &&
                ((this.ReportCustomFields == null && other.ReportCustomFields == null) || (this.ReportCustomFields?.Equals(other.ReportCustomFields) == true)) &&
                ((this.PayStatementsFromDate == null && other.PayStatementsFromDate == null) || (this.PayStatementsFromDate?.Equals(other.PayStatementsFromDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PayrollData = {(this.PayrollData == null ? "null" : this.PayrollData.ToString())}");
            toStringOutput.Add($"this.ReportCustomFields = {(this.ReportCustomFields == null ? "null" : $"[{string.Join(", ", this.ReportCustomFields)} ]")}");
            toStringOutput.Add($"this.PayStatementsFromDate = {(this.PayStatementsFromDate == null ? "null" : this.PayStatementsFromDate.ToString())}");
        }
    }
}