// <copyright file="ConsumerAttributesDataIncome.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesDataIncome.
    /// </summary>
    public class ConsumerAttributesDataIncome
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataIncome"/> class.
        /// </summary>
        public ConsumerAttributesDataIncome()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataIncome"/> class.
        /// </summary>
        /// <param name="netAnnualIncome">netAnnualIncome.</param>
        /// <param name="netAnnualIncomeByAccount">netAnnualIncomeByAccount.</param>
        /// <param name="monthlyNetIncome">monthlyNetIncome.</param>
        /// <param name="monthlyNetIncomeByAccount">monthlyNetIncomeByAccount.</param>
        public ConsumerAttributesDataIncome(
            double netAnnualIncome,
            object netAnnualIncomeByAccount,
            object monthlyNetIncome,
            object monthlyNetIncomeByAccount)
        {
            this.NetAnnualIncome = netAnnualIncome;
            this.NetAnnualIncomeByAccount = netAnnualIncomeByAccount;
            this.MonthlyNetIncome = monthlyNetIncome;
            this.MonthlyNetIncomeByAccount = monthlyNetIncomeByAccount;
        }

        /// <summary>
        /// Net annual of all income by customer for the last 12 months
        /// </summary>
        [JsonProperty("netAnnualIncome")]
        public double NetAnnualIncome { get; set; }

        /// <summary>
        /// Net annual of income by account for the last 12 months
        /// </summary>
        [JsonProperty("netAnnualIncomeByAccount")]
        public object NetAnnualIncomeByAccount { get; set; }

        /// <summary>
        /// Net monthly income by customer for the last 12 months
        /// </summary>
        [JsonProperty("monthlyNetIncome")]
        public object MonthlyNetIncome { get; set; }

        /// <summary>
        /// Net monthly income by account for the last 12 months
        /// </summary>
        [JsonProperty("monthlyNetIncomeByAccount")]
        public object MonthlyNetIncomeByAccount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesDataIncome : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesDataIncome other &&
                this.NetAnnualIncome.Equals(other.NetAnnualIncome) &&
                ((this.NetAnnualIncomeByAccount == null && other.NetAnnualIncomeByAccount == null) || (this.NetAnnualIncomeByAccount?.Equals(other.NetAnnualIncomeByAccount) == true)) &&
                ((this.MonthlyNetIncome == null && other.MonthlyNetIncome == null) || (this.MonthlyNetIncome?.Equals(other.MonthlyNetIncome) == true)) &&
                ((this.MonthlyNetIncomeByAccount == null && other.MonthlyNetIncomeByAccount == null) || (this.MonthlyNetIncomeByAccount?.Equals(other.MonthlyNetIncomeByAccount) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.NetAnnualIncome = {this.NetAnnualIncome}");
            toStringOutput.Add($"NetAnnualIncomeByAccount = {(this.NetAnnualIncomeByAccount == null ? "null" : this.NetAnnualIncomeByAccount.ToString())}");
            toStringOutput.Add($"MonthlyNetIncome = {(this.MonthlyNetIncome == null ? "null" : this.MonthlyNetIncome.ToString())}");
            toStringOutput.Add($"MonthlyNetIncomeByAccount = {(this.MonthlyNetIncomeByAccount == null ? "null" : this.MonthlyNetIncomeByAccount.ToString())}");
        }
    }
}