// <copyright file="CashFlowInflowAttributes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowInflowAttributes.
    /// </summary>
    public class CashFlowInflowAttributes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowInflowAttributes"/> class.
        /// </summary>
        public CashFlowInflowAttributes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowInflowAttributes"/> class.
        /// </summary>
        /// <param name="countDepositsByMonthForTheReportTimePeriod">countDepositsByMonthForTheReportTimePeriod.</param>
        /// <param name="historicCountOfDepositTransactions">historicCountOfDepositTransactions.</param>
        /// <param name="maximumDepositByMonthForTheReportTimePeriod">maximumDepositByMonthForTheReportTimePeriod.</param>
        /// <param name="minimumDepositByMonthForTheReportTimePeriod">minimumDepositByMonthForTheReportTimePeriod.</param>
        /// <param name="sumDepositsByMonthForTheReportTimePeriod">sumDepositsByMonthForTheReportTimePeriod.</param>
        /// <param name="averageDepositByMonthForTheReportTimePeriod">averageDepositByMonthForTheReportTimePeriod.</param>
        /// <param name="historicSumOfDeposits">historicSumOfDeposits.</param>
        public CashFlowInflowAttributes(
            List<Models.ObbDateRangeAndCount> countDepositsByMonthForTheReportTimePeriod,
            int historicCountOfDepositTransactions,
            List<Models.ObbDateRangeAndAmount> maximumDepositByMonthForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> minimumDepositByMonthForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> sumDepositsByMonthForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> averageDepositByMonthForTheReportTimePeriod = null,
            double? historicSumOfDeposits = null)
        {
            this.AverageDepositByMonthForTheReportTimePeriod = averageDepositByMonthForTheReportTimePeriod;
            this.CountDepositsByMonthForTheReportTimePeriod = countDepositsByMonthForTheReportTimePeriod;
            this.HistoricCountOfDepositTransactions = historicCountOfDepositTransactions;
            this.HistoricSumOfDeposits = historicSumOfDeposits;
            this.MaximumDepositByMonthForTheReportTimePeriod = maximumDepositByMonthForTheReportTimePeriod;
            this.MinimumDepositByMonthForTheReportTimePeriod = minimumDepositByMonthForTheReportTimePeriod;
            this.SumDepositsByMonthForTheReportTimePeriod = sumDepositsByMonthForTheReportTimePeriod;
        }

        /// <summary>
        /// Average value of deposits during periods in the report
        /// </summary>
        [JsonProperty("averageDepositByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> AverageDepositByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Count of all deposits during periods in the report
        /// </summary>
        [JsonProperty("countDepositsByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndCount> CountDepositsByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Count of ALL deposits over entire known history of the account (may exceed requested length of report)
        /// </summary>
        [JsonProperty("historicCountOfDepositTransactions")]
        public int HistoricCountOfDepositTransactions { get; set; }

        /// <summary>
        /// Sum of ALL deposits over entire known history of the account (may exceed requested length of report)
        /// </summary>
        [JsonProperty("historicSumOfDeposits", NullValueHandling = NullValueHandling.Ignore)]
        public double? HistoricSumOfDeposits { get; set; }

        /// <summary>
        /// Maximum deposit value for different periods in the report
        /// </summary>
        [JsonProperty("maximumDepositByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> MaximumDepositByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Minimum deposit value for different periods in the report
        /// </summary>
        [JsonProperty("minimumDepositByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> MinimumDepositByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Sum of all deposits during periods in the report
        /// </summary>
        [JsonProperty("sumDepositsByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> SumDepositsByMonthForTheReportTimePeriod { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowInflowAttributes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowInflowAttributes other &&
                ((this.AverageDepositByMonthForTheReportTimePeriod == null && other.AverageDepositByMonthForTheReportTimePeriod == null) || (this.AverageDepositByMonthForTheReportTimePeriod?.Equals(other.AverageDepositByMonthForTheReportTimePeriod) == true)) &&
                ((this.CountDepositsByMonthForTheReportTimePeriod == null && other.CountDepositsByMonthForTheReportTimePeriod == null) || (this.CountDepositsByMonthForTheReportTimePeriod?.Equals(other.CountDepositsByMonthForTheReportTimePeriod) == true)) &&
                this.HistoricCountOfDepositTransactions.Equals(other.HistoricCountOfDepositTransactions) &&
                ((this.HistoricSumOfDeposits == null && other.HistoricSumOfDeposits == null) || (this.HistoricSumOfDeposits?.Equals(other.HistoricSumOfDeposits) == true)) &&
                ((this.MaximumDepositByMonthForTheReportTimePeriod == null && other.MaximumDepositByMonthForTheReportTimePeriod == null) || (this.MaximumDepositByMonthForTheReportTimePeriod?.Equals(other.MaximumDepositByMonthForTheReportTimePeriod) == true)) &&
                ((this.MinimumDepositByMonthForTheReportTimePeriod == null && other.MinimumDepositByMonthForTheReportTimePeriod == null) || (this.MinimumDepositByMonthForTheReportTimePeriod?.Equals(other.MinimumDepositByMonthForTheReportTimePeriod) == true)) &&
                ((this.SumDepositsByMonthForTheReportTimePeriod == null && other.SumDepositsByMonthForTheReportTimePeriod == null) || (this.SumDepositsByMonthForTheReportTimePeriod?.Equals(other.SumDepositsByMonthForTheReportTimePeriod) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AverageDepositByMonthForTheReportTimePeriod = {(this.AverageDepositByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.AverageDepositByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.CountDepositsByMonthForTheReportTimePeriod = {(this.CountDepositsByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.CountDepositsByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.HistoricCountOfDepositTransactions = {this.HistoricCountOfDepositTransactions}");
            toStringOutput.Add($"this.HistoricSumOfDeposits = {(this.HistoricSumOfDeposits == null ? "null" : this.HistoricSumOfDeposits.ToString())}");
            toStringOutput.Add($"this.MaximumDepositByMonthForTheReportTimePeriod = {(this.MaximumDepositByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.MaximumDepositByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.MinimumDepositByMonthForTheReportTimePeriod = {(this.MinimumDepositByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.MinimumDepositByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.SumDepositsByMonthForTheReportTimePeriod = {(this.SumDepositsByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.SumDepositsByMonthForTheReportTimePeriod)} ]")}");
        }
    }
}