// <copyright file="ConsumerAttributesData.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesData.
    /// </summary>
    public class ConsumerAttributesData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesData"/> class.
        /// </summary>
        public ConsumerAttributesData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesData"/> class.
        /// </summary>
        /// <param name="dateRange">dateRange.</param>
        /// <param name="income">income.</param>
        /// <param name="expenses">expenses.</param>
        /// <param name="netAmount">netAmount.</param>
        /// <param name="nsf">nsf.</param>
        /// <param name="assets">assets.</param>
        /// <param name="liabilities">liabilities.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="accountIds">accountIds.</param>
        public ConsumerAttributesData(
            Models.ConsumerAttributesDataDateRange dateRange,
            Models.ConsumerAttributesDataIncome income,
            Models.ConsumerAttributesDataExpenses expenses,
            Models.ConsumerAttributesDataNetAmount netAmount,
            Models.ConsumerAttributesDataNSF nsf,
            Models.ConsumerAttributesDataAssets assets,
            Models.ConsumerAttributesDataLiabilities liabilities,
            string customerId = null,
            List<long> accountIds = null)
        {
            this.CustomerId = customerId;
            this.AccountIds = accountIds;
            this.DateRange = dateRange;
            this.Income = income;
            this.Expenses = expenses;
            this.NetAmount = netAmount;
            this.Nsf = nsf;
            this.Assets = assets;
            this.Liabilities = liabilities;
        }

        /// <summary>
        /// A customer ID. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomerId { get; set; }

        /// <summary>
        /// Gets or sets AccountIds.
        /// </summary>
        [JsonProperty("accountIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> AccountIds { get; set; }

        /// <summary>
        /// Gets or sets DateRange.
        /// </summary>
        [JsonProperty("dateRange")]
        public Models.ConsumerAttributesDataDateRange DateRange { get; set; }

        /// <summary>
        /// Gets or sets Income.
        /// </summary>
        [JsonProperty("income")]
        public Models.ConsumerAttributesDataIncome Income { get; set; }

        /// <summary>
        /// Gets or sets Expenses.
        /// </summary>
        [JsonProperty("expenses")]
        public Models.ConsumerAttributesDataExpenses Expenses { get; set; }

        /// <summary>
        /// Gets or sets NetAmount.
        /// </summary>
        [JsonProperty("netAmount")]
        public Models.ConsumerAttributesDataNetAmount NetAmount { get; set; }

        /// <summary>
        /// Gets or sets Nsf.
        /// </summary>
        [JsonProperty("nsf")]
        public Models.ConsumerAttributesDataNSF Nsf { get; set; }

        /// <summary>
        /// Gets or sets Assets.
        /// </summary>
        [JsonProperty("assets")]
        public Models.ConsumerAttributesDataAssets Assets { get; set; }

        /// <summary>
        /// Gets or sets Liabilities.
        /// </summary>
        [JsonProperty("liabilities")]
        public Models.ConsumerAttributesDataLiabilities Liabilities { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesData : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesData other &&
                ((this.CustomerId == null && other.CustomerId == null) || (this.CustomerId?.Equals(other.CustomerId) == true)) &&
                ((this.AccountIds == null && other.AccountIds == null) || (this.AccountIds?.Equals(other.AccountIds) == true)) &&
                ((this.DateRange == null && other.DateRange == null) || (this.DateRange?.Equals(other.DateRange) == true)) &&
                ((this.Income == null && other.Income == null) || (this.Income?.Equals(other.Income) == true)) &&
                ((this.Expenses == null && other.Expenses == null) || (this.Expenses?.Equals(other.Expenses) == true)) &&
                ((this.NetAmount == null && other.NetAmount == null) || (this.NetAmount?.Equals(other.NetAmount) == true)) &&
                ((this.Nsf == null && other.Nsf == null) || (this.Nsf?.Equals(other.Nsf) == true)) &&
                ((this.Assets == null && other.Assets == null) || (this.Assets?.Equals(other.Assets) == true)) &&
                ((this.Liabilities == null && other.Liabilities == null) || (this.Liabilities?.Equals(other.Liabilities) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CustomerId = {(this.CustomerId == null ? "null" : this.CustomerId == string.Empty ? "" : this.CustomerId)}");
            toStringOutput.Add($"this.AccountIds = {(this.AccountIds == null ? "null" : $"[{string.Join(", ", this.AccountIds)} ]")}");
            toStringOutput.Add($"this.DateRange = {(this.DateRange == null ? "null" : this.DateRange.ToString())}");
            toStringOutput.Add($"this.Income = {(this.Income == null ? "null" : this.Income.ToString())}");
            toStringOutput.Add($"this.Expenses = {(this.Expenses == null ? "null" : this.Expenses.ToString())}");
            toStringOutput.Add($"this.NetAmount = {(this.NetAmount == null ? "null" : this.NetAmount.ToString())}");
            toStringOutput.Add($"this.Nsf = {(this.Nsf == null ? "null" : this.Nsf.ToString())}");
            toStringOutput.Add($"this.Assets = {(this.Assets == null ? "null" : this.Assets.ToString())}");
            toStringOutput.Add($"this.Liabilities = {(this.Liabilities == null ? "null" : this.Liabilities.ToString())}");
        }
    }
}