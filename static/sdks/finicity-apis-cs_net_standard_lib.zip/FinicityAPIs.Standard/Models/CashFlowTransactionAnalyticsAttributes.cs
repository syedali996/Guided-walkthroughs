// <copyright file="CashFlowTransactionAnalyticsAttributes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowTransactionAnalyticsAttributes.
    /// </summary>
    public class CashFlowTransactionAnalyticsAttributes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowTransactionAnalyticsAttributes"/> class.
        /// </summary>
        public CashFlowTransactionAnalyticsAttributes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowTransactionAnalyticsAttributes"/> class.
        /// </summary>
        /// <param name="activityDepositsCreditsForTheReportTimePeriod">activityDepositsCreditsForTheReportTimePeriod.</param>
        /// <param name="activityWithdrawalsDebitsForTheReportTimePeriod">activityWithdrawalsDebitsForTheReportTimePeriod.</param>
        /// <param name="averageTransactionValueByMonthForTheReportTimePeriod">averageTransactionValueByMonthForTheReportTimePeriod.</param>
        /// <param name="historicWeeksWithZeroTransactions">historicWeeksWithZeroTransactions.</param>
        /// <param name="lastTransactionDate">lastTransactionDate.</param>
        /// <param name="netCashFlowByMonthForTheReportTimePeriod">netCashFlowByMonthForTheReportTimePeriod.</param>
        /// <param name="netCashFlowForTheReportTimePeriod">netCashFlowForTheReportTimePeriod.</param>
        public CashFlowTransactionAnalyticsAttributes(
            List<Models.CashFlowActivityDepositsCredits> activityDepositsCreditsForTheReportTimePeriod,
            List<Models.CashFlowActivityWithdrawalsDebits> activityWithdrawalsDebitsForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> averageTransactionValueByMonthForTheReportTimePeriod,
            Models.CashFlowNumWeeksZeros historicWeeksWithZeroTransactions = null,
            List<Models.LastTransactionDate> lastTransactionDate = null,
            List<Models.ObbDateRangeAndAmount> netCashFlowByMonthForTheReportTimePeriod = null,
            double? netCashFlowForTheReportTimePeriod = null)
        {
            this.ActivityDepositsCreditsForTheReportTimePeriod = activityDepositsCreditsForTheReportTimePeriod;
            this.ActivityWithdrawalsDebitsForTheReportTimePeriod = activityWithdrawalsDebitsForTheReportTimePeriod;
            this.AverageTransactionValueByMonthForTheReportTimePeriod = averageTransactionValueByMonthForTheReportTimePeriod;
            this.HistoricWeeksWithZeroTransactions = historicWeeksWithZeroTransactions;
            this.LastTransactionDate = lastTransactionDate;
            this.NetCashFlowByMonthForTheReportTimePeriod = netCashFlowByMonthForTheReportTimePeriod;
            this.NetCashFlowForTheReportTimePeriod = netCashFlowForTheReportTimePeriod;
        }

        /// <summary>
        /// List of all deposit transactions posted to the account during the report period
        /// </summary>
        [JsonProperty("activityDepositsCreditsForTheReportTimePeriod")]
        public List<Models.CashFlowActivityDepositsCredits> ActivityDepositsCreditsForTheReportTimePeriod { get; set; }

        /// <summary>
        /// List of all withdrawal transactions posted to the account during the report period
        /// </summary>
        [JsonProperty("activityWithdrawalsDebitsForTheReportTimePeriod")]
        public List<Models.CashFlowActivityWithdrawalsDebits> ActivityWithdrawalsDebitsForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Average value of transactions during periods in the report. Values may be positive or negative
        /// </summary>
        [JsonProperty("averageTransactionValueByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> AverageTransactionValueByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Details of weeks with zero transactions during the known history of the account
        /// </summary>
        [JsonProperty("historicWeeksWithZeroTransactions", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowNumWeeksZeros HistoricWeeksWithZeroTransactions { get; set; }

        /// <summary>
        /// Latest posted transaction(s) to the account. May be more than one if they share the same timestamp
        /// </summary>
        [JsonProperty("lastTransactionDate", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.LastTransactionDate> LastTransactionDate { get; set; }

        /// <summary>
        /// Net cash flow for each month during the report period
        /// </summary>
        [JsonProperty("netCashFlowByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> NetCashFlowByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Net cash flow during the report period (may be positive or negative)
        /// </summary>
        [JsonProperty("netCashFlowForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? NetCashFlowForTheReportTimePeriod { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowTransactionAnalyticsAttributes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowTransactionAnalyticsAttributes other &&
                ((this.ActivityDepositsCreditsForTheReportTimePeriod == null && other.ActivityDepositsCreditsForTheReportTimePeriod == null) || (this.ActivityDepositsCreditsForTheReportTimePeriod?.Equals(other.ActivityDepositsCreditsForTheReportTimePeriod) == true)) &&
                ((this.ActivityWithdrawalsDebitsForTheReportTimePeriod == null && other.ActivityWithdrawalsDebitsForTheReportTimePeriod == null) || (this.ActivityWithdrawalsDebitsForTheReportTimePeriod?.Equals(other.ActivityWithdrawalsDebitsForTheReportTimePeriod) == true)) &&
                ((this.AverageTransactionValueByMonthForTheReportTimePeriod == null && other.AverageTransactionValueByMonthForTheReportTimePeriod == null) || (this.AverageTransactionValueByMonthForTheReportTimePeriod?.Equals(other.AverageTransactionValueByMonthForTheReportTimePeriod) == true)) &&
                ((this.HistoricWeeksWithZeroTransactions == null && other.HistoricWeeksWithZeroTransactions == null) || (this.HistoricWeeksWithZeroTransactions?.Equals(other.HistoricWeeksWithZeroTransactions) == true)) &&
                ((this.LastTransactionDate == null && other.LastTransactionDate == null) || (this.LastTransactionDate?.Equals(other.LastTransactionDate) == true)) &&
                ((this.NetCashFlowByMonthForTheReportTimePeriod == null && other.NetCashFlowByMonthForTheReportTimePeriod == null) || (this.NetCashFlowByMonthForTheReportTimePeriod?.Equals(other.NetCashFlowByMonthForTheReportTimePeriod) == true)) &&
                ((this.NetCashFlowForTheReportTimePeriod == null && other.NetCashFlowForTheReportTimePeriod == null) || (this.NetCashFlowForTheReportTimePeriod?.Equals(other.NetCashFlowForTheReportTimePeriod) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ActivityDepositsCreditsForTheReportTimePeriod = {(this.ActivityDepositsCreditsForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.ActivityDepositsCreditsForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.ActivityWithdrawalsDebitsForTheReportTimePeriod = {(this.ActivityWithdrawalsDebitsForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.ActivityWithdrawalsDebitsForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.AverageTransactionValueByMonthForTheReportTimePeriod = {(this.AverageTransactionValueByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.AverageTransactionValueByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.HistoricWeeksWithZeroTransactions = {(this.HistoricWeeksWithZeroTransactions == null ? "null" : this.HistoricWeeksWithZeroTransactions.ToString())}");
            toStringOutput.Add($"this.LastTransactionDate = {(this.LastTransactionDate == null ? "null" : $"[{string.Join(", ", this.LastTransactionDate)} ]")}");
            toStringOutput.Add($"this.NetCashFlowByMonthForTheReportTimePeriod = {(this.NetCashFlowByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.NetCashFlowByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.NetCashFlowForTheReportTimePeriod = {(this.NetCashFlowForTheReportTimePeriod == null ? "null" : this.NetCashFlowForTheReportTimePeriod.ToString())}");
        }
    }
}