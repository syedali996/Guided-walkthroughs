// <copyright file="CashFlowAnalyticsMetrics.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowAnalyticsMetrics.
    /// </summary>
    public class CashFlowAnalyticsMetrics
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsMetrics"/> class.
        /// </summary>
        public CashFlowAnalyticsMetrics()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowAnalyticsMetrics"/> class.
        /// </summary>
        /// <param name="inflow">inflow.</param>
        /// <param name="negativeTriggers">negativeTriggers.</param>
        /// <param name="outflow">outflow.</param>
        /// <param name="revenueByMonthForTheReportTimePeriod">revenueByMonthForTheReportTimePeriod.</param>
        /// <param name="revenueForTheReportTimePeriod">revenueForTheReportTimePeriod.</param>
        /// <param name="transactionAnalytics">transactionAnalytics.</param>
        public CashFlowAnalyticsMetrics(
            Models.CashFlowInflowAttributes inflow = null,
            Models.CashFlowNegativeTriggers negativeTriggers = null,
            Models.CashFlowOutflowAttributes outflow = null,
            List<Models.ObbDateRangeAndAmount> revenueByMonthForTheReportTimePeriod = null,
            double? revenueForTheReportTimePeriod = null,
            Models.CashFlowTransactionAnalyticsAttributes transactionAnalytics = null)
        {
            this.Inflow = inflow;
            this.NegativeTriggers = negativeTriggers;
            this.Outflow = outflow;
            this.RevenueByMonthForTheReportTimePeriod = revenueByMonthForTheReportTimePeriod;
            this.RevenueForTheReportTimePeriod = revenueForTheReportTimePeriod;
            this.TransactionAnalytics = transactionAnalytics;
        }

        /// <summary>
        /// Inflow Attributes
        /// </summary>
        [JsonProperty("inflow", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowInflowAttributes Inflow { get; set; }

        /// <summary>
        /// Details of transactions that may be warning signs of bad creditworthiness
        /// </summary>
        [JsonProperty("negativeTriggers", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowNegativeTriggers NegativeTriggers { get; set; }

        /// <summary>
        /// Outflow attributes
        /// </summary>
        [JsonProperty("outflow", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowOutflowAttributes Outflow { get; set; }

        /// <summary>
        /// Sum of all transactions categorized as revenue, split by months
        /// </summary>
        [JsonProperty("revenueByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> RevenueByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Sum of all transactions categorized as revenue
        /// </summary>
        [JsonProperty("revenueForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public double? RevenueForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Transaction Analytics Attributes
        /// </summary>
        [JsonProperty("transactionAnalytics", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowTransactionAnalyticsAttributes TransactionAnalytics { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowAnalyticsMetrics : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowAnalyticsMetrics other &&
                ((this.Inflow == null && other.Inflow == null) || (this.Inflow?.Equals(other.Inflow) == true)) &&
                ((this.NegativeTriggers == null && other.NegativeTriggers == null) || (this.NegativeTriggers?.Equals(other.NegativeTriggers) == true)) &&
                ((this.Outflow == null && other.Outflow == null) || (this.Outflow?.Equals(other.Outflow) == true)) &&
                ((this.RevenueByMonthForTheReportTimePeriod == null && other.RevenueByMonthForTheReportTimePeriod == null) || (this.RevenueByMonthForTheReportTimePeriod?.Equals(other.RevenueByMonthForTheReportTimePeriod) == true)) &&
                ((this.RevenueForTheReportTimePeriod == null && other.RevenueForTheReportTimePeriod == null) || (this.RevenueForTheReportTimePeriod?.Equals(other.RevenueForTheReportTimePeriod) == true)) &&
                ((this.TransactionAnalytics == null && other.TransactionAnalytics == null) || (this.TransactionAnalytics?.Equals(other.TransactionAnalytics) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Inflow = {(this.Inflow == null ? "null" : this.Inflow.ToString())}");
            toStringOutput.Add($"this.NegativeTriggers = {(this.NegativeTriggers == null ? "null" : this.NegativeTriggers.ToString())}");
            toStringOutput.Add($"this.Outflow = {(this.Outflow == null ? "null" : this.Outflow.ToString())}");
            toStringOutput.Add($"this.RevenueByMonthForTheReportTimePeriod = {(this.RevenueByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.RevenueByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.RevenueForTheReportTimePeriod = {(this.RevenueForTheReportTimePeriod == null ? "null" : this.RevenueForTheReportTimePeriod.ToString())}");
            toStringOutput.Add($"this.TransactionAnalytics = {(this.TransactionAnalytics == null ? "null" : this.TransactionAnalytics.ToString())}");
        }
    }
}