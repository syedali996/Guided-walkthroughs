// <copyright file="ACHDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ACHDetails.
    /// </summary>
    public class ACHDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ACHDetails"/> class.
        /// </summary>
        public ACHDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ACHDetails"/> class.
        /// </summary>
        /// <param name="routingNumber">routingNumber.</param>
        /// <param name="realAccountNumber">realAccountNumber.</param>
        public ACHDetails(
            string routingNumber,
            string realAccountNumber)
        {
            this.RoutingNumber = routingNumber;
            this.RealAccountNumber = realAccountNumber;
        }

        /// <summary>
        /// The routing number of the financial institution for this specific customers account
        /// </summary>
        [JsonProperty("routingNumber")]
        public string RoutingNumber { get; set; }

        /// <summary>
        /// The account number for initiating ACH transfers for this account
        /// </summary>
        [JsonProperty("realAccountNumber")]
        public string RealAccountNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ACHDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ACHDetails other &&
                ((this.RoutingNumber == null && other.RoutingNumber == null) || (this.RoutingNumber?.Equals(other.RoutingNumber) == true)) &&
                ((this.RealAccountNumber == null && other.RealAccountNumber == null) || (this.RealAccountNumber?.Equals(other.RealAccountNumber) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RoutingNumber = {(this.RoutingNumber == null ? "null" : this.RoutingNumber == string.Empty ? "" : this.RoutingNumber)}");
            toStringOutput.Add($"this.RealAccountNumber = {(this.RealAccountNumber == null ? "null" : this.RealAccountNumber == string.Empty ? "" : this.RealAccountNumber)}");
        }
    }
}