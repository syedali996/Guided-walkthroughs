// <copyright file="PayStat.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayStat.
    /// </summary>
    public class PayStat
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayStat"/> class.
        /// </summary>
        public PayStat()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayStat"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="type">type.</param>
        /// <param name="description">description.</param>
        /// <param name="amountCurrent">amountCurrent.</param>
        /// <param name="amountYTD">amountYTD.</param>
        public PayStat(
            string name = null,
            string type = null,
            string description = null,
            double? amountCurrent = null,
            double? amountYTD = null)
        {
            this.Name = name;
            this.Type = type;
            this.Description = description;
            this.AmountCurrent = amountCurrent;
            this.AmountYTD = amountYTD;
        }

        /// <summary>
        /// The normalized category of the earnings with a number appended. The number is the will be the iterating number of the type's occurrence starting at one.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The categorization based on the earning line's description. Possible values:
        /// * "bereavement"
        /// * "bonus"
        /// * "commission"
        /// * "holiday"
        /// * "jury duty"
        /// * "overtime"
        /// * "pension"
        /// * "pto"
        /// * "regular"
        /// * "sick"
        /// * "tips"
        /// * "unknown"
        /// * "vacation"
        /// * "reimbursement"
        /// * "stock"
        /// * "benefit"
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// The earnings line's pay type description
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// The amount for the earning line paid out to the employee for the specified pay period.
        /// </summary>
        [JsonProperty("amountCurrent", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountCurrent { get; set; }

        /// <summary>
        /// The amount for the earning line being paid out to the employee for the current pay year.
        /// </summary>
        [JsonProperty("amountYTD", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountYTD { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayStat : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayStat other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.AmountCurrent == null && other.AmountCurrent == null) || (this.AmountCurrent?.Equals(other.AmountCurrent) == true)) &&
                ((this.AmountYTD == null && other.AmountYTD == null) || (this.AmountYTD?.Equals(other.AmountYTD) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.AmountCurrent = {(this.AmountCurrent == null ? "null" : this.AmountCurrent.ToString())}");
            toStringOutput.Add($"this.AmountYTD = {(this.AmountYTD == null ? "null" : this.AmountYTD.ToString())}");
        }
    }
}