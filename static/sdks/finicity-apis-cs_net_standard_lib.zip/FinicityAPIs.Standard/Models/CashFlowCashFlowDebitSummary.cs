// <copyright file="CashFlowCashFlowDebitSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowCashFlowDebitSummary.
    /// </summary>
    public class CashFlowCashFlowDebitSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowDebitSummary"/> class.
        /// </summary>
        public CashFlowCashFlowDebitSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowDebitSummary"/> class.
        /// </summary>
        /// <param name="monthlyCashFlowDebitSummaries">monthlyCashFlowDebitSummaries.</param>
        /// <param name="twelveMonthDebitTotal">twelveMonthDebitTotal.</param>
        /// <param name="twelveMonthDebitTotalLessTransfers">twelveMonthDebitTotalLessTransfers.</param>
        /// <param name="sixMonthDebitTotal">sixMonthDebitTotal.</param>
        /// <param name="sixMonthDebitTotalLessTransfers">sixMonthDebitTotalLessTransfers.</param>
        /// <param name="twoMonthDebitTotal">twoMonthDebitTotal.</param>
        /// <param name="twoMonthDebitTotalLessTransfers">twoMonthDebitTotalLessTransfers.</param>
        public CashFlowCashFlowDebitSummary(
            List<Models.CashFlowMonthlyCashFlowDebitSummaries> monthlyCashFlowDebitSummaries,
            double twelveMonthDebitTotal,
            double twelveMonthDebitTotalLessTransfers,
            double sixMonthDebitTotal,
            double sixMonthDebitTotalLessTransfers,
            double twoMonthDebitTotal,
            double twoMonthDebitTotalLessTransfers)
        {
            this.MonthlyCashFlowDebitSummaries = monthlyCashFlowDebitSummaries;
            this.TwelveMonthDebitTotal = twelveMonthDebitTotal;
            this.TwelveMonthDebitTotalLessTransfers = twelveMonthDebitTotalLessTransfers;
            this.SixMonthDebitTotal = sixMonthDebitTotal;
            this.SixMonthDebitTotalLessTransfers = sixMonthDebitTotalLessTransfers;
            this.TwoMonthDebitTotal = twoMonthDebitTotal;
            this.TwoMonthDebitTotalLessTransfers = twoMonthDebitTotalLessTransfers;
        }

        /// <summary>
        /// List of attributes for each month
        /// </summary>
        [JsonProperty("monthlyCashFlowDebitSummaries")]
        public List<Models.CashFlowMonthlyCashFlowDebitSummaries> MonthlyCashFlowDebitSummaries { get; set; }

        /// <summary>
        /// Sum of all monthly debit transactions for each month by account
        /// </summary>
        [JsonProperty("twelveMonthDebitTotal")]
        public double TwelveMonthDebitTotal { get; set; }

        /// <summary>
        /// Sum of all monthly debit transactions without transfers for the account
        /// </summary>
        [JsonProperty("twelveMonthDebitTotalLessTransfers")]
        public double TwelveMonthDebitTotalLessTransfers { get; set; }

        /// <summary>
        /// Six month sum of all debit transactions by account
        /// </summary>
        [JsonProperty("sixMonthDebitTotal")]
        public double SixMonthDebitTotal { get; set; }

        /// <summary>
        /// Six month sum of all debit transactions without transfers for the account
        /// </summary>
        [JsonProperty("sixMonthDebitTotalLessTransfers")]
        public double SixMonthDebitTotalLessTransfers { get; set; }

        /// <summary>
        /// Two month sum of all debit transactions by account
        /// </summary>
        [JsonProperty("twoMonthDebitTotal")]
        public double TwoMonthDebitTotal { get; set; }

        /// <summary>
        /// Two month sum of all debit transactions without transfers for the account
        /// </summary>
        [JsonProperty("twoMonthDebitTotalLessTransfers")]
        public double TwoMonthDebitTotalLessTransfers { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowCashFlowDebitSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowCashFlowDebitSummary other &&
                ((this.MonthlyCashFlowDebitSummaries == null && other.MonthlyCashFlowDebitSummaries == null) || (this.MonthlyCashFlowDebitSummaries?.Equals(other.MonthlyCashFlowDebitSummaries) == true)) &&
                this.TwelveMonthDebitTotal.Equals(other.TwelveMonthDebitTotal) &&
                this.TwelveMonthDebitTotalLessTransfers.Equals(other.TwelveMonthDebitTotalLessTransfers) &&
                this.SixMonthDebitTotal.Equals(other.SixMonthDebitTotal) &&
                this.SixMonthDebitTotalLessTransfers.Equals(other.SixMonthDebitTotalLessTransfers) &&
                this.TwoMonthDebitTotal.Equals(other.TwoMonthDebitTotal) &&
                this.TwoMonthDebitTotalLessTransfers.Equals(other.TwoMonthDebitTotalLessTransfers);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MonthlyCashFlowDebitSummaries = {(this.MonthlyCashFlowDebitSummaries == null ? "null" : $"[{string.Join(", ", this.MonthlyCashFlowDebitSummaries)} ]")}");
            toStringOutput.Add($"this.TwelveMonthDebitTotal = {this.TwelveMonthDebitTotal}");
            toStringOutput.Add($"this.TwelveMonthDebitTotalLessTransfers = {this.TwelveMonthDebitTotalLessTransfers}");
            toStringOutput.Add($"this.SixMonthDebitTotal = {this.SixMonthDebitTotal}");
            toStringOutput.Add($"this.SixMonthDebitTotalLessTransfers = {this.SixMonthDebitTotalLessTransfers}");
            toStringOutput.Add($"this.TwoMonthDebitTotal = {this.TwoMonthDebitTotal}");
            toStringOutput.Add($"this.TwoMonthDebitTotalLessTransfers = {this.TwoMonthDebitTotalLessTransfers}");
        }
    }
}