// <copyright file="PrequalificationReportAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PrequalificationReportAccount.
    /// </summary>
    public class PrequalificationReportAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportAccount"/> class.
        /// </summary>
        public PrequalificationReportAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportAccount"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="number">number.</param>
        /// <param name="ownerName">ownerName.</param>
        /// <param name="ownerAddress">ownerAddress.</param>
        /// <param name="name">name.</param>
        /// <param name="type">type.</param>
        /// <param name="aggregationStatusCode">aggregationStatusCode.</param>
        /// <param name="balance">balance.</param>
        /// <param name="balanceDate">balanceDate.</param>
        /// <param name="availableBalance">availableBalance.</param>
        /// <param name="averageMonthlyBalance">averageMonthlyBalance.</param>
        /// <param name="totNumberInsufficientFundsFeeDebitTxAccount">totNumberInsufficientFundsFeeDebitTxAccount.</param>
        /// <param name="totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount">totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount.</param>
        /// <param name="totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount">totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount.</param>
        /// <param name="transactions">transactions.</param>
        /// <param name="asset">asset.</param>
        /// <param name="details">details.</param>
        public PrequalificationReportAccount(
            long? id = null,
            string number = null,
            string ownerName = null,
            string ownerAddress = null,
            string name = null,
            string type = null,
            int? aggregationStatusCode = null,
            double? balance = null,
            long? balanceDate = null,
            double? availableBalance = null,
            double? averageMonthlyBalance = null,
            int? totNumberInsufficientFundsFeeDebitTxAccount = null,
            int? totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount = null,
            long? totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount = null,
            List<Models.ReportTransaction> transactions = null,
            Models.PrequalificationReportAssetSummary asset = null,
            Models.AccountDetails details = null)
        {
            this.Id = id;
            this.Number = number;
            this.OwnerName = ownerName;
            this.OwnerAddress = ownerAddress;
            this.Name = name;
            this.Type = type;
            this.AggregationStatusCode = aggregationStatusCode;
            this.Balance = balance;
            this.BalanceDate = balanceDate;
            this.AvailableBalance = availableBalance;
            this.AverageMonthlyBalance = averageMonthlyBalance;
            this.TotNumberInsufficientFundsFeeDebitTxAccount = totNumberInsufficientFundsFeeDebitTxAccount;
            this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount = totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount;
            this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount = totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount;
            this.Transactions = transactions;
            this.Asset = asset;
            this.Details = details;
        }

        /// <summary>
        /// The ID of the account
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// The account number from the institution (all digits except the last four are obfuscated)
        /// </summary>
        [JsonProperty("number", NullValueHandling = NullValueHandling.Ignore)]
        public string Number { get; set; }

        /// <summary>
        /// The name of the account owner. If no owner information is available, this field won't appear in the report.
        /// </summary>
        [JsonProperty("ownerName", NullValueHandling = NullValueHandling.Ignore)]
        public string OwnerName { get; set; }

        /// <summary>
        /// The mailing address of the account owner. If no owner information is available, this field won't appear in the report.
        /// </summary>
        [JsonProperty("ownerAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string OwnerAddress { get; set; }

        /// <summary>
        /// The account name from the institution
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// One of the values from account types
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// The status of the most recent aggregation attempt
        /// </summary>
        [JsonProperty("aggregationStatusCode", NullValueHandling = NullValueHandling.Ignore)]
        public int? AggregationStatusCode { get; set; }

        /// <summary>
        /// The cleared balance of the account as-of `balanceDate`
        /// </summary>
        [JsonProperty("balance", NullValueHandling = NullValueHandling.Ignore)]
        public double? Balance { get; set; }

        /// <summary>
        /// A timestamp of the balance
        /// </summary>
        [JsonProperty("balanceDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? BalanceDate { get; set; }

        /// <summary>
        /// Available balance
        /// </summary>
        [JsonProperty("availableBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AvailableBalance { get; set; }

        /// <summary>
        /// The average monthly balance of the account
        /// </summary>
        [JsonProperty("averageMonthlyBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AverageMonthlyBalance { get; set; }

        /// <summary>
        /// The count for the total number of insufficient funds transactions, based on the `fromDate` of the report
        /// </summary>
        [JsonProperty("totNumberInsufficientFundsFeeDebitTxAccount", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotNumberInsufficientFundsFeeDebitTxAccount { get; set; }

        /// <summary>
        /// The total number of  insufficient funds fees for the account over six months
        /// </summary>
        [JsonProperty("totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount { get; set; }

        /// <summary>
        /// The total number of days since the most recent insufficient funds fee for the account
        /// </summary>
        [JsonProperty("totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount", NullValueHandling = NullValueHandling.Ignore)]
        public long? TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount { get; set; }

        /// <summary>
        /// a list of transaction records
        /// </summary>
        [JsonProperty("transactions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportTransaction> Transactions { get; set; }

        /// <summary>
        /// Gets or sets Asset.
        /// </summary>
        [JsonProperty("asset", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PrequalificationReportAssetSummary Asset { get; set; }

        /// <summary>
        /// Gets or sets Details.
        /// </summary>
        [JsonProperty("details", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AccountDetails Details { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrequalificationReportAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrequalificationReportAccount other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Number == null && other.Number == null) || (this.Number?.Equals(other.Number) == true)) &&
                ((this.OwnerName == null && other.OwnerName == null) || (this.OwnerName?.Equals(other.OwnerName) == true)) &&
                ((this.OwnerAddress == null && other.OwnerAddress == null) || (this.OwnerAddress?.Equals(other.OwnerAddress) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.AggregationStatusCode == null && other.AggregationStatusCode == null) || (this.AggregationStatusCode?.Equals(other.AggregationStatusCode) == true)) &&
                ((this.Balance == null && other.Balance == null) || (this.Balance?.Equals(other.Balance) == true)) &&
                ((this.BalanceDate == null && other.BalanceDate == null) || (this.BalanceDate?.Equals(other.BalanceDate) == true)) &&
                ((this.AvailableBalance == null && other.AvailableBalance == null) || (this.AvailableBalance?.Equals(other.AvailableBalance) == true)) &&
                ((this.AverageMonthlyBalance == null && other.AverageMonthlyBalance == null) || (this.AverageMonthlyBalance?.Equals(other.AverageMonthlyBalance) == true)) &&
                ((this.TotNumberInsufficientFundsFeeDebitTxAccount == null && other.TotNumberInsufficientFundsFeeDebitTxAccount == null) || (this.TotNumberInsufficientFundsFeeDebitTxAccount?.Equals(other.TotNumberInsufficientFundsFeeDebitTxAccount) == true)) &&
                ((this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount == null && other.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount == null) || (this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount?.Equals(other.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount) == true)) &&
                ((this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount == null && other.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount == null) || (this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount?.Equals(other.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount) == true)) &&
                ((this.Transactions == null && other.Transactions == null) || (this.Transactions?.Equals(other.Transactions) == true)) &&
                ((this.Asset == null && other.Asset == null) || (this.Asset?.Equals(other.Asset) == true)) &&
                ((this.Details == null && other.Details == null) || (this.Details?.Equals(other.Details) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Number = {(this.Number == null ? "null" : this.Number == string.Empty ? "" : this.Number)}");
            toStringOutput.Add($"this.OwnerName = {(this.OwnerName == null ? "null" : this.OwnerName == string.Empty ? "" : this.OwnerName)}");
            toStringOutput.Add($"this.OwnerAddress = {(this.OwnerAddress == null ? "null" : this.OwnerAddress == string.Empty ? "" : this.OwnerAddress)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.AggregationStatusCode = {(this.AggregationStatusCode == null ? "null" : this.AggregationStatusCode.ToString())}");
            toStringOutput.Add($"this.Balance = {(this.Balance == null ? "null" : this.Balance.ToString())}");
            toStringOutput.Add($"this.BalanceDate = {(this.BalanceDate == null ? "null" : this.BalanceDate.ToString())}");
            toStringOutput.Add($"this.AvailableBalance = {(this.AvailableBalance == null ? "null" : this.AvailableBalance.ToString())}");
            toStringOutput.Add($"this.AverageMonthlyBalance = {(this.AverageMonthlyBalance == null ? "null" : this.AverageMonthlyBalance.ToString())}");
            toStringOutput.Add($"this.TotNumberInsufficientFundsFeeDebitTxAccount = {(this.TotNumberInsufficientFundsFeeDebitTxAccount == null ? "null" : this.TotNumberInsufficientFundsFeeDebitTxAccount.ToString())}");
            toStringOutput.Add($"this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount = {(this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount == null ? "null" : this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount.ToString())}");
            toStringOutput.Add($"this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount = {(this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount == null ? "null" : this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount.ToString())}");
            toStringOutput.Add($"this.Transactions = {(this.Transactions == null ? "null" : $"[{string.Join(", ", this.Transactions)} ]")}");
            toStringOutput.Add($"this.Asset = {(this.Asset == null ? "null" : this.Asset.ToString())}");
            toStringOutput.Add($"this.Details = {(this.Details == null ? "null" : this.Details.ToString())}");
        }
    }
}