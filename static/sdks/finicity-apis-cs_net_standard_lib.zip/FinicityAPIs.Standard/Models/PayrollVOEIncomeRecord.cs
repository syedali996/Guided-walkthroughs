// <copyright file="PayrollVOEIncomeRecord.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollVOEIncomeRecord.
    /// </summary>
    public class PayrollVOEIncomeRecord
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollVOEIncomeRecord"/> class.
        /// </summary>
        public PayrollVOEIncomeRecord()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollVOEIncomeRecord"/> class.
        /// </summary>
        /// <param name="payFrequency">payFrequency.</param>
        public PayrollVOEIncomeRecord(
            string payFrequency)
        {
            this.PayFrequency = payFrequency;
        }

        /// <summary>
        /// The current pay frequency: <br> * `Daily` <br> * `Weekly` <br> * `Bi-Weekly` <br> * `Bi-Weekly Odd` (Bi-Weekly pay on odd weeks) <br> * `Bi-Weekly Even` (Bi-Weekly pay on even weeks) <br> * `Semi-Monthly` <br> * `Monthly` <br> * `Quarterly` <br>* `Semi-Annual` <br> * `Annual` <br>  * `Every 2.6 wks` <br> * `Every 4 wks` <br> * `Every 5.2 wks`
        /// </summary>
        [JsonProperty("payFrequency")]
        public string PayFrequency { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollVOEIncomeRecord : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollVOEIncomeRecord other &&
                ((this.PayFrequency == null && other.PayFrequency == null) || (this.PayFrequency?.Equals(other.PayFrequency) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PayFrequency = {(this.PayFrequency == null ? "null" : this.PayFrequency == string.Empty ? "" : this.PayFrequency)}");
        }
    }
}