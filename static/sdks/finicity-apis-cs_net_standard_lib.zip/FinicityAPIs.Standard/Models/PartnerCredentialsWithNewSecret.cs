// <copyright file="PartnerCredentialsWithNewSecret.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PartnerCredentialsWithNewSecret.
    /// </summary>
    public class PartnerCredentialsWithNewSecret
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PartnerCredentialsWithNewSecret"/> class.
        /// </summary>
        public PartnerCredentialsWithNewSecret()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PartnerCredentialsWithNewSecret"/> class.
        /// </summary>
        /// <param name="partnerId">partnerId.</param>
        /// <param name="partnerSecret">partnerSecret.</param>
        /// <param name="newPartnerSecret">newPartnerSecret.</param>
        public PartnerCredentialsWithNewSecret(
            string partnerId,
            string partnerSecret,
            string newPartnerSecret)
        {
            this.PartnerId = partnerId;
            this.PartnerSecret = partnerSecret;
            this.NewPartnerSecret = newPartnerSecret;
        }

        /// <summary>
        /// Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerId")]
        public string PartnerId { get; set; }

        /// <summary>
        /// Your Partner Secret displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerSecret")]
        public string PartnerSecret { get; set; }

        /// <summary>
        /// A new value for the Partner Secret
        /// </summary>
        [JsonProperty("newPartnerSecret")]
        public string NewPartnerSecret { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PartnerCredentialsWithNewSecret : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PartnerCredentialsWithNewSecret other &&
                ((this.PartnerId == null && other.PartnerId == null) || (this.PartnerId?.Equals(other.PartnerId) == true)) &&
                ((this.PartnerSecret == null && other.PartnerSecret == null) || (this.PartnerSecret?.Equals(other.PartnerSecret) == true)) &&
                ((this.NewPartnerSecret == null && other.NewPartnerSecret == null) || (this.NewPartnerSecret?.Equals(other.NewPartnerSecret) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PartnerId = {(this.PartnerId == null ? "null" : this.PartnerId == string.Empty ? "" : this.PartnerId)}");
            toStringOutput.Add($"this.PartnerSecret = {(this.PartnerSecret == null ? "null" : this.PartnerSecret == string.Empty ? "" : this.PartnerSecret)}");
            toStringOutput.Add($"this.NewPartnerSecret = {(this.NewPartnerSecret == null ? "null" : this.NewPartnerSecret == string.Empty ? "" : this.NewPartnerSecret)}");
        }
    }
}