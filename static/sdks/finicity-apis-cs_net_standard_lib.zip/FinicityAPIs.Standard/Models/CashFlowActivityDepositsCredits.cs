// <copyright file="CashFlowActivityDepositsCredits.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowActivityDepositsCredits.
    /// </summary>
    public class CashFlowActivityDepositsCredits
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowActivityDepositsCredits"/> class.
        /// </summary>
        public CashFlowActivityDepositsCredits()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowActivityDepositsCredits"/> class.
        /// </summary>
        /// <param name="date">date.</param>
        /// <param name="depositsCredits">depositsCredits.</param>
        /// <param name="transactionDescription">transactionDescription.</param>
        public CashFlowActivityDepositsCredits(
            string date,
            double depositsCredits,
            string transactionDescription = null)
        {
            this.Date = date;
            this.DepositsCredits = depositsCredits;
            this.TransactionDescription = transactionDescription;
        }

        /// <summary>
        /// Date the deposit transaction was posted
        /// </summary>
        [JsonProperty("date")]
        public string Date { get; set; }

        /// <summary>
        /// Amount of the deposit
        /// </summary>
        [JsonProperty("depositsCredits")]
        public double DepositsCredits { get; set; }

        /// <summary>
        /// Description of transaction
        /// </summary>
        [JsonProperty("transactionDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowActivityDepositsCredits : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowActivityDepositsCredits other &&
                ((this.Date == null && other.Date == null) || (this.Date?.Equals(other.Date) == true)) &&
                this.DepositsCredits.Equals(other.DepositsCredits) &&
                ((this.TransactionDescription == null && other.TransactionDescription == null) || (this.TransactionDescription?.Equals(other.TransactionDescription) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Date = {(this.Date == null ? "null" : this.Date == string.Empty ? "" : this.Date)}");
            toStringOutput.Add($"this.DepositsCredits = {this.DepositsCredits}");
            toStringOutput.Add($"this.TransactionDescription = {(this.TransactionDescription == null ? "null" : this.TransactionDescription == string.Empty ? "" : this.TransactionDescription)}");
        }
    }
}