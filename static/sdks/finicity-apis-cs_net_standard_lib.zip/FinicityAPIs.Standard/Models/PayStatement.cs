// <copyright file="PayStatement.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayStatement.
    /// </summary>
    public class PayStatement
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayStatement"/> class.
        /// </summary>
        public PayStatement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayStatement"/> class.
        /// </summary>
        /// <param name="label">label.</param>
        /// <param name="statement">statement.</param>
        public PayStatement(
            string label,
            string statement)
        {
            this.Label = label;
            this.Statement = statement;
        }

        /// <summary>
        /// The label to be associated with the pay statement. This label will allow the paystub to go through data extraction.
        /// * `lastPayPeriod`: default label that should be used for the VOIE - Paystub products
        /// * `lastPayPeriodMinusOne`: the second most recent pay statement
        /// * `lastPayPeriodMinusTwo`: the third most recent pay statement
        /// * `previousYearLastPayPeriod` Last pay statement of the previous calendar year
        /// * `previousYear2LastPayPeriod`: last pay statement of the calendar year 2 years prior
        /// * `earliestPayPeriod`: the earliest pay statement
        /// </summary>
        [JsonProperty("label")]
        public string Label { get; set; }

        /// <summary>
        /// A Base64 encoded pay statement file. Finicity supports PDF, JPG, or PNG files.
        /// </summary>
        [JsonProperty("statement")]
        public string Statement { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayStatement : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayStatement other &&
                ((this.Label == null && other.Label == null) || (this.Label?.Equals(other.Label) == true)) &&
                ((this.Statement == null && other.Statement == null) || (this.Statement?.Equals(other.Statement) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Label = {(this.Label == null ? "null" : this.Label == string.Empty ? "" : this.Label)}");
            toStringOutput.Add($"this.Statement = {(this.Statement == null ? "null" : this.Statement == string.Empty ? "" : this.Statement)}");
        }
    }
}