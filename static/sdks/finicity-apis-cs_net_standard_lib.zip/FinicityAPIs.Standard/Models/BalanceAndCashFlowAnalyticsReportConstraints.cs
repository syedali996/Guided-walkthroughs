// <copyright file="BalanceAndCashFlowAnalyticsReportConstraints.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BalanceAndCashFlowAnalyticsReportConstraints.
    /// </summary>
    public class BalanceAndCashFlowAnalyticsReportConstraints
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAndCashFlowAnalyticsReportConstraints"/> class.
        /// </summary>
        public BalanceAndCashFlowAnalyticsReportConstraints()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAndCashFlowAnalyticsReportConstraints"/> class.
        /// </summary>
        /// <param name="accountIds">accountIds.</param>
        /// <param name="lengthOfReport">lengthOfReport.</param>
        public BalanceAndCashFlowAnalyticsReportConstraints(
            List<long> accountIds = null,
            int? lengthOfReport = null)
        {
            this.AccountIds = accountIds;
            this.LengthOfReport = lengthOfReport;
        }

        /// <summary>
        /// The list of account IDs to include in the report. If omitted, all accounts on record for the customer will be used.
        /// </summary>
        [JsonProperty("accountIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> AccountIds { get; set; }

        /// <summary>
        /// Number of days to search for transactions. Must be one of 30, 90, 180, 270, 365, or 730. If omitted, defaults to 2 years from current time at which the request was received (730 days).
        /// </summary>
        [JsonProperty("lengthOfReport", NullValueHandling = NullValueHandling.Ignore)]
        public int? LengthOfReport { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BalanceAndCashFlowAnalyticsReportConstraints : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BalanceAndCashFlowAnalyticsReportConstraints other &&
                ((this.AccountIds == null && other.AccountIds == null) || (this.AccountIds?.Equals(other.AccountIds) == true)) &&
                ((this.LengthOfReport == null && other.LengthOfReport == null) || (this.LengthOfReport?.Equals(other.LengthOfReport) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountIds = {(this.AccountIds == null ? "null" : $"[{string.Join(", ", this.AccountIds)} ]")}");
            toStringOutput.Add($"this.LengthOfReport = {(this.LengthOfReport == null ? "null" : this.LengthOfReport.ToString())}");
        }
    }
}