// <copyright file="ObbAccountDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbAccountDetails.
    /// </summary>
    public class ObbAccountDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbAccountDetails"/> class.
        /// </summary>
        public ObbAccountDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbAccountDetails"/> class.
        /// </summary>
        /// <param name="accountOwner">accountOwner.</param>
        /// <param name="id">id.</param>
        /// <param name="institution">institution.</param>
        /// <param name="accountNumberDisplay">accountNumberDisplay.</param>
        /// <param name="aggregationAttemptDate">aggregationAttemptDate.</param>
        /// <param name="aggregationStatusCode">aggregationStatusCode.</param>
        /// <param name="aggregationSuccessDate">aggregationSuccessDate.</param>
        /// <param name="currency">currency.</param>
        /// <param name="currentBalance">currentBalance.</param>
        /// <param name="institutionLoginId">institutionLoginId.</param>
        /// <param name="name">name.</param>
        /// <param name="realAccountNumberLast4">realAccountNumberLast4.</param>
        /// <param name="status">status.</param>
        /// <param name="type">type.</param>
        public ObbAccountDetails(
            Models.ObbAccountOwner accountOwner,
            long id,
            Models.ObbInstitution institution,
            string accountNumberDisplay = null,
            string aggregationAttemptDate = null,
            int? aggregationStatusCode = null,
            string aggregationSuccessDate = null,
            string currency = null,
            double? currentBalance = null,
            long? institutionLoginId = null,
            string name = null,
            int? realAccountNumberLast4 = null,
            string status = null,
            string type = null)
        {
            this.AccountNumberDisplay = accountNumberDisplay;
            this.AccountOwner = accountOwner;
            this.AggregationAttemptDate = aggregationAttemptDate;
            this.AggregationStatusCode = aggregationStatusCode;
            this.AggregationSuccessDate = aggregationSuccessDate;
            this.Currency = currency;
            this.CurrentBalance = currentBalance;
            this.Id = id;
            this.Institution = institution;
            this.InstitutionLoginId = institutionLoginId;
            this.Name = name;
            this.RealAccountNumberLast4 = realAccountNumberLast4;
            this.Status = status;
            this.Type = type;
        }

        /// <summary>
        /// The account number from a financial institution in truncated format
        /// </summary>
        [JsonProperty("accountNumberDisplay", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountNumberDisplay { get; set; }

        /// <summary>
        /// Details about who is on record as the owner of the account. May be the business name, the business owner name, or otherwise
        /// </summary>
        [JsonProperty("accountOwner")]
        public Models.ObbAccountOwner AccountOwner { get; set; }

        /// <summary>
        /// A timestamp showing the last aggregation attempt. This will not be present until you have run your first aggregation for the account.
        /// </summary>
        [JsonProperty("aggregationAttemptDate", NullValueHandling = NullValueHandling.Ignore)]
        public string AggregationAttemptDate { get; set; }

        /// <summary>
        /// The status of the most recent aggregation attempt. This will not be present until you have run your first aggregation for the account
        /// </summary>
        [JsonProperty("aggregationStatusCode", NullValueHandling = NullValueHandling.Ignore)]
        public int? AggregationStatusCode { get; set; }

        /// <summary>
        /// A timestamp showing the last successful aggregation of the account. This will not be present until you have run your first aggregation for the account.
        /// </summary>
        [JsonProperty("aggregationSuccessDate", NullValueHandling = NullValueHandling.Ignore)]
        public string AggregationSuccessDate { get; set; }

        /// <summary>
        /// The currency of the account
        /// </summary>
        [JsonProperty("currency", NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; }

        /// <summary>
        /// Current reported balance of the account
        /// </summary>
        [JsonProperty("currentBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentBalance { get; set; }

        /// <summary>
        /// An account ID represented as a number
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// Details of the financial institution this account is home to
        /// </summary>
        [JsonProperty("institution")]
        public Models.ObbInstitution Institution { get; set; }

        /// <summary>
        /// An institution login ID (from the account record), represented as a number
        /// </summary>
        [JsonProperty("institutionLoginId", NullValueHandling = NullValueHandling.Ignore)]
        public long? InstitutionLoginId { get; set; }

        /// <summary>
        /// The account name from the institution
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The last 4 digits of the ACH account number
        /// </summary>
        [JsonProperty("realAccountNumberLast4", NullValueHandling = NullValueHandling.Ignore)]
        public int? RealAccountNumberLast4 { get; set; }

        /// <summary>
        /// pending during account discovery, always active following successful account activation
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// Account type, e.g. checking/saving
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbAccountDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbAccountDetails other &&
                ((this.AccountNumberDisplay == null && other.AccountNumberDisplay == null) || (this.AccountNumberDisplay?.Equals(other.AccountNumberDisplay) == true)) &&
                ((this.AccountOwner == null && other.AccountOwner == null) || (this.AccountOwner?.Equals(other.AccountOwner) == true)) &&
                ((this.AggregationAttemptDate == null && other.AggregationAttemptDate == null) || (this.AggregationAttemptDate?.Equals(other.AggregationAttemptDate) == true)) &&
                ((this.AggregationStatusCode == null && other.AggregationStatusCode == null) || (this.AggregationStatusCode?.Equals(other.AggregationStatusCode) == true)) &&
                ((this.AggregationSuccessDate == null && other.AggregationSuccessDate == null) || (this.AggregationSuccessDate?.Equals(other.AggregationSuccessDate) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.CurrentBalance == null && other.CurrentBalance == null) || (this.CurrentBalance?.Equals(other.CurrentBalance) == true)) &&
                this.Id.Equals(other.Id) &&
                ((this.Institution == null && other.Institution == null) || (this.Institution?.Equals(other.Institution) == true)) &&
                ((this.InstitutionLoginId == null && other.InstitutionLoginId == null) || (this.InstitutionLoginId?.Equals(other.InstitutionLoginId) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.RealAccountNumberLast4 == null && other.RealAccountNumberLast4 == null) || (this.RealAccountNumberLast4?.Equals(other.RealAccountNumberLast4) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountNumberDisplay = {(this.AccountNumberDisplay == null ? "null" : this.AccountNumberDisplay == string.Empty ? "" : this.AccountNumberDisplay)}");
            toStringOutput.Add($"this.AccountOwner = {(this.AccountOwner == null ? "null" : this.AccountOwner.ToString())}");
            toStringOutput.Add($"this.AggregationAttemptDate = {(this.AggregationAttemptDate == null ? "null" : this.AggregationAttemptDate == string.Empty ? "" : this.AggregationAttemptDate)}");
            toStringOutput.Add($"this.AggregationStatusCode = {(this.AggregationStatusCode == null ? "null" : this.AggregationStatusCode.ToString())}");
            toStringOutput.Add($"this.AggregationSuccessDate = {(this.AggregationSuccessDate == null ? "null" : this.AggregationSuccessDate == string.Empty ? "" : this.AggregationSuccessDate)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.CurrentBalance = {(this.CurrentBalance == null ? "null" : this.CurrentBalance.ToString())}");
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.Institution = {(this.Institution == null ? "null" : this.Institution.ToString())}");
            toStringOutput.Add($"this.InstitutionLoginId = {(this.InstitutionLoginId == null ? "null" : this.InstitutionLoginId.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.RealAccountNumberLast4 = {(this.RealAccountNumberLast4 == null ? "null" : this.RealAccountNumberLast4.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
        }
    }
}