// <copyright file="LoanPaymentDetailsGroup.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// LoanPaymentDetailsGroup.
    /// </summary>
    public class LoanPaymentDetailsGroup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetailsGroup"/> class.
        /// </summary>
        public LoanPaymentDetailsGroup()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetailsGroup"/> class.
        /// </summary>
        /// <param name="accountId">accountId.</param>
        /// <param name="groupNumber">groupNumber.</param>
        /// <param name="groupPaymentNumber">groupPaymentNumber.</param>
        /// <param name="groupPaymentAddress">groupPaymentAddress.</param>
        /// <param name="groupLoanDetail">groupLoanDetail.</param>
        /// <param name="groupFuturePayoffAmount">groupFuturePayoffAmount.</param>
        /// <param name="groupFuturePayoffDate">groupFuturePayoffDate.</param>
        public LoanPaymentDetailsGroup(
            string accountId,
            string groupNumber,
            string groupPaymentNumber,
            string groupPaymentAddress,
            List<Models.LoanPaymentDetailsLoan> groupLoanDetail,
            double? groupFuturePayoffAmount = null,
            DateTime? groupFuturePayoffDate = null)
        {
            this.AccountId = accountId;
            this.GroupNumber = groupNumber;
            this.GroupPaymentNumber = groupPaymentNumber;
            this.GroupPaymentAddress = groupPaymentAddress;
            this.GroupFuturePayoffAmount = groupFuturePayoffAmount;
            this.GroupFuturePayoffDate = groupFuturePayoffDate;
            this.GroupLoanDetail = groupLoanDetail;
        }

        /// <summary>
        /// An account ID
        /// </summary>
        [JsonProperty("accountId")]
        public string AccountId { get; set; }

        /// <summary>
        /// Institution's ID of the Student Loan Group
        /// </summary>
        [JsonProperty("groupNumber")]
        public string GroupNumber { get; set; }

        /// <summary>
        /// The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number.
        /// </summary>
        [JsonProperty("groupPaymentNumber")]
        public string GroupPaymentNumber { get; set; }

        /// <summary>
        /// The payment address to which send manual payments should be sent
        /// </summary>
        [JsonProperty("groupPaymentAddress")]
        public string GroupPaymentAddress { get; set; }

        /// <summary>
        /// The payoff amount for the group
        /// </summary>
        [JsonProperty("groupFuturePayoffAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? GroupFuturePayoffAmount { get; set; }

        /// <summary>
        /// The date to which the "Future Payoff Amount" applies
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("groupFuturePayoffDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? GroupFuturePayoffDate { get; set; }

        /// <summary>
        /// Gets or sets GroupLoanDetail.
        /// </summary>
        [JsonProperty("groupLoanDetail")]
        public List<Models.LoanPaymentDetailsLoan> GroupLoanDetail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LoanPaymentDetailsGroup : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LoanPaymentDetailsGroup other &&
                ((this.AccountId == null && other.AccountId == null) || (this.AccountId?.Equals(other.AccountId) == true)) &&
                ((this.GroupNumber == null && other.GroupNumber == null) || (this.GroupNumber?.Equals(other.GroupNumber) == true)) &&
                ((this.GroupPaymentNumber == null && other.GroupPaymentNumber == null) || (this.GroupPaymentNumber?.Equals(other.GroupPaymentNumber) == true)) &&
                ((this.GroupPaymentAddress == null && other.GroupPaymentAddress == null) || (this.GroupPaymentAddress?.Equals(other.GroupPaymentAddress) == true)) &&
                ((this.GroupFuturePayoffAmount == null && other.GroupFuturePayoffAmount == null) || (this.GroupFuturePayoffAmount?.Equals(other.GroupFuturePayoffAmount) == true)) &&
                ((this.GroupFuturePayoffDate == null && other.GroupFuturePayoffDate == null) || (this.GroupFuturePayoffDate?.Equals(other.GroupFuturePayoffDate) == true)) &&
                ((this.GroupLoanDetail == null && other.GroupLoanDetail == null) || (this.GroupLoanDetail?.Equals(other.GroupLoanDetail) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountId = {(this.AccountId == null ? "null" : this.AccountId == string.Empty ? "" : this.AccountId)}");
            toStringOutput.Add($"this.GroupNumber = {(this.GroupNumber == null ? "null" : this.GroupNumber == string.Empty ? "" : this.GroupNumber)}");
            toStringOutput.Add($"this.GroupPaymentNumber = {(this.GroupPaymentNumber == null ? "null" : this.GroupPaymentNumber == string.Empty ? "" : this.GroupPaymentNumber)}");
            toStringOutput.Add($"this.GroupPaymentAddress = {(this.GroupPaymentAddress == null ? "null" : this.GroupPaymentAddress == string.Empty ? "" : this.GroupPaymentAddress)}");
            toStringOutput.Add($"this.GroupFuturePayoffAmount = {(this.GroupFuturePayoffAmount == null ? "null" : this.GroupFuturePayoffAmount.ToString())}");
            toStringOutput.Add($"this.GroupFuturePayoffDate = {(this.GroupFuturePayoffDate == null ? "null" : this.GroupFuturePayoffDate.ToString())}");
            toStringOutput.Add($"this.GroupLoanDetail = {(this.GroupLoanDetail == null ? "null" : $"[{string.Join(", ", this.GroupLoanDetail)} ]")}");
        }
    }
}