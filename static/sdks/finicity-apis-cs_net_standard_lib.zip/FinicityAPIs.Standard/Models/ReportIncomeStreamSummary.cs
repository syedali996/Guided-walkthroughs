// <copyright file="ReportIncomeStreamSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReportIncomeStreamSummary.
    /// </summary>
    public class ReportIncomeStreamSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportIncomeStreamSummary"/> class.
        /// </summary>
        public ReportIncomeStreamSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportIncomeStreamSummary"/> class.
        /// </summary>
        /// <param name="confidenceType">confidenceType.</param>
        /// <param name="netMonthly">netMonthly.</param>
        /// <param name="incomeEstimate">incomeEstimate.</param>
        public ReportIncomeStreamSummary(
            string confidenceType,
            List<Models.NetMonthly> netMonthly,
            Models.ReportIncomeEstimate incomeEstimate)
        {
            this.ConfidenceType = confidenceType;
            this.NetMonthly = netMonthly;
            this.IncomeEstimate = incomeEstimate;
        }

        /// <summary>
        /// Possible values: "HIGH", "MODERATE", "LOW", "NO"
        /// </summary>
        [JsonProperty("confidenceType")]
        public string ConfidenceType { get; set; }

        /// <summary>
        /// Gets or sets NetMonthly.
        /// </summary>
        [JsonProperty("netMonthly")]
        public List<Models.NetMonthly> NetMonthly { get; set; }

        /// <summary>
        /// Gets or sets IncomeEstimate.
        /// </summary>
        [JsonProperty("incomeEstimate")]
        public Models.ReportIncomeEstimate IncomeEstimate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReportIncomeStreamSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReportIncomeStreamSummary other &&
                ((this.ConfidenceType == null && other.ConfidenceType == null) || (this.ConfidenceType?.Equals(other.ConfidenceType) == true)) &&
                ((this.NetMonthly == null && other.NetMonthly == null) || (this.NetMonthly?.Equals(other.NetMonthly) == true)) &&
                ((this.IncomeEstimate == null && other.IncomeEstimate == null) || (this.IncomeEstimate?.Equals(other.IncomeEstimate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ConfidenceType = {(this.ConfidenceType == null ? "null" : this.ConfidenceType == string.Empty ? "" : this.ConfidenceType)}");
            toStringOutput.Add($"this.NetMonthly = {(this.NetMonthly == null ? "null" : $"[{string.Join(", ", this.NetMonthly)} ]")}");
            toStringOutput.Add($"this.IncomeEstimate = {(this.IncomeEstimate == null ? "null" : this.IncomeEstimate.ToString())}");
        }
    }
}