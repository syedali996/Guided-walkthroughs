// <copyright file="StatementReportConstraints.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// StatementReportConstraints.
    /// </summary>
    public class StatementReportConstraints
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatementReportConstraints"/> class.
        /// </summary>
        public StatementReportConstraints()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="StatementReportConstraints"/> class.
        /// </summary>
        /// <param name="statementReportData">statementReportData.</param>
        /// <param name="reportCustomFields">reportCustomFields.</param>
        public StatementReportConstraints(
            Models.StatementData statementReportData,
            List<Models.ReportCustomField> reportCustomFields = null)
        {
            this.StatementReportData = statementReportData;
            this.ReportCustomFields = reportCustomFields;
        }

        /// <summary>
        /// Gets or sets StatementReportData.
        /// </summary>
        [JsonProperty("statementReportData")]
        public Models.StatementData StatementReportData { get; set; }

        /// <summary>
        /// The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.
        /// Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".
        /// * "true": (default) display the custom field in the PDF report
        /// * "false": don't display the custom field in the PDF report
        /// For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.
        /// All custom fields display in the Reseller Billing API.
        /// </summary>
        [JsonProperty("reportCustomFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportCustomField> ReportCustomFields { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"StatementReportConstraints : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is StatementReportConstraints other &&
                ((this.StatementReportData == null && other.StatementReportData == null) || (this.StatementReportData?.Equals(other.StatementReportData) == true)) &&
                ((this.ReportCustomFields == null && other.ReportCustomFields == null) || (this.ReportCustomFields?.Equals(other.ReportCustomFields) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StatementReportData = {(this.StatementReportData == null ? "null" : this.StatementReportData.ToString())}");
            toStringOutput.Add($"this.ReportCustomFields = {(this.ReportCustomFields == null ? "null" : $"[{string.Join(", ", this.ReportCustomFields)} ]")}");
        }
    }
}