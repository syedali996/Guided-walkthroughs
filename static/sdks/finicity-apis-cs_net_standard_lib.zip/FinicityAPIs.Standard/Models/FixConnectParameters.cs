// <copyright file="FixConnectParameters.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// FixConnectParameters.
    /// </summary>
    public class FixConnectParameters
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FixConnectParameters"/> class.
        /// </summary>
        public FixConnectParameters()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FixConnectParameters"/> class.
        /// </summary>
        /// <param name="partnerId">partnerId.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="institutionLoginId">institutionLoginId.</param>
        /// <param name="language">language.</param>
        /// <param name="redirectUri">redirectUri.</param>
        /// <param name="webhook">webhook.</param>
        /// <param name="webhookContentType">webhookContentType.</param>
        /// <param name="webhookData">webhookData.</param>
        /// <param name="webhookHeaders">webhookHeaders.</param>
        /// <param name="experience">experience.</param>
        /// <param name="singleUseUrl">singleUseUrl.</param>
        public FixConnectParameters(
            string partnerId,
            string customerId,
            string institutionLoginId,
            string language = null,
            string redirectUri = null,
            string webhook = null,
            string webhookContentType = "application/json",
            object webhookData = null,
            object webhookHeaders = null,
            string experience = null,
            bool? singleUseUrl = null)
        {
            this.Language = language;
            this.PartnerId = partnerId;
            this.CustomerId = customerId;
            this.InstitutionLoginId = institutionLoginId;
            this.RedirectUri = redirectUri;
            this.Webhook = webhook;
            this.WebhookContentType = webhookContentType;
            this.WebhookData = webhookData;
            this.WebhookHeaders = webhookHeaders;
            this.Experience = experience;
            this.SingleUseUrl = singleUseUrl;
        }

        /// <summary>
        /// Generate a translated Connect URL link.
        /// Supported languages:
        /// * English (default)
        /// * Spanish (United States): `es`
        /// * French (Canada): `fr` or `fr-CA`
        /// </summary>
        [JsonProperty("language", NullValueHandling = NullValueHandling.Ignore)]
        public string Language { get; set; }

        /// <summary>
        /// Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerId")]
        public string PartnerId { get; set; }

        /// <summary>
        /// A customer ID. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }

        /// <summary>
        /// An institution login ID (from the account record)
        /// </summary>
        [JsonProperty("institutionLoginId")]
        public string InstitutionLoginId { get; set; }

        /// <summary>
        /// The URL that customers will be redirected to after completing Finicity Connect. Required unless Connect is embedded inside our application (iframe).
        /// </summary>
        [JsonProperty("redirectUri", NullValueHandling = NullValueHandling.Ignore)]
        public string RedirectUri { get; set; }

        /// <summary>
        /// The publicly available URL you want to be notified with events as the user progresses through the application. See [Connect Webhook Event](https://docs.finicity.com/connect-and-mvs-webhooks/) for event details.
        /// </summary>
        [JsonProperty("webhook", NullValueHandling = NullValueHandling.Ignore)]
        public string Webhook { get; set; }

        /// <summary>
        /// The content type the webhook events will be sent in. Supported types: "application/json" and "application/xml".
        /// </summary>
        [JsonProperty("webhookContentType", NullValueHandling = NullValueHandling.Ignore)]
        public string WebhookContentType { get; set; }

        /// <summary>
        /// Allows additional identifiable information to be inserted into the payload of connect webhook events. See: [Custom Webhooks](https://docs.finicity.com/custom-webhooks/).
        /// </summary>
        [JsonProperty("webhookData", NullValueHandling = NullValueHandling.Ignore)]
        public object WebhookData { get; set; }

        /// <summary>
        /// Allows additional identifiable information to be included as headers of connect webhook event. See: [Custom Webhooks](https://docs.finicity.com/custom-webhooks/).
        /// </summary>
        [JsonProperty("webhookHeaders", NullValueHandling = NullValueHandling.Ignore)]
        public object WebhookHeaders { get; set; }

        /// <summary>
        /// The `experience` field allows you to customize:
        /// * Brand: color and logo
        /// * Icon: displayed on the "Share your data" page
        /// * Popular institutions: displayed on the Bank Search page
        /// * Report: the credit decisioning report to send when Connect completes.
        /// * MVS modules: financial, payroll, paystub
        /// Note: the Finicity sales engineers (SE) help you set up a default experience for your company when you migrate to Connect 2.0. For each additional experience you create thereafter, they'll give you a unique ID. See [Generate 2.0 Connect URL APIs](https://docs.finicity.com/migrate-to-connect-web-sdk-2-0/#migrate-connect-web-sdk-1).
        /// Experience values options:
        /// * "default": your default experience (must be defined)
        /// * GUID: the code for a different experience
        /// * Not defined: If you don't pass the experience parameter, then Connect's out of the box default experience (add accounts but no branding) is used, and the MVS modules will not run.
        /// </summary>
        [JsonProperty("experience", NullValueHandling = NullValueHandling.Ignore)]
        public string Experience { get; set; }

        /// <summary>
        /// "true": The URL link expires after a Connect session successfully completes.
        /// Note: when the `singleUseUrl` and the `experience` parameters are passed in the same call, the `singleUseUrl` value overrides the `singleUseUrl` value configured in the `experience` parameter.
        /// </summary>
        [JsonProperty("singleUseUrl", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SingleUseUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FixConnectParameters : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is FixConnectParameters other &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.PartnerId == null && other.PartnerId == null) || (this.PartnerId?.Equals(other.PartnerId) == true)) &&
                ((this.CustomerId == null && other.CustomerId == null) || (this.CustomerId?.Equals(other.CustomerId) == true)) &&
                ((this.InstitutionLoginId == null && other.InstitutionLoginId == null) || (this.InstitutionLoginId?.Equals(other.InstitutionLoginId) == true)) &&
                ((this.RedirectUri == null && other.RedirectUri == null) || (this.RedirectUri?.Equals(other.RedirectUri) == true)) &&
                ((this.Webhook == null && other.Webhook == null) || (this.Webhook?.Equals(other.Webhook) == true)) &&
                ((this.WebhookContentType == null && other.WebhookContentType == null) || (this.WebhookContentType?.Equals(other.WebhookContentType) == true)) &&
                ((this.WebhookData == null && other.WebhookData == null) || (this.WebhookData?.Equals(other.WebhookData) == true)) &&
                ((this.WebhookHeaders == null && other.WebhookHeaders == null) || (this.WebhookHeaders?.Equals(other.WebhookHeaders) == true)) &&
                ((this.Experience == null && other.Experience == null) || (this.Experience?.Equals(other.Experience) == true)) &&
                ((this.SingleUseUrl == null && other.SingleUseUrl == null) || (this.SingleUseUrl?.Equals(other.SingleUseUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language == string.Empty ? "" : this.Language)}");
            toStringOutput.Add($"this.PartnerId = {(this.PartnerId == null ? "null" : this.PartnerId == string.Empty ? "" : this.PartnerId)}");
            toStringOutput.Add($"this.CustomerId = {(this.CustomerId == null ? "null" : this.CustomerId == string.Empty ? "" : this.CustomerId)}");
            toStringOutput.Add($"this.InstitutionLoginId = {(this.InstitutionLoginId == null ? "null" : this.InstitutionLoginId == string.Empty ? "" : this.InstitutionLoginId)}");
            toStringOutput.Add($"this.RedirectUri = {(this.RedirectUri == null ? "null" : this.RedirectUri == string.Empty ? "" : this.RedirectUri)}");
            toStringOutput.Add($"this.Webhook = {(this.Webhook == null ? "null" : this.Webhook == string.Empty ? "" : this.Webhook)}");
            toStringOutput.Add($"this.WebhookContentType = {(this.WebhookContentType == null ? "null" : this.WebhookContentType == string.Empty ? "" : this.WebhookContentType)}");
            toStringOutput.Add($"WebhookData = {(this.WebhookData == null ? "null" : this.WebhookData.ToString())}");
            toStringOutput.Add($"WebhookHeaders = {(this.WebhookHeaders == null ? "null" : this.WebhookHeaders.ToString())}");
            toStringOutput.Add($"this.Experience = {(this.Experience == null ? "null" : this.Experience == string.Empty ? "" : this.Experience)}");
            toStringOutput.Add($"this.SingleUseUrl = {(this.SingleUseUrl == null ? "null" : this.SingleUseUrl.ToString())}");
        }
    }
}