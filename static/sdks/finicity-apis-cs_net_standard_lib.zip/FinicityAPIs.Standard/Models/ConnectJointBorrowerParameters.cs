// <copyright file="ConnectJointBorrowerParameters.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConnectJointBorrowerParameters.
    /// </summary>
    public class ConnectJointBorrowerParameters
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectJointBorrowerParameters"/> class.
        /// </summary>
        public ConnectJointBorrowerParameters()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectJointBorrowerParameters"/> class.
        /// </summary>
        /// <param name="partnerId">partnerId.</param>
        /// <param name="borrowers">borrowers.</param>
        /// <param name="language">language.</param>
        /// <param name="redirectUri">redirectUri.</param>
        /// <param name="webhook">webhook.</param>
        /// <param name="webhookContentType">webhookContentType.</param>
        /// <param name="webhookData">webhookData.</param>
        /// <param name="webhookHeaders">webhookHeaders.</param>
        /// <param name="institutionSettings">institutionSettings.</param>
        /// <param name="experience">experience.</param>
        /// <param name="fromDate">fromDate.</param>
        /// <param name="reportCustomFields">reportCustomFields.</param>
        /// <param name="singleUseUrl">singleUseUrl.</param>
        public ConnectJointBorrowerParameters(
            string partnerId,
            List<Models.Borrower> borrowers,
            string language = null,
            string redirectUri = null,
            string webhook = null,
            string webhookContentType = "application/json",
            object webhookData = null,
            object webhookHeaders = null,
            object institutionSettings = null,
            string experience = null,
            long? fromDate = null,
            List<Models.ReportCustomField> reportCustomFields = null,
            bool? singleUseUrl = null)
        {
            this.Language = language;
            this.PartnerId = partnerId;
            this.Borrowers = borrowers;
            this.RedirectUri = redirectUri;
            this.Webhook = webhook;
            this.WebhookContentType = webhookContentType;
            this.WebhookData = webhookData;
            this.WebhookHeaders = webhookHeaders;
            this.InstitutionSettings = institutionSettings;
            this.Experience = experience;
            this.FromDate = fromDate;
            this.ReportCustomFields = reportCustomFields;
            this.SingleUseUrl = singleUseUrl;
        }

        /// <summary>
        /// Generate a translated Connect URL link.
        /// Supported languages:
        /// * English (default)
        /// * Spanish (United States): `es`
        /// * French (Canada): `fr` or `fr-CA`
        /// </summary>
        [JsonProperty("language", NullValueHandling = NullValueHandling.Ignore)]
        public string Language { get; set; }

        /// <summary>
        /// Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerId")]
        public string PartnerId { get; set; }

        /// <summary>
        /// (MVS) Array of borrowers to pass the primary and joint borrower's customer and consumer IDs
        /// </summary>
        [JsonProperty("borrowers")]
        public List<Models.Borrower> Borrowers { get; set; }

        /// <summary>
        /// The URL that customers will be redirected to after completing Finicity Connect. Required unless Connect is embedded inside our application (iframe).
        /// </summary>
        [JsonProperty("redirectUri", NullValueHandling = NullValueHandling.Ignore)]
        public string RedirectUri { get; set; }

        /// <summary>
        /// The publicly available URL you want to be notified with events as the user progresses through the application. See [Connect Webhook Event](https://docs.finicity.com/connect-and-mvs-webhooks/) for event details.
        /// </summary>
        [JsonProperty("webhook", NullValueHandling = NullValueHandling.Ignore)]
        public string Webhook { get; set; }

        /// <summary>
        /// The content type the webhook events will be sent in. Supported types: "application/json" and "application/xml".
        /// </summary>
        [JsonProperty("webhookContentType", NullValueHandling = NullValueHandling.Ignore)]
        public string WebhookContentType { get; set; }

        /// <summary>
        /// Allows additional identifiable information to be inserted into the payload of connect webhook events. See: [Custom Webhooks](https://docs.finicity.com/custom-webhooks/).
        /// </summary>
        [JsonProperty("webhookData", NullValueHandling = NullValueHandling.Ignore)]
        public object WebhookData { get; set; }

        /// <summary>
        /// Allows additional identifiable information to be included as headers of connect webhook event. See: [Custom Webhooks](https://docs.finicity.com/custom-webhooks/).
        /// </summary>
        [JsonProperty("webhookHeaders", NullValueHandling = NullValueHandling.Ignore)]
        public object WebhookHeaders { get; set; }

        /// <summary>
        /// Advanced options for configuration of which institutions to display in. See [Institution Settings](https://docs.finicity.com/connect-institution-settings/).
        /// </summary>
        [JsonProperty("institutionSettings", NullValueHandling = NullValueHandling.Ignore)]
        public object InstitutionSettings { get; set; }

        /// <summary>
        /// The `experience` field allows you to customize:
        /// * Brand: color and logo
        /// * Icon: displayed on the "Share your data" page
        /// * Popular institutions: displayed on the Bank Search page
        /// * Report: the credit decisioning report to send when Connect completes.
        /// * MVS modules: financial, payroll, paystub
        /// Note: the Finicity sales engineers (SE) help you set up a default experience for your company when you migrate to Connect 2.0. For each additional experience you create thereafter, they'll give you a unique ID. See [Generate 2.0 Connect URL APIs](https://docs.finicity.com/migrate-to-connect-web-sdk-2-0/#migrate-connect-web-sdk-1).
        /// Experience values options:
        /// * "default": your default experience (must be defined)
        /// * GUID: the code for a different experience
        /// * Not defined: If you don't pass the experience parameter, then Connect's out of the box default experience (add accounts but no branding) is used, and the MVS modules will not run.
        /// </summary>
        [JsonProperty("experience", NullValueHandling = NullValueHandling.Ignore)]
        public string Experience { get; set; }

        /// <summary>
        /// The `fromDate` parameter is used when experiences are associated with a credit decisioning report and any other reports with transaction data. The value is in epoch time and must be 10 digits. Example: 1494449017. If it's greater than 10 digits, then the `fromDate` is set to the credit decisioning report's default `fromDate`.
        /// For an experience that generates multiple reports, the `fromDate` gets passed to the reports that support it.
        /// However, Connect doesn't pass this parameter to the following reports:
        /// * Pay Statement Extraction Report
        /// * VOIE - Paystub (with TXVerify) Report
        /// * Statement Report
        /// * Verification of Income Report
        /// * VOIE - Payroll Report
        /// Note: this field isn't used if you're only collecting transaction data without a report.
        /// </summary>
        [JsonProperty("fromDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? FromDate { get; set; }

        /// <summary>
        /// The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.
        /// Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".
        /// * "true": (default) display the custom field in the PDF report
        /// * "false": don't display the custom field in the PDF report
        /// For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.
        /// All custom fields display in the Reseller Billing API.
        /// </summary>
        [JsonProperty("reportCustomFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportCustomField> ReportCustomFields { get; set; }

        /// <summary>
        /// "true": The URL link expires after a Connect session successfully completes.
        /// Note: when the `singleUseUrl` and the `experience` parameters are passed in the same call, the `singleUseUrl` value overrides the `singleUseUrl` value configured in the `experience` parameter.
        /// </summary>
        [JsonProperty("singleUseUrl", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SingleUseUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConnectJointBorrowerParameters : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConnectJointBorrowerParameters other &&
                ((this.Language == null && other.Language == null) || (this.Language?.Equals(other.Language) == true)) &&
                ((this.PartnerId == null && other.PartnerId == null) || (this.PartnerId?.Equals(other.PartnerId) == true)) &&
                ((this.Borrowers == null && other.Borrowers == null) || (this.Borrowers?.Equals(other.Borrowers) == true)) &&
                ((this.RedirectUri == null && other.RedirectUri == null) || (this.RedirectUri?.Equals(other.RedirectUri) == true)) &&
                ((this.Webhook == null && other.Webhook == null) || (this.Webhook?.Equals(other.Webhook) == true)) &&
                ((this.WebhookContentType == null && other.WebhookContentType == null) || (this.WebhookContentType?.Equals(other.WebhookContentType) == true)) &&
                ((this.WebhookData == null && other.WebhookData == null) || (this.WebhookData?.Equals(other.WebhookData) == true)) &&
                ((this.WebhookHeaders == null && other.WebhookHeaders == null) || (this.WebhookHeaders?.Equals(other.WebhookHeaders) == true)) &&
                ((this.InstitutionSettings == null && other.InstitutionSettings == null) || (this.InstitutionSettings?.Equals(other.InstitutionSettings) == true)) &&
                ((this.Experience == null && other.Experience == null) || (this.Experience?.Equals(other.Experience) == true)) &&
                ((this.FromDate == null && other.FromDate == null) || (this.FromDate?.Equals(other.FromDate) == true)) &&
                ((this.ReportCustomFields == null && other.ReportCustomFields == null) || (this.ReportCustomFields?.Equals(other.ReportCustomFields) == true)) &&
                ((this.SingleUseUrl == null && other.SingleUseUrl == null) || (this.SingleUseUrl?.Equals(other.SingleUseUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Language = {(this.Language == null ? "null" : this.Language == string.Empty ? "" : this.Language)}");
            toStringOutput.Add($"this.PartnerId = {(this.PartnerId == null ? "null" : this.PartnerId == string.Empty ? "" : this.PartnerId)}");
            toStringOutput.Add($"this.Borrowers = {(this.Borrowers == null ? "null" : $"[{string.Join(", ", this.Borrowers)} ]")}");
            toStringOutput.Add($"this.RedirectUri = {(this.RedirectUri == null ? "null" : this.RedirectUri == string.Empty ? "" : this.RedirectUri)}");
            toStringOutput.Add($"this.Webhook = {(this.Webhook == null ? "null" : this.Webhook == string.Empty ? "" : this.Webhook)}");
            toStringOutput.Add($"this.WebhookContentType = {(this.WebhookContentType == null ? "null" : this.WebhookContentType == string.Empty ? "" : this.WebhookContentType)}");
            toStringOutput.Add($"WebhookData = {(this.WebhookData == null ? "null" : this.WebhookData.ToString())}");
            toStringOutput.Add($"WebhookHeaders = {(this.WebhookHeaders == null ? "null" : this.WebhookHeaders.ToString())}");
            toStringOutput.Add($"InstitutionSettings = {(this.InstitutionSettings == null ? "null" : this.InstitutionSettings.ToString())}");
            toStringOutput.Add($"this.Experience = {(this.Experience == null ? "null" : this.Experience == string.Empty ? "" : this.Experience)}");
            toStringOutput.Add($"this.FromDate = {(this.FromDate == null ? "null" : this.FromDate.ToString())}");
            toStringOutput.Add($"this.ReportCustomFields = {(this.ReportCustomFields == null ? "null" : $"[{string.Join(", ", this.ReportCustomFields)} ]")}");
            toStringOutput.Add($"this.SingleUseUrl = {(this.SingleUseUrl == null ? "null" : this.SingleUseUrl.ToString())}");
        }
    }
}