// <copyright file="BusinessSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BusinessSummary.
    /// </summary>
    public class BusinessSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessSummary"/> class.
        /// </summary>
        public BusinessSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessSummary"/> class.
        /// </summary>
        /// <param name="currentReportRequest">currentReportRequest.</param>
        /// <param name="historicDataAvailability">historicDataAvailability.</param>
        /// <param name="cashflowAnalyticsMetrics">cashflowAnalyticsMetrics.</param>
        /// <param name="balanceAnalyticsMetrics">balanceAnalyticsMetrics.</param>
        public BusinessSummary(
            Models.ObbCurrentReportRequestDetails currentReportRequest,
            Models.ObbDataAvailability historicDataAvailability,
            Models.CashFlowAnalyticsMetrics cashflowAnalyticsMetrics = null,
            Models.BalanceAnalyticsMetrics balanceAnalyticsMetrics = null)
        {
            this.CashflowAnalyticsMetrics = cashflowAnalyticsMetrics;
            this.CurrentReportRequest = currentReportRequest;
            this.HistoricDataAvailability = historicDataAvailability;
            this.BalanceAnalyticsMetrics = balanceAnalyticsMetrics;
        }

        /// <summary>
        /// Cash flow analytics metrics and calculations across all accounts in the report
        /// </summary>
        [JsonProperty("cashflowAnalyticsMetrics", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowAnalyticsMetrics CashflowAnalyticsMetrics { get; set; }

        /// <summary>
        /// Gets or sets CurrentReportRequest.
        /// </summary>
        [JsonProperty("currentReportRequest")]
        public Models.ObbCurrentReportRequestDetails CurrentReportRequest { get; set; }

        /// <summary>
        /// Gets or sets HistoricDataAvailability.
        /// </summary>
        [JsonProperty("historicDataAvailability")]
        public Models.ObbDataAvailability HistoricDataAvailability { get; set; }

        /// <summary>
        /// Balance analytics metrics and calculations across all accounts in the report
        /// </summary>
        [JsonProperty("balanceAnalyticsMetrics", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BalanceAnalyticsMetrics BalanceAnalyticsMetrics { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BusinessSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BusinessSummary other &&
                ((this.CashflowAnalyticsMetrics == null && other.CashflowAnalyticsMetrics == null) || (this.CashflowAnalyticsMetrics?.Equals(other.CashflowAnalyticsMetrics) == true)) &&
                ((this.CurrentReportRequest == null && other.CurrentReportRequest == null) || (this.CurrentReportRequest?.Equals(other.CurrentReportRequest) == true)) &&
                ((this.HistoricDataAvailability == null && other.HistoricDataAvailability == null) || (this.HistoricDataAvailability?.Equals(other.HistoricDataAvailability) == true)) &&
                ((this.BalanceAnalyticsMetrics == null && other.BalanceAnalyticsMetrics == null) || (this.BalanceAnalyticsMetrics?.Equals(other.BalanceAnalyticsMetrics) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CashflowAnalyticsMetrics = {(this.CashflowAnalyticsMetrics == null ? "null" : this.CashflowAnalyticsMetrics.ToString())}");
            toStringOutput.Add($"this.CurrentReportRequest = {(this.CurrentReportRequest == null ? "null" : this.CurrentReportRequest.ToString())}");
            toStringOutput.Add($"this.HistoricDataAvailability = {(this.HistoricDataAvailability == null ? "null" : this.HistoricDataAvailability.ToString())}");
            toStringOutput.Add($"this.BalanceAnalyticsMetrics = {(this.BalanceAnalyticsMetrics == null ? "null" : this.BalanceAnalyticsMetrics.ToString())}");
        }
    }
}