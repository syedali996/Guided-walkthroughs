// <copyright file="ConnectEmailUrl.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConnectEmailUrl.
    /// </summary>
    public class ConnectEmailUrl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectEmailUrl"/> class.
        /// </summary>
        public ConnectEmailUrl()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectEmailUrl"/> class.
        /// </summary>
        /// <param name="link">link.</param>
        /// <param name="emailConfig">emailConfig.</param>
        public ConnectEmailUrl(
            string link,
            Models.EmailOptions emailConfig)
        {
            this.Link = link;
            this.EmailConfig = emailConfig;
        }

        /// <summary>
        /// A generated Connect URL
        /// </summary>
        [JsonProperty("link")]
        public string Link { get; set; }

        /// <summary>
        /// Configuration for the Connect email's sent to customers
        /// </summary>
        [JsonProperty("emailConfig")]
        public Models.EmailOptions EmailConfig { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConnectEmailUrl : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConnectEmailUrl other &&
                ((this.Link == null && other.Link == null) || (this.Link?.Equals(other.Link) == true)) &&
                ((this.EmailConfig == null && other.EmailConfig == null) || (this.EmailConfig?.Equals(other.EmailConfig) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Link = {(this.Link == null ? "null" : this.Link == string.Empty ? "" : this.Link)}");
            toStringOutput.Add($"this.EmailConfig = {(this.EmailConfig == null ? "null" : this.EmailConfig.ToString())}");
        }
    }
}