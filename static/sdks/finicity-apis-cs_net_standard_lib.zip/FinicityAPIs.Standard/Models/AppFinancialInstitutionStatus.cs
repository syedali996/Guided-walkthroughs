// <copyright file="AppFinancialInstitutionStatus.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AppFinancialInstitutionStatus.
    /// </summary>
    public class AppFinancialInstitutionStatus
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppFinancialInstitutionStatus"/> class.
        /// </summary>
        public AppFinancialInstitutionStatus()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AppFinancialInstitutionStatus"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="decryptionKeyActivated">decryptionKeyActivated.</param>
        /// <param name="createdDate">createdDate.</param>
        /// <param name="lastModifiedDate">lastModifiedDate.</param>
        /// <param name="status">status.</param>
        /// <param name="abbrvName">abbrvName.</param>
        /// <param name="logoUrl">logoUrl.</param>
        public AppFinancialInstitutionStatus(
            long id,
            bool decryptionKeyActivated,
            long createdDate,
            long lastModifiedDate,
            bool status,
            string abbrvName = null,
            string logoUrl = null)
        {
            this.Id = id;
            this.AbbrvName = abbrvName;
            this.LogoUrl = logoUrl;
            this.DecryptionKeyActivated = decryptionKeyActivated;
            this.CreatedDate = createdDate;
            this.LastModifiedDate = lastModifiedDate;
            this.Status = status;
        }

        /// <summary>
        /// The ID of a financial institution, represented as a number
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// The application's abbreviated name
        /// </summary>
        [JsonProperty("abbrvName", NullValueHandling = NullValueHandling.Ignore)]
        public string AbbrvName { get; set; }

        /// <summary>
        /// An URL to a logo file
        /// </summary>
        [JsonProperty("logoUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string LogoUrl { get; set; }

        /// <summary>
        /// Status of decryption keys for financial institution app registration
        /// </summary>
        [JsonProperty("decryptionKeyActivated")]
        public bool DecryptionKeyActivated { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate")]
        public long CreatedDate { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("lastModifiedDate")]
        public long LastModifiedDate { get; set; }

        /// <summary>
        /// "false" indicates registration is still pending
        /// </summary>
        [JsonProperty("status")]
        public bool Status { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AppFinancialInstitutionStatus : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AppFinancialInstitutionStatus other &&
                this.Id.Equals(other.Id) &&
                ((this.AbbrvName == null && other.AbbrvName == null) || (this.AbbrvName?.Equals(other.AbbrvName) == true)) &&
                ((this.LogoUrl == null && other.LogoUrl == null) || (this.LogoUrl?.Equals(other.LogoUrl) == true)) &&
                this.DecryptionKeyActivated.Equals(other.DecryptionKeyActivated) &&
                this.CreatedDate.Equals(other.CreatedDate) &&
                this.LastModifiedDate.Equals(other.LastModifiedDate) &&
                this.Status.Equals(other.Status);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.AbbrvName = {(this.AbbrvName == null ? "null" : this.AbbrvName == string.Empty ? "" : this.AbbrvName)}");
            toStringOutput.Add($"this.LogoUrl = {(this.LogoUrl == null ? "null" : this.LogoUrl == string.Empty ? "" : this.LogoUrl)}");
            toStringOutput.Add($"this.DecryptionKeyActivated = {this.DecryptionKeyActivated}");
            toStringOutput.Add($"this.CreatedDate = {this.CreatedDate}");
            toStringOutput.Add($"this.LastModifiedDate = {this.LastModifiedDate}");
            toStringOutput.Add($"this.Status = {this.Status}");
        }
    }
}