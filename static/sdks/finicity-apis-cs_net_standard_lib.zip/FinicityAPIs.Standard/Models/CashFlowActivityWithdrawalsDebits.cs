// <copyright file="CashFlowActivityWithdrawalsDebits.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowActivityWithdrawalsDebits.
    /// </summary>
    public class CashFlowActivityWithdrawalsDebits
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowActivityWithdrawalsDebits"/> class.
        /// </summary>
        public CashFlowActivityWithdrawalsDebits()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowActivityWithdrawalsDebits"/> class.
        /// </summary>
        /// <param name="date">date.</param>
        /// <param name="withdrawalsDebits">withdrawalsDebits.</param>
        /// <param name="transactionDescription">transactionDescription.</param>
        public CashFlowActivityWithdrawalsDebits(
            string date,
            double withdrawalsDebits,
            string transactionDescription = null)
        {
            this.Date = date;
            this.TransactionDescription = transactionDescription;
            this.WithdrawalsDebits = withdrawalsDebits;
        }

        /// <summary>
        /// Date the withdrawal transaction was posted
        /// </summary>
        [JsonProperty("date")]
        public string Date { get; set; }

        /// <summary>
        /// Description of transaction
        /// </summary>
        [JsonProperty("transactionDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Amount of the withdrawal
        /// </summary>
        [JsonProperty("withdrawalsDebits")]
        public double WithdrawalsDebits { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowActivityWithdrawalsDebits : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowActivityWithdrawalsDebits other &&
                ((this.Date == null && other.Date == null) || (this.Date?.Equals(other.Date) == true)) &&
                ((this.TransactionDescription == null && other.TransactionDescription == null) || (this.TransactionDescription?.Equals(other.TransactionDescription) == true)) &&
                this.WithdrawalsDebits.Equals(other.WithdrawalsDebits);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Date = {(this.Date == null ? "null" : this.Date == string.Empty ? "" : this.Date)}");
            toStringOutput.Add($"this.TransactionDescription = {(this.TransactionDescription == null ? "null" : this.TransactionDescription == string.Empty ? "" : this.TransactionDescription)}");
            toStringOutput.Add($"this.WithdrawalsDebits = {this.WithdrawalsDebits}");
        }
    }
}