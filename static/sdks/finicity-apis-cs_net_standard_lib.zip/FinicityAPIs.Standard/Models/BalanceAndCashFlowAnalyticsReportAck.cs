// <copyright file="BalanceAndCashFlowAnalyticsReportAck.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BalanceAndCashFlowAnalyticsReportAck.
    /// </summary>
    public class BalanceAndCashFlowAnalyticsReportAck
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAndCashFlowAnalyticsReportAck"/> class.
        /// </summary>
        public BalanceAndCashFlowAnalyticsReportAck()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BalanceAndCashFlowAnalyticsReportAck"/> class.
        /// </summary>
        /// <param name="accountIds">accountIds.</param>
        /// <param name="createdDate">createdDate.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="reportId">reportId.</param>
        /// <param name="reportPin">reportPin.</param>
        /// <param name="title">title.</param>
        /// <param name="businessId">businessId.</param>
        /// <param name="requesterName">requesterName.</param>
        public BalanceAndCashFlowAnalyticsReportAck(
            List<long> accountIds,
            string createdDate,
            long customerId,
            string reportId,
            string reportPin,
            string title,
            int? businessId = null,
            string requesterName = null)
        {
            this.AccountIds = accountIds;
            this.BusinessId = businessId;
            this.CreatedDate = createdDate;
            this.CustomerId = customerId;
            this.ReportId = reportId;
            this.ReportPin = reportPin;
            this.RequesterName = requesterName;
            this.Title = title;
        }

        /// <summary>
        /// List of account IDs included in the report
        /// </summary>
        [JsonProperty("accountIds")]
        public List<long> AccountIds { get; set; }

        /// <summary>
        /// Business ID associated with the requested customer
        /// </summary>
        [JsonProperty("businessId", NullValueHandling = NullValueHandling.Ignore)]
        public int? BusinessId { get; set; }

        /// <summary>
        /// Created date of balance analytics request
        /// </summary>
        [JsonProperty("createdDate")]
        public string CreatedDate { get; set; }

        /// <summary>
        /// A customer ID represented as a number. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public long CustomerId { get; set; }

        /// <summary>
        /// A report ID
        /// </summary>
        [JsonProperty("reportId")]
        public string ReportId { get; set; }

        /// <summary>
        /// PIN that may be used to access the report
        /// </summary>
        [JsonProperty("reportPin")]
        public string ReportPin { get; set; }

        /// <summary>
        /// Name of requester
        /// </summary>
        [JsonProperty("requesterName", NullValueHandling = NullValueHandling.Ignore)]
        public string RequesterName { get; set; }

        /// <summary>
        /// Title of the report
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BalanceAndCashFlowAnalyticsReportAck : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BalanceAndCashFlowAnalyticsReportAck other &&
                ((this.AccountIds == null && other.AccountIds == null) || (this.AccountIds?.Equals(other.AccountIds) == true)) &&
                ((this.BusinessId == null && other.BusinessId == null) || (this.BusinessId?.Equals(other.BusinessId) == true)) &&
                ((this.CreatedDate == null && other.CreatedDate == null) || (this.CreatedDate?.Equals(other.CreatedDate) == true)) &&
                this.CustomerId.Equals(other.CustomerId) &&
                ((this.ReportId == null && other.ReportId == null) || (this.ReportId?.Equals(other.ReportId) == true)) &&
                ((this.ReportPin == null && other.ReportPin == null) || (this.ReportPin?.Equals(other.ReportPin) == true)) &&
                ((this.RequesterName == null && other.RequesterName == null) || (this.RequesterName?.Equals(other.RequesterName) == true)) &&
                ((this.Title == null && other.Title == null) || (this.Title?.Equals(other.Title) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountIds = {(this.AccountIds == null ? "null" : $"[{string.Join(", ", this.AccountIds)} ]")}");
            toStringOutput.Add($"this.BusinessId = {(this.BusinessId == null ? "null" : this.BusinessId.ToString())}");
            toStringOutput.Add($"this.CreatedDate = {(this.CreatedDate == null ? "null" : this.CreatedDate == string.Empty ? "" : this.CreatedDate)}");
            toStringOutput.Add($"this.CustomerId = {this.CustomerId}");
            toStringOutput.Add($"this.ReportId = {(this.ReportId == null ? "null" : this.ReportId == string.Empty ? "" : this.ReportId)}");
            toStringOutput.Add($"this.ReportPin = {(this.ReportPin == null ? "null" : this.ReportPin == string.Empty ? "" : this.ReportPin)}");
            toStringOutput.Add($"this.RequesterName = {(this.RequesterName == null ? "null" : this.RequesterName == string.Empty ? "" : this.RequesterName)}");
            toStringOutput.Add($"this.Title = {(this.Title == null ? "null" : this.Title == string.Empty ? "" : this.Title)}");
        }
    }
}