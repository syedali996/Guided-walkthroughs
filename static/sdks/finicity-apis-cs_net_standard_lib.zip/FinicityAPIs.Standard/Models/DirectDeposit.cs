// <copyright file="DirectDeposit.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// DirectDeposit.
    /// </summary>
    public class DirectDeposit
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDeposit"/> class.
        /// </summary>
        public DirectDeposit()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDeposit"/> class.
        /// </summary>
        /// <param name="amountCurrent">amountCurrent.</param>
        /// <param name="accountLastFour">accountLastFour.</param>
        public DirectDeposit(
            double? amountCurrent = null,
            string accountLastFour = null)
        {
            this.AmountCurrent = amountCurrent;
            this.AccountLastFour = accountLastFour;
        }

        /// <summary>
        /// The amount of the deposit
        /// </summary>
        [JsonProperty("amountCurrent", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountCurrent { get; set; }

        /// <summary>
        /// The last four numbers of the account the deposit went into
        /// </summary>
        [JsonProperty("accountLastFour", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountLastFour { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DirectDeposit : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DirectDeposit other &&
                ((this.AmountCurrent == null && other.AmountCurrent == null) || (this.AmountCurrent?.Equals(other.AmountCurrent) == true)) &&
                ((this.AccountLastFour == null && other.AccountLastFour == null) || (this.AccountLastFour?.Equals(other.AccountLastFour) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AmountCurrent = {(this.AmountCurrent == null ? "null" : this.AmountCurrent.ToString())}");
            toStringOutput.Add($"this.AccountLastFour = {(this.AccountLastFour == null ? "null" : this.AccountLastFour == string.Empty ? "" : this.AccountLastFour)}");
        }
    }
}