// <copyright file="InsufficientFundsTransaction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InsufficientFundsTransaction.
    /// </summary>
    public class InsufficientFundsTransaction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InsufficientFundsTransaction"/> class.
        /// </summary>
        public InsufficientFundsTransaction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InsufficientFundsTransaction"/> class.
        /// </summary>
        /// <param name="amount">amount.</param>
        /// <param name="postedDate">postedDate.</param>
        /// <param name="transactionId">transactionId.</param>
        /// <param name="description">description.</param>
        /// <param name="memo">memo.</param>
        public InsufficientFundsTransaction(
            double amount,
            string postedDate,
            long transactionId,
            string description = null,
            string memo = null)
        {
            this.Amount = amount;
            this.Description = description;
            this.Memo = memo;
            this.PostedDate = postedDate;
            this.TransactionId = transactionId;
        }

        /// <summary>
        /// Amount of the NSF transaction
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Description of the transaction
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// Transaction memo
        /// </summary>
        [JsonProperty("memo", NullValueHandling = NullValueHandling.Ignore)]
        public string Memo { get; set; }

        /// <summary>
        /// Posted date of the NSF transaction
        /// </summary>
        [JsonProperty("postedDate")]
        public string PostedDate { get; set; }

        /// <summary>
        /// Finicity transaction ID
        /// </summary>
        [JsonProperty("transactionId")]
        public long TransactionId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InsufficientFundsTransaction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is InsufficientFundsTransaction other &&
                this.Amount.Equals(other.Amount) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Memo == null && other.Memo == null) || (this.Memo?.Equals(other.Memo) == true)) &&
                ((this.PostedDate == null && other.PostedDate == null) || (this.PostedDate?.Equals(other.PostedDate) == true)) &&
                this.TransactionId.Equals(other.TransactionId);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Amount = {this.Amount}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Memo = {(this.Memo == null ? "null" : this.Memo == string.Empty ? "" : this.Memo)}");
            toStringOutput.Add($"this.PostedDate = {(this.PostedDate == null ? "null" : this.PostedDate == string.Empty ? "" : this.PostedDate)}");
            toStringOutput.Add($"this.TransactionId = {this.TransactionId}");
        }
    }
}