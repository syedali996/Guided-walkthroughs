// <copyright file="PrequalificationReportConstraintsOut.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PrequalificationReportConstraintsOut.
    /// </summary>
    public class PrequalificationReportConstraintsOut
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportConstraintsOut"/> class.
        /// </summary>
        public PrequalificationReportConstraintsOut()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrequalificationReportConstraintsOut"/> class.
        /// </summary>
        /// <param name="accountIds">accountIds.</param>
        /// <param name="reportCustomFields">reportCustomFields.</param>
        /// <param name="showNsf">showNsf.</param>
        /// <param name="fromDate">fromDate.</param>
        public PrequalificationReportConstraintsOut(
            List<string> accountIds = null,
            List<Models.ReportCustomField> reportCustomFields = null,
            bool? showNsf = null,
            long? fromDate = null)
        {
            this.AccountIds = accountIds;
            this.ReportCustomFields = reportCustomFields;
            this.ShowNsf = showNsf;
            this.FromDate = fromDate;
        }

        /// <summary>
        /// An array of account IDs to be included in the report (all accounts will be included if not set)
        /// </summary>
        [JsonProperty("accountIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> AccountIds { get; set; }

        /// <summary>
        /// The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.
        /// Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".
        /// * "true": (default) display the custom field in the PDF report
        /// * "false": don't display the custom field in the PDF report
        /// For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.
        /// All custom fields display in the Reseller Billing API.
        /// </summary>
        [JsonProperty("reportCustomFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportCustomField> ReportCustomFields { get; set; }

        /// <summary>
        /// Include the non-sufficient funds (NSF) summary JSON and the NSF summary PDF section in the report. Data included:
        /// * Account
        /// * Total number of NSF funds
        /// * Days since the most recent NFS funds fee
        /// </summary>
        [JsonProperty("showNsf", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ShowNsf { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("fromDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? FromDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PrequalificationReportConstraintsOut : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PrequalificationReportConstraintsOut other &&
                ((this.AccountIds == null && other.AccountIds == null) || (this.AccountIds?.Equals(other.AccountIds) == true)) &&
                ((this.ReportCustomFields == null && other.ReportCustomFields == null) || (this.ReportCustomFields?.Equals(other.ReportCustomFields) == true)) &&
                ((this.ShowNsf == null && other.ShowNsf == null) || (this.ShowNsf?.Equals(other.ShowNsf) == true)) &&
                ((this.FromDate == null && other.FromDate == null) || (this.FromDate?.Equals(other.FromDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountIds = {(this.AccountIds == null ? "null" : $"[{string.Join(", ", this.AccountIds)} ]")}");
            toStringOutput.Add($"this.ReportCustomFields = {(this.ReportCustomFields == null ? "null" : $"[{string.Join(", ", this.ReportCustomFields)} ]")}");
            toStringOutput.Add($"this.ShowNsf = {(this.ShowNsf == null ? "null" : this.ShowNsf.ToString())}");
            toStringOutput.Add($"this.FromDate = {(this.FromDate == null ? "null" : this.FromDate.ToString())}");
        }
    }
}