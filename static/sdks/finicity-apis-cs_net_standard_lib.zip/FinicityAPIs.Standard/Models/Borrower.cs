// <copyright file="Borrower.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Borrower.
    /// </summary>
    public class Borrower
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Borrower"/> class.
        /// </summary>
        public Borrower()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Borrower"/> class.
        /// </summary>
        /// <param name="customerId">customerId.</param>
        /// <param name="consumerId">consumerId.</param>
        /// <param name="type">type.</param>
        /// <param name="optionalConsumerInfo">optionalConsumerInfo.</param>
        public Borrower(
            string customerId,
            string consumerId,
            string type,
            Models.ConsumerInfo optionalConsumerInfo = null)
        {
            this.CustomerId = customerId;
            this.ConsumerId = consumerId;
            this.Type = type;
            this.OptionalConsumerInfo = optionalConsumerInfo;
        }

        /// <summary>
        /// A customer ID. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }

        /// <summary>
        /// A consumer ID. See Create Consumer API for how to create a consumer ID.
        /// </summary>
        [JsonProperty("consumerId")]
        public string ConsumerId { get; set; }

        /// <summary>
        /// "primary" or "jointBorrower"
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// The SSN and date of birth of a consumer
        /// </summary>
        [JsonProperty("optionalConsumerInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ConsumerInfo OptionalConsumerInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Borrower : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Borrower other &&
                ((this.CustomerId == null && other.CustomerId == null) || (this.CustomerId?.Equals(other.CustomerId) == true)) &&
                ((this.ConsumerId == null && other.ConsumerId == null) || (this.ConsumerId?.Equals(other.ConsumerId) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.OptionalConsumerInfo == null && other.OptionalConsumerInfo == null) || (this.OptionalConsumerInfo?.Equals(other.OptionalConsumerInfo) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CustomerId = {(this.CustomerId == null ? "null" : this.CustomerId == string.Empty ? "" : this.CustomerId)}");
            toStringOutput.Add($"this.ConsumerId = {(this.ConsumerId == null ? "null" : this.ConsumerId == string.Empty ? "" : this.ConsumerId)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.OptionalConsumerInfo = {(this.OptionalConsumerInfo == null ? "null" : this.OptionalConsumerInfo.ToString())}");
        }
    }
}