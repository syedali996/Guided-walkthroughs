// <copyright file="CreatedTestTxPushTransaction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreatedTestTxPushTransaction.
    /// </summary>
    public class CreatedTestTxPushTransaction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreatedTestTxPushTransaction"/> class.
        /// </summary>
        public CreatedTestTxPushTransaction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreatedTestTxPushTransaction"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="createdDate">createdDate.</param>
        public CreatedTestTxPushTransaction(
            long id,
            long createdDate)
        {
            this.Id = id;
            this.CreatedDate = createdDate;
        }

        /// <summary>
        /// A transaction ID
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate")]
        public long CreatedDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreatedTestTxPushTransaction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreatedTestTxPushTransaction other &&
                this.Id.Equals(other.Id) &&
                this.CreatedDate.Equals(other.CreatedDate);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.CreatedDate = {this.CreatedDate}");
        }
    }
}