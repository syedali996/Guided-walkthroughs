// <copyright file="CashFlowMonthlyCashFlowCharacteristicSummaries.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowMonthlyCashFlowCharacteristicSummaries.
    /// </summary>
    public class CashFlowMonthlyCashFlowCharacteristicSummaries
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowCharacteristicSummaries"/> class.
        /// </summary>
        public CashFlowMonthlyCashFlowCharacteristicSummaries()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowMonthlyCashFlowCharacteristicSummaries"/> class.
        /// </summary>
        /// <param name="month">month.</param>
        /// <param name="totalCreditsLessTotalDebits">totalCreditsLessTotalDebits.</param>
        /// <param name="totalCreditsLessTotalDebitsLessTransfers">totalCreditsLessTotalDebitsLessTransfers.</param>
        /// <param name="averageTransactionAmount">averageTransactionAmount.</param>
        public CashFlowMonthlyCashFlowCharacteristicSummaries(
            long month,
            double totalCreditsLessTotalDebits,
            double totalCreditsLessTotalDebitsLessTransfers,
            double averageTransactionAmount)
        {
            this.Month = month;
            this.TotalCreditsLessTotalDebits = totalCreditsLessTotalDebits;
            this.TotalCreditsLessTotalDebitsLessTransfers = totalCreditsLessTotalDebitsLessTransfers;
            this.AverageTransactionAmount = averageTransactionAmount;
        }

        /// <summary>
        /// One instance for each complete calendar month in the report
        /// </summary>
        [JsonProperty("month")]
        public long Month { get; set; }

        /// <summary>
        /// Total Credits - Total Debits by month across all accounts
        /// </summary>
        [JsonProperty("totalCreditsLessTotalDebits")]
        public double TotalCreditsLessTotalDebits { get; set; }

        /// <summary>
        /// Total Credits - Total Debits by month (Without Transfers) across all accounts
        /// </summary>
        [JsonProperty("totalCreditsLessTotalDebitsLessTransfers")]
        public double TotalCreditsLessTotalDebitsLessTransfers { get; set; }

        /// <summary>
        /// Average transaction amount across all accounts
        /// </summary>
        [JsonProperty("averageTransactionAmount")]
        public double AverageTransactionAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowMonthlyCashFlowCharacteristicSummaries : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowMonthlyCashFlowCharacteristicSummaries other &&
                this.Month.Equals(other.Month) &&
                this.TotalCreditsLessTotalDebits.Equals(other.TotalCreditsLessTotalDebits) &&
                this.TotalCreditsLessTotalDebitsLessTransfers.Equals(other.TotalCreditsLessTotalDebitsLessTransfers) &&
                this.AverageTransactionAmount.Equals(other.AverageTransactionAmount);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Month = {this.Month}");
            toStringOutput.Add($"this.TotalCreditsLessTotalDebits = {this.TotalCreditsLessTotalDebits}");
            toStringOutput.Add($"this.TotalCreditsLessTotalDebitsLessTransfers = {this.TotalCreditsLessTotalDebitsLessTransfers}");
            toStringOutput.Add($"this.AverageTransactionAmount = {this.AverageTransactionAmount}");
        }
    }
}