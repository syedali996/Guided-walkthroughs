// <copyright file="ObbCurrentReportRequestDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbCurrentReportRequestDetails.
    /// </summary>
    public class ObbCurrentReportRequestDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbCurrentReportRequestDetails"/> class.
        /// </summary>
        public ObbCurrentReportRequestDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbCurrentReportRequestDetails"/> class.
        /// </summary>
        /// <param name="reportBeginDate">reportBeginDate.</param>
        /// <param name="reportEndDate">reportEndDate.</param>
        /// <param name="reportRequestDate">reportRequestDate.</param>
        /// <param name="requestedDaysForReport">requestedDaysForReport.</param>
        /// <param name="requestedReportBeginDate">requestedReportBeginDate.</param>
        public ObbCurrentReportRequestDetails(
            string reportBeginDate,
            string reportEndDate,
            string reportRequestDate,
            int requestedDaysForReport,
            string requestedReportBeginDate)
        {
            this.ReportBeginDate = reportBeginDate;
            this.ReportEndDate = reportEndDate;
            this.ReportRequestDate = reportRequestDate;
            this.RequestedDaysForReport = requestedDaysForReport;
            this.RequestedReportBeginDate = requestedReportBeginDate;
        }

        /// <summary>
        /// Date from when the requested data is available
        /// </summary>
        [JsonProperty("reportBeginDate")]
        public string ReportBeginDate { get; set; }

        /// <summary>
        /// Date to which the requested data is available
        /// </summary>
        [JsonProperty("reportEndDate")]
        public string ReportEndDate { get; set; }

        /// <summary>
        /// The date and time the report was requested
        /// </summary>
        [JsonProperty("reportRequestDate")]
        public string ReportRequestDate { get; set; }

        /// <summary>
        /// Number of days requested for the report
        /// </summary>
        [JsonProperty("requestedDaysForReport")]
        public int RequestedDaysForReport { get; set; }

        /// <summary>
        /// Date the report would have began on if enough data was available for which the partner requested
        /// </summary>
        [JsonProperty("requestedReportBeginDate")]
        public string RequestedReportBeginDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbCurrentReportRequestDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbCurrentReportRequestDetails other &&
                ((this.ReportBeginDate == null && other.ReportBeginDate == null) || (this.ReportBeginDate?.Equals(other.ReportBeginDate) == true)) &&
                ((this.ReportEndDate == null && other.ReportEndDate == null) || (this.ReportEndDate?.Equals(other.ReportEndDate) == true)) &&
                ((this.ReportRequestDate == null && other.ReportRequestDate == null) || (this.ReportRequestDate?.Equals(other.ReportRequestDate) == true)) &&
                this.RequestedDaysForReport.Equals(other.RequestedDaysForReport) &&
                ((this.RequestedReportBeginDate == null && other.RequestedReportBeginDate == null) || (this.RequestedReportBeginDate?.Equals(other.RequestedReportBeginDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReportBeginDate = {(this.ReportBeginDate == null ? "null" : this.ReportBeginDate == string.Empty ? "" : this.ReportBeginDate)}");
            toStringOutput.Add($"this.ReportEndDate = {(this.ReportEndDate == null ? "null" : this.ReportEndDate == string.Empty ? "" : this.ReportEndDate)}");
            toStringOutput.Add($"this.ReportRequestDate = {(this.ReportRequestDate == null ? "null" : this.ReportRequestDate == string.Empty ? "" : this.ReportRequestDate)}");
            toStringOutput.Add($"this.RequestedDaysForReport = {this.RequestedDaysForReport}");
            toStringOutput.Add($"this.RequestedReportBeginDate = {(this.RequestedReportBeginDate == null ? "null" : this.RequestedReportBeginDate == string.Empty ? "" : this.RequestedReportBeginDate)}");
        }
    }
}