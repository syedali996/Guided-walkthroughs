// <copyright file="CashFlowCashFlowCharacteristicsSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowCashFlowCharacteristicsSummary.
    /// </summary>
    public class CashFlowCashFlowCharacteristicsSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCharacteristicsSummary"/> class.
        /// </summary>
        public CashFlowCashFlowCharacteristicsSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowCashFlowCharacteristicsSummary"/> class.
        /// </summary>
        /// <param name="monthlyCashFlowCharacteristicSummaries">monthlyCashFlowCharacteristicSummaries.</param>
        /// <param name="averageMonthlyNet">averageMonthlyNet.</param>
        /// <param name="averageMonthlyNetLessTransfers">averageMonthlyNetLessTransfers.</param>
        /// <param name="twelveMonthTotalNet">twelveMonthTotalNet.</param>
        /// <param name="twelveMonthTotalNetLessTransfers">twelveMonthTotalNetLessTransfers.</param>
        /// <param name="sixMonthAverageTotalCreditsLessTotalDebits">sixMonthAverageTotalCreditsLessTotalDebits.</param>
        /// <param name="sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers">sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers.</param>
        /// <param name="twoMonthAverageTotalCreditsLessTotalDebits">twoMonthAverageTotalCreditsLessTotalDebits.</param>
        /// <param name="twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers">twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers.</param>
        public CashFlowCashFlowCharacteristicsSummary(
            List<Models.CashFlowMonthlyCashFlowCharacteristicSummaries> monthlyCashFlowCharacteristicSummaries,
            double averageMonthlyNet,
            double averageMonthlyNetLessTransfers,
            double twelveMonthTotalNet,
            double twelveMonthTotalNetLessTransfers,
            double sixMonthAverageTotalCreditsLessTotalDebits,
            double sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers,
            double twoMonthAverageTotalCreditsLessTotalDebits,
            double twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers)
        {
            this.MonthlyCashFlowCharacteristicSummaries = monthlyCashFlowCharacteristicSummaries;
            this.AverageMonthlyNet = averageMonthlyNet;
            this.AverageMonthlyNetLessTransfers = averageMonthlyNetLessTransfers;
            this.TwelveMonthTotalNet = twelveMonthTotalNet;
            this.TwelveMonthTotalNetLessTransfers = twelveMonthTotalNetLessTransfers;
            this.SixMonthAverageTotalCreditsLessTotalDebits = sixMonthAverageTotalCreditsLessTotalDebits;
            this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers = sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers;
            this.TwoMonthAverageTotalCreditsLessTotalDebits = twoMonthAverageTotalCreditsLessTotalDebits;
            this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers = twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers;
        }

        /// <summary>
        /// List of attributes for each month
        /// </summary>
        [JsonProperty("monthlyCashFlowCharacteristicSummaries")]
        public List<Models.CashFlowMonthlyCashFlowCharacteristicSummaries> MonthlyCashFlowCharacteristicSummaries { get; set; }

        /// <summary>
        /// Average monthly net amount
        /// </summary>
        [JsonProperty("averageMonthlyNet")]
        public double AverageMonthlyNet { get; set; }

        /// <summary>
        /// Average monthly net less transfers
        /// </summary>
        [JsonProperty("averageMonthlyNetLessTransfers")]
        public double AverageMonthlyNetLessTransfers { get; set; }

        /// <summary>
        /// Sum of all monthly (Total Credits - Total Debits) each month by the account
        /// </summary>
        [JsonProperty("twelveMonthTotalNet")]
        public double TwelveMonthTotalNet { get; set; }

        /// <summary>
        /// Sum of all monthly (Total Credits - Total Debits) without transfers by the account
        /// </summary>
        [JsonProperty("twelveMonthTotalNetLessTransfers")]
        public double TwelveMonthTotalNetLessTransfers { get; set; }

        /// <summary>
        /// 6 Month Average (Total Credits - Total Debits) across all accounts
        /// </summary>
        [JsonProperty("sixMonthAverageTotalCreditsLessTotalDebits")]
        public double SixMonthAverageTotalCreditsLessTotalDebits { get; set; }

        /// <summary>
        /// 6 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts
        /// </summary>
        [JsonProperty("sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers")]
        public double SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers { get; set; }

        /// <summary>
        /// 2 Month Average (Total Credits - Total Debits) across all accounts
        /// </summary>
        [JsonProperty("twoMonthAverageTotalCreditsLessTotalDebits")]
        public double TwoMonthAverageTotalCreditsLessTotalDebits { get; set; }

        /// <summary>
        /// 2 Month Average (Total Credits - Total Debits) - (Without Transfers) across all accounts
        /// </summary>
        [JsonProperty("twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers")]
        public double TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowCashFlowCharacteristicsSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowCashFlowCharacteristicsSummary other &&
                ((this.MonthlyCashFlowCharacteristicSummaries == null && other.MonthlyCashFlowCharacteristicSummaries == null) || (this.MonthlyCashFlowCharacteristicSummaries?.Equals(other.MonthlyCashFlowCharacteristicSummaries) == true)) &&
                this.AverageMonthlyNet.Equals(other.AverageMonthlyNet) &&
                this.AverageMonthlyNetLessTransfers.Equals(other.AverageMonthlyNetLessTransfers) &&
                this.TwelveMonthTotalNet.Equals(other.TwelveMonthTotalNet) &&
                this.TwelveMonthTotalNetLessTransfers.Equals(other.TwelveMonthTotalNetLessTransfers) &&
                this.SixMonthAverageTotalCreditsLessTotalDebits.Equals(other.SixMonthAverageTotalCreditsLessTotalDebits) &&
                this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers.Equals(other.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers) &&
                this.TwoMonthAverageTotalCreditsLessTotalDebits.Equals(other.TwoMonthAverageTotalCreditsLessTotalDebits) &&
                this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers.Equals(other.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MonthlyCashFlowCharacteristicSummaries = {(this.MonthlyCashFlowCharacteristicSummaries == null ? "null" : $"[{string.Join(", ", this.MonthlyCashFlowCharacteristicSummaries)} ]")}");
            toStringOutput.Add($"this.AverageMonthlyNet = {this.AverageMonthlyNet}");
            toStringOutput.Add($"this.AverageMonthlyNetLessTransfers = {this.AverageMonthlyNetLessTransfers}");
            toStringOutput.Add($"this.TwelveMonthTotalNet = {this.TwelveMonthTotalNet}");
            toStringOutput.Add($"this.TwelveMonthTotalNetLessTransfers = {this.TwelveMonthTotalNetLessTransfers}");
            toStringOutput.Add($"this.SixMonthAverageTotalCreditsLessTotalDebits = {this.SixMonthAverageTotalCreditsLessTotalDebits}");
            toStringOutput.Add($"this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers = {this.SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers}");
            toStringOutput.Add($"this.TwoMonthAverageTotalCreditsLessTotalDebits = {this.TwoMonthAverageTotalCreditsLessTotalDebits}");
            toStringOutput.Add($"this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers = {this.TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers}");
        }
    }
}