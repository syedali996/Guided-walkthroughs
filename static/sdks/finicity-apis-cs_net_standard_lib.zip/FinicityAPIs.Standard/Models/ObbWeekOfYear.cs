// <copyright file="ObbWeekOfYear.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbWeekOfYear.
    /// </summary>
    public class ObbWeekOfYear
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbWeekOfYear"/> class.
        /// </summary>
        public ObbWeekOfYear()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbWeekOfYear"/> class.
        /// </summary>
        /// <param name="fromDate">fromDate.</param>
        /// <param name="toDate">toDate.</param>
        /// <param name="week">week.</param>
        public ObbWeekOfYear(
            string fromDate,
            string toDate,
            int week)
        {
            this.FromDate = fromDate;
            this.ToDate = toDate;
            this.Week = week;
        }

        /// <summary>
        /// Begin date of the week
        /// </summary>
        [JsonProperty("fromDate")]
        public string FromDate { get; set; }

        /// <summary>
        /// End date of the week
        /// </summary>
        [JsonProperty("toDate")]
        public string ToDate { get; set; }

        /// <summary>
        /// Week number, where the first week of each year begins on January 1st and ends on January 7th. May be in the range [1, 53]
        /// </summary>
        [JsonProperty("week")]
        public int Week { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbWeekOfYear : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbWeekOfYear other &&
                ((this.FromDate == null && other.FromDate == null) || (this.FromDate?.Equals(other.FromDate) == true)) &&
                ((this.ToDate == null && other.ToDate == null) || (this.ToDate?.Equals(other.ToDate) == true)) &&
                this.Week.Equals(other.Week);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FromDate = {(this.FromDate == null ? "null" : this.FromDate == string.Empty ? "" : this.FromDate)}");
            toStringOutput.Add($"this.ToDate = {(this.ToDate == null ? "null" : this.ToDate == string.Empty ? "" : this.ToDate)}");
            toStringOutput.Add($"this.Week = {this.Week}");
        }
    }
}