// <copyright file="CashFlowOutflowAttributes.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowOutflowAttributes.
    /// </summary>
    public class CashFlowOutflowAttributes
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowOutflowAttributes"/> class.
        /// </summary>
        public CashFlowOutflowAttributes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowOutflowAttributes"/> class.
        /// </summary>
        /// <param name="countWithdrawalsByMonthForTheReportTimePeriod">countWithdrawalsByMonthForTheReportTimePeriod.</param>
        /// <param name="historicCountOfWithdrawalTransactions">historicCountOfWithdrawalTransactions.</param>
        /// <param name="maximumWithdrawalByMonthForTheReportTimePeriod">maximumWithdrawalByMonthForTheReportTimePeriod.</param>
        /// <param name="minimumWithdrawalByMonthForTheReportTimePeriod">minimumWithdrawalByMonthForTheReportTimePeriod.</param>
        /// <param name="sumWithdrawalsByMonthForTheReportTimePeriod">sumWithdrawalsByMonthForTheReportTimePeriod.</param>
        /// <param name="averageWithdrawalByMonthForTheReportTimePeriod">averageWithdrawalByMonthForTheReportTimePeriod.</param>
        /// <param name="historicSumOfWithdrawals">historicSumOfWithdrawals.</param>
        public CashFlowOutflowAttributes(
            List<Models.ObbDateRangeAndCount> countWithdrawalsByMonthForTheReportTimePeriod,
            int historicCountOfWithdrawalTransactions,
            List<Models.ObbDateRangeAndAmount> maximumWithdrawalByMonthForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> minimumWithdrawalByMonthForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> sumWithdrawalsByMonthForTheReportTimePeriod,
            List<Models.ObbDateRangeAndAmount> averageWithdrawalByMonthForTheReportTimePeriod = null,
            double? historicSumOfWithdrawals = null)
        {
            this.AverageWithdrawalByMonthForTheReportTimePeriod = averageWithdrawalByMonthForTheReportTimePeriod;
            this.CountWithdrawalsByMonthForTheReportTimePeriod = countWithdrawalsByMonthForTheReportTimePeriod;
            this.HistoricCountOfWithdrawalTransactions = historicCountOfWithdrawalTransactions;
            this.HistoricSumOfWithdrawals = historicSumOfWithdrawals;
            this.MaximumWithdrawalByMonthForTheReportTimePeriod = maximumWithdrawalByMonthForTheReportTimePeriod;
            this.MinimumWithdrawalByMonthForTheReportTimePeriod = minimumWithdrawalByMonthForTheReportTimePeriod;
            this.SumWithdrawalsByMonthForTheReportTimePeriod = sumWithdrawalsByMonthForTheReportTimePeriod;
        }

        /// <summary>
        /// Average value of withdrawals during periods in the report
        /// </summary>
        [JsonProperty("averageWithdrawalByMonthForTheReportTimePeriod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ObbDateRangeAndAmount> AverageWithdrawalByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Count of all withdrawals during periods in the report
        /// </summary>
        [JsonProperty("countWithdrawalsByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndCount> CountWithdrawalsByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Count of ALL withdrawals over entire known history of the account (may exceed requested length of report)
        /// </summary>
        [JsonProperty("historicCountOfWithdrawalTransactions")]
        public int HistoricCountOfWithdrawalTransactions { get; set; }

        /// <summary>
        /// Sum of ALL withdrawals over entire known history of the account (may exceed requested length of report)
        /// </summary>
        [JsonProperty("historicSumOfWithdrawals", NullValueHandling = NullValueHandling.Ignore)]
        public double? HistoricSumOfWithdrawals { get; set; }

        /// <summary>
        /// Maximum withdrawal value for different periods in the report
        /// </summary>
        [JsonProperty("maximumWithdrawalByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> MaximumWithdrawalByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Minimum withdrawal value for different periods in the report
        /// </summary>
        [JsonProperty("minimumWithdrawalByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> MinimumWithdrawalByMonthForTheReportTimePeriod { get; set; }

        /// <summary>
        /// Sum of all withdrawals during periods in the report
        /// </summary>
        [JsonProperty("sumWithdrawalsByMonthForTheReportTimePeriod")]
        public List<Models.ObbDateRangeAndAmount> SumWithdrawalsByMonthForTheReportTimePeriod { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowOutflowAttributes : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowOutflowAttributes other &&
                ((this.AverageWithdrawalByMonthForTheReportTimePeriod == null && other.AverageWithdrawalByMonthForTheReportTimePeriod == null) || (this.AverageWithdrawalByMonthForTheReportTimePeriod?.Equals(other.AverageWithdrawalByMonthForTheReportTimePeriod) == true)) &&
                ((this.CountWithdrawalsByMonthForTheReportTimePeriod == null && other.CountWithdrawalsByMonthForTheReportTimePeriod == null) || (this.CountWithdrawalsByMonthForTheReportTimePeriod?.Equals(other.CountWithdrawalsByMonthForTheReportTimePeriod) == true)) &&
                this.HistoricCountOfWithdrawalTransactions.Equals(other.HistoricCountOfWithdrawalTransactions) &&
                ((this.HistoricSumOfWithdrawals == null && other.HistoricSumOfWithdrawals == null) || (this.HistoricSumOfWithdrawals?.Equals(other.HistoricSumOfWithdrawals) == true)) &&
                ((this.MaximumWithdrawalByMonthForTheReportTimePeriod == null && other.MaximumWithdrawalByMonthForTheReportTimePeriod == null) || (this.MaximumWithdrawalByMonthForTheReportTimePeriod?.Equals(other.MaximumWithdrawalByMonthForTheReportTimePeriod) == true)) &&
                ((this.MinimumWithdrawalByMonthForTheReportTimePeriod == null && other.MinimumWithdrawalByMonthForTheReportTimePeriod == null) || (this.MinimumWithdrawalByMonthForTheReportTimePeriod?.Equals(other.MinimumWithdrawalByMonthForTheReportTimePeriod) == true)) &&
                ((this.SumWithdrawalsByMonthForTheReportTimePeriod == null && other.SumWithdrawalsByMonthForTheReportTimePeriod == null) || (this.SumWithdrawalsByMonthForTheReportTimePeriod?.Equals(other.SumWithdrawalsByMonthForTheReportTimePeriod) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AverageWithdrawalByMonthForTheReportTimePeriod = {(this.AverageWithdrawalByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.AverageWithdrawalByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.CountWithdrawalsByMonthForTheReportTimePeriod = {(this.CountWithdrawalsByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.CountWithdrawalsByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.HistoricCountOfWithdrawalTransactions = {this.HistoricCountOfWithdrawalTransactions}");
            toStringOutput.Add($"this.HistoricSumOfWithdrawals = {(this.HistoricSumOfWithdrawals == null ? "null" : this.HistoricSumOfWithdrawals.ToString())}");
            toStringOutput.Add($"this.MaximumWithdrawalByMonthForTheReportTimePeriod = {(this.MaximumWithdrawalByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.MaximumWithdrawalByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.MinimumWithdrawalByMonthForTheReportTimePeriod = {(this.MinimumWithdrawalByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.MinimumWithdrawalByMonthForTheReportTimePeriod)} ]")}");
            toStringOutput.Add($"this.SumWithdrawalsByMonthForTheReportTimePeriod = {(this.SumWithdrawalsByMonthForTheReportTimePeriod == null ? "null" : $"[{string.Join(", ", this.SumWithdrawalsByMonthForTheReportTimePeriod)} ]")}");
        }
    }
}