// <copyright file="CertifiedInstitution.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CertifiedInstitution.
    /// </summary>
    public class CertifiedInstitution
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CertifiedInstitution"/> class.
        /// </summary>
        public CertifiedInstitution()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CertifiedInstitution"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="transAgg">transAgg.</param>
        /// <param name="ach">ach.</param>
        /// <param name="stateAgg">stateAgg.</param>
        /// <param name="voi">voi.</param>
        /// <param name="voa">voa.</param>
        /// <param name="aha">aha.</param>
        /// <param name="availBalance">availBalance.</param>
        /// <param name="accountOwner">accountOwner.</param>
        /// <param name="studentLoanData">studentLoanData.</param>
        /// <param name="loanPaymentDetails">loanPaymentDetails.</param>
        /// <param name="rssd">rssd.</param>
        /// <param name="childInstitutions">childInstitutions.</param>
        public CertifiedInstitution(
            long id,
            string name,
            bool transAgg,
            bool ach,
            bool stateAgg,
            bool voi,
            bool voa,
            bool aha,
            bool availBalance,
            bool accountOwner,
            bool studentLoanData,
            bool loanPaymentDetails,
            long? rssd = null,
            List<Models.ChildInstitution> childInstitutions = null)
        {
            this.Id = id;
            this.Rssd = rssd;
            this.Name = name;
            this.TransAgg = transAgg;
            this.Ach = ach;
            this.StateAgg = stateAgg;
            this.Voi = voi;
            this.Voa = voa;
            this.Aha = aha;
            this.AvailBalance = availBalance;
            this.AccountOwner = accountOwner;
            this.StudentLoanData = studentLoanData;
            this.LoanPaymentDetails = loanPaymentDetails;
            this.ChildInstitutions = childInstitutions;
        }

        /// <summary>
        /// The ID of a financial institution, represented as a number
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// The RSSD ID is a unique identifier assigned to financial institutions by the Federal Reserve. While the length of the RSSD ID varies by institution, it cannot exceed 10 numerical digits.
        /// </summary>
        [JsonProperty("rssd", NullValueHandling = NullValueHandling.Ignore)]
        public long? Rssd { get; set; }

        /// <summary>
        /// The name of the institution
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Transaction Aggregation product
        /// "false": The institution is decertified for the Transaction Aggregation product
        /// </summary>
        [JsonProperty("transAgg")]
        public bool TransAgg { get; set; }

        /// <summary>
        /// "true": The institution is certified for the ACH product
        /// "false": The institution is decertified for the ACH product
        /// </summary>
        [JsonProperty("ach")]
        public bool Ach { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Statement Aggregation product
        /// "false": The institution is decertified for the Statement Aggregation product
        /// </summary>
        [JsonProperty("stateAgg")]
        public bool StateAgg { get; set; }

        /// <summary>
        /// "true": The institution is certified for the VOI product
        /// "false": The institution is decertified for the VOI product
        /// </summary>
        [JsonProperty("voi")]
        public bool Voi { get; set; }

        /// <summary>
        /// "true": The institution is certified for the VOA product
        /// "false": The institution is decertified for the VOA product
        /// </summary>
        [JsonProperty("voa")]
        public bool Voa { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Account History Aggregation product
        /// "false": The institution is decertified for the Account History Aggregation product
        /// </summary>
        [JsonProperty("aha")]
        public bool Aha { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Account Balance Check (ABC) product
        /// "false": The institution is decertified for the Account Balance Check (ABC) product
        /// </summary>
        [JsonProperty("availBalance")]
        public bool AvailBalance { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Account Owner product
        /// "false": The institution is decertified for the Account Owner product
        /// </summary>
        [JsonProperty("accountOwner")]
        public bool AccountOwner { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Student Loan Data product
        /// "false": The institution is decertified for the Student Loan Data product
        /// </summary>
        [JsonProperty("studentLoanData")]
        public bool StudentLoanData { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Loan Payment Detail product
        /// "false": The institution is decertified for the Loan Payment Detail product
        /// </summary>
        [JsonProperty("loanPaymentDetails")]
        public bool LoanPaymentDetails { get; set; }

        /// <summary>
        /// An array of child financial institutions
        /// </summary>
        [JsonProperty("childInstitutions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ChildInstitution> ChildInstitutions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CertifiedInstitution : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CertifiedInstitution other &&
                this.Id.Equals(other.Id) &&
                ((this.Rssd == null && other.Rssd == null) || (this.Rssd?.Equals(other.Rssd) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                this.TransAgg.Equals(other.TransAgg) &&
                this.Ach.Equals(other.Ach) &&
                this.StateAgg.Equals(other.StateAgg) &&
                this.Voi.Equals(other.Voi) &&
                this.Voa.Equals(other.Voa) &&
                this.Aha.Equals(other.Aha) &&
                this.AvailBalance.Equals(other.AvailBalance) &&
                this.AccountOwner.Equals(other.AccountOwner) &&
                this.StudentLoanData.Equals(other.StudentLoanData) &&
                this.LoanPaymentDetails.Equals(other.LoanPaymentDetails) &&
                ((this.ChildInstitutions == null && other.ChildInstitutions == null) || (this.ChildInstitutions?.Equals(other.ChildInstitutions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.Rssd = {(this.Rssd == null ? "null" : this.Rssd.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.TransAgg = {this.TransAgg}");
            toStringOutput.Add($"this.Ach = {this.Ach}");
            toStringOutput.Add($"this.StateAgg = {this.StateAgg}");
            toStringOutput.Add($"this.Voi = {this.Voi}");
            toStringOutput.Add($"this.Voa = {this.Voa}");
            toStringOutput.Add($"this.Aha = {this.Aha}");
            toStringOutput.Add($"this.AvailBalance = {this.AvailBalance}");
            toStringOutput.Add($"this.AccountOwner = {this.AccountOwner}");
            toStringOutput.Add($"this.StudentLoanData = {this.StudentLoanData}");
            toStringOutput.Add($"this.LoanPaymentDetails = {this.LoanPaymentDetails}");
            toStringOutput.Add($"this.ChildInstitutions = {(this.ChildInstitutions == null ? "null" : $"[{string.Join(", ", this.ChildInstitutions)} ]")}");
        }
    }
}