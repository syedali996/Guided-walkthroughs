// <copyright file="AccountDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AccountDetails.
    /// </summary>
    public class AccountDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AccountDetails"/> class.
        /// </summary>
        public AccountDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountDetails"/> class.
        /// </summary>
        /// <param name="interestMarginBalance">interestMarginBalance.</param>
        /// <param name="availableCashBalance">availableCashBalance.</param>
        /// <param name="vestedBalance">vestedBalance.</param>
        /// <param name="currentLoanBalance">currentLoanBalance.</param>
        /// <param name="availableBalanceAmount">availableBalanceAmount.</param>
        public AccountDetails(
            double? interestMarginBalance = null,
            double? availableCashBalance = null,
            double? vestedBalance = null,
            double? currentLoanBalance = null,
            double? availableBalanceAmount = null)
        {
            this.InterestMarginBalance = interestMarginBalance;
            this.AvailableCashBalance = availableCashBalance;
            this.VestedBalance = vestedBalance;
            this.CurrentLoanBalance = currentLoanBalance;
            this.AvailableBalanceAmount = availableBalanceAmount;
        }

        /// <summary>
        /// Only available for investment accounts. Net interest earned after deducting interest paid out.
        /// </summary>
        [JsonProperty("interestMarginBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? InterestMarginBalance { get; set; }

        /// <summary>
        /// Only available for investment accounts. Amount available for cash withdrawal.
        /// </summary>
        [JsonProperty("availableCashBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AvailableCashBalance { get; set; }

        /// <summary>
        /// Only available for investment accounts. Vested amount in account.
        /// </summary>
        [JsonProperty("vestedBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? VestedBalance { get; set; }

        /// <summary>
        /// Only available for investment accounts. Current loan balance.
        /// </summary>
        [JsonProperty("currentLoanBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentLoanBalance { get; set; }

        /// <summary>
        /// The available balance for the account
        /// </summary>
        [JsonProperty("availableBalanceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? AvailableBalanceAmount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AccountDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AccountDetails other &&
                ((this.InterestMarginBalance == null && other.InterestMarginBalance == null) || (this.InterestMarginBalance?.Equals(other.InterestMarginBalance) == true)) &&
                ((this.AvailableCashBalance == null && other.AvailableCashBalance == null) || (this.AvailableCashBalance?.Equals(other.AvailableCashBalance) == true)) &&
                ((this.VestedBalance == null && other.VestedBalance == null) || (this.VestedBalance?.Equals(other.VestedBalance) == true)) &&
                ((this.CurrentLoanBalance == null && other.CurrentLoanBalance == null) || (this.CurrentLoanBalance?.Equals(other.CurrentLoanBalance) == true)) &&
                ((this.AvailableBalanceAmount == null && other.AvailableBalanceAmount == null) || (this.AvailableBalanceAmount?.Equals(other.AvailableBalanceAmount) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.InterestMarginBalance = {(this.InterestMarginBalance == null ? "null" : this.InterestMarginBalance.ToString())}");
            toStringOutput.Add($"this.AvailableCashBalance = {(this.AvailableCashBalance == null ? "null" : this.AvailableCashBalance.ToString())}");
            toStringOutput.Add($"this.VestedBalance = {(this.VestedBalance == null ? "null" : this.VestedBalance.ToString())}");
            toStringOutput.Add($"this.CurrentLoanBalance = {(this.CurrentLoanBalance == null ? "null" : this.CurrentLoanBalance.ToString())}");
            toStringOutput.Add($"this.AvailableBalanceAmount = {(this.AvailableBalanceAmount == null ? "null" : this.AvailableBalanceAmount.ToString())}");
        }
    }
}