// <copyright file="LoanPaymentDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// LoanPaymentDetails.
    /// </summary>
    public class LoanPaymentDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetails"/> class.
        /// </summary>
        public LoanPaymentDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LoanPaymentDetails"/> class.
        /// </summary>
        /// <param name="loanNumber">loanNumber.</param>
        /// <param name="loanPaymentNumber">loanPaymentNumber.</param>
        /// <param name="loanPaymentAddress">loanPaymentAddress.</param>
        /// <param name="accountDetail">accountDetail.</param>
        public LoanPaymentDetails(
            string loanNumber,
            string loanPaymentNumber,
            string loanPaymentAddress,
            Models.LoanPaymentDetailsAccount accountDetail = null)
        {
            this.LoanNumber = loanNumber;
            this.LoanPaymentNumber = loanPaymentNumber;
            this.LoanPaymentAddress = loanPaymentAddress;
            this.AccountDetail = accountDetail;
        }

        /// <summary>
        /// The number of the specific loan under the account.
        /// </summary>
        [JsonProperty("loanNumber")]
        public string LoanNumber { get; set; }

        /// <summary>
        /// The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number.
        /// </summary>
        [JsonProperty("loanPaymentNumber")]
        public string LoanPaymentNumber { get; set; }

        /// <summary>
        /// The payment address to send manual payments to
        /// </summary>
        [JsonProperty("loanPaymentAddress")]
        public string LoanPaymentAddress { get; set; }

        /// <summary>
        /// Gets or sets AccountDetail.
        /// </summary>
        [JsonProperty("accountDetail", NullValueHandling = NullValueHandling.Ignore)]
        public Models.LoanPaymentDetailsAccount AccountDetail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"LoanPaymentDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is LoanPaymentDetails other &&
                ((this.LoanNumber == null && other.LoanNumber == null) || (this.LoanNumber?.Equals(other.LoanNumber) == true)) &&
                ((this.LoanPaymentNumber == null && other.LoanPaymentNumber == null) || (this.LoanPaymentNumber?.Equals(other.LoanPaymentNumber) == true)) &&
                ((this.LoanPaymentAddress == null && other.LoanPaymentAddress == null) || (this.LoanPaymentAddress?.Equals(other.LoanPaymentAddress) == true)) &&
                ((this.AccountDetail == null && other.AccountDetail == null) || (this.AccountDetail?.Equals(other.AccountDetail) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.LoanNumber = {(this.LoanNumber == null ? "null" : this.LoanNumber == string.Empty ? "" : this.LoanNumber)}");
            toStringOutput.Add($"this.LoanPaymentNumber = {(this.LoanPaymentNumber == null ? "null" : this.LoanPaymentNumber == string.Empty ? "" : this.LoanPaymentNumber)}");
            toStringOutput.Add($"this.LoanPaymentAddress = {(this.LoanPaymentAddress == null ? "null" : this.LoanPaymentAddress == string.Empty ? "" : this.LoanPaymentAddress)}");
            toStringOutput.Add($"this.AccountDetail = {(this.AccountDetail == null ? "null" : this.AccountDetail.ToString())}");
        }
    }
}