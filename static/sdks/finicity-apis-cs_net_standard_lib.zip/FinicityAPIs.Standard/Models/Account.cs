// <copyright file="Account.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Account.
    /// </summary>
    public class Account
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Account"/> class.
        /// </summary>
        public Account()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Account"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="ownerName">ownerName.</param>
        /// <param name="ownerAddress">ownerAddress.</param>
        /// <param name="name">name.</param>
        /// <param name="number">number.</param>
        /// <param name="type">type.</param>
        /// <param name="aggregationStatusCode">aggregationStatusCode.</param>
        /// <param name="availableBalance">availableBalance.</param>
        /// <param name="transactions">transactions.</param>
        /// <param name="balance">balance.</param>
        /// <param name="averageMonthlyBalance">averageMonthlyBalance.</param>
        /// <param name="incomeStreams">incomeStreams.</param>
        /// <param name="currentBalance">currentBalance.</param>
        /// <param name="balanceDate">balanceDate.</param>
        /// <param name="cashFlowBalance">cashFlowBalance.</param>
        /// <param name="cashFlowCredit">cashFlowCredit.</param>
        /// <param name="cashFlowDebit">cashFlowDebit.</param>
        /// <param name="cashFlowCharacteristic">cashFlowCharacteristic.</param>
        /// <param name="totNumberInsufficientFundsFeeDebitTxAccount">totNumberInsufficientFundsFeeDebitTxAccount.</param>
        /// <param name="totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount">totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount.</param>
        /// <param name="totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount">totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount.</param>
        /// <param name="asset">asset.</param>
        /// <param name="details">details.</param>
        /// <param name="totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount">totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount.</param>
        /// <param name="beginningBalance">beginningBalance.</param>
        /// <param name="miscDeposits">miscDeposits.</param>
        public Account(
            string id,
            string ownerName,
            string ownerAddress,
            string name,
            string number,
            string type,
            string aggregationStatusCode,
            double availableBalance,
            List<Models.ReportTransaction> transactions,
            double balance,
            double averageMonthlyBalance,
            List<Models.VOAIReportIncomeStream2> incomeStreams,
            double? currentBalance = null,
            long? balanceDate = null,
            Models.CashFlowCashFlowBalance cashFlowBalance = null,
            Models.CashFlowCashFlowCredit cashFlowCredit = null,
            Models.CashFlowCashFlowDebit cashFlowDebit = null,
            Models.CashFlowCashFlowCharacteristic cashFlowCharacteristic = null,
            int? totNumberInsufficientFundsFeeDebitTxAccount = null,
            int? totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount = null,
            long? totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount = null,
            Models.PrequalificationReportAssetSummary asset = null,
            Models.AccountDetails details = null,
            long? totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount = null,
            double? beginningBalance = null,
            List<Models.ReportTransaction> miscDeposits = null)
        {
            this.Id = id;
            this.OwnerName = ownerName;
            this.OwnerAddress = ownerAddress;
            this.Name = name;
            this.Number = number;
            this.Type = type;
            this.AggregationStatusCode = aggregationStatusCode;
            this.CurrentBalance = currentBalance;
            this.AvailableBalance = availableBalance;
            this.BalanceDate = balanceDate;
            this.Transactions = transactions;
            this.CashFlowBalance = cashFlowBalance;
            this.CashFlowCredit = cashFlowCredit;
            this.CashFlowDebit = cashFlowDebit;
            this.CashFlowCharacteristic = cashFlowCharacteristic;
            this.Balance = balance;
            this.AverageMonthlyBalance = averageMonthlyBalance;
            this.TotNumberInsufficientFundsFeeDebitTxAccount = totNumberInsufficientFundsFeeDebitTxAccount;
            this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount = totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount;
            this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount = totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount;
            this.Asset = asset;
            this.Details = details;
            this.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount = totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount;
            this.IncomeStreams = incomeStreams;
            this.BeginningBalance = beginningBalance;
            this.MiscDeposits = miscDeposits;
        }

        /// <summary>
        /// Finicity account ID
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// The name(s) of the account owner(s), retrieved from the institution.
        /// </summary>
        [JsonProperty("ownerName")]
        public string OwnerName { get; set; }

        /// <summary>
        /// The mailing address of the account owner, retrieved from the institution.
        /// </summary>
        [JsonProperty("ownerAddress")]
        public string OwnerAddress { get; set; }

        /// <summary>
        /// The account name from the institution
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// The account number from the institution (obfuscated)
        /// </summary>
        [JsonProperty("number")]
        public string Number { get; set; }

        /// <summary>
        /// CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...)
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable)
        /// </summary>
        [JsonProperty("aggregationStatusCode")]
        public string AggregationStatusCode { get; set; }

        /// <summary>
        /// The cleared balance of the account as-of `balanceDate`
        /// </summary>
        [JsonProperty("currentBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentBalance { get; set; }

        /// <summary>
        /// Available balance
        /// </summary>
        [JsonProperty("availableBalance")]
        public double AvailableBalance { get; set; }

        /// <summary>
        /// A timestamp showing when the `balance` was captured
        /// </summary>
        [JsonProperty("balanceDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? BalanceDate { get; set; }

        /// <summary>
        /// a list of transaction records
        /// </summary>
        [JsonProperty("transactions")]
        public List<Models.ReportTransaction> Transactions { get; set; }

        /// <summary>
        /// Gets or sets CashFlowBalance.
        /// </summary>
        [JsonProperty("cashFlowBalance", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowCashFlowBalance CashFlowBalance { get; set; }

        /// <summary>
        /// Gets or sets CashFlowCredit.
        /// </summary>
        [JsonProperty("cashFlowCredit", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowCashFlowCredit CashFlowCredit { get; set; }

        /// <summary>
        /// Gets or sets CashFlowDebit.
        /// </summary>
        [JsonProperty("cashFlowDebit", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowCashFlowDebit CashFlowDebit { get; set; }

        /// <summary>
        /// Gets or sets CashFlowCharacteristic.
        /// </summary>
        [JsonProperty("cashFlowCharacteristic", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowCashFlowCharacteristic CashFlowCharacteristic { get; set; }

        /// <summary>
        /// The cleared balance of the account as-of `balanceDate`
        /// </summary>
        [JsonProperty("balance")]
        public double Balance { get; set; }

        /// <summary>
        /// The average monthly balance of the account
        /// </summary>
        [JsonProperty("averageMonthlyBalance")]
        public double AverageMonthlyBalance { get; set; }

        /// <summary>
        /// The count for the total number of insufficient funds transactions, based on the `fromDate` of the report
        /// </summary>
        [JsonProperty("totNumberInsufficientFundsFeeDebitTxAccount", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotNumberInsufficientFundsFeeDebitTxAccount { get; set; }

        /// <summary>
        /// The total number of  insufficient funds fees for the account over six months
        /// </summary>
        [JsonProperty("totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount { get; set; }

        /// <summary>
        /// The total number of days since the most recent insufficient funds fee for the account
        /// </summary>
        [JsonProperty("totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount", NullValueHandling = NullValueHandling.Ignore)]
        public long? TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount { get; set; }

        /// <summary>
        /// Gets or sets Asset.
        /// </summary>
        [JsonProperty("asset", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PrequalificationReportAssetSummary Asset { get; set; }

        /// <summary>
        /// Gets or sets Details.
        /// </summary>
        [JsonProperty("details", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AccountDetails Details { get; set; }

        /// <summary>
        /// The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report.
        /// </summary>
        [JsonProperty("totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount", NullValueHandling = NullValueHandling.Ignore)]
        public long? TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount { get; set; }

        /// <summary>
        /// A list of income stream records
        /// </summary>
        [JsonProperty("incomeStreams")]
        public List<Models.VOAIReportIncomeStream2> IncomeStreams { get; set; }

        /// <summary>
        /// Beginning balance of account per the time period in the report
        /// </summary>
        [JsonProperty("beginningBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? BeginningBalance { get; set; }

        /// <summary>
        /// A list of miscellaneous deposits
        /// </summary>
        [JsonProperty("miscDeposits", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportTransaction> MiscDeposits { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Account : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Account other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.OwnerName == null && other.OwnerName == null) || (this.OwnerName?.Equals(other.OwnerName) == true)) &&
                ((this.OwnerAddress == null && other.OwnerAddress == null) || (this.OwnerAddress?.Equals(other.OwnerAddress) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Number == null && other.Number == null) || (this.Number?.Equals(other.Number) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.AggregationStatusCode == null && other.AggregationStatusCode == null) || (this.AggregationStatusCode?.Equals(other.AggregationStatusCode) == true)) &&
                ((this.CurrentBalance == null && other.CurrentBalance == null) || (this.CurrentBalance?.Equals(other.CurrentBalance) == true)) &&
                this.AvailableBalance.Equals(other.AvailableBalance) &&
                ((this.BalanceDate == null && other.BalanceDate == null) || (this.BalanceDate?.Equals(other.BalanceDate) == true)) &&
                ((this.Transactions == null && other.Transactions == null) || (this.Transactions?.Equals(other.Transactions) == true)) &&
                ((this.CashFlowBalance == null && other.CashFlowBalance == null) || (this.CashFlowBalance?.Equals(other.CashFlowBalance) == true)) &&
                ((this.CashFlowCredit == null && other.CashFlowCredit == null) || (this.CashFlowCredit?.Equals(other.CashFlowCredit) == true)) &&
                ((this.CashFlowDebit == null && other.CashFlowDebit == null) || (this.CashFlowDebit?.Equals(other.CashFlowDebit) == true)) &&
                ((this.CashFlowCharacteristic == null && other.CashFlowCharacteristic == null) || (this.CashFlowCharacteristic?.Equals(other.CashFlowCharacteristic) == true)) &&
                this.Balance.Equals(other.Balance) &&
                this.AverageMonthlyBalance.Equals(other.AverageMonthlyBalance) &&
                ((this.TotNumberInsufficientFundsFeeDebitTxAccount == null && other.TotNumberInsufficientFundsFeeDebitTxAccount == null) || (this.TotNumberInsufficientFundsFeeDebitTxAccount?.Equals(other.TotNumberInsufficientFundsFeeDebitTxAccount) == true)) &&
                ((this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount == null && other.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount == null) || (this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount?.Equals(other.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount) == true)) &&
                ((this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount == null && other.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount == null) || (this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount?.Equals(other.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount) == true)) &&
                ((this.Asset == null && other.Asset == null) || (this.Asset?.Equals(other.Asset) == true)) &&
                ((this.Details == null && other.Details == null) || (this.Details?.Equals(other.Details) == true)) &&
                ((this.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount == null && other.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount == null) || (this.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount?.Equals(other.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount) == true)) &&
                ((this.IncomeStreams == null && other.IncomeStreams == null) || (this.IncomeStreams?.Equals(other.IncomeStreams) == true)) &&
                ((this.BeginningBalance == null && other.BeginningBalance == null) || (this.BeginningBalance?.Equals(other.BeginningBalance) == true)) &&
                ((this.MiscDeposits == null && other.MiscDeposits == null) || (this.MiscDeposits?.Equals(other.MiscDeposits) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.OwnerName = {(this.OwnerName == null ? "null" : this.OwnerName == string.Empty ? "" : this.OwnerName)}");
            toStringOutput.Add($"this.OwnerAddress = {(this.OwnerAddress == null ? "null" : this.OwnerAddress == string.Empty ? "" : this.OwnerAddress)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Number = {(this.Number == null ? "null" : this.Number == string.Empty ? "" : this.Number)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.AggregationStatusCode = {(this.AggregationStatusCode == null ? "null" : this.AggregationStatusCode == string.Empty ? "" : this.AggregationStatusCode)}");
            toStringOutput.Add($"this.CurrentBalance = {(this.CurrentBalance == null ? "null" : this.CurrentBalance.ToString())}");
            toStringOutput.Add($"this.AvailableBalance = {this.AvailableBalance}");
            toStringOutput.Add($"this.BalanceDate = {(this.BalanceDate == null ? "null" : this.BalanceDate.ToString())}");
            toStringOutput.Add($"this.Transactions = {(this.Transactions == null ? "null" : $"[{string.Join(", ", this.Transactions)} ]")}");
            toStringOutput.Add($"this.CashFlowBalance = {(this.CashFlowBalance == null ? "null" : this.CashFlowBalance.ToString())}");
            toStringOutput.Add($"this.CashFlowCredit = {(this.CashFlowCredit == null ? "null" : this.CashFlowCredit.ToString())}");
            toStringOutput.Add($"this.CashFlowDebit = {(this.CashFlowDebit == null ? "null" : this.CashFlowDebit.ToString())}");
            toStringOutput.Add($"this.CashFlowCharacteristic = {(this.CashFlowCharacteristic == null ? "null" : this.CashFlowCharacteristic.ToString())}");
            toStringOutput.Add($"this.Balance = {this.Balance}");
            toStringOutput.Add($"this.AverageMonthlyBalance = {this.AverageMonthlyBalance}");
            toStringOutput.Add($"this.TotNumberInsufficientFundsFeeDebitTxAccount = {(this.TotNumberInsufficientFundsFeeDebitTxAccount == null ? "null" : this.TotNumberInsufficientFundsFeeDebitTxAccount.ToString())}");
            toStringOutput.Add($"this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount = {(this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount == null ? "null" : this.TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount.ToString())}");
            toStringOutput.Add($"this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount = {(this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount == null ? "null" : this.TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount.ToString())}");
            toStringOutput.Add($"this.Asset = {(this.Asset == null ? "null" : this.Asset.ToString())}");
            toStringOutput.Add($"this.Details = {(this.Details == null ? "null" : this.Details.ToString())}");
            toStringOutput.Add($"this.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount = {(this.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount == null ? "null" : this.TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount.ToString())}");
            toStringOutput.Add($"this.IncomeStreams = {(this.IncomeStreams == null ? "null" : $"[{string.Join(", ", this.IncomeStreams)} ]")}");
            toStringOutput.Add($"this.BeginningBalance = {(this.BeginningBalance == null ? "null" : this.BeginningBalance.ToString())}");
            toStringOutput.Add($"this.MiscDeposits = {(this.MiscDeposits == null ? "null" : $"[{string.Join(", ", this.MiscDeposits)} ]")}");
        }
    }
}