// <copyright file="Institution.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Institution.
    /// </summary>
    public class Institution
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Institution"/> class.
        /// </summary>
        public Institution()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Institution"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="transAgg">transAgg.</param>
        /// <param name="ach">ach.</param>
        /// <param name="stateAgg">stateAgg.</param>
        /// <param name="voi">voi.</param>
        /// <param name="voa">voa.</param>
        /// <param name="aha">aha.</param>
        /// <param name="availBalance">availBalance.</param>
        /// <param name="accountOwner">accountOwner.</param>
        /// <param name="oauthEnabled">oauthEnabled.</param>
        /// <param name="currency">currency.</param>
        /// <param name="status">status.</param>
        /// <param name="name">name.</param>
        /// <param name="studentLoanData">studentLoanData.</param>
        /// <param name="loanPaymentDetails">loanPaymentDetails.</param>
        /// <param name="accountTypeDescription">accountTypeDescription.</param>
        /// <param name="phone">phone.</param>
        /// <param name="urlHomeApp">urlHomeApp.</param>
        /// <param name="urlLogonApp">urlLogonApp.</param>
        /// <param name="urlForgotPassword">urlForgotPassword.</param>
        /// <param name="urlOnlineRegistration">urlOnlineRegistration.</param>
        /// <param name="mClass">class.</param>
        /// <param name="specialText">specialText.</param>
        /// <param name="timeZone">timeZone.</param>
        /// <param name="specialInstructions">specialInstructions.</param>
        /// <param name="specialInstutionsTitle">specialInstutionsTitle.</param>
        /// <param name="address">address.</param>
        /// <param name="email">email.</param>
        /// <param name="newInstitutionId">newInstitutionId.</param>
        /// <param name="branding">branding.</param>
        /// <param name="oauthInstitutionId">oauthInstitutionId.</param>
        public Institution(
            long id,
            bool transAgg,
            bool ach,
            bool stateAgg,
            bool voi,
            bool voa,
            bool aha,
            bool availBalance,
            bool accountOwner,
            bool oauthEnabled,
            string currency,
            string status,
            string name = null,
            bool? studentLoanData = null,
            bool? loanPaymentDetails = null,
            string accountTypeDescription = null,
            string phone = null,
            string urlHomeApp = null,
            string urlLogonApp = null,
            string urlForgotPassword = null,
            string urlOnlineRegistration = null,
            string mClass = null,
            string specialText = null,
            string timeZone = null,
            List<string> specialInstructions = null,
            string specialInstutionsTitle = null,
            Models.InstitutionAddress address = null,
            string email = null,
            long? newInstitutionId = null,
            Models.Branding branding = null,
            long? oauthInstitutionId = null)
        {
            this.Id = id;
            this.Name = name;
            this.TransAgg = transAgg;
            this.Ach = ach;
            this.StateAgg = stateAgg;
            this.Voi = voi;
            this.Voa = voa;
            this.Aha = aha;
            this.AvailBalance = availBalance;
            this.AccountOwner = accountOwner;
            this.StudentLoanData = studentLoanData;
            this.LoanPaymentDetails = loanPaymentDetails;
            this.AccountTypeDescription = accountTypeDescription;
            this.Phone = phone;
            this.UrlHomeApp = urlHomeApp;
            this.UrlLogonApp = urlLogonApp;
            this.OauthEnabled = oauthEnabled;
            this.UrlForgotPassword = urlForgotPassword;
            this.UrlOnlineRegistration = urlOnlineRegistration;
            this.MClass = mClass;
            this.SpecialText = specialText;
            this.TimeZone = timeZone;
            this.SpecialInstructions = specialInstructions;
            this.SpecialInstutionsTitle = specialInstutionsTitle;
            this.Address = address;
            this.Currency = currency;
            this.Email = email;
            this.Status = status;
            this.NewInstitutionId = newInstitutionId;
            this.Branding = branding;
            this.OauthInstitutionId = oauthInstitutionId;
        }

        /// <summary>
        /// The ID of a financial institution, represented as a number
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// The name of the institution
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Transaction Aggregation product
        /// "false": The institution is decertified for the Transaction Aggregation product
        /// </summary>
        [JsonProperty("transAgg")]
        public bool TransAgg { get; set; }

        /// <summary>
        /// "true": The institution is certified for the ACH product
        /// "false": The institution is decertified for the ACH product
        /// </summary>
        [JsonProperty("ach")]
        public bool Ach { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Statement Aggregation product
        /// "false": The institution is decertified for the Statement Aggregation product
        /// </summary>
        [JsonProperty("stateAgg")]
        public bool StateAgg { get; set; }

        /// <summary>
        /// "true": The institution is certified for the VOI product
        /// "false": The institution is decertified for the VOI product
        /// </summary>
        [JsonProperty("voi")]
        public bool Voi { get; set; }

        /// <summary>
        /// "true": The institution is certified for the VOA product
        /// "false": The institution is decertified for the VOA product
        /// </summary>
        [JsonProperty("voa")]
        public bool Voa { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Account History Aggregation product
        /// "false": The institution is decertified for the Account History Aggregation product
        /// </summary>
        [JsonProperty("aha")]
        public bool Aha { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Account Balance Check (ABC) product
        /// "false": The institution is decertified for the Account Balance Check (ABC) product
        /// </summary>
        [JsonProperty("availBalance")]
        public bool AvailBalance { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Account Owner product
        /// "false": The institution is decertified for the Account Owner product
        /// </summary>
        [JsonProperty("accountOwner")]
        public bool AccountOwner { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Student Loan Data product
        /// "false": The institution is decertified for the Student Loan Data product
        /// </summary>
        [JsonProperty("studentLoanData", NullValueHandling = NullValueHandling.Ignore)]
        public bool? StudentLoanData { get; set; }

        /// <summary>
        /// "true": The institution is certified for the Loan Payment Detail product
        /// "false": The institution is decertified for the Loan Payment Detail product
        /// </summary>
        [JsonProperty("loanPaymentDetails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LoanPaymentDetails { get; set; }

        /// <summary>
        /// Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance
        /// </summary>
        [JsonProperty("accountTypeDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountTypeDescription { get; set; }

        /// <summary>
        /// A phone number
        /// </summary>
        [JsonProperty("phone", NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; }

        /// <summary>
        /// The URL of the institution's primary home page
        /// </summary>
        [JsonProperty("urlHomeApp", NullValueHandling = NullValueHandling.Ignore)]
        public string UrlHomeApp { get; set; }

        /// <summary>
        /// The URL of the institution's login page
        /// </summary>
        [JsonProperty("urlLogonApp", NullValueHandling = NullValueHandling.Ignore)]
        public string UrlLogonApp { get; set; }

        /// <summary>
        /// "true": The institution is an OAuth connection
        /// "false": The institution isn't an OAuth connection
        /// </summary>
        [JsonProperty("oauthEnabled")]
        public bool OauthEnabled { get; set; }

        /// <summary>
        /// Institution's forgot password page
        /// </summary>
        [JsonProperty("urlForgotPassword", NullValueHandling = NullValueHandling.Ignore)]
        public string UrlForgotPassword { get; set; }

        /// <summary>
        /// Institution's signup page
        /// </summary>
        [JsonProperty("urlOnlineRegistration", NullValueHandling = NullValueHandling.Ignore)]
        public string UrlOnlineRegistration { get; set; }

        /// <summary>
        /// Institution's class
        /// </summary>
        [JsonProperty("class", NullValueHandling = NullValueHandling.Ignore)]
        public string MClass { get; set; }

        /// <summary>
        /// Special instructions given to customers for login
        /// </summary>
        [JsonProperty("specialText", NullValueHandling = NullValueHandling.Ignore)]
        public string SpecialText { get; set; }

        /// <summary>
        /// The time zone of the institution.
        /// </summary>
        [JsonProperty("timeZone", NullValueHandling = NullValueHandling.Ignore)]
        public string TimeZone { get; set; }

        /// <summary>
        /// Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.
        /// Note: this helps the customer to provide the proper permission for data needed for the application.
        /// </summary>
        [JsonProperty("specialInstructions", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> SpecialInstructions { get; set; }

        /// <summary>
        /// The title of the special instructions, if one exists or is required.
        /// </summary>
        [JsonProperty("specialInstutionsTitle", NullValueHandling = NullValueHandling.Ignore)]
        public string SpecialInstutionsTitle { get; set; }

        /// <summary>
        /// The address of a financial institution
        /// </summary>
        [JsonProperty("address", NullValueHandling = NullValueHandling.Ignore)]
        public Models.InstitutionAddress Address { get; set; }

        /// <summary>
        /// A currency code
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// An email address
        /// </summary>
        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// Status for the institution: "online", "offline", "maintenance", "testing"
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <summary>
        /// The ID of a financial institution, represented as a number
        /// </summary>
        [JsonProperty("newInstitutionId", NullValueHandling = NullValueHandling.Ignore)]
        public long? NewInstitutionId { get; set; }

        /// <summary>
        /// All assets are SVGs so can be slightly resized without any issues.
        /// </summary>
        [JsonProperty("branding", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Branding Branding { get; set; }

        /// <summary>
        /// The ID of a financial institution, represented as a number
        /// </summary>
        [JsonProperty("oauthInstitutionId", NullValueHandling = NullValueHandling.Ignore)]
        public long? OauthInstitutionId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Institution : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Institution other &&
                this.Id.Equals(other.Id) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                this.TransAgg.Equals(other.TransAgg) &&
                this.Ach.Equals(other.Ach) &&
                this.StateAgg.Equals(other.StateAgg) &&
                this.Voi.Equals(other.Voi) &&
                this.Voa.Equals(other.Voa) &&
                this.Aha.Equals(other.Aha) &&
                this.AvailBalance.Equals(other.AvailBalance) &&
                this.AccountOwner.Equals(other.AccountOwner) &&
                ((this.StudentLoanData == null && other.StudentLoanData == null) || (this.StudentLoanData?.Equals(other.StudentLoanData) == true)) &&
                ((this.LoanPaymentDetails == null && other.LoanPaymentDetails == null) || (this.LoanPaymentDetails?.Equals(other.LoanPaymentDetails) == true)) &&
                ((this.AccountTypeDescription == null && other.AccountTypeDescription == null) || (this.AccountTypeDescription?.Equals(other.AccountTypeDescription) == true)) &&
                ((this.Phone == null && other.Phone == null) || (this.Phone?.Equals(other.Phone) == true)) &&
                ((this.UrlHomeApp == null && other.UrlHomeApp == null) || (this.UrlHomeApp?.Equals(other.UrlHomeApp) == true)) &&
                ((this.UrlLogonApp == null && other.UrlLogonApp == null) || (this.UrlLogonApp?.Equals(other.UrlLogonApp) == true)) &&
                this.OauthEnabled.Equals(other.OauthEnabled) &&
                ((this.UrlForgotPassword == null && other.UrlForgotPassword == null) || (this.UrlForgotPassword?.Equals(other.UrlForgotPassword) == true)) &&
                ((this.UrlOnlineRegistration == null && other.UrlOnlineRegistration == null) || (this.UrlOnlineRegistration?.Equals(other.UrlOnlineRegistration) == true)) &&
                ((this.MClass == null && other.MClass == null) || (this.MClass?.Equals(other.MClass) == true)) &&
                ((this.SpecialText == null && other.SpecialText == null) || (this.SpecialText?.Equals(other.SpecialText) == true)) &&
                ((this.TimeZone == null && other.TimeZone == null) || (this.TimeZone?.Equals(other.TimeZone) == true)) &&
                ((this.SpecialInstructions == null && other.SpecialInstructions == null) || (this.SpecialInstructions?.Equals(other.SpecialInstructions) == true)) &&
                ((this.SpecialInstutionsTitle == null && other.SpecialInstutionsTitle == null) || (this.SpecialInstutionsTitle?.Equals(other.SpecialInstutionsTitle) == true)) &&
                ((this.Address == null && other.Address == null) || (this.Address?.Equals(other.Address) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.NewInstitutionId == null && other.NewInstitutionId == null) || (this.NewInstitutionId?.Equals(other.NewInstitutionId) == true)) &&
                ((this.Branding == null && other.Branding == null) || (this.Branding?.Equals(other.Branding) == true)) &&
                ((this.OauthInstitutionId == null && other.OauthInstitutionId == null) || (this.OauthInstitutionId?.Equals(other.OauthInstitutionId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.TransAgg = {this.TransAgg}");
            toStringOutput.Add($"this.Ach = {this.Ach}");
            toStringOutput.Add($"this.StateAgg = {this.StateAgg}");
            toStringOutput.Add($"this.Voi = {this.Voi}");
            toStringOutput.Add($"this.Voa = {this.Voa}");
            toStringOutput.Add($"this.Aha = {this.Aha}");
            toStringOutput.Add($"this.AvailBalance = {this.AvailBalance}");
            toStringOutput.Add($"this.AccountOwner = {this.AccountOwner}");
            toStringOutput.Add($"this.StudentLoanData = {(this.StudentLoanData == null ? "null" : this.StudentLoanData.ToString())}");
            toStringOutput.Add($"this.LoanPaymentDetails = {(this.LoanPaymentDetails == null ? "null" : this.LoanPaymentDetails.ToString())}");
            toStringOutput.Add($"this.AccountTypeDescription = {(this.AccountTypeDescription == null ? "null" : this.AccountTypeDescription == string.Empty ? "" : this.AccountTypeDescription)}");
            toStringOutput.Add($"this.Phone = {(this.Phone == null ? "null" : this.Phone == string.Empty ? "" : this.Phone)}");
            toStringOutput.Add($"this.UrlHomeApp = {(this.UrlHomeApp == null ? "null" : this.UrlHomeApp == string.Empty ? "" : this.UrlHomeApp)}");
            toStringOutput.Add($"this.UrlLogonApp = {(this.UrlLogonApp == null ? "null" : this.UrlLogonApp == string.Empty ? "" : this.UrlLogonApp)}");
            toStringOutput.Add($"this.OauthEnabled = {this.OauthEnabled}");
            toStringOutput.Add($"this.UrlForgotPassword = {(this.UrlForgotPassword == null ? "null" : this.UrlForgotPassword == string.Empty ? "" : this.UrlForgotPassword)}");
            toStringOutput.Add($"this.UrlOnlineRegistration = {(this.UrlOnlineRegistration == null ? "null" : this.UrlOnlineRegistration == string.Empty ? "" : this.UrlOnlineRegistration)}");
            toStringOutput.Add($"this.MClass = {(this.MClass == null ? "null" : this.MClass == string.Empty ? "" : this.MClass)}");
            toStringOutput.Add($"this.SpecialText = {(this.SpecialText == null ? "null" : this.SpecialText == string.Empty ? "" : this.SpecialText)}");
            toStringOutput.Add($"this.TimeZone = {(this.TimeZone == null ? "null" : this.TimeZone == string.Empty ? "" : this.TimeZone)}");
            toStringOutput.Add($"this.SpecialInstructions = {(this.SpecialInstructions == null ? "null" : $"[{string.Join(", ", this.SpecialInstructions)} ]")}");
            toStringOutput.Add($"this.SpecialInstutionsTitle = {(this.SpecialInstutionsTitle == null ? "null" : this.SpecialInstutionsTitle == string.Empty ? "" : this.SpecialInstutionsTitle)}");
            toStringOutput.Add($"this.Address = {(this.Address == null ? "null" : this.Address.ToString())}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.NewInstitutionId = {(this.NewInstitutionId == null ? "null" : this.NewInstitutionId.ToString())}");
            toStringOutput.Add($"this.Branding = {(this.Branding == null ? "null" : this.Branding.ToString())}");
            toStringOutput.Add($"this.OauthInstitutionId = {(this.OauthInstitutionId == null ? "null" : this.OauthInstitutionId.ToString())}");
        }
    }
}