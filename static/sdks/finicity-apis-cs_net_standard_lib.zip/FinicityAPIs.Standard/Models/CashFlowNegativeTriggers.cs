// <copyright file="CashFlowNegativeTriggers.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CashFlowNegativeTriggers.
    /// </summary>
    public class CashFlowNegativeTriggers
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowNegativeTriggers"/> class.
        /// </summary>
        public CashFlowNegativeTriggers()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CashFlowNegativeTriggers"/> class.
        /// </summary>
        /// <param name="insufficientFundFees">insufficientFundFees.</param>
        public CashFlowNegativeTriggers(
            Models.CashFlowInsufficientFundsFees insufficientFundFees = null)
        {
            this.InsufficientFundFees = insufficientFundFees;
        }

        /// <summary>
        /// Non Sufficient Fund Fees
        /// </summary>
        [JsonProperty("insufficientFundFees", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CashFlowInsufficientFundsFees InsufficientFundFees { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CashFlowNegativeTriggers : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CashFlowNegativeTriggers other &&
                ((this.InsufficientFundFees == null && other.InsufficientFundFees == null) || (this.InsufficientFundFees?.Equals(other.InsufficientFundFees) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.InsufficientFundFees = {(this.InsufficientFundFees == null ? "null" : this.InsufficientFundFees.ToString())}");
        }
    }
}