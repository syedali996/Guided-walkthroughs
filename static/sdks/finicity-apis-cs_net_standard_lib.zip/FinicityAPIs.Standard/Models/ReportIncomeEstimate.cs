// <copyright file="ReportIncomeEstimate.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReportIncomeEstimate.
    /// </summary>
    public class ReportIncomeEstimate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportIncomeEstimate"/> class.
        /// </summary>
        public ReportIncomeEstimate()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportIncomeEstimate"/> class.
        /// </summary>
        /// <param name="netAnnual">netAnnual.</param>
        /// <param name="projectedNetAnnual">projectedNetAnnual.</param>
        /// <param name="estimatedGrossAnnual">estimatedGrossAnnual.</param>
        /// <param name="projectedGrossAnnual">projectedGrossAnnual.</param>
        public ReportIncomeEstimate(
            double netAnnual,
            double projectedNetAnnual,
            double estimatedGrossAnnual,
            double projectedGrossAnnual)
        {
            this.NetAnnual = netAnnual;
            this.ProjectedNetAnnual = projectedNetAnnual;
            this.EstimatedGrossAnnual = estimatedGrossAnnual;
            this.ProjectedGrossAnnual = projectedGrossAnnual;
        }

        /// <summary>
        /// Gets or sets NetAnnual.
        /// </summary>
        [JsonProperty("netAnnual")]
        public double NetAnnual { get; set; }

        /// <summary>
        /// Gets or sets ProjectedNetAnnual.
        /// </summary>
        [JsonProperty("projectedNetAnnual")]
        public double ProjectedNetAnnual { get; set; }

        /// <summary>
        /// Gets or sets EstimatedGrossAnnual.
        /// </summary>
        [JsonProperty("estimatedGrossAnnual")]
        public double EstimatedGrossAnnual { get; set; }

        /// <summary>
        /// Gets or sets ProjectedGrossAnnual.
        /// </summary>
        [JsonProperty("projectedGrossAnnual")]
        public double ProjectedGrossAnnual { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReportIncomeEstimate : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReportIncomeEstimate other &&
                this.NetAnnual.Equals(other.NetAnnual) &&
                this.ProjectedNetAnnual.Equals(other.ProjectedNetAnnual) &&
                this.EstimatedGrossAnnual.Equals(other.EstimatedGrossAnnual) &&
                this.ProjectedGrossAnnual.Equals(other.ProjectedGrossAnnual);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.NetAnnual = {this.NetAnnual}");
            toStringOutput.Add($"this.ProjectedNetAnnual = {this.ProjectedNetAnnual}");
            toStringOutput.Add($"this.EstimatedGrossAnnual = {this.EstimatedGrossAnnual}");
            toStringOutput.Add($"this.ProjectedGrossAnnual = {this.ProjectedGrossAnnual}");
        }
    }
}