// <copyright file="Deduction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Deduction.
    /// </summary>
    public class Deduction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Deduction"/> class.
        /// </summary>
        public Deduction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Deduction"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="description">description.</param>
        /// <param name="amountCurrent">amountCurrent.</param>
        /// <param name="amountYTD">amountYTD.</param>
        /// <param name="type">type.</param>
        public Deduction(
            string name = null,
            string description = null,
            double? amountCurrent = null,
            double? amountYTD = null,
            string type = null)
        {
            this.Name = name;
            this.Description = description;
            this.AmountCurrent = amountCurrent;
            this.AmountYTD = amountYTD;
            this.Type = type;
        }

        /// <summary>
        /// The normalized category of the deductions in the format [type][number]. The number is the will be the iterating number of the type's occurrence starting at one.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The deduction line's deduction type description
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// The amount for the deduction line deducted from employee's pay for the specified pay period
        /// </summary>
        [JsonProperty("amountCurrent", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountCurrent { get; set; }

        /// <summary>
        /// The amount for the deduction line being deducted from the employee's pay for the current pay year
        /// </summary>
        [JsonProperty("amountYTD", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountYTD { get; set; }

        /// <summary>
        /// Categorization based on the deduction line's description
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Deduction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Deduction other &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.AmountCurrent == null && other.AmountCurrent == null) || (this.AmountCurrent?.Equals(other.AmountCurrent) == true)) &&
                ((this.AmountYTD == null && other.AmountYTD == null) || (this.AmountYTD?.Equals(other.AmountYTD) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.AmountCurrent = {(this.AmountCurrent == null ? "null" : this.AmountCurrent.ToString())}");
            toStringOutput.Add($"this.AmountYTD = {(this.AmountYTD == null ? "null" : this.AmountYTD.ToString())}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
        }
    }
}