// <copyright file="ObbNumWeeksAverageBalanceIncreasing.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ObbNumWeeksAverageBalanceIncreasing.
    /// </summary>
    public class ObbNumWeeksAverageBalanceIncreasing
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObbNumWeeksAverageBalanceIncreasing"/> class.
        /// </summary>
        public ObbNumWeeksAverageBalanceIncreasing()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObbNumWeeksAverageBalanceIncreasing"/> class.
        /// </summary>
        /// <param name="historicAverageWeeklyBalances">historicAverageWeeklyBalances.</param>
        /// <param name="historicNumberOfWeeksAverageBalanceIncreasing">historicNumberOfWeeksAverageBalanceIncreasing.</param>
        /// <param name="historicNumberOfWeeksWithDataAvailable">historicNumberOfWeeksWithDataAvailable.</param>
        public ObbNumWeeksAverageBalanceIncreasing(
            List<Models.ObbAverageWeeklyBalance> historicAverageWeeklyBalances,
            int historicNumberOfWeeksAverageBalanceIncreasing,
            int historicNumberOfWeeksWithDataAvailable)
        {
            this.HistoricAverageWeeklyBalances = historicAverageWeeklyBalances;
            this.HistoricNumberOfWeeksAverageBalanceIncreasing = historicNumberOfWeeksAverageBalanceIncreasing;
            this.HistoricNumberOfWeeksWithDataAvailable = historicNumberOfWeeksWithDataAvailable;
        }

        /// <summary>
        /// Average weekly balances over the known history
        /// </summary>
        [JsonProperty("historicAverageWeeklyBalances")]
        public List<Models.ObbAverageWeeklyBalance> HistoricAverageWeeklyBalances { get; set; }

        /// <summary>
        /// Number of weeks during the known history where the average balance of the account increased week over week
        /// </summary>
        [JsonProperty("historicNumberOfWeeksAverageBalanceIncreasing")]
        public int HistoricNumberOfWeeksAverageBalanceIncreasing { get; set; }

        /// <summary>
        /// Number of weeks during the history in which data was available
        /// </summary>
        [JsonProperty("historicNumberOfWeeksWithDataAvailable")]
        public int HistoricNumberOfWeeksWithDataAvailable { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ObbNumWeeksAverageBalanceIncreasing : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ObbNumWeeksAverageBalanceIncreasing other &&
                ((this.HistoricAverageWeeklyBalances == null && other.HistoricAverageWeeklyBalances == null) || (this.HistoricAverageWeeklyBalances?.Equals(other.HistoricAverageWeeklyBalances) == true)) &&
                this.HistoricNumberOfWeeksAverageBalanceIncreasing.Equals(other.HistoricNumberOfWeeksAverageBalanceIncreasing) &&
                this.HistoricNumberOfWeeksWithDataAvailable.Equals(other.HistoricNumberOfWeeksWithDataAvailable);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.HistoricAverageWeeklyBalances = {(this.HistoricAverageWeeklyBalances == null ? "null" : $"[{string.Join(", ", this.HistoricAverageWeeklyBalances)} ]")}");
            toStringOutput.Add($"this.HistoricNumberOfWeeksAverageBalanceIncreasing = {this.HistoricNumberOfWeeksAverageBalanceIncreasing}");
            toStringOutput.Add($"this.HistoricNumberOfWeeksWithDataAvailable = {this.HistoricNumberOfWeeksWithDataAvailable}");
        }
    }
}