// <copyright file="ConsumerAttributesDataExpenses.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesDataExpenses.
    /// </summary>
    public class ConsumerAttributesDataExpenses
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataExpenses"/> class.
        /// </summary>
        public ConsumerAttributesDataExpenses()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataExpenses"/> class.
        /// </summary>
        /// <param name="dwellingExpenseTotal">dwellingExpenseTotal.</param>
        /// <param name="dwellingExpensesByAccount">dwellingExpensesByAccount.</param>
        /// <param name="monthlyDwellingExpenseByCustomer">monthlyDwellingExpenseByCustomer.</param>
        /// <param name="monthlyDwellingExpenseByAccount">monthlyDwellingExpenseByAccount.</param>
        /// <param name="monthlyDebitAmountByCustomer">monthlyDebitAmountByCustomer.</param>
        /// <param name="monthlyExpenseAmountByCustomer">monthlyExpenseAmountByCustomer.</param>
        public ConsumerAttributesDataExpenses(
            double dwellingExpenseTotal,
            object dwellingExpensesByAccount,
            object monthlyDwellingExpenseByCustomer,
            object monthlyDwellingExpenseByAccount,
            object monthlyDebitAmountByCustomer,
            object monthlyExpenseAmountByCustomer)
        {
            this.DwellingExpenseTotal = dwellingExpenseTotal;
            this.DwellingExpensesByAccount = dwellingExpensesByAccount;
            this.MonthlyDwellingExpenseByCustomer = monthlyDwellingExpenseByCustomer;
            this.MonthlyDwellingExpenseByAccount = monthlyDwellingExpenseByAccount;
            this.MonthlyDebitAmountByCustomer = monthlyDebitAmountByCustomer;
            this.MonthlyExpenseAmountByCustomer = monthlyExpenseAmountByCustomer;
        }

        /// <summary>
        /// Total dwelling expenses for the last 12 months: rent, mortgage, utilities, and insurance
        /// </summary>
        [JsonProperty("dwellingExpenseTotal")]
        public double DwellingExpenseTotal { get; set; }

        /// <summary>
        /// Total dwelling expenses by account for the last 12 months: rent, mortgage, utilities, and insurance
        /// </summary>
        [JsonProperty("dwellingExpensesByAccount")]
        public object DwellingExpensesByAccount { get; set; }

        /// <summary>
        /// Monthly dwelling expenses by customer
        /// </summary>
        [JsonProperty("monthlyDwellingExpenseByCustomer")]
        public object MonthlyDwellingExpenseByCustomer { get; set; }

        /// <summary>
        /// Monthly dwelling expenses by account
        /// </summary>
        [JsonProperty("monthlyDwellingExpenseByAccount")]
        public object MonthlyDwellingExpenseByAccount { get; set; }

        /// <summary>
        /// Total monthly debit amounts by customer
        /// </summary>
        [JsonProperty("monthlyDebitAmountByCustomer")]
        public object MonthlyDebitAmountByCustomer { get; set; }

        /// <summary>
        /// Total monthly debit amounts, excluding transfers and credit card payments
        /// </summary>
        [JsonProperty("monthlyExpenseAmountByCustomer")]
        public object MonthlyExpenseAmountByCustomer { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesDataExpenses : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesDataExpenses other &&
                this.DwellingExpenseTotal.Equals(other.DwellingExpenseTotal) &&
                ((this.DwellingExpensesByAccount == null && other.DwellingExpensesByAccount == null) || (this.DwellingExpensesByAccount?.Equals(other.DwellingExpensesByAccount) == true)) &&
                ((this.MonthlyDwellingExpenseByCustomer == null && other.MonthlyDwellingExpenseByCustomer == null) || (this.MonthlyDwellingExpenseByCustomer?.Equals(other.MonthlyDwellingExpenseByCustomer) == true)) &&
                ((this.MonthlyDwellingExpenseByAccount == null && other.MonthlyDwellingExpenseByAccount == null) || (this.MonthlyDwellingExpenseByAccount?.Equals(other.MonthlyDwellingExpenseByAccount) == true)) &&
                ((this.MonthlyDebitAmountByCustomer == null && other.MonthlyDebitAmountByCustomer == null) || (this.MonthlyDebitAmountByCustomer?.Equals(other.MonthlyDebitAmountByCustomer) == true)) &&
                ((this.MonthlyExpenseAmountByCustomer == null && other.MonthlyExpenseAmountByCustomer == null) || (this.MonthlyExpenseAmountByCustomer?.Equals(other.MonthlyExpenseAmountByCustomer) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DwellingExpenseTotal = {this.DwellingExpenseTotal}");
            toStringOutput.Add($"DwellingExpensesByAccount = {(this.DwellingExpensesByAccount == null ? "null" : this.DwellingExpensesByAccount.ToString())}");
            toStringOutput.Add($"MonthlyDwellingExpenseByCustomer = {(this.MonthlyDwellingExpenseByCustomer == null ? "null" : this.MonthlyDwellingExpenseByCustomer.ToString())}");
            toStringOutput.Add($"MonthlyDwellingExpenseByAccount = {(this.MonthlyDwellingExpenseByAccount == null ? "null" : this.MonthlyDwellingExpenseByAccount.ToString())}");
            toStringOutput.Add($"MonthlyDebitAmountByCustomer = {(this.MonthlyDebitAmountByCustomer == null ? "null" : this.MonthlyDebitAmountByCustomer.ToString())}");
            toStringOutput.Add($"MonthlyExpenseAmountByCustomer = {(this.MonthlyExpenseAmountByCustomer == null ? "null" : this.MonthlyExpenseAmountByCustomer.ToString())}");
        }
    }
}