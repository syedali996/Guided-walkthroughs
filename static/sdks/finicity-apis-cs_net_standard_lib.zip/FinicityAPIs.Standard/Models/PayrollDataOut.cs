// <copyright file="PayrollDataOut.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollDataOut.
    /// </summary>
    public class PayrollDataOut
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollDataOut"/> class.
        /// </summary>
        public PayrollDataOut()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollDataOut"/> class.
        /// </summary>
        /// <param name="payrollDataRetrievalId">payrollDataRetrievalId.</param>
        /// <param name="employerNames">employerNames.</param>
        /// <param name="reportId">reportId.</param>
        public PayrollDataOut(
            string payrollDataRetrievalId,
            List<string> employerNames,
            string reportId = null)
        {
            this.PayrollDataRetrievalId = payrollDataRetrievalId;
            this.EmployerNames = employerNames;
            this.ReportId = reportId;
        }

        /// <summary>
        /// An id to identify the data retrieved from the payroll providers for the report.
        /// </summary>
        [JsonProperty("payrollDataRetrievalId")]
        public string PayrollDataRetrievalId { get; set; }

        /// <summary>
        /// An array of employer names that the consumer submitted after completing the Connect application.
        /// </summary>
        [JsonProperty("employerNames")]
        public List<string> EmployerNames { get; set; }

        /// <summary>
        /// A report ID
        /// </summary>
        [JsonProperty("reportId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReportId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollDataOut : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollDataOut other &&
                ((this.PayrollDataRetrievalId == null && other.PayrollDataRetrievalId == null) || (this.PayrollDataRetrievalId?.Equals(other.PayrollDataRetrievalId) == true)) &&
                ((this.EmployerNames == null && other.EmployerNames == null) || (this.EmployerNames?.Equals(other.EmployerNames) == true)) &&
                ((this.ReportId == null && other.ReportId == null) || (this.ReportId?.Equals(other.ReportId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PayrollDataRetrievalId = {(this.PayrollDataRetrievalId == null ? "null" : this.PayrollDataRetrievalId == string.Empty ? "" : this.PayrollDataRetrievalId)}");
            toStringOutput.Add($"this.EmployerNames = {(this.EmployerNames == null ? "null" : $"[{string.Join(", ", this.EmployerNames)} ]")}");
            toStringOutput.Add($"this.ReportId = {(this.ReportId == null ? "null" : this.ReportId == string.Empty ? "" : this.ReportId)}");
        }
    }
}