// <copyright file="ReportHeader.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReportHeader.
    /// </summary>
    public class ReportHeader
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportHeader"/> class.
        /// </summary>
        public ReportHeader()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportHeader"/> class.
        /// </summary>
        /// <param name="reportDate">reportDate.</param>
        /// <param name="reportId">reportId.</param>
        /// <param name="businessAddress">businessAddress.</param>
        /// <param name="businessCity">businessCity.</param>
        /// <param name="businessName">businessName.</param>
        /// <param name="businessState">businessState.</param>
        /// <param name="businessZip">businessZip.</param>
        /// <param name="referenceNumber">referenceNumber.</param>
        public ReportHeader(
            string reportDate,
            string reportId,
            string businessAddress = null,
            string businessCity = null,
            string businessName = null,
            string businessState = null,
            string businessZip = null,
            string referenceNumber = null)
        {
            this.BusinessAddress = businessAddress;
            this.BusinessCity = businessCity;
            this.BusinessName = businessName;
            this.BusinessState = businessState;
            this.BusinessZip = businessZip;
            this.ReferenceNumber = referenceNumber;
            this.ReportDate = reportDate;
            this.ReportId = reportId;
        }

        /// <summary>
        /// Business address line 1
        /// </summary>
        [JsonProperty("businessAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessAddress { get; set; }

        /// <summary>
        /// Business address city
        /// </summary>
        [JsonProperty("businessCity", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessCity { get; set; }

        /// <summary>
        /// Name of the business
        /// </summary>
        [JsonProperty("businessName", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessName { get; set; }

        /// <summary>
        /// Business address state
        /// </summary>
        [JsonProperty("businessState", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessState { get; set; }

        /// <summary>
        /// Business address zip
        /// </summary>
        [JsonProperty("businessZip", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessZip { get; set; }

        /// <summary>
        /// Partner-provided reference number
        /// </summary>
        [JsonProperty("referenceNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// Date the report was requested
        /// </summary>
        [JsonProperty("reportDate")]
        public string ReportDate { get; set; }

        /// <summary>
        /// Generated unique report ID
        /// </summary>
        [JsonProperty("reportId")]
        public string ReportId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReportHeader : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReportHeader other &&
                ((this.BusinessAddress == null && other.BusinessAddress == null) || (this.BusinessAddress?.Equals(other.BusinessAddress) == true)) &&
                ((this.BusinessCity == null && other.BusinessCity == null) || (this.BusinessCity?.Equals(other.BusinessCity) == true)) &&
                ((this.BusinessName == null && other.BusinessName == null) || (this.BusinessName?.Equals(other.BusinessName) == true)) &&
                ((this.BusinessState == null && other.BusinessState == null) || (this.BusinessState?.Equals(other.BusinessState) == true)) &&
                ((this.BusinessZip == null && other.BusinessZip == null) || (this.BusinessZip?.Equals(other.BusinessZip) == true)) &&
                ((this.ReferenceNumber == null && other.ReferenceNumber == null) || (this.ReferenceNumber?.Equals(other.ReferenceNumber) == true)) &&
                ((this.ReportDate == null && other.ReportDate == null) || (this.ReportDate?.Equals(other.ReportDate) == true)) &&
                ((this.ReportId == null && other.ReportId == null) || (this.ReportId?.Equals(other.ReportId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BusinessAddress = {(this.BusinessAddress == null ? "null" : this.BusinessAddress == string.Empty ? "" : this.BusinessAddress)}");
            toStringOutput.Add($"this.BusinessCity = {(this.BusinessCity == null ? "null" : this.BusinessCity == string.Empty ? "" : this.BusinessCity)}");
            toStringOutput.Add($"this.BusinessName = {(this.BusinessName == null ? "null" : this.BusinessName == string.Empty ? "" : this.BusinessName)}");
            toStringOutput.Add($"this.BusinessState = {(this.BusinessState == null ? "null" : this.BusinessState == string.Empty ? "" : this.BusinessState)}");
            toStringOutput.Add($"this.BusinessZip = {(this.BusinessZip == null ? "null" : this.BusinessZip == string.Empty ? "" : this.BusinessZip)}");
            toStringOutput.Add($"this.ReferenceNumber = {(this.ReferenceNumber == null ? "null" : this.ReferenceNumber == string.Empty ? "" : this.ReferenceNumber)}");
            toStringOutput.Add($"this.ReportDate = {(this.ReportDate == null ? "null" : this.ReportDate == string.Empty ? "" : this.ReportDate)}");
            toStringOutput.Add($"this.ReportId = {(this.ReportId == null ? "null" : this.ReportId == string.Empty ? "" : this.ReportId)}");
        }
    }
}