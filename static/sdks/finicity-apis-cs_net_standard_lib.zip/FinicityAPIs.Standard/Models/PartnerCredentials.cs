// <copyright file="PartnerCredentials.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PartnerCredentials.
    /// </summary>
    public class PartnerCredentials
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PartnerCredentials"/> class.
        /// </summary>
        public PartnerCredentials()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PartnerCredentials"/> class.
        /// </summary>
        /// <param name="partnerId">partnerId.</param>
        /// <param name="partnerSecret">partnerSecret.</param>
        public PartnerCredentials(
            string partnerId,
            string partnerSecret)
        {
            this.PartnerId = partnerId;
            this.PartnerSecret = partnerSecret;
        }

        /// <summary>
        /// Your Partner ID displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerId")]
        public string PartnerId { get; set; }

        /// <summary>
        /// Your Partner Secret displayed in the [Developer Dashboard](https://developer.finicity.com/admin)
        /// </summary>
        [JsonProperty("partnerSecret")]
        public string PartnerSecret { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PartnerCredentials : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PartnerCredentials other &&
                ((this.PartnerId == null && other.PartnerId == null) || (this.PartnerId?.Equals(other.PartnerId) == true)) &&
                ((this.PartnerSecret == null && other.PartnerSecret == null) || (this.PartnerSecret?.Equals(other.PartnerSecret) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PartnerId = {(this.PartnerId == null ? "null" : this.PartnerId == string.Empty ? "" : this.PartnerId)}");
            toStringOutput.Add($"this.PartnerSecret = {(this.PartnerSecret == null ? "null" : this.PartnerSecret == string.Empty ? "" : this.PartnerSecret)}");
        }
    }
}