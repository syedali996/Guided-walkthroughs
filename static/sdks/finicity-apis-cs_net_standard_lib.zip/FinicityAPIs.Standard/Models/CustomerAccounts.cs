// <copyright file="CustomerAccounts.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CustomerAccounts.
    /// </summary>
    public class CustomerAccounts
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccounts"/> class.
        /// </summary>
        public CustomerAccounts()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccounts"/> class.
        /// </summary>
        /// <param name="accounts">accounts.</param>
        public CustomerAccounts(
            List<Models.CustomerAccount> accounts)
        {
            this.Accounts = accounts;
        }

        /// <summary>
        /// List of customer accounts
        /// </summary>
        [JsonProperty("accounts")]
        public List<Models.CustomerAccount> Accounts { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomerAccounts : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CustomerAccounts other &&
                ((this.Accounts == null && other.Accounts == null) || (this.Accounts?.Equals(other.Accounts) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Accounts = {(this.Accounts == null ? "null" : $"[{string.Join(", ", this.Accounts)} ]")}");
        }
    }
}