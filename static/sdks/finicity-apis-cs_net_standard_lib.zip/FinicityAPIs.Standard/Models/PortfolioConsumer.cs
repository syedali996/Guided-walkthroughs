// <copyright file="PortfolioConsumer.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PortfolioConsumer.
    /// </summary>
    public class PortfolioConsumer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PortfolioConsumer"/> class.
        /// </summary>
        public PortfolioConsumer()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PortfolioConsumer"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="firstName">firstName.</param>
        /// <param name="lastName">lastName.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="ssn">ssn.</param>
        /// <param name="birthday">birthday.</param>
        /// <param name="suffix">suffix.</param>
        public PortfolioConsumer(
            string id,
            string firstName,
            string lastName,
            long customerId,
            string ssn,
            Models.Birthday birthday,
            string suffix = null)
        {
            this.Id = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.CustomerId = customerId;
            this.Ssn = ssn;
            this.Birthday = birthday;
            this.Suffix = suffix;
        }

        /// <summary>
        /// A consumer ID. See Create Consumer API for how to create a consumer ID.
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// First name(s) / given name(s)
        /// </summary>
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// Last name(s) / surname(s)
        /// </summary>
        [JsonProperty("lastName")]
        public string LastName { get; set; }

        /// <summary>
        /// A customer ID represented as a number. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public long CustomerId { get; set; }

        /// <summary>
        /// A full SSN with or without hyphens
        /// </summary>
        [JsonProperty("ssn")]
        public string Ssn { get; set; }

        /// <summary>
        /// A birth date
        /// </summary>
        [JsonProperty("birthday")]
        public Models.Birthday Birthday { get; set; }

        /// <summary>
        /// A person suffix
        /// </summary>
        [JsonProperty("suffix", NullValueHandling = NullValueHandling.Ignore)]
        public string Suffix { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PortfolioConsumer : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PortfolioConsumer other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                this.CustomerId.Equals(other.CustomerId) &&
                ((this.Ssn == null && other.Ssn == null) || (this.Ssn?.Equals(other.Ssn) == true)) &&
                ((this.Birthday == null && other.Birthday == null) || (this.Birthday?.Equals(other.Birthday) == true)) &&
                ((this.Suffix == null && other.Suffix == null) || (this.Suffix?.Equals(other.Suffix) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName == string.Empty ? "" : this.LastName)}");
            toStringOutput.Add($"this.CustomerId = {this.CustomerId}");
            toStringOutput.Add($"this.Ssn = {(this.Ssn == null ? "null" : this.Ssn == string.Empty ? "" : this.Ssn)}");
            toStringOutput.Add($"this.Birthday = {(this.Birthday == null ? "null" : this.Birthday.ToString())}");
            toStringOutput.Add($"this.Suffix = {(this.Suffix == null ? "null" : this.Suffix == string.Empty ? "" : this.Suffix)}");
        }
    }
}