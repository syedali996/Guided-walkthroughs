// <copyright file="RegisteredApplication.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// RegisteredApplication.
    /// </summary>
    public class RegisteredApplication
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RegisteredApplication"/> class.
        /// </summary>
        public RegisteredApplication()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RegisteredApplication"/> class.
        /// </summary>
        /// <param name="preAppId">preAppId.</param>
        /// <param name="status">status.</param>
        public RegisteredApplication(
            long preAppId,
            string status)
        {
            this.PreAppId = preAppId;
            this.Status = status;
        }

        /// <summary>
        /// Identifier to track the application registration from the App Registration and Get App Registration Status APIs, represented as a number
        /// </summary>
        [JsonProperty("preAppId")]
        public long PreAppId { get; set; }

        /// <summary>
        /// The status of an app registration request. "A" means approved. "P" means pending which is the status when initially submitted or when the app is modified and awaiting approval. "R" means rejected. If it is rejected there will be a note with the rejected reason.
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"RegisteredApplication : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is RegisteredApplication other &&
                this.PreAppId.Equals(other.PreAppId) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PreAppId = {this.PreAppId}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
        }
    }
}