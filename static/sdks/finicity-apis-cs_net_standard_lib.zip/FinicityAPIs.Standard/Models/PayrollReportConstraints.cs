// <copyright file="PayrollReportConstraints.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollReportConstraints.
    /// </summary>
    public class PayrollReportConstraints
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollReportConstraints"/> class.
        /// </summary>
        public PayrollReportConstraints()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollReportConstraints"/> class.
        /// </summary>
        /// <param name="payrollData">payrollData.</param>
        /// <param name="reportCustomFields">reportCustomFields.</param>
        /// <param name="payStatementsFromDate">payStatementsFromDate.</param>
        /// <param name="marketSegment">marketSegment.</param>
        /// <param name="excludeEmpInfo">excludeEmpInfo.</param>
        /// <param name="purpose">purpose.</param>
        public PayrollReportConstraints(
            Models.PayrollData payrollData,
            List<Models.ReportCustomField> reportCustomFields = null,
            long? payStatementsFromDate = null,
            string marketSegment = null,
            bool? excludeEmpInfo = null,
            string purpose = null)
        {
            this.PayrollData = payrollData;
            this.ReportCustomFields = reportCustomFields;
            this.PayStatementsFromDate = payStatementsFromDate;
            this.MarketSegment = marketSegment;
            this.ExcludeEmpInfo = excludeEmpInfo;
            this.Purpose = purpose;
        }

        /// <summary>
        /// Gets or sets PayrollData.
        /// </summary>
        [JsonProperty("payrollData")]
        public Models.PayrollData PayrollData { get; set; }

        /// <summary>
        /// The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.
        /// Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".
        /// * "true": (default) display the custom field in the PDF report
        /// * "false": don't display the custom field in the PDF report
        /// For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.
        /// All custom fields display in the Reseller Billing API.
        /// </summary>
        [JsonProperty("reportCustomFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ReportCustomField> ReportCustomFields { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("payStatementsFromDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? PayStatementsFromDate { get; set; }

        /// <summary>
        /// Filter consumer’s data based on the market segment. Currently supported values are; "Mortgage", "KYC", and "Identity".
        /// </summary>
        [JsonProperty("marketSegment", NullValueHandling = NullValueHandling.Ignore)]
        public string MarketSegment { get; set; }

        /// <summary>
        /// If true is passed, Employment information data will not be searched or returned.
        /// </summary>
        [JsonProperty("excludeEmpInfo", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ExcludeEmpInfo { get; set; }

        /// <summary>
        /// 2-digit code from [Permissible Purpose Codes] (https://docs.finicity.com/permissible-purpose-codes/), specifying the reason for retrieving this report.
        /// </summary>
        [JsonProperty("purpose", NullValueHandling = NullValueHandling.Ignore)]
        public string Purpose { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollReportConstraints : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollReportConstraints other &&
                ((this.PayrollData == null && other.PayrollData == null) || (this.PayrollData?.Equals(other.PayrollData) == true)) &&
                ((this.ReportCustomFields == null && other.ReportCustomFields == null) || (this.ReportCustomFields?.Equals(other.ReportCustomFields) == true)) &&
                ((this.PayStatementsFromDate == null && other.PayStatementsFromDate == null) || (this.PayStatementsFromDate?.Equals(other.PayStatementsFromDate) == true)) &&
                ((this.MarketSegment == null && other.MarketSegment == null) || (this.MarketSegment?.Equals(other.MarketSegment) == true)) &&
                ((this.ExcludeEmpInfo == null && other.ExcludeEmpInfo == null) || (this.ExcludeEmpInfo?.Equals(other.ExcludeEmpInfo) == true)) &&
                ((this.Purpose == null && other.Purpose == null) || (this.Purpose?.Equals(other.Purpose) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PayrollData = {(this.PayrollData == null ? "null" : this.PayrollData.ToString())}");
            toStringOutput.Add($"this.ReportCustomFields = {(this.ReportCustomFields == null ? "null" : $"[{string.Join(", ", this.ReportCustomFields)} ]")}");
            toStringOutput.Add($"this.PayStatementsFromDate = {(this.PayStatementsFromDate == null ? "null" : this.PayStatementsFromDate.ToString())}");
            toStringOutput.Add($"this.MarketSegment = {(this.MarketSegment == null ? "null" : this.MarketSegment == string.Empty ? "" : this.MarketSegment)}");
            toStringOutput.Add($"this.ExcludeEmpInfo = {(this.ExcludeEmpInfo == null ? "null" : this.ExcludeEmpInfo.ToString())}");
            toStringOutput.Add($"this.Purpose = {(this.Purpose == null ? "null" : this.Purpose == string.Empty ? "" : this.Purpose)}");
        }
    }
}