// <copyright file="NetMonthly.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// NetMonthly.
    /// </summary>
    public class NetMonthly
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NetMonthly"/> class.
        /// </summary>
        public NetMonthly()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NetMonthly"/> class.
        /// </summary>
        /// <param name="month">month.</param>
        /// <param name="net">net.</param>
        public NetMonthly(
            long month,
            double net)
        {
            this.Month = month;
            this.Net = net;
        }

        /// <summary>
        /// Timestamp for the first day of this month
        /// </summary>
        [JsonProperty("month")]
        public long Month { get; set; }

        /// <summary>
        /// Total income during the given month, across all income streams
        /// </summary>
        [JsonProperty("net")]
        public double Net { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"NetMonthly : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is NetMonthly other &&
                this.Month.Equals(other.Month) &&
                this.Net.Equals(other.Net);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Month = {this.Month}");
            toStringOutput.Add($"this.Net = {this.Net}");
        }
    }
}