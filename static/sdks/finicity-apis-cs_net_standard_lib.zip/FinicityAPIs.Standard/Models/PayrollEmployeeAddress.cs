// <copyright file="PayrollEmployeeAddress.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PayrollEmployeeAddress.
    /// </summary>
    public class PayrollEmployeeAddress
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollEmployeeAddress"/> class.
        /// </summary>
        public PayrollEmployeeAddress()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollEmployeeAddress"/> class.
        /// </summary>
        /// <param name="address1">address1.</param>
        /// <param name="city">city.</param>
        /// <param name="state">state.</param>
        /// <param name="zip">zip.</param>
        public PayrollEmployeeAddress(
            string address1 = null,
            string city = null,
            string state = null,
            string zip = null)
        {
            this.Address1 = address1;
            this.City = city;
            this.State = state;
            this.Zip = zip;
        }

        /// <summary>
        /// Employee address as stated by the employer in the payroll system
        /// </summary>
        [JsonProperty("address1", NullValueHandling = NullValueHandling.Ignore)]
        public string Address1 { get; set; }

        /// <summary>
        /// Employee city as stated by the employer in the payroll system
        /// </summary>
        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// Employee state as stated by the employer in the payroll system
        /// </summary>
        [JsonProperty("state", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// Employee zip code as stated by the employer in the payroll system
        /// </summary>
        [JsonProperty("zip", NullValueHandling = NullValueHandling.Ignore)]
        public string Zip { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PayrollEmployeeAddress : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PayrollEmployeeAddress other &&
                ((this.Address1 == null && other.Address1 == null) || (this.Address1?.Equals(other.Address1) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.Zip == null && other.Zip == null) || (this.Zip?.Equals(other.Zip) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Address1 = {(this.Address1 == null ? "null" : this.Address1 == string.Empty ? "" : this.Address1)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.Zip = {(this.Zip == null ? "null" : this.Zip == string.Empty ? "" : this.Zip)}");
        }
    }
}