// <copyright file="ConsumerAttributesDataLiabilities.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesDataLiabilities.
    /// </summary>
    public class ConsumerAttributesDataLiabilities
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataLiabilities"/> class.
        /// </summary>
        public ConsumerAttributesDataLiabilities()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataLiabilities"/> class.
        /// </summary>
        /// <param name="monthlyLoanDeposits">monthlyLoanDeposits.</param>
        /// <param name="monthlyLoanWitdrawls">monthlyLoanWitdrawls.</param>
        /// <param name="monthlyNumberOfLoanDeposits">monthlyNumberOfLoanDeposits.</param>
        /// <param name="monthlyNumberOfLoanWithdrawls">monthlyNumberOfLoanWithdrawls.</param>
        public ConsumerAttributesDataLiabilities(
            object monthlyLoanDeposits,
            object monthlyLoanWitdrawls,
            object monthlyNumberOfLoanDeposits,
            object monthlyNumberOfLoanWithdrawls)
        {
            this.MonthlyLoanDeposits = monthlyLoanDeposits;
            this.MonthlyLoanWitdrawls = monthlyLoanWitdrawls;
            this.MonthlyNumberOfLoanDeposits = monthlyNumberOfLoanDeposits;
            this.MonthlyNumberOfLoanWithdrawls = monthlyNumberOfLoanWithdrawls;
        }

        /// <summary>
        /// Monthly loan deposits amount by account
        /// </summary>
        [JsonProperty("monthlyLoanDeposits")]
        public object MonthlyLoanDeposits { get; set; }

        /// <summary>
        /// Monthly loan withdrawal amount by account
        /// </summary>
        [JsonProperty("monthlyLoanWitdrawls")]
        public object MonthlyLoanWitdrawls { get; set; }

        /// <summary>
        /// Monthly count of the number of loan deposits by account
        /// </summary>
        [JsonProperty("monthlyNumberOfLoanDeposits")]
        public object MonthlyNumberOfLoanDeposits { get; set; }

        /// <summary>
        /// Monthly amount of the number of loan deposits by account
        /// </summary>
        [JsonProperty("monthlyNumberOfLoanWithdrawls")]
        public object MonthlyNumberOfLoanWithdrawls { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesDataLiabilities : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesDataLiabilities other &&
                ((this.MonthlyLoanDeposits == null && other.MonthlyLoanDeposits == null) || (this.MonthlyLoanDeposits?.Equals(other.MonthlyLoanDeposits) == true)) &&
                ((this.MonthlyLoanWitdrawls == null && other.MonthlyLoanWitdrawls == null) || (this.MonthlyLoanWitdrawls?.Equals(other.MonthlyLoanWitdrawls) == true)) &&
                ((this.MonthlyNumberOfLoanDeposits == null && other.MonthlyNumberOfLoanDeposits == null) || (this.MonthlyNumberOfLoanDeposits?.Equals(other.MonthlyNumberOfLoanDeposits) == true)) &&
                ((this.MonthlyNumberOfLoanWithdrawls == null && other.MonthlyNumberOfLoanWithdrawls == null) || (this.MonthlyNumberOfLoanWithdrawls?.Equals(other.MonthlyNumberOfLoanWithdrawls) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"MonthlyLoanDeposits = {(this.MonthlyLoanDeposits == null ? "null" : this.MonthlyLoanDeposits.ToString())}");
            toStringOutput.Add($"MonthlyLoanWitdrawls = {(this.MonthlyLoanWitdrawls == null ? "null" : this.MonthlyLoanWitdrawls.ToString())}");
            toStringOutput.Add($"MonthlyNumberOfLoanDeposits = {(this.MonthlyNumberOfLoanDeposits == null ? "null" : this.MonthlyNumberOfLoanDeposits.ToString())}");
            toStringOutput.Add($"MonthlyNumberOfLoanWithdrawls = {(this.MonthlyNumberOfLoanWithdrawls == null ? "null" : this.MonthlyNumberOfLoanWithdrawls.ToString())}");
        }
    }
}