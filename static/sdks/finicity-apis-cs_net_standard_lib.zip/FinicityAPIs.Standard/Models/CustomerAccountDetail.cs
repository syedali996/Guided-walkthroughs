// <copyright file="CustomerAccountDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CustomerAccountDetail.
    /// </summary>
    public class CustomerAccountDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccountDetail"/> class.
        /// </summary>
        public CustomerAccountDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccountDetail"/> class.
        /// </summary>
        /// <param name="availableBalanceAmount">availableBalanceAmount.</param>
        /// <param name="dateAsOf">dateAsOf.</param>
        /// <param name="openDate">openDate.</param>
        /// <param name="periodStartDate">periodStartDate.</param>
        /// <param name="periodEndDate">periodEndDate.</param>
        /// <param name="periodInterestRate">periodInterestRate.</param>
        /// <param name="periodDepositAmount">periodDepositAmount.</param>
        /// <param name="periodInterestAmount">periodInterestAmount.</param>
        /// <param name="interestYtdAmount">interestYtdAmount.</param>
        /// <param name="interestPriorYtdAmount">interestPriorYtdAmount.</param>
        /// <param name="maturityDate">maturityDate.</param>
        /// <param name="interestRate">interestRate.</param>
        /// <param name="creditAvailableAmount">creditAvailableAmount.</param>
        /// <param name="creditMaxAmount">creditMaxAmount.</param>
        /// <param name="cashAdvanceAvailableAmount">cashAdvanceAvailableAmount.</param>
        /// <param name="cashAdvanceMaxAmount">cashAdvanceMaxAmount.</param>
        /// <param name="cashAdvanceBalance">cashAdvanceBalance.</param>
        /// <param name="cashAdvanceInterestRate">cashAdvanceInterestRate.</param>
        /// <param name="currentBalance">currentBalance.</param>
        /// <param name="paymentMinAmount">paymentMinAmount.</param>
        /// <param name="paymentDueDate">paymentDueDate.</param>
        /// <param name="previousBalance">previousBalance.</param>
        /// <param name="statementStartDate">statementStartDate.</param>
        /// <param name="statementEndDate">statementEndDate.</param>
        /// <param name="statementPurchaseAmount">statementPurchaseAmount.</param>
        /// <param name="statementFinanceAmount">statementFinanceAmount.</param>
        /// <param name="statementCreditAmount">statementCreditAmount.</param>
        /// <param name="rewardEarnedBalance">rewardEarnedBalance.</param>
        /// <param name="pastDueAmount">pastDueAmount.</param>
        /// <param name="lastPaymentAmount">lastPaymentAmount.</param>
        /// <param name="lastPaymentDate">lastPaymentDate.</param>
        /// <param name="statementCloseBalance">statementCloseBalance.</param>
        /// <param name="termOfMl">termOfMl.</param>
        /// <param name="mlHolderName">mlHolderName.</param>
        /// <param name="description">description.</param>
        /// <param name="lateFeeAmount">lateFeeAmount.</param>
        /// <param name="payoffAmount">payoffAmount.</param>
        /// <param name="payoffAmountDate">payoffAmountDate.</param>
        /// <param name="originalMaturityDate">originalMaturityDate.</param>
        /// <param name="principalBalance">principalBalance.</param>
        /// <param name="escrowBalance">escrowBalance.</param>
        /// <param name="interestPeriod">interestPeriod.</param>
        /// <param name="initialMlAmount">initialMlAmount.</param>
        /// <param name="initialMlDate">initialMlDate.</param>
        /// <param name="nextPaymentPrincipalAmount">nextPaymentPrincipalAmount.</param>
        /// <param name="nextPaymentInterestAmount">nextPaymentInterestAmount.</param>
        /// <param name="nextPayment">nextPayment.</param>
        /// <param name="nextPaymentDate">nextPaymentDate.</param>
        /// <param name="lastPaymentDueDate">lastPaymentDueDate.</param>
        /// <param name="lastPaymentReceiveDate">lastPaymentReceiveDate.</param>
        /// <param name="lastPaymentPrincipalAmount">lastPaymentPrincipalAmount.</param>
        /// <param name="lastPaymentInterestAmount">lastPaymentInterestAmount.</param>
        /// <param name="lastPaymentEscrowAmount">lastPaymentEscrowAmount.</param>
        /// <param name="lastPaymentLastFeeAmount">lastPaymentLastFeeAmount.</param>
        /// <param name="lastPaymentLateCharge">lastPaymentLateCharge.</param>
        /// <param name="ytdPrincipalPaid">ytdPrincipalPaid.</param>
        /// <param name="ytdInterestPaid">ytdInterestPaid.</param>
        /// <param name="ytdInsurancePaid">ytdInsurancePaid.</param>
        /// <param name="ytdTaxPaid">ytdTaxPaid.</param>
        /// <param name="autoPayEnrolled">autoPayEnrolled.</param>
        /// <param name="collateral">collateral.</param>
        /// <param name="currentSchool">currentSchool.</param>
        /// <param name="firstPaymentDate">firstPaymentDate.</param>
        /// <param name="firstMortgage">firstMortgage.</param>
        /// <param name="loanPaymentFreq">loanPaymentFreq.</param>
        /// <param name="originalSchool">originalSchool.</param>
        /// <param name="recurringPaymentAmount">recurringPaymentAmount.</param>
        /// <param name="lender">lender.</param>
        /// <param name="endingBalanceAmount">endingBalanceAmount.</param>
        /// <param name="loanTermType">loanTermType.</param>
        /// <param name="paymentsMade">paymentsMade.</param>
        /// <param name="balloonAmount">balloonAmount.</param>
        /// <param name="projectedInterest">projectedInterest.</param>
        /// <param name="interestPaidLtd">interestPaidLtd.</param>
        /// <param name="interestRateType">interestRateType.</param>
        /// <param name="loanPaymentType">loanPaymentType.</param>
        /// <param name="repaymentPlan">repaymentPlan.</param>
        /// <param name="paymentsRemaining">paymentsRemaining.</param>
        /// <param name="marginBalance">marginBalance.</param>
        /// <param name="shortBalance">shortBalance.</param>
        /// <param name="availableCashBalance">availableCashBalance.</param>
        /// <param name="maturityValueAmount">maturityValueAmount.</param>
        /// <param name="vestedBalance">vestedBalance.</param>
        /// <param name="empMatchAmount">empMatchAmount.</param>
        /// <param name="empPretaxContribAmount">empPretaxContribAmount.</param>
        /// <param name="empPretaxContribAmountYtd">empPretaxContribAmountYtd.</param>
        /// <param name="contribTotalYtd">contribTotalYtd.</param>
        /// <param name="cashBalanceAmount">cashBalanceAmount.</param>
        /// <param name="preTaxAmount">preTaxAmount.</param>
        /// <param name="afterTaxAmount">afterTaxAmount.</param>
        /// <param name="matchAmount">matchAmount.</param>
        /// <param name="profitSharingAmount">profitSharingAmount.</param>
        /// <param name="rolloverAmount">rolloverAmount.</param>
        /// <param name="otherVestAmount">otherVestAmount.</param>
        /// <param name="otherNonvestAmount">otherNonvestAmount.</param>
        /// <param name="currentLoanBalance">currentLoanBalance.</param>
        /// <param name="loanRate">loanRate.</param>
        /// <param name="buyPower">buyPower.</param>
        /// <param name="rolloverLtd">rolloverLtd.</param>
        /// <param name="loanAwardId">loanAwardId.</param>
        /// <param name="originalInterestRate">originalInterestRate.</param>
        /// <param name="guarantor">guarantor.</param>
        /// <param name="owner">owner.</param>
        /// <param name="interestSubsidyType">interestSubsidyType.</param>
        /// <param name="interestBalance">interestBalance.</param>
        /// <param name="remainingTermOfMl">remainingTermOfMl.</param>
        /// <param name="initialInterestRate">initialInterestRate.</param>
        /// <param name="feesBalance">feesBalance.</param>
        /// <param name="loanYtdInterestPaid">loanYtdInterestPaid.</param>
        /// <param name="loanYtdFeesPaid">loanYtdFeesPaid.</param>
        /// <param name="loanYtdPrincipalPaid">loanYtdPrincipalPaid.</param>
        /// <param name="loanStatus">loanStatus.</param>
        /// <param name="loanStatusStartDate">loanStatusStartDate.</param>
        /// <param name="loanStatusEndDate">loanStatusEndDate.</param>
        /// <param name="weightedInterestRate">weightedInterestRate.</param>
        /// <param name="repaymentPlanStartDate">repaymentPlanStartDate.</param>
        /// <param name="repaymentPlanEndDate">repaymentPlanEndDate.</param>
        /// <param name="expectedPayoffDate">expectedPayoffDate.</param>
        /// <param name="outOfSchoolDate">outOfSchoolDate.</param>
        /// <param name="convertToRepayment">convertToRepayment.</param>
        /// <param name="daysDelinquent">daysDelinquent.</param>
        /// <param name="totalPrincipalPaid">totalPrincipalPaid.</param>
        /// <param name="totalInterestPaid">totalInterestPaid.</param>
        /// <param name="totalAmountPaid">totalAmountPaid.</param>
        public CustomerAccountDetail(
            double availableBalanceAmount,
            long? dateAsOf = null,
            long? openDate = null,
            long? periodStartDate = null,
            long? periodEndDate = null,
            double? periodInterestRate = null,
            double? periodDepositAmount = null,
            double? periodInterestAmount = null,
            double? interestYtdAmount = null,
            double? interestPriorYtdAmount = null,
            long? maturityDate = null,
            string interestRate = null,
            double? creditAvailableAmount = null,
            double? creditMaxAmount = null,
            double? cashAdvanceAvailableAmount = null,
            double? cashAdvanceMaxAmount = null,
            double? cashAdvanceBalance = null,
            double? cashAdvanceInterestRate = null,
            double? currentBalance = null,
            double? paymentMinAmount = null,
            long? paymentDueDate = null,
            double? previousBalance = null,
            long? statementStartDate = null,
            long? statementEndDate = null,
            double? statementPurchaseAmount = null,
            double? statementFinanceAmount = null,
            double? statementCreditAmount = null,
            int? rewardEarnedBalance = null,
            double? pastDueAmount = null,
            double? lastPaymentAmount = null,
            long? lastPaymentDate = null,
            double? statementCloseBalance = null,
            string termOfMl = null,
            string mlHolderName = null,
            string description = null,
            double? lateFeeAmount = null,
            double? payoffAmount = null,
            long? payoffAmountDate = null,
            long? originalMaturityDate = null,
            double? principalBalance = null,
            double? escrowBalance = null,
            string interestPeriod = null,
            double? initialMlAmount = null,
            long? initialMlDate = null,
            double? nextPaymentPrincipalAmount = null,
            double? nextPaymentInterestAmount = null,
            double? nextPayment = null,
            long? nextPaymentDate = null,
            long? lastPaymentDueDate = null,
            long? lastPaymentReceiveDate = null,
            double? lastPaymentPrincipalAmount = null,
            double? lastPaymentInterestAmount = null,
            double? lastPaymentEscrowAmount = null,
            double? lastPaymentLastFeeAmount = null,
            double? lastPaymentLateCharge = null,
            double? ytdPrincipalPaid = null,
            double? ytdInterestPaid = null,
            double? ytdInsurancePaid = null,
            double? ytdTaxPaid = null,
            bool? autoPayEnrolled = null,
            string collateral = null,
            string currentSchool = null,
            long? firstPaymentDate = null,
            bool? firstMortgage = null,
            string loanPaymentFreq = null,
            string originalSchool = null,
            double? recurringPaymentAmount = null,
            string lender = null,
            double? endingBalanceAmount = null,
            string loanTermType = null,
            int? paymentsMade = null,
            double? balloonAmount = null,
            double? projectedInterest = null,
            double? interestPaidLtd = null,
            string interestRateType = null,
            string loanPaymentType = null,
            string repaymentPlan = null,
            int? paymentsRemaining = null,
            double? marginBalance = null,
            double? shortBalance = null,
            double? availableCashBalance = null,
            double? maturityValueAmount = null,
            double? vestedBalance = null,
            double? empMatchAmount = null,
            double? empPretaxContribAmount = null,
            double? empPretaxContribAmountYtd = null,
            double? contribTotalYtd = null,
            double? cashBalanceAmount = null,
            double? preTaxAmount = null,
            double? afterTaxAmount = null,
            double? matchAmount = null,
            double? profitSharingAmount = null,
            double? rolloverAmount = null,
            double? otherVestAmount = null,
            double? otherNonvestAmount = null,
            double? currentLoanBalance = null,
            double? loanRate = null,
            double? buyPower = null,
            double? rolloverLtd = null,
            string loanAwardId = null,
            double? originalInterestRate = null,
            string guarantor = null,
            string owner = null,
            string interestSubsidyType = null,
            double? interestBalance = null,
            double? remainingTermOfMl = null,
            double? initialInterestRate = null,
            double? feesBalance = null,
            double? loanYtdInterestPaid = null,
            double? loanYtdFeesPaid = null,
            double? loanYtdPrincipalPaid = null,
            string loanStatus = null,
            long? loanStatusStartDate = null,
            long? loanStatusEndDate = null,
            double? weightedInterestRate = null,
            long? repaymentPlanStartDate = null,
            long? repaymentPlanEndDate = null,
            long? expectedPayoffDate = null,
            long? outOfSchoolDate = null,
            long? convertToRepayment = null,
            int? daysDelinquent = null,
            double? totalPrincipalPaid = null,
            double? totalInterestPaid = null,
            double? totalAmountPaid = null)
        {
            this.DateAsOf = dateAsOf;
            this.AvailableBalanceAmount = availableBalanceAmount;
            this.OpenDate = openDate;
            this.PeriodStartDate = periodStartDate;
            this.PeriodEndDate = periodEndDate;
            this.PeriodInterestRate = periodInterestRate;
            this.PeriodDepositAmount = periodDepositAmount;
            this.PeriodInterestAmount = periodInterestAmount;
            this.InterestYtdAmount = interestYtdAmount;
            this.InterestPriorYtdAmount = interestPriorYtdAmount;
            this.MaturityDate = maturityDate;
            this.InterestRate = interestRate;
            this.CreditAvailableAmount = creditAvailableAmount;
            this.CreditMaxAmount = creditMaxAmount;
            this.CashAdvanceAvailableAmount = cashAdvanceAvailableAmount;
            this.CashAdvanceMaxAmount = cashAdvanceMaxAmount;
            this.CashAdvanceBalance = cashAdvanceBalance;
            this.CashAdvanceInterestRate = cashAdvanceInterestRate;
            this.CurrentBalance = currentBalance;
            this.PaymentMinAmount = paymentMinAmount;
            this.PaymentDueDate = paymentDueDate;
            this.PreviousBalance = previousBalance;
            this.StatementStartDate = statementStartDate;
            this.StatementEndDate = statementEndDate;
            this.StatementPurchaseAmount = statementPurchaseAmount;
            this.StatementFinanceAmount = statementFinanceAmount;
            this.StatementCreditAmount = statementCreditAmount;
            this.RewardEarnedBalance = rewardEarnedBalance;
            this.PastDueAmount = pastDueAmount;
            this.LastPaymentAmount = lastPaymentAmount;
            this.LastPaymentDate = lastPaymentDate;
            this.StatementCloseBalance = statementCloseBalance;
            this.TermOfMl = termOfMl;
            this.MlHolderName = mlHolderName;
            this.Description = description;
            this.LateFeeAmount = lateFeeAmount;
            this.PayoffAmount = payoffAmount;
            this.PayoffAmountDate = payoffAmountDate;
            this.OriginalMaturityDate = originalMaturityDate;
            this.PrincipalBalance = principalBalance;
            this.EscrowBalance = escrowBalance;
            this.InterestPeriod = interestPeriod;
            this.InitialMlAmount = initialMlAmount;
            this.InitialMlDate = initialMlDate;
            this.NextPaymentPrincipalAmount = nextPaymentPrincipalAmount;
            this.NextPaymentInterestAmount = nextPaymentInterestAmount;
            this.NextPayment = nextPayment;
            this.NextPaymentDate = nextPaymentDate;
            this.LastPaymentDueDate = lastPaymentDueDate;
            this.LastPaymentReceiveDate = lastPaymentReceiveDate;
            this.LastPaymentPrincipalAmount = lastPaymentPrincipalAmount;
            this.LastPaymentInterestAmount = lastPaymentInterestAmount;
            this.LastPaymentEscrowAmount = lastPaymentEscrowAmount;
            this.LastPaymentLastFeeAmount = lastPaymentLastFeeAmount;
            this.LastPaymentLateCharge = lastPaymentLateCharge;
            this.YtdPrincipalPaid = ytdPrincipalPaid;
            this.YtdInterestPaid = ytdInterestPaid;
            this.YtdInsurancePaid = ytdInsurancePaid;
            this.YtdTaxPaid = ytdTaxPaid;
            this.AutoPayEnrolled = autoPayEnrolled;
            this.Collateral = collateral;
            this.CurrentSchool = currentSchool;
            this.FirstPaymentDate = firstPaymentDate;
            this.FirstMortgage = firstMortgage;
            this.LoanPaymentFreq = loanPaymentFreq;
            this.OriginalSchool = originalSchool;
            this.RecurringPaymentAmount = recurringPaymentAmount;
            this.Lender = lender;
            this.EndingBalanceAmount = endingBalanceAmount;
            this.LoanTermType = loanTermType;
            this.PaymentsMade = paymentsMade;
            this.BalloonAmount = balloonAmount;
            this.ProjectedInterest = projectedInterest;
            this.InterestPaidLtd = interestPaidLtd;
            this.InterestRateType = interestRateType;
            this.LoanPaymentType = loanPaymentType;
            this.RepaymentPlan = repaymentPlan;
            this.PaymentsRemaining = paymentsRemaining;
            this.MarginBalance = marginBalance;
            this.ShortBalance = shortBalance;
            this.AvailableCashBalance = availableCashBalance;
            this.MaturityValueAmount = maturityValueAmount;
            this.VestedBalance = vestedBalance;
            this.EmpMatchAmount = empMatchAmount;
            this.EmpPretaxContribAmount = empPretaxContribAmount;
            this.EmpPretaxContribAmountYtd = empPretaxContribAmountYtd;
            this.ContribTotalYtd = contribTotalYtd;
            this.CashBalanceAmount = cashBalanceAmount;
            this.PreTaxAmount = preTaxAmount;
            this.AfterTaxAmount = afterTaxAmount;
            this.MatchAmount = matchAmount;
            this.ProfitSharingAmount = profitSharingAmount;
            this.RolloverAmount = rolloverAmount;
            this.OtherVestAmount = otherVestAmount;
            this.OtherNonvestAmount = otherNonvestAmount;
            this.CurrentLoanBalance = currentLoanBalance;
            this.LoanRate = loanRate;
            this.BuyPower = buyPower;
            this.RolloverLtd = rolloverLtd;
            this.LoanAwardId = loanAwardId;
            this.OriginalInterestRate = originalInterestRate;
            this.Guarantor = guarantor;
            this.Owner = owner;
            this.InterestSubsidyType = interestSubsidyType;
            this.InterestBalance = interestBalance;
            this.RemainingTermOfMl = remainingTermOfMl;
            this.InitialInterestRate = initialInterestRate;
            this.FeesBalance = feesBalance;
            this.LoanYtdInterestPaid = loanYtdInterestPaid;
            this.LoanYtdFeesPaid = loanYtdFeesPaid;
            this.LoanYtdPrincipalPaid = loanYtdPrincipalPaid;
            this.LoanStatus = loanStatus;
            this.LoanStatusStartDate = loanStatusStartDate;
            this.LoanStatusEndDate = loanStatusEndDate;
            this.WeightedInterestRate = weightedInterestRate;
            this.RepaymentPlanStartDate = repaymentPlanStartDate;
            this.RepaymentPlanEndDate = repaymentPlanEndDate;
            this.ExpectedPayoffDate = expectedPayoffDate;
            this.OutOfSchoolDate = outOfSchoolDate;
            this.ConvertToRepayment = convertToRepayment;
            this.DaysDelinquent = daysDelinquent;
            this.TotalPrincipalPaid = totalPrincipalPaid;
            this.TotalInterestPaid = totalInterestPaid;
            this.TotalAmountPaid = totalAmountPaid;
        }

        /// <summary>
        /// (All Account Types) Most recent date of the following information. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("dateAsOf", NullValueHandling = NullValueHandling.Ignore)]
        public long? DateAsOf { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) and (Mortgage/Loan) The available balance (typically the current balance with adjustments for any pending transactions)
        /// </summary>
        [JsonProperty("availableBalanceAmount")]
        public double AvailableBalanceAmount { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Date when account was opened. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("openDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? OpenDate { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Start date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("periodStartDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? PeriodStartDate { get; set; }

        /// <summary>
        /// End date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("periodEndDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? PeriodEndDate { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) The APY for the current period interest rate
        /// </summary>
        [JsonProperty("periodInterestRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? PeriodInterestRate { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Amount deposited in period
        /// </summary>
        [JsonProperty("periodDepositAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PeriodDepositAmount { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Interest accrued during the current period
        /// </summary>
        [JsonProperty("periodInterestAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PeriodInterestAmount { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Interest accrued year-to-date
        /// </summary>
        [JsonProperty("interestYtdAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? InterestYtdAmount { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Interest earned in prior year
        /// </summary>
        [JsonProperty("interestPriorYtdAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? InterestPriorYtdAmount { get; set; }

        /// <summary>
        /// (Checking/Savings/CD/MoneyMarket) Maturity date of account type. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("maturityDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? MaturityDate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) and (Mortgage/Loan) The account's current interest rate
        /// </summary>
        [JsonProperty("interestRate", NullValueHandling = NullValueHandling.Ignore)]
        public string InterestRate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) The available credit (typically the credit limit minus the current balance)
        /// </summary>
        [JsonProperty("creditAvailableAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? CreditAvailableAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) The account's credit limit
        /// </summary>
        [JsonProperty("creditMaxAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? CreditMaxAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Currently available cash advance
        /// </summary>
        [JsonProperty("cashAdvanceAvailableAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? CashAdvanceAvailableAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Maximum cash advance amount
        /// </summary>
        [JsonProperty("cashAdvanceMaxAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? CashAdvanceMaxAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Balance of current cash advance
        /// </summary>
        [JsonProperty("cashAdvanceBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CashAdvanceBalance { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Interest rate for cash advances
        /// </summary>
        [JsonProperty("cashAdvanceInterestRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? CashAdvanceInterestRate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) and (Investment) Current balance
        /// </summary>
        [JsonProperty("currentBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentBalance { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) and (Mortgage/Loan) Minimum payment due
        /// </summary>
        [JsonProperty("paymentMinAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PaymentMinAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("paymentDueDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? PaymentDueDate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Prior balance in last statement
        /// </summary>
        [JsonProperty("previousBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? PreviousBalance { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Start date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("statementStartDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? StatementStartDate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) End date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("statementEndDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? StatementEndDate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Purchase amount of statement period
        /// </summary>
        [JsonProperty("statementPurchaseAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? StatementPurchaseAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Finance amount of statement period
        /// </summary>
        [JsonProperty("statementFinanceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? StatementFinanceAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Credit amount applied in statement period
        /// </summary>
        [JsonProperty("statementCreditAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? StatementCreditAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Earned reward balance
        /// </summary>
        [JsonProperty("rewardEarnedBalance", NullValueHandling = NullValueHandling.Ignore)]
        public int? RewardEarnedBalance { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Balance past due
        /// </summary>
        [JsonProperty("pastDueAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PastDueAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) and (Mortgage/Loan) The amount received in the last payment
        /// </summary>
        [JsonProperty("lastPaymentAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LastPaymentAmount { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("lastPaymentDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LastPaymentDate { get; set; }

        /// <summary>
        /// (Credit Card/Line Of Credit) Balance of statement at close
        /// </summary>
        [JsonProperty("statementCloseBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? StatementCloseBalance { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Length of loan in months
        /// </summary>
        [JsonProperty("termOfMl", NullValueHandling = NullValueHandling.Ignore)]
        public string TermOfMl { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Holder of the mortgage or loan
        /// </summary>
        [JsonProperty("mlHolderName", NullValueHandling = NullValueHandling.Ignore)]
        public string MlHolderName { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Description of loan
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Late fee charged
        /// </summary>
        [JsonProperty("lateFeeAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LateFeeAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) The amount required to payoff the loan
        /// </summary>
        [JsonProperty("payoffAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PayoffAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Date of final payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("payoffAmountDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? PayoffAmountDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Original date of loan maturity. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("originalMaturityDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? OriginalMaturityDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) The principal balance
        /// </summary>
        [JsonProperty("principalBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? PrincipalBalance { get; set; }

        /// <summary>
        /// (Mortgage/Loan) The escrow balance
        /// </summary>
        [JsonProperty("escrowBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? EscrowBalance { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Period of interest
        /// </summary>
        [JsonProperty("interestPeriod", NullValueHandling = NullValueHandling.Ignore)]
        public string InterestPeriod { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Original loan amount
        /// </summary>
        [JsonProperty("initialMlAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? InitialMlAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Original date of loan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("initialMlDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? InitialMlDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount towards principal in next payment
        /// </summary>
        [JsonProperty("nextPaymentPrincipalAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? NextPaymentPrincipalAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount of interest in next payment
        /// </summary>
        [JsonProperty("nextPaymentInterestAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? NextPaymentInterestAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Minimum payment due
        /// </summary>
        [JsonProperty("nextPayment", NullValueHandling = NullValueHandling.Ignore)]
        public double? NextPayment { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("nextPaymentDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? NextPaymentDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Due date of last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("lastPaymentDueDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LastPaymentDueDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("lastPaymentReceiveDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LastPaymentReceiveDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount towards principal in last payment
        /// </summary>
        [JsonProperty("lastPaymentPrincipalAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LastPaymentPrincipalAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount of interest in last payment
        /// </summary>
        [JsonProperty("lastPaymentInterestAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LastPaymentInterestAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount towards escrow in last payment
        /// </summary>
        [JsonProperty("lastPaymentEscrowAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LastPaymentEscrowAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount of last fee in last payment
        /// </summary>
        [JsonProperty("lastPaymentLastFeeAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? LastPaymentLastFeeAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Amount of late charge in last payment
        /// </summary>
        [JsonProperty("lastPaymentLateCharge", NullValueHandling = NullValueHandling.Ignore)]
        public double? LastPaymentLateCharge { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Principal paid year-to-date
        /// </summary>
        [JsonProperty("ytdPrincipalPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? YtdPrincipalPaid { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Interest paid year-to-date
        /// </summary>
        [JsonProperty("ytdInterestPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? YtdInterestPaid { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Insurance paid year-to-date
        /// </summary>
        [JsonProperty("ytdInsurancePaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? YtdInsurancePaid { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Tax paid year-to-date
        /// </summary>
        [JsonProperty("ytdTaxPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? YtdTaxPaid { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Enrolled in autopay (F/Y)
        /// </summary>
        [JsonProperty("autoPayEnrolled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AutoPayEnrolled { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Collateral on loan
        /// </summary>
        [JsonProperty("collateral", NullValueHandling = NullValueHandling.Ignore)]
        public string Collateral { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Current school
        /// </summary>
        [JsonProperty("currentSchool", NullValueHandling = NullValueHandling.Ignore)]
        public string CurrentSchool { get; set; }

        /// <summary>
        /// (Mortgage/Loan) First payment due date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("firstPaymentDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? FirstPaymentDate { get; set; }

        /// <summary>
        /// (Mortgage/Loan) First mortgage (F/Y)
        /// </summary>
        [JsonProperty("firstMortgage", NullValueHandling = NullValueHandling.Ignore)]
        public bool? FirstMortgage { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Frequency of payments (monthly, etc.)
        /// </summary>
        [JsonProperty("loanPaymentFreq", NullValueHandling = NullValueHandling.Ignore)]
        public string LoanPaymentFreq { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Original school
        /// </summary>
        [JsonProperty("originalSchool", NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSchool { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Recurring payment amount
        /// </summary>
        [JsonProperty("recurringPaymentAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? RecurringPaymentAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Owner of loan
        /// </summary>
        [JsonProperty("lender", NullValueHandling = NullValueHandling.Ignore)]
        public string Lender { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Ending balance
        /// </summary>
        [JsonProperty("endingBalanceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? EndingBalanceAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Type of loan term
        /// </summary>
        [JsonProperty("loanTermType", NullValueHandling = NullValueHandling.Ignore)]
        public string LoanTermType { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Number of payments made
        /// </summary>
        [JsonProperty("paymentsMade", NullValueHandling = NullValueHandling.Ignore)]
        public int? PaymentsMade { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Balloon payment amount
        /// </summary>
        [JsonProperty("balloonAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? BalloonAmount { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Projected interest on the loan
        /// </summary>
        [JsonProperty("projectedInterest", NullValueHandling = NullValueHandling.Ignore)]
        public double? ProjectedInterest { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Interest paid since inception of loan (life to date)
        /// </summary>
        [JsonProperty("interestPaidLtd", NullValueHandling = NullValueHandling.Ignore)]
        public double? InterestPaidLtd { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Type of interest rate
        /// </summary>
        [JsonProperty("interestRateType", NullValueHandling = NullValueHandling.Ignore)]
        public string InterestRateType { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Type of loan payment
        /// </summary>
        [JsonProperty("loanPaymentType", NullValueHandling = NullValueHandling.Ignore)]
        public string LoanPaymentType { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Type of repayment plan for the student loan
        /// </summary>
        [JsonProperty("repaymentPlan", NullValueHandling = NullValueHandling.Ignore)]
        public string RepaymentPlan { get; set; }

        /// <summary>
        /// (Mortgage/Loan) Number of payments remaining before loan is paid off
        /// </summary>
        [JsonProperty("paymentsRemaining", NullValueHandling = NullValueHandling.Ignore)]
        public int? PaymentsRemaining { get; set; }

        /// <summary>
        /// (Investment) Net interest earned after deducting interest paid out
        /// </summary>
        [JsonProperty("marginBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? MarginBalance { get; set; }

        /// <summary>
        /// (Investment) Sum of short balance
        /// </summary>
        [JsonProperty("shortBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? ShortBalance { get; set; }

        /// <summary>
        /// (Investment) Amount available for cash withdrawal
        /// </summary>
        [JsonProperty("availableCashBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AvailableCashBalance { get; set; }

        /// <summary>
        /// (Investment) amount payable to an investor at maturity
        /// </summary>
        [JsonProperty("maturityValueAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? MaturityValueAmount { get; set; }

        /// <summary>
        /// (Investment) Vested amount in account
        /// </summary>
        [JsonProperty("vestedBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? VestedBalance { get; set; }

        /// <summary>
        /// (Investment) Employer matched contributions
        /// </summary>
        [JsonProperty("empMatchAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? EmpMatchAmount { get; set; }

        /// <summary>
        /// (Investment) Employer pretax contribution amount
        /// </summary>
        [JsonProperty("empPretaxContribAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? EmpPretaxContribAmount { get; set; }

        /// <summary>
        /// (Investment) Employer pretax contribution amount year to date
        /// </summary>
        [JsonProperty("empPretaxContribAmountYtd", NullValueHandling = NullValueHandling.Ignore)]
        public double? EmpPretaxContribAmountYtd { get; set; }

        /// <summary>
        /// (Investment) Total year to date contributions
        /// </summary>
        [JsonProperty("contribTotalYtd", NullValueHandling = NullValueHandling.Ignore)]
        public double? ContribTotalYtd { get; set; }

        /// <summary>
        /// (Investment) Cash balance of account
        /// </summary>
        [JsonProperty("cashBalanceAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? CashBalanceAmount { get; set; }

        /// <summary>
        /// (Investment) Pre tax amount of total balance
        /// </summary>
        [JsonProperty("preTaxAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PreTaxAmount { get; set; }

        /// <summary>
        /// (Investment) Post tax amount of total balance
        /// </summary>
        [JsonProperty("afterTaxAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? AfterTaxAmount { get; set; }

        /// <summary>
        /// (Investment) Amount matched
        /// </summary>
        [JsonProperty("matchAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? MatchAmount { get; set; }

        /// <summary>
        /// (Investment) Amount of balance for profit sharing
        /// </summary>
        [JsonProperty("profitSharingAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? ProfitSharingAmount { get; set; }

        /// <summary>
        /// (Investment) Amount of balance rolled over from original account (401k, etc.)
        /// </summary>
        [JsonProperty("rolloverAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? RolloverAmount { get; set; }

        /// <summary>
        /// (Investment) Other vested amount
        /// </summary>
        [JsonProperty("otherVestAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? OtherVestAmount { get; set; }

        /// <summary>
        /// (Investment) Other nonvested amount
        /// </summary>
        [JsonProperty("otherNonvestAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? OtherNonvestAmount { get; set; }

        /// <summary>
        /// (Investment) Current loan balance
        /// </summary>
        [JsonProperty("currentLoanBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentLoanBalance { get; set; }

        /// <summary>
        /// (Investment) Interest rate of loan
        /// </summary>
        [JsonProperty("loanRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? LoanRate { get; set; }

        /// <summary>
        /// (Investment) Money available to buy securities
        /// </summary>
        [JsonProperty("buyPower", NullValueHandling = NullValueHandling.Ignore)]
        public double? BuyPower { get; set; }

        /// <summary>
        /// (Investment) Life to date of money rolled over
        /// </summary>
        [JsonProperty("rolloverLtd", NullValueHandling = NullValueHandling.Ignore)]
        public double? RolloverLtd { get; set; }

        /// <summary>
        /// (Student Loan) The federal unique loan identifying number
        /// </summary>
        [JsonProperty("loanAwardId", NullValueHandling = NullValueHandling.Ignore)]
        public string LoanAwardId { get; set; }

        /// <summary>
        /// (Student Loan) The original interest rate to which the loan was disbursed, in APY
        /// </summary>
        [JsonProperty("originalInterestRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? OriginalInterestRate { get; set; }

        /// <summary>
        /// (Student Loan) The financial institution guarantor of the loan (who will pay the loan amount to the owner if the borrower defaults)
        /// </summary>
        [JsonProperty("guarantor", NullValueHandling = NullValueHandling.Ignore)]
        public string Guarantor { get; set; }

        /// <summary>
        /// (Student Loan) Owner of the loan
        /// </summary>
        [JsonProperty("owner", NullValueHandling = NullValueHandling.Ignore)]
        public string Owner { get; set; }

        /// <summary>
        /// (Student Loan) The indication of the presence of an interest subsidy (i.e. subsidized)
        /// </summary>
        [JsonProperty("interestSubsidyType", NullValueHandling = NullValueHandling.Ignore)]
        public string InterestSubsidyType { get; set; }

        /// <summary>
        /// (Student Loan) The total outstanding interest balance
        /// </summary>
        [JsonProperty("interestBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? InterestBalance { get; set; }

        /// <summary>
        /// (Student Loan) The number of months still outstanding on a loan
        /// </summary>
        [JsonProperty("remainingTermOfMl", NullValueHandling = NullValueHandling.Ignore)]
        public double? RemainingTermOfMl { get; set; }

        /// <summary>
        /// (Student Loan) Initial interest rate of loan
        /// </summary>
        [JsonProperty("initialInterestRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? InitialInterestRate { get; set; }

        /// <summary>
        /// (Student Loan) The total outstanding fees balance
        /// </summary>
        [JsonProperty("feesBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? FeesBalance { get; set; }

        /// <summary>
        /// (Student Loan) Loan interest paid year-to-date
        /// </summary>
        [JsonProperty("loanYtdInterestPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? LoanYtdInterestPaid { get; set; }

        /// <summary>
        /// (Student Loan) Loan fees paid year-to-date
        /// </summary>
        [JsonProperty("loanYtdFeesPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? LoanYtdFeesPaid { get; set; }

        /// <summary>
        /// (Student Loan) Loan principal paid year-to-date
        /// </summary>
        [JsonProperty("loanYtdPrincipalPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? LoanYtdPrincipalPaid { get; set; }

        /// <summary>
        /// (Student Loan) The repayment status phase (i.e. In School, Grace, Repayment, Deferment, Forbearance)
        /// </summary>
        [JsonProperty("loanStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string LoanStatus { get; set; }

        /// <summary>
        /// (Student Loan) The start date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("loanStatusStartDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LoanStatusStartDate { get; set; }

        /// <summary>
        /// (Student Loan) The end date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("loanStatusEndDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LoanStatusEndDate { get; set; }

        /// <summary>
        /// (Student Loan) The interest rate of multiple interest rates and balances at the group level, in APY
        /// </summary>
        [JsonProperty("weightedInterestRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? WeightedInterestRate { get; set; }

        /// <summary>
        /// (Student Loan) The start date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("repaymentPlanStartDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? RepaymentPlanStartDate { get; set; }

        /// <summary>
        /// (Student Loan) The end date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("repaymentPlanEndDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? RepaymentPlanEndDate { get; set; }

        /// <summary>
        /// (Student Loan) The expected date of the payoff date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("expectedPayoffDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? ExpectedPayoffDate { get; set; }

        /// <summary>
        /// (Student Loan) The date the borrower graduated or dropped below half-time enrollment in school. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("outOfSchoolDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? OutOfSchoolDate { get; set; }

        /// <summary>
        /// (Student Loan) The date the loan enters into repayment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("convertToRepayment", NullValueHandling = NullValueHandling.Ignore)]
        public long? ConvertToRepayment { get; set; }

        /// <summary>
        /// (Student Loan) The number of days past a due date that a payment should have been made
        /// </summary>
        [JsonProperty("daysDelinquent", NullValueHandling = NullValueHandling.Ignore)]
        public int? DaysDelinquent { get; set; }

        /// <summary>
        /// (Student Loan) The total amount paid towards the principal balance
        /// </summary>
        [JsonProperty("totalPrincipalPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalPrincipalPaid { get; set; }

        /// <summary>
        /// (Student Loan) The total amount paid towards interest
        /// </summary>
        [JsonProperty("totalInterestPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalInterestPaid { get; set; }

        /// <summary>
        /// (Student Loan) The total amount paid
        /// </summary>
        [JsonProperty("totalAmountPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalAmountPaid { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomerAccountDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CustomerAccountDetail other &&
                ((this.DateAsOf == null && other.DateAsOf == null) || (this.DateAsOf?.Equals(other.DateAsOf) == true)) &&
                this.AvailableBalanceAmount.Equals(other.AvailableBalanceAmount) &&
                ((this.OpenDate == null && other.OpenDate == null) || (this.OpenDate?.Equals(other.OpenDate) == true)) &&
                ((this.PeriodStartDate == null && other.PeriodStartDate == null) || (this.PeriodStartDate?.Equals(other.PeriodStartDate) == true)) &&
                ((this.PeriodEndDate == null && other.PeriodEndDate == null) || (this.PeriodEndDate?.Equals(other.PeriodEndDate) == true)) &&
                ((this.PeriodInterestRate == null && other.PeriodInterestRate == null) || (this.PeriodInterestRate?.Equals(other.PeriodInterestRate) == true)) &&
                ((this.PeriodDepositAmount == null && other.PeriodDepositAmount == null) || (this.PeriodDepositAmount?.Equals(other.PeriodDepositAmount) == true)) &&
                ((this.PeriodInterestAmount == null && other.PeriodInterestAmount == null) || (this.PeriodInterestAmount?.Equals(other.PeriodInterestAmount) == true)) &&
                ((this.InterestYtdAmount == null && other.InterestYtdAmount == null) || (this.InterestYtdAmount?.Equals(other.InterestYtdAmount) == true)) &&
                ((this.InterestPriorYtdAmount == null && other.InterestPriorYtdAmount == null) || (this.InterestPriorYtdAmount?.Equals(other.InterestPriorYtdAmount) == true)) &&
                ((this.MaturityDate == null && other.MaturityDate == null) || (this.MaturityDate?.Equals(other.MaturityDate) == true)) &&
                ((this.InterestRate == null && other.InterestRate == null) || (this.InterestRate?.Equals(other.InterestRate) == true)) &&
                ((this.CreditAvailableAmount == null && other.CreditAvailableAmount == null) || (this.CreditAvailableAmount?.Equals(other.CreditAvailableAmount) == true)) &&
                ((this.CreditMaxAmount == null && other.CreditMaxAmount == null) || (this.CreditMaxAmount?.Equals(other.CreditMaxAmount) == true)) &&
                ((this.CashAdvanceAvailableAmount == null && other.CashAdvanceAvailableAmount == null) || (this.CashAdvanceAvailableAmount?.Equals(other.CashAdvanceAvailableAmount) == true)) &&
                ((this.CashAdvanceMaxAmount == null && other.CashAdvanceMaxAmount == null) || (this.CashAdvanceMaxAmount?.Equals(other.CashAdvanceMaxAmount) == true)) &&
                ((this.CashAdvanceBalance == null && other.CashAdvanceBalance == null) || (this.CashAdvanceBalance?.Equals(other.CashAdvanceBalance) == true)) &&
                ((this.CashAdvanceInterestRate == null && other.CashAdvanceInterestRate == null) || (this.CashAdvanceInterestRate?.Equals(other.CashAdvanceInterestRate) == true)) &&
                ((this.CurrentBalance == null && other.CurrentBalance == null) || (this.CurrentBalance?.Equals(other.CurrentBalance) == true)) &&
                ((this.PaymentMinAmount == null && other.PaymentMinAmount == null) || (this.PaymentMinAmount?.Equals(other.PaymentMinAmount) == true)) &&
                ((this.PaymentDueDate == null && other.PaymentDueDate == null) || (this.PaymentDueDate?.Equals(other.PaymentDueDate) == true)) &&
                ((this.PreviousBalance == null && other.PreviousBalance == null) || (this.PreviousBalance?.Equals(other.PreviousBalance) == true)) &&
                ((this.StatementStartDate == null && other.StatementStartDate == null) || (this.StatementStartDate?.Equals(other.StatementStartDate) == true)) &&
                ((this.StatementEndDate == null && other.StatementEndDate == null) || (this.StatementEndDate?.Equals(other.StatementEndDate) == true)) &&
                ((this.StatementPurchaseAmount == null && other.StatementPurchaseAmount == null) || (this.StatementPurchaseAmount?.Equals(other.StatementPurchaseAmount) == true)) &&
                ((this.StatementFinanceAmount == null && other.StatementFinanceAmount == null) || (this.StatementFinanceAmount?.Equals(other.StatementFinanceAmount) == true)) &&
                ((this.StatementCreditAmount == null && other.StatementCreditAmount == null) || (this.StatementCreditAmount?.Equals(other.StatementCreditAmount) == true)) &&
                ((this.RewardEarnedBalance == null && other.RewardEarnedBalance == null) || (this.RewardEarnedBalance?.Equals(other.RewardEarnedBalance) == true)) &&
                ((this.PastDueAmount == null && other.PastDueAmount == null) || (this.PastDueAmount?.Equals(other.PastDueAmount) == true)) &&
                ((this.LastPaymentAmount == null && other.LastPaymentAmount == null) || (this.LastPaymentAmount?.Equals(other.LastPaymentAmount) == true)) &&
                ((this.LastPaymentDate == null && other.LastPaymentDate == null) || (this.LastPaymentDate?.Equals(other.LastPaymentDate) == true)) &&
                ((this.StatementCloseBalance == null && other.StatementCloseBalance == null) || (this.StatementCloseBalance?.Equals(other.StatementCloseBalance) == true)) &&
                ((this.TermOfMl == null && other.TermOfMl == null) || (this.TermOfMl?.Equals(other.TermOfMl) == true)) &&
                ((this.MlHolderName == null && other.MlHolderName == null) || (this.MlHolderName?.Equals(other.MlHolderName) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.LateFeeAmount == null && other.LateFeeAmount == null) || (this.LateFeeAmount?.Equals(other.LateFeeAmount) == true)) &&
                ((this.PayoffAmount == null && other.PayoffAmount == null) || (this.PayoffAmount?.Equals(other.PayoffAmount) == true)) &&
                ((this.PayoffAmountDate == null && other.PayoffAmountDate == null) || (this.PayoffAmountDate?.Equals(other.PayoffAmountDate) == true)) &&
                ((this.OriginalMaturityDate == null && other.OriginalMaturityDate == null) || (this.OriginalMaturityDate?.Equals(other.OriginalMaturityDate) == true)) &&
                ((this.PrincipalBalance == null && other.PrincipalBalance == null) || (this.PrincipalBalance?.Equals(other.PrincipalBalance) == true)) &&
                ((this.EscrowBalance == null && other.EscrowBalance == null) || (this.EscrowBalance?.Equals(other.EscrowBalance) == true)) &&
                ((this.InterestPeriod == null && other.InterestPeriod == null) || (this.InterestPeriod?.Equals(other.InterestPeriod) == true)) &&
                ((this.InitialMlAmount == null && other.InitialMlAmount == null) || (this.InitialMlAmount?.Equals(other.InitialMlAmount) == true)) &&
                ((this.InitialMlDate == null && other.InitialMlDate == null) || (this.InitialMlDate?.Equals(other.InitialMlDate) == true)) &&
                ((this.NextPaymentPrincipalAmount == null && other.NextPaymentPrincipalAmount == null) || (this.NextPaymentPrincipalAmount?.Equals(other.NextPaymentPrincipalAmount) == true)) &&
                ((this.NextPaymentInterestAmount == null && other.NextPaymentInterestAmount == null) || (this.NextPaymentInterestAmount?.Equals(other.NextPaymentInterestAmount) == true)) &&
                ((this.NextPayment == null && other.NextPayment == null) || (this.NextPayment?.Equals(other.NextPayment) == true)) &&
                ((this.NextPaymentDate == null && other.NextPaymentDate == null) || (this.NextPaymentDate?.Equals(other.NextPaymentDate) == true)) &&
                ((this.LastPaymentDueDate == null && other.LastPaymentDueDate == null) || (this.LastPaymentDueDate?.Equals(other.LastPaymentDueDate) == true)) &&
                ((this.LastPaymentReceiveDate == null && other.LastPaymentReceiveDate == null) || (this.LastPaymentReceiveDate?.Equals(other.LastPaymentReceiveDate) == true)) &&
                ((this.LastPaymentPrincipalAmount == null && other.LastPaymentPrincipalAmount == null) || (this.LastPaymentPrincipalAmount?.Equals(other.LastPaymentPrincipalAmount) == true)) &&
                ((this.LastPaymentInterestAmount == null && other.LastPaymentInterestAmount == null) || (this.LastPaymentInterestAmount?.Equals(other.LastPaymentInterestAmount) == true)) &&
                ((this.LastPaymentEscrowAmount == null && other.LastPaymentEscrowAmount == null) || (this.LastPaymentEscrowAmount?.Equals(other.LastPaymentEscrowAmount) == true)) &&
                ((this.LastPaymentLastFeeAmount == null && other.LastPaymentLastFeeAmount == null) || (this.LastPaymentLastFeeAmount?.Equals(other.LastPaymentLastFeeAmount) == true)) &&
                ((this.LastPaymentLateCharge == null && other.LastPaymentLateCharge == null) || (this.LastPaymentLateCharge?.Equals(other.LastPaymentLateCharge) == true)) &&
                ((this.YtdPrincipalPaid == null && other.YtdPrincipalPaid == null) || (this.YtdPrincipalPaid?.Equals(other.YtdPrincipalPaid) == true)) &&
                ((this.YtdInterestPaid == null && other.YtdInterestPaid == null) || (this.YtdInterestPaid?.Equals(other.YtdInterestPaid) == true)) &&
                ((this.YtdInsurancePaid == null && other.YtdInsurancePaid == null) || (this.YtdInsurancePaid?.Equals(other.YtdInsurancePaid) == true)) &&
                ((this.YtdTaxPaid == null && other.YtdTaxPaid == null) || (this.YtdTaxPaid?.Equals(other.YtdTaxPaid) == true)) &&
                ((this.AutoPayEnrolled == null && other.AutoPayEnrolled == null) || (this.AutoPayEnrolled?.Equals(other.AutoPayEnrolled) == true)) &&
                ((this.Collateral == null && other.Collateral == null) || (this.Collateral?.Equals(other.Collateral) == true)) &&
                ((this.CurrentSchool == null && other.CurrentSchool == null) || (this.CurrentSchool?.Equals(other.CurrentSchool) == true)) &&
                ((this.FirstPaymentDate == null && other.FirstPaymentDate == null) || (this.FirstPaymentDate?.Equals(other.FirstPaymentDate) == true)) &&
                ((this.FirstMortgage == null && other.FirstMortgage == null) || (this.FirstMortgage?.Equals(other.FirstMortgage) == true)) &&
                ((this.LoanPaymentFreq == null && other.LoanPaymentFreq == null) || (this.LoanPaymentFreq?.Equals(other.LoanPaymentFreq) == true)) &&
                ((this.OriginalSchool == null && other.OriginalSchool == null) || (this.OriginalSchool?.Equals(other.OriginalSchool) == true)) &&
                ((this.RecurringPaymentAmount == null && other.RecurringPaymentAmount == null) || (this.RecurringPaymentAmount?.Equals(other.RecurringPaymentAmount) == true)) &&
                ((this.Lender == null && other.Lender == null) || (this.Lender?.Equals(other.Lender) == true)) &&
                ((this.EndingBalanceAmount == null && other.EndingBalanceAmount == null) || (this.EndingBalanceAmount?.Equals(other.EndingBalanceAmount) == true)) &&
                ((this.LoanTermType == null && other.LoanTermType == null) || (this.LoanTermType?.Equals(other.LoanTermType) == true)) &&
                ((this.PaymentsMade == null && other.PaymentsMade == null) || (this.PaymentsMade?.Equals(other.PaymentsMade) == true)) &&
                ((this.BalloonAmount == null && other.BalloonAmount == null) || (this.BalloonAmount?.Equals(other.BalloonAmount) == true)) &&
                ((this.ProjectedInterest == null && other.ProjectedInterest == null) || (this.ProjectedInterest?.Equals(other.ProjectedInterest) == true)) &&
                ((this.InterestPaidLtd == null && other.InterestPaidLtd == null) || (this.InterestPaidLtd?.Equals(other.InterestPaidLtd) == true)) &&
                ((this.InterestRateType == null && other.InterestRateType == null) || (this.InterestRateType?.Equals(other.InterestRateType) == true)) &&
                ((this.LoanPaymentType == null && other.LoanPaymentType == null) || (this.LoanPaymentType?.Equals(other.LoanPaymentType) == true)) &&
                ((this.RepaymentPlan == null && other.RepaymentPlan == null) || (this.RepaymentPlan?.Equals(other.RepaymentPlan) == true)) &&
                ((this.PaymentsRemaining == null && other.PaymentsRemaining == null) || (this.PaymentsRemaining?.Equals(other.PaymentsRemaining) == true)) &&
                ((this.MarginBalance == null && other.MarginBalance == null) || (this.MarginBalance?.Equals(other.MarginBalance) == true)) &&
                ((this.ShortBalance == null && other.ShortBalance == null) || (this.ShortBalance?.Equals(other.ShortBalance) == true)) &&
                ((this.AvailableCashBalance == null && other.AvailableCashBalance == null) || (this.AvailableCashBalance?.Equals(other.AvailableCashBalance) == true)) &&
                ((this.MaturityValueAmount == null && other.MaturityValueAmount == null) || (this.MaturityValueAmount?.Equals(other.MaturityValueAmount) == true)) &&
                ((this.VestedBalance == null && other.VestedBalance == null) || (this.VestedBalance?.Equals(other.VestedBalance) == true)) &&
                ((this.EmpMatchAmount == null && other.EmpMatchAmount == null) || (this.EmpMatchAmount?.Equals(other.EmpMatchAmount) == true)) &&
                ((this.EmpPretaxContribAmount == null && other.EmpPretaxContribAmount == null) || (this.EmpPretaxContribAmount?.Equals(other.EmpPretaxContribAmount) == true)) &&
                ((this.EmpPretaxContribAmountYtd == null && other.EmpPretaxContribAmountYtd == null) || (this.EmpPretaxContribAmountYtd?.Equals(other.EmpPretaxContribAmountYtd) == true)) &&
                ((this.ContribTotalYtd == null && other.ContribTotalYtd == null) || (this.ContribTotalYtd?.Equals(other.ContribTotalYtd) == true)) &&
                ((this.CashBalanceAmount == null && other.CashBalanceAmount == null) || (this.CashBalanceAmount?.Equals(other.CashBalanceAmount) == true)) &&
                ((this.PreTaxAmount == null && other.PreTaxAmount == null) || (this.PreTaxAmount?.Equals(other.PreTaxAmount) == true)) &&
                ((this.AfterTaxAmount == null && other.AfterTaxAmount == null) || (this.AfterTaxAmount?.Equals(other.AfterTaxAmount) == true)) &&
                ((this.MatchAmount == null && other.MatchAmount == null) || (this.MatchAmount?.Equals(other.MatchAmount) == true)) &&
                ((this.ProfitSharingAmount == null && other.ProfitSharingAmount == null) || (this.ProfitSharingAmount?.Equals(other.ProfitSharingAmount) == true)) &&
                ((this.RolloverAmount == null && other.RolloverAmount == null) || (this.RolloverAmount?.Equals(other.RolloverAmount) == true)) &&
                ((this.OtherVestAmount == null && other.OtherVestAmount == null) || (this.OtherVestAmount?.Equals(other.OtherVestAmount) == true)) &&
                ((this.OtherNonvestAmount == null && other.OtherNonvestAmount == null) || (this.OtherNonvestAmount?.Equals(other.OtherNonvestAmount) == true)) &&
                ((this.CurrentLoanBalance == null && other.CurrentLoanBalance == null) || (this.CurrentLoanBalance?.Equals(other.CurrentLoanBalance) == true)) &&
                ((this.LoanRate == null && other.LoanRate == null) || (this.LoanRate?.Equals(other.LoanRate) == true)) &&
                ((this.BuyPower == null && other.BuyPower == null) || (this.BuyPower?.Equals(other.BuyPower) == true)) &&
                ((this.RolloverLtd == null && other.RolloverLtd == null) || (this.RolloverLtd?.Equals(other.RolloverLtd) == true)) &&
                ((this.LoanAwardId == null && other.LoanAwardId == null) || (this.LoanAwardId?.Equals(other.LoanAwardId) == true)) &&
                ((this.OriginalInterestRate == null && other.OriginalInterestRate == null) || (this.OriginalInterestRate?.Equals(other.OriginalInterestRate) == true)) &&
                ((this.Guarantor == null && other.Guarantor == null) || (this.Guarantor?.Equals(other.Guarantor) == true)) &&
                ((this.Owner == null && other.Owner == null) || (this.Owner?.Equals(other.Owner) == true)) &&
                ((this.InterestSubsidyType == null && other.InterestSubsidyType == null) || (this.InterestSubsidyType?.Equals(other.InterestSubsidyType) == true)) &&
                ((this.InterestBalance == null && other.InterestBalance == null) || (this.InterestBalance?.Equals(other.InterestBalance) == true)) &&
                ((this.RemainingTermOfMl == null && other.RemainingTermOfMl == null) || (this.RemainingTermOfMl?.Equals(other.RemainingTermOfMl) == true)) &&
                ((this.InitialInterestRate == null && other.InitialInterestRate == null) || (this.InitialInterestRate?.Equals(other.InitialInterestRate) == true)) &&
                ((this.FeesBalance == null && other.FeesBalance == null) || (this.FeesBalance?.Equals(other.FeesBalance) == true)) &&
                ((this.LoanYtdInterestPaid == null && other.LoanYtdInterestPaid == null) || (this.LoanYtdInterestPaid?.Equals(other.LoanYtdInterestPaid) == true)) &&
                ((this.LoanYtdFeesPaid == null && other.LoanYtdFeesPaid == null) || (this.LoanYtdFeesPaid?.Equals(other.LoanYtdFeesPaid) == true)) &&
                ((this.LoanYtdPrincipalPaid == null && other.LoanYtdPrincipalPaid == null) || (this.LoanYtdPrincipalPaid?.Equals(other.LoanYtdPrincipalPaid) == true)) &&
                ((this.LoanStatus == null && other.LoanStatus == null) || (this.LoanStatus?.Equals(other.LoanStatus) == true)) &&
                ((this.LoanStatusStartDate == null && other.LoanStatusStartDate == null) || (this.LoanStatusStartDate?.Equals(other.LoanStatusStartDate) == true)) &&
                ((this.LoanStatusEndDate == null && other.LoanStatusEndDate == null) || (this.LoanStatusEndDate?.Equals(other.LoanStatusEndDate) == true)) &&
                ((this.WeightedInterestRate == null && other.WeightedInterestRate == null) || (this.WeightedInterestRate?.Equals(other.WeightedInterestRate) == true)) &&
                ((this.RepaymentPlanStartDate == null && other.RepaymentPlanStartDate == null) || (this.RepaymentPlanStartDate?.Equals(other.RepaymentPlanStartDate) == true)) &&
                ((this.RepaymentPlanEndDate == null && other.RepaymentPlanEndDate == null) || (this.RepaymentPlanEndDate?.Equals(other.RepaymentPlanEndDate) == true)) &&
                ((this.ExpectedPayoffDate == null && other.ExpectedPayoffDate == null) || (this.ExpectedPayoffDate?.Equals(other.ExpectedPayoffDate) == true)) &&
                ((this.OutOfSchoolDate == null && other.OutOfSchoolDate == null) || (this.OutOfSchoolDate?.Equals(other.OutOfSchoolDate) == true)) &&
                ((this.ConvertToRepayment == null && other.ConvertToRepayment == null) || (this.ConvertToRepayment?.Equals(other.ConvertToRepayment) == true)) &&
                ((this.DaysDelinquent == null && other.DaysDelinquent == null) || (this.DaysDelinquent?.Equals(other.DaysDelinquent) == true)) &&
                ((this.TotalPrincipalPaid == null && other.TotalPrincipalPaid == null) || (this.TotalPrincipalPaid?.Equals(other.TotalPrincipalPaid) == true)) &&
                ((this.TotalInterestPaid == null && other.TotalInterestPaid == null) || (this.TotalInterestPaid?.Equals(other.TotalInterestPaid) == true)) &&
                ((this.TotalAmountPaid == null && other.TotalAmountPaid == null) || (this.TotalAmountPaid?.Equals(other.TotalAmountPaid) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DateAsOf = {(this.DateAsOf == null ? "null" : this.DateAsOf.ToString())}");
            toStringOutput.Add($"this.AvailableBalanceAmount = {this.AvailableBalanceAmount}");
            toStringOutput.Add($"this.OpenDate = {(this.OpenDate == null ? "null" : this.OpenDate.ToString())}");
            toStringOutput.Add($"this.PeriodStartDate = {(this.PeriodStartDate == null ? "null" : this.PeriodStartDate.ToString())}");
            toStringOutput.Add($"this.PeriodEndDate = {(this.PeriodEndDate == null ? "null" : this.PeriodEndDate.ToString())}");
            toStringOutput.Add($"this.PeriodInterestRate = {(this.PeriodInterestRate == null ? "null" : this.PeriodInterestRate.ToString())}");
            toStringOutput.Add($"this.PeriodDepositAmount = {(this.PeriodDepositAmount == null ? "null" : this.PeriodDepositAmount.ToString())}");
            toStringOutput.Add($"this.PeriodInterestAmount = {(this.PeriodInterestAmount == null ? "null" : this.PeriodInterestAmount.ToString())}");
            toStringOutput.Add($"this.InterestYtdAmount = {(this.InterestYtdAmount == null ? "null" : this.InterestYtdAmount.ToString())}");
            toStringOutput.Add($"this.InterestPriorYtdAmount = {(this.InterestPriorYtdAmount == null ? "null" : this.InterestPriorYtdAmount.ToString())}");
            toStringOutput.Add($"this.MaturityDate = {(this.MaturityDate == null ? "null" : this.MaturityDate.ToString())}");
            toStringOutput.Add($"this.InterestRate = {(this.InterestRate == null ? "null" : this.InterestRate == string.Empty ? "" : this.InterestRate)}");
            toStringOutput.Add($"this.CreditAvailableAmount = {(this.CreditAvailableAmount == null ? "null" : this.CreditAvailableAmount.ToString())}");
            toStringOutput.Add($"this.CreditMaxAmount = {(this.CreditMaxAmount == null ? "null" : this.CreditMaxAmount.ToString())}");
            toStringOutput.Add($"this.CashAdvanceAvailableAmount = {(this.CashAdvanceAvailableAmount == null ? "null" : this.CashAdvanceAvailableAmount.ToString())}");
            toStringOutput.Add($"this.CashAdvanceMaxAmount = {(this.CashAdvanceMaxAmount == null ? "null" : this.CashAdvanceMaxAmount.ToString())}");
            toStringOutput.Add($"this.CashAdvanceBalance = {(this.CashAdvanceBalance == null ? "null" : this.CashAdvanceBalance.ToString())}");
            toStringOutput.Add($"this.CashAdvanceInterestRate = {(this.CashAdvanceInterestRate == null ? "null" : this.CashAdvanceInterestRate.ToString())}");
            toStringOutput.Add($"this.CurrentBalance = {(this.CurrentBalance == null ? "null" : this.CurrentBalance.ToString())}");
            toStringOutput.Add($"this.PaymentMinAmount = {(this.PaymentMinAmount == null ? "null" : this.PaymentMinAmount.ToString())}");
            toStringOutput.Add($"this.PaymentDueDate = {(this.PaymentDueDate == null ? "null" : this.PaymentDueDate.ToString())}");
            toStringOutput.Add($"this.PreviousBalance = {(this.PreviousBalance == null ? "null" : this.PreviousBalance.ToString())}");
            toStringOutput.Add($"this.StatementStartDate = {(this.StatementStartDate == null ? "null" : this.StatementStartDate.ToString())}");
            toStringOutput.Add($"this.StatementEndDate = {(this.StatementEndDate == null ? "null" : this.StatementEndDate.ToString())}");
            toStringOutput.Add($"this.StatementPurchaseAmount = {(this.StatementPurchaseAmount == null ? "null" : this.StatementPurchaseAmount.ToString())}");
            toStringOutput.Add($"this.StatementFinanceAmount = {(this.StatementFinanceAmount == null ? "null" : this.StatementFinanceAmount.ToString())}");
            toStringOutput.Add($"this.StatementCreditAmount = {(this.StatementCreditAmount == null ? "null" : this.StatementCreditAmount.ToString())}");
            toStringOutput.Add($"this.RewardEarnedBalance = {(this.RewardEarnedBalance == null ? "null" : this.RewardEarnedBalance.ToString())}");
            toStringOutput.Add($"this.PastDueAmount = {(this.PastDueAmount == null ? "null" : this.PastDueAmount.ToString())}");
            toStringOutput.Add($"this.LastPaymentAmount = {(this.LastPaymentAmount == null ? "null" : this.LastPaymentAmount.ToString())}");
            toStringOutput.Add($"this.LastPaymentDate = {(this.LastPaymentDate == null ? "null" : this.LastPaymentDate.ToString())}");
            toStringOutput.Add($"this.StatementCloseBalance = {(this.StatementCloseBalance == null ? "null" : this.StatementCloseBalance.ToString())}");
            toStringOutput.Add($"this.TermOfMl = {(this.TermOfMl == null ? "null" : this.TermOfMl == string.Empty ? "" : this.TermOfMl)}");
            toStringOutput.Add($"this.MlHolderName = {(this.MlHolderName == null ? "null" : this.MlHolderName == string.Empty ? "" : this.MlHolderName)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.LateFeeAmount = {(this.LateFeeAmount == null ? "null" : this.LateFeeAmount.ToString())}");
            toStringOutput.Add($"this.PayoffAmount = {(this.PayoffAmount == null ? "null" : this.PayoffAmount.ToString())}");
            toStringOutput.Add($"this.PayoffAmountDate = {(this.PayoffAmountDate == null ? "null" : this.PayoffAmountDate.ToString())}");
            toStringOutput.Add($"this.OriginalMaturityDate = {(this.OriginalMaturityDate == null ? "null" : this.OriginalMaturityDate.ToString())}");
            toStringOutput.Add($"this.PrincipalBalance = {(this.PrincipalBalance == null ? "null" : this.PrincipalBalance.ToString())}");
            toStringOutput.Add($"this.EscrowBalance = {(this.EscrowBalance == null ? "null" : this.EscrowBalance.ToString())}");
            toStringOutput.Add($"this.InterestPeriod = {(this.InterestPeriod == null ? "null" : this.InterestPeriod == string.Empty ? "" : this.InterestPeriod)}");
            toStringOutput.Add($"this.InitialMlAmount = {(this.InitialMlAmount == null ? "null" : this.InitialMlAmount.ToString())}");
            toStringOutput.Add($"this.InitialMlDate = {(this.InitialMlDate == null ? "null" : this.InitialMlDate.ToString())}");
            toStringOutput.Add($"this.NextPaymentPrincipalAmount = {(this.NextPaymentPrincipalAmount == null ? "null" : this.NextPaymentPrincipalAmount.ToString())}");
            toStringOutput.Add($"this.NextPaymentInterestAmount = {(this.NextPaymentInterestAmount == null ? "null" : this.NextPaymentInterestAmount.ToString())}");
            toStringOutput.Add($"this.NextPayment = {(this.NextPayment == null ? "null" : this.NextPayment.ToString())}");
            toStringOutput.Add($"this.NextPaymentDate = {(this.NextPaymentDate == null ? "null" : this.NextPaymentDate.ToString())}");
            toStringOutput.Add($"this.LastPaymentDueDate = {(this.LastPaymentDueDate == null ? "null" : this.LastPaymentDueDate.ToString())}");
            toStringOutput.Add($"this.LastPaymentReceiveDate = {(this.LastPaymentReceiveDate == null ? "null" : this.LastPaymentReceiveDate.ToString())}");
            toStringOutput.Add($"this.LastPaymentPrincipalAmount = {(this.LastPaymentPrincipalAmount == null ? "null" : this.LastPaymentPrincipalAmount.ToString())}");
            toStringOutput.Add($"this.LastPaymentInterestAmount = {(this.LastPaymentInterestAmount == null ? "null" : this.LastPaymentInterestAmount.ToString())}");
            toStringOutput.Add($"this.LastPaymentEscrowAmount = {(this.LastPaymentEscrowAmount == null ? "null" : this.LastPaymentEscrowAmount.ToString())}");
            toStringOutput.Add($"this.LastPaymentLastFeeAmount = {(this.LastPaymentLastFeeAmount == null ? "null" : this.LastPaymentLastFeeAmount.ToString())}");
            toStringOutput.Add($"this.LastPaymentLateCharge = {(this.LastPaymentLateCharge == null ? "null" : this.LastPaymentLateCharge.ToString())}");
            toStringOutput.Add($"this.YtdPrincipalPaid = {(this.YtdPrincipalPaid == null ? "null" : this.YtdPrincipalPaid.ToString())}");
            toStringOutput.Add($"this.YtdInterestPaid = {(this.YtdInterestPaid == null ? "null" : this.YtdInterestPaid.ToString())}");
            toStringOutput.Add($"this.YtdInsurancePaid = {(this.YtdInsurancePaid == null ? "null" : this.YtdInsurancePaid.ToString())}");
            toStringOutput.Add($"this.YtdTaxPaid = {(this.YtdTaxPaid == null ? "null" : this.YtdTaxPaid.ToString())}");
            toStringOutput.Add($"this.AutoPayEnrolled = {(this.AutoPayEnrolled == null ? "null" : this.AutoPayEnrolled.ToString())}");
            toStringOutput.Add($"this.Collateral = {(this.Collateral == null ? "null" : this.Collateral == string.Empty ? "" : this.Collateral)}");
            toStringOutput.Add($"this.CurrentSchool = {(this.CurrentSchool == null ? "null" : this.CurrentSchool == string.Empty ? "" : this.CurrentSchool)}");
            toStringOutput.Add($"this.FirstPaymentDate = {(this.FirstPaymentDate == null ? "null" : this.FirstPaymentDate.ToString())}");
            toStringOutput.Add($"this.FirstMortgage = {(this.FirstMortgage == null ? "null" : this.FirstMortgage.ToString())}");
            toStringOutput.Add($"this.LoanPaymentFreq = {(this.LoanPaymentFreq == null ? "null" : this.LoanPaymentFreq == string.Empty ? "" : this.LoanPaymentFreq)}");
            toStringOutput.Add($"this.OriginalSchool = {(this.OriginalSchool == null ? "null" : this.OriginalSchool == string.Empty ? "" : this.OriginalSchool)}");
            toStringOutput.Add($"this.RecurringPaymentAmount = {(this.RecurringPaymentAmount == null ? "null" : this.RecurringPaymentAmount.ToString())}");
            toStringOutput.Add($"this.Lender = {(this.Lender == null ? "null" : this.Lender == string.Empty ? "" : this.Lender)}");
            toStringOutput.Add($"this.EndingBalanceAmount = {(this.EndingBalanceAmount == null ? "null" : this.EndingBalanceAmount.ToString())}");
            toStringOutput.Add($"this.LoanTermType = {(this.LoanTermType == null ? "null" : this.LoanTermType == string.Empty ? "" : this.LoanTermType)}");
            toStringOutput.Add($"this.PaymentsMade = {(this.PaymentsMade == null ? "null" : this.PaymentsMade.ToString())}");
            toStringOutput.Add($"this.BalloonAmount = {(this.BalloonAmount == null ? "null" : this.BalloonAmount.ToString())}");
            toStringOutput.Add($"this.ProjectedInterest = {(this.ProjectedInterest == null ? "null" : this.ProjectedInterest.ToString())}");
            toStringOutput.Add($"this.InterestPaidLtd = {(this.InterestPaidLtd == null ? "null" : this.InterestPaidLtd.ToString())}");
            toStringOutput.Add($"this.InterestRateType = {(this.InterestRateType == null ? "null" : this.InterestRateType == string.Empty ? "" : this.InterestRateType)}");
            toStringOutput.Add($"this.LoanPaymentType = {(this.LoanPaymentType == null ? "null" : this.LoanPaymentType == string.Empty ? "" : this.LoanPaymentType)}");
            toStringOutput.Add($"this.RepaymentPlan = {(this.RepaymentPlan == null ? "null" : this.RepaymentPlan == string.Empty ? "" : this.RepaymentPlan)}");
            toStringOutput.Add($"this.PaymentsRemaining = {(this.PaymentsRemaining == null ? "null" : this.PaymentsRemaining.ToString())}");
            toStringOutput.Add($"this.MarginBalance = {(this.MarginBalance == null ? "null" : this.MarginBalance.ToString())}");
            toStringOutput.Add($"this.ShortBalance = {(this.ShortBalance == null ? "null" : this.ShortBalance.ToString())}");
            toStringOutput.Add($"this.AvailableCashBalance = {(this.AvailableCashBalance == null ? "null" : this.AvailableCashBalance.ToString())}");
            toStringOutput.Add($"this.MaturityValueAmount = {(this.MaturityValueAmount == null ? "null" : this.MaturityValueAmount.ToString())}");
            toStringOutput.Add($"this.VestedBalance = {(this.VestedBalance == null ? "null" : this.VestedBalance.ToString())}");
            toStringOutput.Add($"this.EmpMatchAmount = {(this.EmpMatchAmount == null ? "null" : this.EmpMatchAmount.ToString())}");
            toStringOutput.Add($"this.EmpPretaxContribAmount = {(this.EmpPretaxContribAmount == null ? "null" : this.EmpPretaxContribAmount.ToString())}");
            toStringOutput.Add($"this.EmpPretaxContribAmountYtd = {(this.EmpPretaxContribAmountYtd == null ? "null" : this.EmpPretaxContribAmountYtd.ToString())}");
            toStringOutput.Add($"this.ContribTotalYtd = {(this.ContribTotalYtd == null ? "null" : this.ContribTotalYtd.ToString())}");
            toStringOutput.Add($"this.CashBalanceAmount = {(this.CashBalanceAmount == null ? "null" : this.CashBalanceAmount.ToString())}");
            toStringOutput.Add($"this.PreTaxAmount = {(this.PreTaxAmount == null ? "null" : this.PreTaxAmount.ToString())}");
            toStringOutput.Add($"this.AfterTaxAmount = {(this.AfterTaxAmount == null ? "null" : this.AfterTaxAmount.ToString())}");
            toStringOutput.Add($"this.MatchAmount = {(this.MatchAmount == null ? "null" : this.MatchAmount.ToString())}");
            toStringOutput.Add($"this.ProfitSharingAmount = {(this.ProfitSharingAmount == null ? "null" : this.ProfitSharingAmount.ToString())}");
            toStringOutput.Add($"this.RolloverAmount = {(this.RolloverAmount == null ? "null" : this.RolloverAmount.ToString())}");
            toStringOutput.Add($"this.OtherVestAmount = {(this.OtherVestAmount == null ? "null" : this.OtherVestAmount.ToString())}");
            toStringOutput.Add($"this.OtherNonvestAmount = {(this.OtherNonvestAmount == null ? "null" : this.OtherNonvestAmount.ToString())}");
            toStringOutput.Add($"this.CurrentLoanBalance = {(this.CurrentLoanBalance == null ? "null" : this.CurrentLoanBalance.ToString())}");
            toStringOutput.Add($"this.LoanRate = {(this.LoanRate == null ? "null" : this.LoanRate.ToString())}");
            toStringOutput.Add($"this.BuyPower = {(this.BuyPower == null ? "null" : this.BuyPower.ToString())}");
            toStringOutput.Add($"this.RolloverLtd = {(this.RolloverLtd == null ? "null" : this.RolloverLtd.ToString())}");
            toStringOutput.Add($"this.LoanAwardId = {(this.LoanAwardId == null ? "null" : this.LoanAwardId == string.Empty ? "" : this.LoanAwardId)}");
            toStringOutput.Add($"this.OriginalInterestRate = {(this.OriginalInterestRate == null ? "null" : this.OriginalInterestRate.ToString())}");
            toStringOutput.Add($"this.Guarantor = {(this.Guarantor == null ? "null" : this.Guarantor == string.Empty ? "" : this.Guarantor)}");
            toStringOutput.Add($"this.Owner = {(this.Owner == null ? "null" : this.Owner == string.Empty ? "" : this.Owner)}");
            toStringOutput.Add($"this.InterestSubsidyType = {(this.InterestSubsidyType == null ? "null" : this.InterestSubsidyType == string.Empty ? "" : this.InterestSubsidyType)}");
            toStringOutput.Add($"this.InterestBalance = {(this.InterestBalance == null ? "null" : this.InterestBalance.ToString())}");
            toStringOutput.Add($"this.RemainingTermOfMl = {(this.RemainingTermOfMl == null ? "null" : this.RemainingTermOfMl.ToString())}");
            toStringOutput.Add($"this.InitialInterestRate = {(this.InitialInterestRate == null ? "null" : this.InitialInterestRate.ToString())}");
            toStringOutput.Add($"this.FeesBalance = {(this.FeesBalance == null ? "null" : this.FeesBalance.ToString())}");
            toStringOutput.Add($"this.LoanYtdInterestPaid = {(this.LoanYtdInterestPaid == null ? "null" : this.LoanYtdInterestPaid.ToString())}");
            toStringOutput.Add($"this.LoanYtdFeesPaid = {(this.LoanYtdFeesPaid == null ? "null" : this.LoanYtdFeesPaid.ToString())}");
            toStringOutput.Add($"this.LoanYtdPrincipalPaid = {(this.LoanYtdPrincipalPaid == null ? "null" : this.LoanYtdPrincipalPaid.ToString())}");
            toStringOutput.Add($"this.LoanStatus = {(this.LoanStatus == null ? "null" : this.LoanStatus == string.Empty ? "" : this.LoanStatus)}");
            toStringOutput.Add($"this.LoanStatusStartDate = {(this.LoanStatusStartDate == null ? "null" : this.LoanStatusStartDate.ToString())}");
            toStringOutput.Add($"this.LoanStatusEndDate = {(this.LoanStatusEndDate == null ? "null" : this.LoanStatusEndDate.ToString())}");
            toStringOutput.Add($"this.WeightedInterestRate = {(this.WeightedInterestRate == null ? "null" : this.WeightedInterestRate.ToString())}");
            toStringOutput.Add($"this.RepaymentPlanStartDate = {(this.RepaymentPlanStartDate == null ? "null" : this.RepaymentPlanStartDate.ToString())}");
            toStringOutput.Add($"this.RepaymentPlanEndDate = {(this.RepaymentPlanEndDate == null ? "null" : this.RepaymentPlanEndDate.ToString())}");
            toStringOutput.Add($"this.ExpectedPayoffDate = {(this.ExpectedPayoffDate == null ? "null" : this.ExpectedPayoffDate.ToString())}");
            toStringOutput.Add($"this.OutOfSchoolDate = {(this.OutOfSchoolDate == null ? "null" : this.OutOfSchoolDate.ToString())}");
            toStringOutput.Add($"this.ConvertToRepayment = {(this.ConvertToRepayment == null ? "null" : this.ConvertToRepayment.ToString())}");
            toStringOutput.Add($"this.DaysDelinquent = {(this.DaysDelinquent == null ? "null" : this.DaysDelinquent.ToString())}");
            toStringOutput.Add($"this.TotalPrincipalPaid = {(this.TotalPrincipalPaid == null ? "null" : this.TotalPrincipalPaid.ToString())}");
            toStringOutput.Add($"this.TotalInterestPaid = {(this.TotalInterestPaid == null ? "null" : this.TotalInterestPaid.ToString())}");
            toStringOutput.Add($"this.TotalAmountPaid = {(this.TotalAmountPaid == null ? "null" : this.TotalAmountPaid.ToString())}");
        }
    }
}