// <copyright file="CustomerAccount.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CustomerAccount.
    /// </summary>
    public class CustomerAccount
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccount"/> class.
        /// </summary>
        public CustomerAccount()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccount"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="number">number.</param>
        /// <param name="accountNumberDisplay">accountNumberDisplay.</param>
        /// <param name="name">name.</param>
        /// <param name="balance">balance.</param>
        /// <param name="type">type.</param>
        /// <param name="status">status.</param>
        /// <param name="customerId">customerId.</param>
        /// <param name="institutionId">institutionId.</param>
        /// <param name="balanceDate">balanceDate.</param>
        /// <param name="createdDate">createdDate.</param>
        /// <param name="currency">currency.</param>
        /// <param name="oldestTransactionDate">oldestTransactionDate.</param>
        /// <param name="institutionLoginId">institutionLoginId.</param>
        /// <param name="realAccountNumberLast4">realAccountNumberLast4.</param>
        /// <param name="aggregationStatusCode">aggregationStatusCode.</param>
        /// <param name="aggregationSuccessDate">aggregationSuccessDate.</param>
        /// <param name="aggregationAttemptDate">aggregationAttemptDate.</param>
        /// <param name="lastTransactionDate">lastTransactionDate.</param>
        /// <param name="detail">detail.</param>
        /// <param name="position">position.</param>
        /// <param name="displayPosition">displayPosition.</param>
        /// <param name="parentAccount">parentAccount.</param>
        public CustomerAccount(
            string id,
            string number,
            string accountNumberDisplay,
            string name,
            double balance,
            string type,
            string status,
            string customerId,
            string institutionId,
            long balanceDate,
            long createdDate,
            string currency,
            long oldestTransactionDate,
            long institutionLoginId,
            string realAccountNumberLast4 = null,
            int? aggregationStatusCode = null,
            long? aggregationSuccessDate = null,
            long? aggregationAttemptDate = null,
            long? lastTransactionDate = null,
            Models.CustomerAccountDetail detail = null,
            List<Models.CustomerAccountPosition> position = null,
            int? displayPosition = null,
            string parentAccount = null)
        {
            this.Id = id;
            this.Number = number;
            this.AccountNumberDisplay = accountNumberDisplay;
            this.RealAccountNumberLast4 = realAccountNumberLast4;
            this.Name = name;
            this.Balance = balance;
            this.Type = type;
            this.AggregationStatusCode = aggregationStatusCode;
            this.Status = status;
            this.CustomerId = customerId;
            this.InstitutionId = institutionId;
            this.BalanceDate = balanceDate;
            this.AggregationSuccessDate = aggregationSuccessDate;
            this.AggregationAttemptDate = aggregationAttemptDate;
            this.CreatedDate = createdDate;
            this.Currency = currency;
            this.LastTransactionDate = lastTransactionDate;
            this.OldestTransactionDate = oldestTransactionDate;
            this.InstitutionLoginId = institutionLoginId;
            this.Detail = detail;
            this.Position = position;
            this.DisplayPosition = displayPosition;
            this.ParentAccount = parentAccount;
        }

        /// <summary>
        /// An account ID
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// Use the `accountNumberDisplay` field. Starting July 1, 2021 the `number` field will sunset with limited support until April 1, 2022, at which time it will be deprecated (no longer available).
        /// </summary>
        [JsonProperty("number")]
        public string Number { get; set; }

        /// <summary>
        /// The account number from a financial institution in truncated format:
        /// * Last four digits: "1234"
        /// * Last four digits with suffix: "1234-9"
        /// * Full value for string accounts: "john@gmail.com"
        /// </summary>
        [JsonProperty("accountNumberDisplay")]
        public string AccountNumberDisplay { get; set; }

        /// <summary>
        /// The last 4 digits of the ACH account number
        /// </summary>
        [JsonProperty("realAccountNumberLast4", NullValueHandling = NullValueHandling.Ignore)]
        public string RealAccountNumberLast4 { get; set; }

        /// <summary>
        /// The account name from the institution
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// The cleared balance of the account as of `balanceDate`
        /// </summary>
        [JsonProperty("balance")]
        public double Balance { get; set; }

        /// <summary>
        /// The list of supported account types.
        /// * "checking": Standard checking
        /// * "savings": Standard savings
        /// * "cd": Certificates of deposit
        /// * "moneyMarket": Money Market
        /// * "creditCard": Standard credit cards
        /// * "lineOfCredit": Home equity, line of credit
        /// * "investment": Generic investment (no details)
        /// * "investmentTaxDeferred": Generic tax-advantaged investment (no details)
        /// * "employeeStockPurchasePlan": ESPP, Employee Stock Ownership Plans (ESOP), Stock Purchase Plans
        /// * "ira": Individual Retirement Account (not Rollover or Roth)
        /// * "401k": 401K Plan
        /// * "roth": Roth IRA, Roth 401K
        /// * "403b": 403B Plan
        /// * "529plan": 529 Plan (True value is 529)
        /// * "rollover": Rollover IRA
        /// * "ugma": Uniform Gifts to Minors Act
        /// * "utma": Uniform Transfers to Minors Act
        /// * "keogh": Keogh Plan
        /// * "457plan": 457 Plan (True value is 457)
        /// * "401a": 401A Plan
        /// * "brokerageAccount": Brokerage Account
        /// * "educationSavings": Education Savings Account that is not a 529
        /// * "healthSavingsAccount": HSA (Health Savings Accounts)
        /// * "pension": Pension
        /// * "profitSharingPlan": Profit Sharing Plan
        /// * "roth401k": Roth 401K
        /// * "sepIRA": Simplified Employee Pension IRA
        /// * "simpleIRA": Simple IRA
        /// * "thriftSavingsPlan": Thrift Savings Plan
        /// * "variableAnnuity": Variable Annuity
        /// * "cryptocurrency": Cryptocurrency Wallet, Cryptocurrency Account
        /// * "mortgage": Standard Mortgages
        /// * "loan": Auto loans, equity loans, other loans
        /// * "studentLoan": Student Loan
        /// * "studentLoanGroup": Student Loan Group
        /// * "studentLoanAccount": Student Loan Account
        /// </summary>
        [JsonProperty("type")]
        public string Type { get; set; }

        /// <summary>
        /// The status of the most recent aggregation attempt (see [Aggregation Status Codes](https://docs.finicity.com/aggregation-status-codes/)). Won't be present until you have run your first aggregation for the account.
        /// </summary>
        [JsonProperty("aggregationStatusCode", NullValueHandling = NullValueHandling.Ignore)]
        public int? AggregationStatusCode { get; set; }

        /// <summary>
        /// "pending" during account discovery, always "active" following successful account activation
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }

        /// <summary>
        /// A customer ID. See Add Customer API for how to create a customer ID.
        /// </summary>
        [JsonProperty("customerId")]
        public string CustomerId { get; set; }

        /// <summary>
        /// The ID of a financial institution
        /// </summary>
        [JsonProperty("institutionId")]
        public string InstitutionId { get; set; }

        /// <summary>
        /// A timestamp showing when the balance was captured. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("balanceDate")]
        public long BalanceDate { get; set; }

        /// <summary>
        /// A timestamp showing the last successful aggregation of the account. This will not be present until you have run your first aggregation for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("aggregationSuccessDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? AggregationSuccessDate { get; set; }

        /// <summary>
        /// A timestamp showing the last aggregation attempt, whether successful or not. This will not be present until you have run your first aggregation for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("aggregationAttemptDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? AggregationAttemptDate { get; set; }

        /// <summary>
        /// A timestamp showing when the account was added to the system. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("createdDate")]
        public long CreatedDate { get; set; }

        /// <summary>
        /// A currency code
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// The date of the latest transaction on the account. This will not be present until you have run your first aggregation for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("lastTransactionDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? LastTransactionDate { get; set; }

        /// <summary>
        /// The date of the oldest transaction in the transactions for the account. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("oldestTransactionDate")]
        public long OldestTransactionDate { get; set; }

        /// <summary>
        /// An institution login ID (from the account record), represented as a number
        /// </summary>
        [JsonProperty("institutionLoginId")]
        public long InstitutionLoginId { get; set; }

        /// <summary>
        /// Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution.
        /// </summary>
        [JsonProperty("detail", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CustomerAccountDetail Detail { get; set; }

        /// <summary>
        /// Investment holdings
        /// </summary>
        [JsonProperty("position", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CustomerAccountPosition> Position { get; set; }

        /// <summary>
        /// Display position of the account at the financial institution, "1" being the top listed account
        /// </summary>
        [JsonProperty("displayPosition", NullValueHandling = NullValueHandling.Ignore)]
        public int? DisplayPosition { get; set; }

        /// <summary>
        /// The assigned account ID for the account one level higher in the student loan account hierarchy
        /// </summary>
        [JsonProperty("parentAccount", NullValueHandling = NullValueHandling.Ignore)]
        public string ParentAccount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomerAccount : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CustomerAccount other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Number == null && other.Number == null) || (this.Number?.Equals(other.Number) == true)) &&
                ((this.AccountNumberDisplay == null && other.AccountNumberDisplay == null) || (this.AccountNumberDisplay?.Equals(other.AccountNumberDisplay) == true)) &&
                ((this.RealAccountNumberLast4 == null && other.RealAccountNumberLast4 == null) || (this.RealAccountNumberLast4?.Equals(other.RealAccountNumberLast4) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                this.Balance.Equals(other.Balance) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.AggregationStatusCode == null && other.AggregationStatusCode == null) || (this.AggregationStatusCode?.Equals(other.AggregationStatusCode) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.CustomerId == null && other.CustomerId == null) || (this.CustomerId?.Equals(other.CustomerId) == true)) &&
                ((this.InstitutionId == null && other.InstitutionId == null) || (this.InstitutionId?.Equals(other.InstitutionId) == true)) &&
                this.BalanceDate.Equals(other.BalanceDate) &&
                ((this.AggregationSuccessDate == null && other.AggregationSuccessDate == null) || (this.AggregationSuccessDate?.Equals(other.AggregationSuccessDate) == true)) &&
                ((this.AggregationAttemptDate == null && other.AggregationAttemptDate == null) || (this.AggregationAttemptDate?.Equals(other.AggregationAttemptDate) == true)) &&
                this.CreatedDate.Equals(other.CreatedDate) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                ((this.LastTransactionDate == null && other.LastTransactionDate == null) || (this.LastTransactionDate?.Equals(other.LastTransactionDate) == true)) &&
                this.OldestTransactionDate.Equals(other.OldestTransactionDate) &&
                this.InstitutionLoginId.Equals(other.InstitutionLoginId) &&
                ((this.Detail == null && other.Detail == null) || (this.Detail?.Equals(other.Detail) == true)) &&
                ((this.Position == null && other.Position == null) || (this.Position?.Equals(other.Position) == true)) &&
                ((this.DisplayPosition == null && other.DisplayPosition == null) || (this.DisplayPosition?.Equals(other.DisplayPosition) == true)) &&
                ((this.ParentAccount == null && other.ParentAccount == null) || (this.ParentAccount?.Equals(other.ParentAccount) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.Number = {(this.Number == null ? "null" : this.Number == string.Empty ? "" : this.Number)}");
            toStringOutput.Add($"this.AccountNumberDisplay = {(this.AccountNumberDisplay == null ? "null" : this.AccountNumberDisplay == string.Empty ? "" : this.AccountNumberDisplay)}");
            toStringOutput.Add($"this.RealAccountNumberLast4 = {(this.RealAccountNumberLast4 == null ? "null" : this.RealAccountNumberLast4 == string.Empty ? "" : this.RealAccountNumberLast4)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Balance = {this.Balance}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.AggregationStatusCode = {(this.AggregationStatusCode == null ? "null" : this.AggregationStatusCode.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.CustomerId = {(this.CustomerId == null ? "null" : this.CustomerId == string.Empty ? "" : this.CustomerId)}");
            toStringOutput.Add($"this.InstitutionId = {(this.InstitutionId == null ? "null" : this.InstitutionId == string.Empty ? "" : this.InstitutionId)}");
            toStringOutput.Add($"this.BalanceDate = {this.BalanceDate}");
            toStringOutput.Add($"this.AggregationSuccessDate = {(this.AggregationSuccessDate == null ? "null" : this.AggregationSuccessDate.ToString())}");
            toStringOutput.Add($"this.AggregationAttemptDate = {(this.AggregationAttemptDate == null ? "null" : this.AggregationAttemptDate.ToString())}");
            toStringOutput.Add($"this.CreatedDate = {this.CreatedDate}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.LastTransactionDate = {(this.LastTransactionDate == null ? "null" : this.LastTransactionDate.ToString())}");
            toStringOutput.Add($"this.OldestTransactionDate = {this.OldestTransactionDate}");
            toStringOutput.Add($"this.InstitutionLoginId = {this.InstitutionLoginId}");
            toStringOutput.Add($"this.Detail = {(this.Detail == null ? "null" : this.Detail.ToString())}");
            toStringOutput.Add($"this.Position = {(this.Position == null ? "null" : $"[{string.Join(", ", this.Position)} ]")}");
            toStringOutput.Add($"this.DisplayPosition = {(this.DisplayPosition == null ? "null" : this.DisplayPosition.ToString())}");
            toStringOutput.Add($"this.ParentAccount = {(this.ParentAccount == null ? "null" : this.ParentAccount == string.Empty ? "" : this.ParentAccount)}");
        }
    }
}