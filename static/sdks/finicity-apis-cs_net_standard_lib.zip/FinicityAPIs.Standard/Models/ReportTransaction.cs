// <copyright file="ReportTransaction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReportTransaction.
    /// </summary>
    public class ReportTransaction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportTransaction"/> class.
        /// </summary>
        public ReportTransaction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportTransaction"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="postedDate">postedDate.</param>
        /// <param name="description">description.</param>
        /// <param name="normalizedPayee">normalizedPayee.</param>
        /// <param name="institutionTransactionId">institutionTransactionId.</param>
        /// <param name="category">category.</param>
        /// <param name="amount">amount.</param>
        /// <param name="memo">memo.</param>
        /// <param name="type">type.</param>
        /// <param name="securityType">securityType.</param>
        /// <param name="symbol">symbol.</param>
        /// <param name="commission">commission.</param>
        public ReportTransaction(
            long id,
            long postedDate,
            string description,
            string normalizedPayee,
            string institutionTransactionId,
            string category,
            double? amount = null,
            string memo = null,
            string type = null,
            string securityType = null,
            string symbol = null,
            double? commission = null)
        {
            this.Id = id;
            this.Amount = amount;
            this.PostedDate = postedDate;
            this.Description = description;
            this.Memo = memo;
            this.NormalizedPayee = normalizedPayee;
            this.InstitutionTransactionId = institutionTransactionId;
            this.Category = category;
            this.Type = type;
            this.SecurityType = securityType;
            this.Symbol = symbol;
            this.Commission = commission;
        }

        /// <summary>
        /// A transaction ID
        /// </summary>
        [JsonProperty("id")]
        public long Id { get; set; }

        /// <summary>
        /// The total amount of the transaction. Transactions for deposits are positive values, withdrawals and debits are negative values.
        /// </summary>
        [JsonProperty("amount", NullValueHandling = NullValueHandling.Ignore)]
        public double? Amount { get; set; }

        /// <summary>
        /// A timestamp showing when the transaction was posted or cleared by the institution
        /// </summary>
        [JsonProperty("postedDate")]
        public long PostedDate { get; set; }

        /// <summary>
        /// The description of the transaction, as provided by the institution (often known as `payee`). In the event that this field is left blank by the institution, Finicity will pass a value of "No description provided by institution". All other values are provided by the institution.
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }

        /// <summary>
        /// The memo field of the transaction, as provided by the institution. The institution must provide either a description, a memo, or both. It is recommended to concatenate the two fields into a single value.
        /// </summary>
        [JsonProperty("memo", NullValueHandling = NullValueHandling.Ignore)]
        public string Memo { get; set; }

        /// <summary>
        /// A normalized payee, derived from the transaction's `description` and `memo` fields
        /// </summary>
        [JsonProperty("normalizedPayee")]
        public string NormalizedPayee { get; set; }

        /// <summary>
        /// The unique identifier given by the FI for each transaction
        /// </summary>
        [JsonProperty("institutionTransactionId")]
        public string InstitutionTransactionId { get; set; }

        /// <summary>
        /// One of the values from Categories (assigned based on the payee name)
        /// </summary>
        [JsonProperty("category")]
        public string Category { get; set; }

        /// <summary>
        /// One of the values from transaction types
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// The type of investment security (VOA only)
        /// </summary>
        [JsonProperty("securityType", NullValueHandling = NullValueHandling.Ignore)]
        public string SecurityType { get; set; }

        /// <summary>
        /// Investment symbol (VOA only)
        /// </summary>
        [JsonProperty("symbol", NullValueHandling = NullValueHandling.Ignore)]
        public string Symbol { get; set; }

        /// <summary>
        /// Gets or sets Commission.
        /// </summary>
        [JsonProperty("commission", NullValueHandling = NullValueHandling.Ignore)]
        public double? Commission { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReportTransaction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReportTransaction other &&
                this.Id.Equals(other.Id) &&
                ((this.Amount == null && other.Amount == null) || (this.Amount?.Equals(other.Amount) == true)) &&
                this.PostedDate.Equals(other.PostedDate) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Memo == null && other.Memo == null) || (this.Memo?.Equals(other.Memo) == true)) &&
                ((this.NormalizedPayee == null && other.NormalizedPayee == null) || (this.NormalizedPayee?.Equals(other.NormalizedPayee) == true)) &&
                ((this.InstitutionTransactionId == null && other.InstitutionTransactionId == null) || (this.InstitutionTransactionId?.Equals(other.InstitutionTransactionId) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true)) &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.SecurityType == null && other.SecurityType == null) || (this.SecurityType?.Equals(other.SecurityType) == true)) &&
                ((this.Symbol == null && other.Symbol == null) || (this.Symbol?.Equals(other.Symbol) == true)) &&
                ((this.Commission == null && other.Commission == null) || (this.Commission?.Equals(other.Commission) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {this.Id}");
            toStringOutput.Add($"this.Amount = {(this.Amount == null ? "null" : this.Amount.ToString())}");
            toStringOutput.Add($"this.PostedDate = {this.PostedDate}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Memo = {(this.Memo == null ? "null" : this.Memo == string.Empty ? "" : this.Memo)}");
            toStringOutput.Add($"this.NormalizedPayee = {(this.NormalizedPayee == null ? "null" : this.NormalizedPayee == string.Empty ? "" : this.NormalizedPayee)}");
            toStringOutput.Add($"this.InstitutionTransactionId = {(this.InstitutionTransactionId == null ? "null" : this.InstitutionTransactionId == string.Empty ? "" : this.InstitutionTransactionId)}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category == string.Empty ? "" : this.Category)}");
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"this.SecurityType = {(this.SecurityType == null ? "null" : this.SecurityType == string.Empty ? "" : this.SecurityType)}");
            toStringOutput.Add($"this.Symbol = {(this.Symbol == null ? "null" : this.Symbol == string.Empty ? "" : this.Symbol)}");
            toStringOutput.Add($"this.Commission = {(this.Commission == null ? "null" : this.Commission.ToString())}");
        }
    }
}