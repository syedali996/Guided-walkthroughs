// <copyright file="ConsumerAttributesDataDateRange.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerAttributesDataDateRange.
    /// </summary>
    public class ConsumerAttributesDataDateRange
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataDateRange"/> class.
        /// </summary>
        public ConsumerAttributesDataDateRange()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerAttributesDataDateRange"/> class.
        /// </summary>
        /// <param name="from">From.</param>
        /// <param name="to">To.</param>
        public ConsumerAttributesDataDateRange(
            DateTime from,
            DateTime to)
        {
            this.From = from;
            this.To = to;
        }

        /// <summary>
        /// A 'YYYY-MM-DD' date notation as defined by [RFC 3339, section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6)
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("From")]
        public DateTime From { get; set; }

        /// <summary>
        /// A 'YYYY-MM-DD' date notation as defined by [RFC 3339, section 5.6](https://www.rfc-editor.org/rfc/rfc3339#section-5.6)
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("To")]
        public DateTime To { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ConsumerAttributesDataDateRange : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ConsumerAttributesDataDateRange other &&
                this.From.Equals(other.From) &&
                this.To.Equals(other.To);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.From = {this.From}");
            toStringOutput.Add($"this.To = {this.To}");
        }
    }
}