// <copyright file="PortfolioWithConsumerSummary.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PortfolioWithConsumerSummary.
    /// </summary>
    public class PortfolioWithConsumerSummary
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PortfolioWithConsumerSummary"/> class.
        /// </summary>
        public PortfolioWithConsumerSummary()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PortfolioWithConsumerSummary"/> class.
        /// </summary>
        /// <param name="portfolioId">portfolioId.</param>
        /// <param name="reports">reports.</param>
        /// <param name="consumer">consumer.</param>
        public PortfolioWithConsumerSummary(
            string portfolioId,
            List<Models.PortfolioReport> reports,
            Models.PortfolioConsumer consumer)
        {
            this.PortfolioId = portfolioId;
            this.Reports = reports;
            this.Consumer = consumer;
        }

        /// <summary>
        /// A unique identifier that will be consistent across all reports created for the same customer
        /// </summary>
        [JsonProperty("portfolioId")]
        public string PortfolioId { get; set; }

        /// <summary>
        /// A list of reports in the portfolio
        /// </summary>
        [JsonProperty("reports")]
        public List<Models.PortfolioReport> Reports { get; set; }

        /// <summary>
        /// Gets or sets Consumer.
        /// </summary>
        [JsonProperty("consumer")]
        public Models.PortfolioConsumer Consumer { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PortfolioWithConsumerSummary : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PortfolioWithConsumerSummary other &&
                ((this.PortfolioId == null && other.PortfolioId == null) || (this.PortfolioId?.Equals(other.PortfolioId) == true)) &&
                ((this.Reports == null && other.Reports == null) || (this.Reports?.Equals(other.Reports) == true)) &&
                ((this.Consumer == null && other.Consumer == null) || (this.Consumer?.Equals(other.Consumer) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PortfolioId = {(this.PortfolioId == null ? "null" : this.PortfolioId == string.Empty ? "" : this.PortfolioId)}");
            toStringOutput.Add($"this.Reports = {(this.Reports == null ? "null" : $"[{string.Join(", ", this.Reports)} ]")}");
            toStringOutput.Add($"this.Consumer = {(this.Consumer == null ? "null" : this.Consumer.ToString())}");
        }
    }
}