// <copyright file="CustomerAccountPosition.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CustomerAccountPosition.
    /// </summary>
    public class CustomerAccountPosition
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccountPosition"/> class.
        /// </summary>
        public CustomerAccountPosition()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerAccountPosition"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="description">description.</param>
        /// <param name="symbol">symbol.</param>
        /// <param name="units">units.</param>
        /// <param name="currentPrice">currentPrice.</param>
        /// <param name="securityName">securityName.</param>
        /// <param name="transactionType">transactionType.</param>
        /// <param name="marketValue">marketValue.</param>
        /// <param name="costBasis">costBasis.</param>
        /// <param name="status">status.</param>
        /// <param name="currentPriceDate">currentPriceDate.</param>
        /// <param name="securityType">securityType.</param>
        /// <param name="mfType">mfType.</param>
        /// <param name="posType">posType.</param>
        /// <param name="totalGLDollar">totalGLDollar.</param>
        /// <param name="totalGLPercent">totalGLPercent.</param>
        /// <param name="optionStrikePrice">optionStrikePrice.</param>
        /// <param name="optionType">optionType.</param>
        /// <param name="optionSharesPerContract">optionSharesPerContract.</param>
        /// <param name="optionExpireDate">optionExpireDate.</param>
        /// <param name="fiAssetClass">fiAssetClass.</param>
        /// <param name="assetClass">assetClass.</param>
        /// <param name="currencyRate">currencyRate.</param>
        /// <param name="securityId">securityId.</param>
        /// <param name="securityIdType">securityIdType.</param>
        /// <param name="costBasisPerShare">costBasisPerShare.</param>
        /// <param name="subAccountType">subAccountType.</param>
        /// <param name="securityCurrency">securityCurrency.</param>
        /// <param name="todayGLDollar">todayGLDollar.</param>
        /// <param name="todayGLPercent">todayGLPercent.</param>
        public CustomerAccountPosition(
            long? id = null,
            string description = null,
            string symbol = null,
            double? units = null,
            double? currentPrice = null,
            string securityName = null,
            string transactionType = null,
            double? marketValue = null,
            double? costBasis = null,
            string status = null,
            long? currentPriceDate = null,
            string securityType = null,
            string mfType = null,
            string posType = null,
            double? totalGLDollar = null,
            double? totalGLPercent = null,
            double? optionStrikePrice = null,
            string optionType = null,
            double? optionSharesPerContract = null,
            DateTime? optionExpireDate = null,
            string fiAssetClass = null,
            string assetClass = null,
            double? currencyRate = null,
            string securityId = null,
            string securityIdType = null,
            double? costBasisPerShare = null,
            string subAccountType = null,
            string securityCurrency = null,
            double? todayGLDollar = null,
            double? todayGLPercent = null)
        {
            this.Id = id;
            this.Description = description;
            this.Symbol = symbol;
            this.Units = units;
            this.CurrentPrice = currentPrice;
            this.SecurityName = securityName;
            this.TransactionType = transactionType;
            this.MarketValue = marketValue;
            this.CostBasis = costBasis;
            this.Status = status;
            this.CurrentPriceDate = currentPriceDate;
            this.SecurityType = securityType;
            this.MfType = mfType;
            this.PosType = posType;
            this.TotalGLDollar = totalGLDollar;
            this.TotalGLPercent = totalGLPercent;
            this.OptionStrikePrice = optionStrikePrice;
            this.OptionType = optionType;
            this.OptionSharesPerContract = optionSharesPerContract;
            this.OptionExpireDate = optionExpireDate;
            this.FiAssetClass = fiAssetClass;
            this.AssetClass = assetClass;
            this.CurrencyRate = currencyRate;
            this.SecurityId = securityId;
            this.SecurityIdType = securityIdType;
            this.CostBasisPerShare = costBasisPerShare;
            this.SubAccountType = subAccountType;
            this.SecurityCurrency = securityCurrency;
            this.TodayGLDollar = todayGLDollar;
            this.TodayGLPercent = todayGLPercent;
        }

        /// <summary>
        /// The id of the investment position
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// The description of the holding
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// The investment position's market ticker symbol
        /// </summary>
        [JsonProperty("symbol", NullValueHandling = NullValueHandling.Ignore)]
        public string Symbol { get; set; }

        /// <summary>
        /// The number of units of the holding
        /// </summary>
        [JsonProperty("units", NullValueHandling = NullValueHandling.Ignore)]
        public double? Units { get; set; }

        /// <summary>
        /// The current price of the investment holding
        /// </summary>
        [JsonProperty("currentPrice", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrentPrice { get; set; }

        /// <summary>
        /// The security name for the investment holding
        /// </summary>
        [JsonProperty("securityName", NullValueHandling = NullValueHandling.Ignore)]
        public string SecurityName { get; set; }

        /// <summary>
        /// The transaction type of the holding, such as cash, margin, and more
        /// </summary>
        [JsonProperty("transactionType", NullValueHandling = NullValueHandling.Ignore)]
        public string TransactionType { get; set; }

        /// <summary>
        /// Market value of an investment position at the time of retrieval
        /// </summary>
        [JsonProperty("marketValue", NullValueHandling = NullValueHandling.Ignore)]
        public double? MarketValue { get; set; }

        /// <summary>
        /// The total cost of acquiring the security
        /// </summary>
        [JsonProperty("costBasis", NullValueHandling = NullValueHandling.Ignore)]
        public double? CostBasis { get; set; }

        /// <summary>
        /// The status of the holding
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/).
        /// </summary>
        [JsonProperty("currentPriceDate", NullValueHandling = NullValueHandling.Ignore)]
        public long? CurrentPriceDate { get; set; }

        /// <summary>
        /// Type of security for the investment position
        /// </summary>
        [JsonProperty("securityType", NullValueHandling = NullValueHandling.Ignore)]
        public string SecurityType { get; set; }

        /// <summary>
        /// Type of mutual fund, such as open ended
        /// </summary>
        [JsonProperty("mfType", NullValueHandling = NullValueHandling.Ignore)]
        public string MfType { get; set; }

        /// <summary>
        /// Fund type assigned by the FI (long or short)
        /// </summary>
        [JsonProperty("posType", NullValueHandling = NullValueHandling.Ignore)]
        public string PosType { get; set; }

        /// <summary>
        /// Total gain and loss of the position at the time of aggregation in dollars
        /// </summary>
        [JsonProperty("totalGLDollar", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalGLDollar { get; set; }

        /// <summary>
        /// Total gain and loss of the position at the time of aggregation in percentage
        /// </summary>
        [JsonProperty("totalGLPercent", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalGLPercent { get; set; }

        /// <summary>
        /// The strike price of the option contract
        /// </summary>
        [JsonProperty("optionStrikePrice", NullValueHandling = NullValueHandling.Ignore)]
        public double? OptionStrikePrice { get; set; }

        /// <summary>
        /// The type of option contract (PUT or CALL)
        /// </summary>
        [JsonProperty("optionType", NullValueHandling = NullValueHandling.Ignore)]
        public string OptionType { get; set; }

        /// <summary>
        /// The number of shares per option contract
        /// </summary>
        [JsonProperty("optionSharesPerContract", NullValueHandling = NullValueHandling.Ignore)]
        public double? OptionSharesPerContract { get; set; }

        /// <summary>
        /// Expiration date of option
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("optionExpireDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? OptionExpireDate { get; set; }

        /// <summary>
        /// Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS)
        /// </summary>
        [JsonProperty("fiAssetClass", NullValueHandling = NullValueHandling.Ignore)]
        public string FiAssetClass { get; set; }

        /// <summary>
        /// An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER)
        /// </summary>
        [JsonProperty("assetClass", NullValueHandling = NullValueHandling.Ignore)]
        public string AssetClass { get; set; }

        /// <summary>
        /// Currency rate, ratio of currency to original currency
        /// </summary>
        [JsonProperty("currencyRate", NullValueHandling = NullValueHandling.Ignore)]
        public double? CurrencyRate { get; set; }

        /// <summary>
        /// The security ID of the transaction
        /// </summary>
        [JsonProperty("securityId", NullValueHandling = NullValueHandling.Ignore)]
        public string SecurityId { get; set; }

        /// <summary>
        /// The security type. This field is related to the `securityId` field. Possible values:
        /// * "CUSIP"
        /// * "ISIN"
        /// * "SEDOL"
        /// * "SICC"
        /// * "VALOR"
        /// * "WKN"
        /// </summary>
        [JsonProperty("securityIdType", NullValueHandling = NullValueHandling.Ignore)]
        public string SecurityIdType { get; set; }

        /// <summary>
        /// The per share cost of acquiring the security
        /// </summary>
        [JsonProperty("costBasisPerShare", NullValueHandling = NullValueHandling.Ignore)]
        public double? CostBasisPerShare { get; set; }

        /// <summary>
        /// The subaccount's type, such as cash
        /// </summary>
        [JsonProperty("subAccountType", NullValueHandling = NullValueHandling.Ignore)]
        public string SubAccountType { get; set; }

        /// <summary>
        /// Symbol for the currency that the account is being converted into
        /// </summary>
        [JsonProperty("securityCurrency", NullValueHandling = NullValueHandling.Ignore)]
        public string SecurityCurrency { get; set; }

        /// <summary>
        /// The current day's gain and loss of the position at the time of aggregation in dollars
        /// </summary>
        [JsonProperty("todayGLDollar", NullValueHandling = NullValueHandling.Ignore)]
        public double? TodayGLDollar { get; set; }

        /// <summary>
        /// The current day's gain and loss of the position at the time of aggregation in percentage
        /// </summary>
        [JsonProperty("todayGLPercent", NullValueHandling = NullValueHandling.Ignore)]
        public double? TodayGLPercent { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomerAccountPosition : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CustomerAccountPosition other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Symbol == null && other.Symbol == null) || (this.Symbol?.Equals(other.Symbol) == true)) &&
                ((this.Units == null && other.Units == null) || (this.Units?.Equals(other.Units) == true)) &&
                ((this.CurrentPrice == null && other.CurrentPrice == null) || (this.CurrentPrice?.Equals(other.CurrentPrice) == true)) &&
                ((this.SecurityName == null && other.SecurityName == null) || (this.SecurityName?.Equals(other.SecurityName) == true)) &&
                ((this.TransactionType == null && other.TransactionType == null) || (this.TransactionType?.Equals(other.TransactionType) == true)) &&
                ((this.MarketValue == null && other.MarketValue == null) || (this.MarketValue?.Equals(other.MarketValue) == true)) &&
                ((this.CostBasis == null && other.CostBasis == null) || (this.CostBasis?.Equals(other.CostBasis) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.CurrentPriceDate == null && other.CurrentPriceDate == null) || (this.CurrentPriceDate?.Equals(other.CurrentPriceDate) == true)) &&
                ((this.SecurityType == null && other.SecurityType == null) || (this.SecurityType?.Equals(other.SecurityType) == true)) &&
                ((this.MfType == null && other.MfType == null) || (this.MfType?.Equals(other.MfType) == true)) &&
                ((this.PosType == null && other.PosType == null) || (this.PosType?.Equals(other.PosType) == true)) &&
                ((this.TotalGLDollar == null && other.TotalGLDollar == null) || (this.TotalGLDollar?.Equals(other.TotalGLDollar) == true)) &&
                ((this.TotalGLPercent == null && other.TotalGLPercent == null) || (this.TotalGLPercent?.Equals(other.TotalGLPercent) == true)) &&
                ((this.OptionStrikePrice == null && other.OptionStrikePrice == null) || (this.OptionStrikePrice?.Equals(other.OptionStrikePrice) == true)) &&
                ((this.OptionType == null && other.OptionType == null) || (this.OptionType?.Equals(other.OptionType) == true)) &&
                ((this.OptionSharesPerContract == null && other.OptionSharesPerContract == null) || (this.OptionSharesPerContract?.Equals(other.OptionSharesPerContract) == true)) &&
                ((this.OptionExpireDate == null && other.OptionExpireDate == null) || (this.OptionExpireDate?.Equals(other.OptionExpireDate) == true)) &&
                ((this.FiAssetClass == null && other.FiAssetClass == null) || (this.FiAssetClass?.Equals(other.FiAssetClass) == true)) &&
                ((this.AssetClass == null && other.AssetClass == null) || (this.AssetClass?.Equals(other.AssetClass) == true)) &&
                ((this.CurrencyRate == null && other.CurrencyRate == null) || (this.CurrencyRate?.Equals(other.CurrencyRate) == true)) &&
                ((this.SecurityId == null && other.SecurityId == null) || (this.SecurityId?.Equals(other.SecurityId) == true)) &&
                ((this.SecurityIdType == null && other.SecurityIdType == null) || (this.SecurityIdType?.Equals(other.SecurityIdType) == true)) &&
                ((this.CostBasisPerShare == null && other.CostBasisPerShare == null) || (this.CostBasisPerShare?.Equals(other.CostBasisPerShare) == true)) &&
                ((this.SubAccountType == null && other.SubAccountType == null) || (this.SubAccountType?.Equals(other.SubAccountType) == true)) &&
                ((this.SecurityCurrency == null && other.SecurityCurrency == null) || (this.SecurityCurrency?.Equals(other.SecurityCurrency) == true)) &&
                ((this.TodayGLDollar == null && other.TodayGLDollar == null) || (this.TodayGLDollar?.Equals(other.TodayGLDollar) == true)) &&
                ((this.TodayGLPercent == null && other.TodayGLPercent == null) || (this.TodayGLPercent?.Equals(other.TodayGLPercent) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Symbol = {(this.Symbol == null ? "null" : this.Symbol == string.Empty ? "" : this.Symbol)}");
            toStringOutput.Add($"this.Units = {(this.Units == null ? "null" : this.Units.ToString())}");
            toStringOutput.Add($"this.CurrentPrice = {(this.CurrentPrice == null ? "null" : this.CurrentPrice.ToString())}");
            toStringOutput.Add($"this.SecurityName = {(this.SecurityName == null ? "null" : this.SecurityName == string.Empty ? "" : this.SecurityName)}");
            toStringOutput.Add($"this.TransactionType = {(this.TransactionType == null ? "null" : this.TransactionType == string.Empty ? "" : this.TransactionType)}");
            toStringOutput.Add($"this.MarketValue = {(this.MarketValue == null ? "null" : this.MarketValue.ToString())}");
            toStringOutput.Add($"this.CostBasis = {(this.CostBasis == null ? "null" : this.CostBasis.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.CurrentPriceDate = {(this.CurrentPriceDate == null ? "null" : this.CurrentPriceDate.ToString())}");
            toStringOutput.Add($"this.SecurityType = {(this.SecurityType == null ? "null" : this.SecurityType == string.Empty ? "" : this.SecurityType)}");
            toStringOutput.Add($"this.MfType = {(this.MfType == null ? "null" : this.MfType == string.Empty ? "" : this.MfType)}");
            toStringOutput.Add($"this.PosType = {(this.PosType == null ? "null" : this.PosType == string.Empty ? "" : this.PosType)}");
            toStringOutput.Add($"this.TotalGLDollar = {(this.TotalGLDollar == null ? "null" : this.TotalGLDollar.ToString())}");
            toStringOutput.Add($"this.TotalGLPercent = {(this.TotalGLPercent == null ? "null" : this.TotalGLPercent.ToString())}");
            toStringOutput.Add($"this.OptionStrikePrice = {(this.OptionStrikePrice == null ? "null" : this.OptionStrikePrice.ToString())}");
            toStringOutput.Add($"this.OptionType = {(this.OptionType == null ? "null" : this.OptionType == string.Empty ? "" : this.OptionType)}");
            toStringOutput.Add($"this.OptionSharesPerContract = {(this.OptionSharesPerContract == null ? "null" : this.OptionSharesPerContract.ToString())}");
            toStringOutput.Add($"this.OptionExpireDate = {(this.OptionExpireDate == null ? "null" : this.OptionExpireDate.ToString())}");
            toStringOutput.Add($"this.FiAssetClass = {(this.FiAssetClass == null ? "null" : this.FiAssetClass == string.Empty ? "" : this.FiAssetClass)}");
            toStringOutput.Add($"this.AssetClass = {(this.AssetClass == null ? "null" : this.AssetClass == string.Empty ? "" : this.AssetClass)}");
            toStringOutput.Add($"this.CurrencyRate = {(this.CurrencyRate == null ? "null" : this.CurrencyRate.ToString())}");
            toStringOutput.Add($"this.SecurityId = {(this.SecurityId == null ? "null" : this.SecurityId == string.Empty ? "" : this.SecurityId)}");
            toStringOutput.Add($"this.SecurityIdType = {(this.SecurityIdType == null ? "null" : this.SecurityIdType == string.Empty ? "" : this.SecurityIdType)}");
            toStringOutput.Add($"this.CostBasisPerShare = {(this.CostBasisPerShare == null ? "null" : this.CostBasisPerShare.ToString())}");
            toStringOutput.Add($"this.SubAccountType = {(this.SubAccountType == null ? "null" : this.SubAccountType == string.Empty ? "" : this.SubAccountType)}");
            toStringOutput.Add($"this.SecurityCurrency = {(this.SecurityCurrency == null ? "null" : this.SecurityCurrency == string.Empty ? "" : this.SecurityCurrency)}");
            toStringOutput.Add($"this.TodayGLDollar = {(this.TodayGLDollar == null ? "null" : this.TodayGLDollar.ToString())}");
            toStringOutput.Add($"this.TodayGLPercent = {(this.TodayGLPercent == null ? "null" : this.TodayGLPercent.ToString())}");
        }
    }
}