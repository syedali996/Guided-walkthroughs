// <copyright file="CustomHeaderAuthenticationManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard.Authentication
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using FinicityAPIs.Standard.Http.Request;
    using APIMatic.Core.Authentication;

    /// <summary>
    /// CustomHeaderAuthenticationManager Class.
    /// </summary>
    internal class CustomHeaderAuthenticationManager : AuthManager, ICustomHeaderAuthenticationCredentials
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomHeaderAuthenticationManager"/> class.
        /// </summary>
        /// <param name="finicityAppKey">Finicity-App-Key.</param>
        /// <param name="finicityAppToken">Finicity-App-Token.</param>
        public CustomHeaderAuthenticationManager(string finicityAppKey, string finicityAppToken)
        {
            this.FinicityAppKey = finicityAppKey;
            this.FinicityAppToken = finicityAppToken;
            Parameters(paramBuilder => paramBuilder
                .Header(header => header.Setup("Finicity-App-Key", FinicityAppKey))
                .Header(header => header.Setup("Finicity-App-Token", FinicityAppToken))
            );
        }

        /// <summary>
        /// Gets string value for finicityAppKey.
        /// </summary>
        public string FinicityAppKey { get; }

        /// <summary>
        /// Gets string value for finicityAppToken.
        /// </summary>
        public string FinicityAppToken { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="finicityAppKey"> The string value for credentials.</param>
        /// <param name="finicityAppToken"> The string value for credentials.</param>
        /// <returns> True if credentials matched.</returns>
        public bool Equals(string finicityAppKey, string finicityAppToken)
        {
            return finicityAppKey.Equals(this.FinicityAppKey)
                    && finicityAppToken.Equals(this.FinicityAppToken);
        }
    }
}