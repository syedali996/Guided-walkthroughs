// <copyright file="FinicityAPIsClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using APIMatic.Core;
    using APIMatic.Core.Authentication;
    using APIMatic.Core.Types;
    using FinicityAPIs.Standard.Authentication;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class FinicityAPIsClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Enum, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Enum, string>>
        {
            {
                Environment.Production, new Dictionary<Enum, string>
                {
                    { Server.Default, "https://api.finicity.com" },
                }
            },
        };

        private readonly GlobalConfiguration globalConfiguration;
        private const string userAgent = "APIMATIC 3.0";
        private readonly HttpCallBack httpCallBack;
        private readonly CustomHeaderAuthenticationManager customHeaderAuthenticationManager;
        private readonly Lazy<AccountsController> accounts;
        private readonly Lazy<AnalyticsAndAttributesController> analyticsAndAttributes;
        private readonly Lazy<AppRegistrationController> appRegistration;
        private readonly Lazy<AssetsController> assets;
        private readonly Lazy<AuthenticationController> authentication;
        private readonly Lazy<BalanceAnalyticsController> balanceAnalytics;
        private readonly Lazy<BankStatementsController> bankStatements;
        private readonly Lazy<CashFlowController> cashFlow;
        private readonly Lazy<CashFlowAnalyticsController> cashFlowAnalytics;
        private readonly Lazy<ConnectController> connect;
        private readonly Lazy<ConsumersController> consumers;
        private readonly Lazy<CustomersController> customers;
        private readonly Lazy<InstitutionsController> institutions;
        private readonly Lazy<PayStatementsController> payStatements;
        private readonly Lazy<PaymentsController> payments;
        private readonly Lazy<PortfoliosController> portfolios;
        private readonly Lazy<ReportsController> reports;
        private readonly Lazy<TransactionsController> transactions;
        private readonly Lazy<TxPushController> txPush;
        private readonly Lazy<VerifyAssetsController> verifyAssets;
        private readonly Lazy<VerifyIncomeAndEmploymentController> verifyIncomeAndEmployment;

        private FinicityAPIsClient(
            Environment environment,
            string finicityAppKey,
            string finicityAppToken,
            HttpCallBack httpCallBack,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.httpCallBack = httpCallBack;
            this.HttpClientConfiguration = httpClientConfiguration;
            customHeaderAuthenticationManager = new CustomHeaderAuthenticationManager(finicityAppKey, finicityAppToken);
            globalConfiguration = new GlobalConfiguration.Builder()
                .AuthManagers(new Dictionary<string, AuthManager> {
                        {"global", customHeaderAuthenticationManager}
                })
                .ApiCallback(httpCallBack)
                .HttpConfiguration(httpClientConfiguration)
                .ServerUrls(EnvironmentsMap[environment], Server.Default)
                .UserAgent(userAgent)
                .Build();


            this.accounts = new Lazy<AccountsController>(
                () => new AccountsController(globalConfiguration));
            this.analyticsAndAttributes = new Lazy<AnalyticsAndAttributesController>(
                () => new AnalyticsAndAttributesController(globalConfiguration));
            this.appRegistration = new Lazy<AppRegistrationController>(
                () => new AppRegistrationController(globalConfiguration));
            this.assets = new Lazy<AssetsController>(
                () => new AssetsController(globalConfiguration));
            this.authentication = new Lazy<AuthenticationController>(
                () => new AuthenticationController(globalConfiguration));
            this.balanceAnalytics = new Lazy<BalanceAnalyticsController>(
                () => new BalanceAnalyticsController(globalConfiguration));
            this.bankStatements = new Lazy<BankStatementsController>(
                () => new BankStatementsController(globalConfiguration));
            this.cashFlow = new Lazy<CashFlowController>(
                () => new CashFlowController(globalConfiguration));
            this.cashFlowAnalytics = new Lazy<CashFlowAnalyticsController>(
                () => new CashFlowAnalyticsController(globalConfiguration));
            this.connect = new Lazy<ConnectController>(
                () => new ConnectController(globalConfiguration));
            this.consumers = new Lazy<ConsumersController>(
                () => new ConsumersController(globalConfiguration));
            this.customers = new Lazy<CustomersController>(
                () => new CustomersController(globalConfiguration));
            this.institutions = new Lazy<InstitutionsController>(
                () => new InstitutionsController(globalConfiguration));
            this.payStatements = new Lazy<PayStatementsController>(
                () => new PayStatementsController(globalConfiguration));
            this.payments = new Lazy<PaymentsController>(
                () => new PaymentsController(globalConfiguration));
            this.portfolios = new Lazy<PortfoliosController>(
                () => new PortfoliosController(globalConfiguration));
            this.reports = new Lazy<ReportsController>(
                () => new ReportsController(globalConfiguration));
            this.transactions = new Lazy<TransactionsController>(
                () => new TransactionsController(globalConfiguration));
            this.txPush = new Lazy<TxPushController>(
                () => new TxPushController(globalConfiguration));
            this.verifyAssets = new Lazy<VerifyAssetsController>(
                () => new VerifyAssetsController(globalConfiguration));
            this.verifyIncomeAndEmployment = new Lazy<VerifyIncomeAndEmploymentController>(
                () => new VerifyIncomeAndEmploymentController(globalConfiguration));
        }

        /// <summary>
        /// Gets AccountsController controller.
        /// </summary>
        public AccountsController AccountsController => this.accounts.Value;

        /// <summary>
        /// Gets AnalyticsAndAttributesController controller.
        /// </summary>
        public AnalyticsAndAttributesController AnalyticsAndAttributesController => this.analyticsAndAttributes.Value;

        /// <summary>
        /// Gets AppRegistrationController controller.
        /// </summary>
        public AppRegistrationController AppRegistrationController => this.appRegistration.Value;

        /// <summary>
        /// Gets AssetsController controller.
        /// </summary>
        public AssetsController AssetsController => this.assets.Value;

        /// <summary>
        /// Gets AuthenticationController controller.
        /// </summary>
        public AuthenticationController AuthenticationController => this.authentication.Value;

        /// <summary>
        /// Gets BalanceAnalyticsController controller.
        /// </summary>
        public BalanceAnalyticsController BalanceAnalyticsController => this.balanceAnalytics.Value;

        /// <summary>
        /// Gets BankStatementsController controller.
        /// </summary>
        public BankStatementsController BankStatementsController => this.bankStatements.Value;

        /// <summary>
        /// Gets CashFlowController controller.
        /// </summary>
        public CashFlowController CashFlowController => this.cashFlow.Value;

        /// <summary>
        /// Gets CashFlowAnalyticsController controller.
        /// </summary>
        public CashFlowAnalyticsController CashFlowAnalyticsController => this.cashFlowAnalytics.Value;

        /// <summary>
        /// Gets ConnectController controller.
        /// </summary>
        public ConnectController ConnectController => this.connect.Value;

        /// <summary>
        /// Gets ConsumersController controller.
        /// </summary>
        public ConsumersController ConsumersController => this.consumers.Value;

        /// <summary>
        /// Gets CustomersController controller.
        /// </summary>
        public CustomersController CustomersController => this.customers.Value;

        /// <summary>
        /// Gets InstitutionsController controller.
        /// </summary>
        public InstitutionsController InstitutionsController => this.institutions.Value;

        /// <summary>
        /// Gets PayStatementsController controller.
        /// </summary>
        public PayStatementsController PayStatementsController => this.payStatements.Value;

        /// <summary>
        /// Gets PaymentsController controller.
        /// </summary>
        public PaymentsController PaymentsController => this.payments.Value;

        /// <summary>
        /// Gets PortfoliosController controller.
        /// </summary>
        public PortfoliosController PortfoliosController => this.portfolios.Value;

        /// <summary>
        /// Gets ReportsController controller.
        /// </summary>
        public ReportsController ReportsController => this.reports.Value;

        /// <summary>
        /// Gets TransactionsController controller.
        /// </summary>
        public TransactionsController TransactionsController => this.transactions.Value;

        /// <summary>
        /// Gets TxPushController controller.
        /// </summary>
        public TxPushController TxPushController => this.txPush.Value;

        /// <summary>
        /// Gets VerifyAssetsController controller.
        /// </summary>
        public VerifyAssetsController VerifyAssetsController => this.verifyAssets.Value;

        /// <summary>
        /// Gets VerifyIncomeAndEmploymentController controller.
        /// </summary>
        public VerifyIncomeAndEmploymentController VerifyIncomeAndEmploymentController => this.verifyIncomeAndEmployment.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets http callback.
        /// </summary>
        internal HttpCallBack HttpCallBack => this.httpCallBack;

        /// <summary>
        /// Gets the credentials to use with CustomHeaderAuthentication.
        /// </summary>
        public ICustomHeaderAuthenticationCredentials CustomHeaderAuthenticationCredentials => this.customHeaderAuthenticationManager;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            return globalConfiguration.ServerUrl(alias);
        }

        /// <summary>
        /// Creates an object of the FinicityAPIsClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .CustomHeaderAuthenticationCredentials(customHeaderAuthenticationManager.FinicityAppKey, customHeaderAuthenticationManager.FinicityAppToken)
                .HttpCallBack(httpCallBack)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> FinicityAPIsClient.</returns>
        internal static FinicityAPIsClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("FINICITY_AP_IS_STANDARD_ENVIRONMENT");
            string finicityAppKey = System.Environment.GetEnvironmentVariable("FINICITY_AP_IS_STANDARD_FINICITY_APP_KEY");
            string finicityAppToken = System.Environment.GetEnvironmentVariable("FINICITY_AP_IS_STANDARD_FINICITY_APP_TOKEN");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (finicityAppKey != null && finicityAppToken != null)
            {
                builder.CustomHeaderAuthenticationCredentials(finicityAppKey, finicityAppToken);
            }

            return builder.Build();
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = FinicityAPIs.Standard.Environment.Production;
            private string finicityAppKey = "";
            private string finicityAppToken = "";
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private HttpCallBack httpCallBack;

            /// <summary>
            /// Sets credentials for CustomHeaderAuthentication.
            /// </summary>
            /// <param name="finicityAppKey">FinicityAppKey.</param>
            /// <param name="finicityAppToken">FinicityAppToken.</param>
            /// <returns>Builder.</returns>
            public Builder CustomHeaderAuthenticationCredentials(string finicityAppKey, string finicityAppToken)
            {
                this.finicityAppKey = finicityAppKey ?? throw new ArgumentNullException(nameof(finicityAppKey));
                this.finicityAppToken = finicityAppToken ?? throw new ArgumentNullException(nameof(finicityAppToken));
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

           

            /// <summary>
            /// Sets the HttpCallBack for the Builder.
            /// </summary>
            /// <param name="httpCallBack"> http callback. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpCallBack(HttpCallBack httpCallBack)
            {
                this.httpCallBack = httpCallBack;
                return this;
            }

            /// <summary>
            /// Creates an object of the FinicityAPIsClient using the values provided for the builder.
            /// </summary>
            /// <returns>FinicityAPIsClient.</returns>
            public FinicityAPIsClient Build()
            {

                return new FinicityAPIsClient(
                    environment,
                    finicityAppKey,
                    finicityAppToken,
                    httpCallBack,
                    httpClientConfig.Build());
            }
        }
    }
}
