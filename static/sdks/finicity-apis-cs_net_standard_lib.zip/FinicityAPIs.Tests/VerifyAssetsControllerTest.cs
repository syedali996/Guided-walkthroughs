// <copyright file="VerifyAssetsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// VerifyAssetsControllerTest.
    /// </summary>
    [TestFixture]
    public class VerifyAssetsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private VerifyAssetsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.VerifyAssetsController;
        }

        /// <summary>
        /// Generate a Verification of Assets (VOA) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to twelve months of transaction history for each account and uses this information to generate the VOA report.
        ///
        ///This is a premium service. The billing rate is the variable rate for Verification of Assets under the current subscription plan. The billable event is the successful generation of a VOA report.
        ///
        ///Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        ///
        ///If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOAReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.VOAReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.VOAReportConstraints>("{\"accountIds\":\"1000535275\",\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false,\"fromDate\":1580558400}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.VOAReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOAReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"u4hstnnak45g\",\"portfolioId\":\"dyr6qvqd2yhb-1-port\",\"customerType\":\"active\",\"customerId\":1000006677,\"requestId\":\"sfb7xp439w\",\"requesterName\":\"Decisioning API\",\"createdDate\":1588350269,\"title\":\"Finicity Verification of Assets\",\"consumerId\":\"ac39e237c7619a4ecf014b8d399c0696\",\"consumerSsn\":\"6789\",\"constraints\":{\"accountIds\":[\"1000535275\",\"1000535276\"],\"fromDate\":1577986990,\"showNsf\":false,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]},\"type\":\"voa\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Generate a Verification of Assets with Income (VOAI) report for all checking, savings, money market, and investment accounts for the given customer. This service retrieves up to 24 months of transaction history for each account and uses this information to generate the VOAI report. The report includes 1 - 6 months of all debit and credit transactions for asset verification. By default, the history is set to 61 days, however, you can change the transaction history in this section by setting the `fromDate` parameter. The report also includes up to 24 months of income credit transactions (ordered by account and confidence level) regardless of `fromDate` for income verification.
        ///
        ///This is a premium service. The billable event is the successful generation of a VOAI report.
        ///
        ///Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        ///
        ///If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOAWithIncomeReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.VOAWithIncomeReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.VOAWithIncomeReportConstraints>("{\"accountIds\":\"1000535275\",\"fromDate\":1580558400,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false,\"incomeStreamConfidenceMinimum\":50}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.VOAWithIncomeReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOAWithIncomeReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"u4hstnyak45g\",\"portfolioId\":\"dyr6weqd2yhb-1-port\",\"customerType\":\"active\",\"customerId\":1000006677,\"requestId\":\"sfb7x1we9w\",\"requesterName\":\"Decisioning API\",\"createdDate\":1588350269,\"title\":\"Verification of Asset and Income - Transactions\",\"consumerId\":\"ac39e237c7619a4ecf014b8d399c0696\",\"consumerSsn\":\"6789\",\"constraints\":{\"accountIds\":[\"1000535275\"],\"fromDate\":1580558400,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false,\"incomeStreamConfidenceMinimum\":50},\"type\":\"voaHistory\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Retrieve all checking, savings, money market, and investment accounts for a consumer. The account, owner information, and the number of insufficient funds (NSFs) for checking accounts are also provided.
        ///
        ///If no account of type checking, savings, money market, or investment is found, the service will return HTTP 400 Bad Request.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGeneratePrequalificationCRAReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.PrequalificationReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.PrequalificationReportConstraints>("{\"accountIds\":\"1000535275\",\"fromDate\":1580558400,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.PrequalificationReportAck result = null;
            try
            {
                result = await this.controller.GeneratePrequalificationCRAReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"88w4fbssrbja-prequalvoa\",\"portfolioId\":\"0whcism47a34-5-port\",\"customerType\":\"active\",\"customerId\":1000006677,\"requestId\":\"sfb7xacr9w\",\"requesterName\":\"Decisioning API\",\"createdDate\":1588350269,\"title\":\"Asset Ready Report (CRA)\",\"consumerId\":\"cb619e10185177cd92271c4da2df3fa3\",\"consumerSsn\":\"6789\",\"constraints\":{\"accountIds\":[\"1000535275\",\"1000535276\"],\"fromDate\":1577986990,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false},\"type\":\"preQualVoa\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}