// <copyright file="TxPushControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// TxPushControllerTest.
    /// </summary>
    [TestFixture]
    public class TxPushControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private TxPushController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.TxPushController;
        }

        /// <summary>
        /// Delete all TxPush subscriptions with their notifications for the given account. No more notifications will be sent for account or transaction events.
        ///
        ///For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDisableTxPushNotifications()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            try
            {
                await this.controller.DisableTxPushNotificationsAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(204, HttpCallBack.Response.StatusCode, "Status should be 204");
        }

        /// <summary>
        /// Delete a specific subscription to TxPush notifications for the given account. This could be individual deleting the account or transactions events. No more events will be sent for that specific subscription.
        ///
        ///For additional details on this process, see [TxPush Listener Service](https://docs.finicity.com/txpush-listener-service/).
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestDeleteTxPushSubscription()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            long subscriptionId = 17554874;

            // Perform API call
            try
            {
                await this.controller.DeleteTxPushSubscriptionAsync(customerId, subscriptionId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(204, HttpCallBack.Response.StatusCode, "Status should be 204");
        }
    }
}