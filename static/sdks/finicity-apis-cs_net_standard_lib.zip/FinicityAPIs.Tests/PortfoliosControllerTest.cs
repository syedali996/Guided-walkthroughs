// <copyright file="PortfoliosControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// PortfoliosControllerTest.
    /// </summary>
    [TestFixture]
    public class PortfoliosControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PortfoliosController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PortfoliosController;
        }

        /// <summary>
        /// Return a portfolio of most recently generated reports for each report type for the given customer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)
        ///.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetPortfolioByCustomer()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string portfolioId = "y4zsgccj4xpw-6-port";

            // Perform API call
            Standard.Models.PortfolioSummary result = null;
            try
            {
                result = await this.controller.GetPortfolioByCustomerAsync(customerId, portfolioId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Return a portfolio of most recently generated reports for each report type for a given consumer. If there are multiple reports that were generated for a report type (VOA, VOI, etc.), only the most recently generated report for the type will be returned.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetPortfolioByConsumer()
        {
            // Parameters for the API call
            string consumerId = "0bf46322c167b562e6cbed9d40e19a4c";
            string portfolioId = "y4zsgccj4xpw-6-port";

            // Perform API call
            Standard.Models.PortfolioWithConsumerSummary result = null;
            try
            {
                result = await this.controller.GetPortfolioByConsumerAsync(consumerId, portfolioId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}