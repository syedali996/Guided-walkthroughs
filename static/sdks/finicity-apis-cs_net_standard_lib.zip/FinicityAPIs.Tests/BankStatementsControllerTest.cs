// <copyright file="BankStatementsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// BankStatementsControllerTest.
    /// </summary>
    [TestFixture]
    public class BankStatementsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private BankStatementsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.BankStatementsController;
        }

        /// <summary>
        /// Retrieve the customer's bank statements in PDF format. Up to 24 months of history is available depending on the financial institution. Since this is a premium service, charges incur per each successful statement retrieved. 
        ///
        ///For certified financial institutions, statements are available for the following account types:
        ///* Checking
        ///* Savings
        ///* Money market
        ///* CDs
        ///* Investments
        ///* Mortgage
        ///* Credit cards
        ///* Loans
        ///* Line of credit
        ///* Student Loans
        ///
        ///Note: setting the timeout to 180 seconds is recommended to allow enough time for a response.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetCustomerAccountStatement()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";
            int? index = 1;
            string type = "taxStatement";

            // Perform API call
            Stream result = null;
            try
            {
                result = await this.controller.GetCustomerAccountStatementAsync(customerId, accountId, index, type);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/octet-stream");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve the customer's bank statements in PDF format. Up to 24 months of history is available depending on the financial institution. Since this is a premium service, charges incur per each successful statement retrieved. 
        ///
        ///For certified financial institutions, statements are available for the following account types:
        ///* Checking
        ///* Savings
        ///* Money market
        ///* CDs
        ///* Investments
        ///* Mortgage
        ///* Credit cards
        ///* Loans
        ///* Line of credit
        ///* Student Loans
        ///
        ///Note: setting the timeout to 180 seconds is recommended to allow enough time for a response.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetCustomerAccountStatement1()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";
            int? index = 1;
            string type = "taxStatement";

            // Perform API call
            Stream result = null;
            try
            {
                result = await this.controller.GetCustomerAccountStatementAsync(customerId, accountId, index, type);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(203, HttpCallBack.Response.StatusCode, "Status should be 203");
        }

        /// <summary>
        /// Generate a Statement Report report for the given accounts under the given customer.
        ///
        ///This is a premium service. A billable event will be created upon the successful generation of the Statement Report. 
        ///
        ///Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateStatementReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.StatementReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.StatementReportConstraints>("{\"statementReportData\":{\"accountId\":1000076901,\"index\":1},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"123456\",\"shown\":true}]}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.StatementReportAck result = null;
            try
            {
                result = await this.controller.GenerateStatementReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"38dknche83oh-statement\",\"portfolioId\":\"sy7aa68w2ugx-1-port\",\"customerType\":\"active\",\"customerId\":1010560999,\"requestId\":\"ny7x32stfq\",\"requesterName\":\"Demo\",\"createdDate\":1596226182,\"title\":\"Finicity Statement Report\",\"consumerId\":\"555595ec74c8ec57adf44dadddb6a35\",\"consumerSsn\":\"1234\",\"constraints\":{\"statementReportData\":{\"accountId\":1000076901,\"index\":1},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"123456\",\"shown\":true}]},\"type\":\"statement\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}