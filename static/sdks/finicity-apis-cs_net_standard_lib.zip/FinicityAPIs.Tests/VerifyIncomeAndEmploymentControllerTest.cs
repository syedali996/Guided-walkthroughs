// <copyright file="VerifyIncomeAndEmploymentControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// VerifyIncomeAndEmploymentControllerTest.
    /// </summary>
    [TestFixture]
    public class VerifyIncomeAndEmploymentControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private VerifyIncomeAndEmploymentController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.VerifyIncomeAndEmploymentController;
        }

        /// <summary>
        /// Generate a Verification of Income (VOI) report for all checking, savings, and money market accounts for the given customer. This service retrieves up to two years of transaction history for each account and uses this information to generate the VOI report.
        ///
        ///This is a premium service. The billing rate is the variable rate for Verification of Income under the current subscription plan. The billable event is the successful generation of a VOI report.
        ///
        ///If no account of type checking, savings, or money market is found, the service will return HTTP 400 Bad Request.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOIReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.VOIReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.VOIReportConstraints>("{\"accountIds\":\"1000535275 1000535276\",\"fromDate\":1577986990,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"incomeStreamConfidenceMinimum\":50}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.VOIReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOIReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"u4hstnnaewetr-voi\",\"portfolioId\":\"dyr6qvqd2erw-1-port\",\"customerType\":\"active\",\"customerId\":1000006677,\"requestId\":\"sfb7xp4wer\",\"requesterName\":\"Decisioning API\",\"createdDate\":1588350269,\"title\":\"Finicity Verification of Income\",\"consumerId\":\"ac39e237c7619a4ecf014b8d399c0696\",\"consumerSsn\":\"6789\",\"constraints\":{\"accountIds\":[\"1000535275\",\"1000535276\"],\"fromDate\":1577986990,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]},\"type\":\"voi\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Premium Service: A billable event when the API response is successful. 
        ///
        ///MVS Implementation Options: Direct API Integration.
        ///
        ///Used as a complementary report to the VOIE-Payroll report. This report is used to fulfill the pre-close VOE requirements. It retrieves the customer's employment details and employment status through the payroll source without any income information. 
        ///
        ///To generate this report, pass the values from the customer SSN, DOB, and the report ID from the first VOIE-Payroll report generated after the Connect session.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOEPayrollReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.PayrollReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.PayrollReportConstraints>("{\"payrollData\":{\"ssn\":\"999990000\",\"dob\":315576000,\"reportId\":\"abcdefghijkl-voiepayroll\"},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true}],\"payStatementsFromDate\":1580558400,\"marketSegment\":\"Mortgage\",\"excludeEmpInfo\":true,\"purpose\":\"99\"}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.PayrollReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOEPayrollReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"41h4nzppn47u-voepayroll\",\"portfolioId\":\"9qud7dtuzbew-3-port\",\"customerType\":\"active\",\"customerId\":1011140000,\"requestId\":\"7a7qyps2iy\",\"requesterName\":\"Decisioning API\",\"createdDate\":1579819592,\"title\":\"Finicity Verification of Employment - Payroll\",\"consumerId\":\"656cf7083c5c06e0c125a698579f0000\",\"consumerSsn\":\"6789\",\"constraints\":{\"payrollData\":{\"payrollDataRetrievalId\":\"hahvhe2k0000\",\"employerNames\":[\"ACME INC\"],\"reportId\":\"abcdefghijkl-voiepayroll\"},\"payStatementsFromDate\":1580558400,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true}]},\"type\":\"voePayroll\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Premium Service: A billable event when the API response is successful.
        ///
        ///MVS-Direct integration developers only.
        ///
        ///Used as a complimentary report to the VOA with Income and VOIE - Paystub (with TXVerify) reports and used to fulfill the pre-close VOE requirements. 
        ///
        ///Retrieve the latest credit transaction information from the borrower's connected bank accounts and groups them into income streams so that you can view their payment history to ensure a direct deport was made within the expected cadence. The report displays transaction descriptions without any dollar amounts so that income re-verification isn't necessary.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOETransactionsReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.VOETransactionsReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.VOETransactionsReportConstraints>("{\"reportId\":\"j7k8qbgwsa7d-voietxverify\",\"accountIds\":\"123456789\",\"fromDate\":1580558400,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"incomeStreamConfidenceMinimum\":50}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.VOETransactionsReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOETransactionsReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"u4hstny1k25g-voetransactions\",\"portfolioId\":\"dyr6weqd2yhb-2-port\",\"customerType\":\"active\",\"customerId\":1000006677,\"requestId\":\"sfb7x1we9w\",\"requesterName\":\"Decisioning API\",\"createdDate\":1588350269,\"title\":\"Finicity Verification Employment - Transactions\",\"consumerId\":\"ac39e237c7619a4ecf014b8d399c0696\",\"consumerSsn\":\"6789\",\"constraints\":{\"reportId\":\"j7k8qbgwsa7d-voietxverify\",\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]},\"type\":\"voeTransactions\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Generate Pay Statement Extraction Report for the given customer. This service accepts asset IDs of the stored pay statements to generate a Pay Statement Extraction Report. 
        ///
        ///This is a premium service. The billing rate is the variable rate for Pay Statement Extraction Report under the current subscription plan. The billable event is the successful generation of a Pay Statement Extraction Report.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGeneratePayStatementReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.PayStatementReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.PayStatementReportConstraints>("{\"paystatementReport\":{\"assetIds\":[\"6f8fb0a0-e882-4f57-b672-cf53f1397581\"],\"extractEarnings\":true,\"extractDeductions\":false,\"extractDirectDeposit\":true},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.PayStatementReportAck result = null;
            try
            {
                result = await this.controller.GeneratePayStatementReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"y0ejausptjg1-paystatement\",\"portfolioId\":\"spd8aehuw63i-10-port\",\"customerType\":\"active\",\"customerId\":1003413624,\"requestId\":\"8wy5htqg8u\",\"requesterName\":\"Decisioning API\",\"createdDate\":1588350269,\"title\":\"Finicity Pay Statement Extraction Report\",\"consumerId\":\"4089f408963dd6b90b28a935e9903c0e\",\"consumerSsn\":\"6789\",\"constraints\":{\"paystatementReport\":{\"assetIds\":[\"6f8fb0a0-e882-4f57-b672-cf53f1397581\"],\"extractEarnings\":true,\"extractDeductions\":false,\"extractDirectDeposit\":true},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]},\"type\":\"paystatement\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Generate a VOIE - Paystub (with TXVerify) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given accounts. It then uses this information as well as the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub (with TXVerify) report.
        ///
        ///Note: if you are using this API to refresh the bank transactions, use the same asset ID from the first report. A new paystub is not required unless the paystub is too old for underwriting requirements. Using the same asset ID that was on the original report and the previously extracted details will be used to speed up report generation response time.
        ///
        ///This is a premium service. The billing rate is the variable rate for VOIE TXVerify under the current subscription plan. The billable event is the successful generation of a VOIE TXVerify Report.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOIEPaystubWithTXVerifyReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.VOIEWithTXVerifyReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.VOIEWithTXVerifyReportConstraints>("{\"accountIds\":\"1028361677\",\"voieWithInterviewData\":{\"txVerifyInterview\":[{\"assetId\":\"7eb57060-6d98-4449-992d-4dd4490448f3-1236011097\"}]},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"123456\",\"shown\":true}]}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.VOIEPaystubWithTXVerifyReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOIEPaystubWithTXVerifyReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"2f3z55zuwewm-voietxverify\",\"customerId\":1275320,\"consumerId\":\"3f7ff2cf0ffb3d0cd59875e070c9b1d4\",\"consumerSsn\":\"6789\",\"requesterName\":\"Decisioning API\",\"requestId\":\"7a7qyps2iy\",\"type\":\"voieTxVerify\",\"status\":\"inProgress\",\"createdDate\":1579819592,\"constraints\":{\"accountIds\":[\"1000535275\"],\"voieWithInterviewData\":{\"txVerifyInterview\":[{\"assetId\":\"6f8fb0a0-e882-4f57-b672-cf53f1397581\",\"accounts\":[]}],\"extractEarnings\":true,\"extractDeductions\":false,\"extractDirectDeposit\":true},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"123456\",\"shown\":true}]},\"customerType\":\"active\",\"title\":\"Finicity Verification of Income and Employment - Paystub (with TXVerify)\",\"portfolioId\":\"9qud7dtuzbew-2-port\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Generate a VOIE - Paystub report. This service uses the provided paystub(s), which are passed into the request body as asset IDs (generated using the Store Customer Pay Statement API) to generate the VOIE - Paystub report with digitized paystub details.
        ///
        ///This is a premium service. The billing rate is the variable rate for VOIE - Paystub under the current subscription plan. The billable event is the successful generation of a VOIE - Paystub Report.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateVOIEPaystubReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.VOIEReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.VOIEReportConstraints>("{\"voieWithStatementData\":{\"assetIds\":[\"d50ed92f-543b-431c-8286-c8b8f6556679\"]},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"123456\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true}]}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.VOIEPaystubReportAck result = null;
            try
            {
                result = await this.controller.GenerateVOIEPaystubReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"2f3z55zuwewm-voietxverify\",\"portfolioId\":\"9qud7dtuzbew-13-port\",\"customerType\":\"active\",\"customerId\":1275320,\"requestId\":\"7a7qyps2iy\",\"requesterName\":\"Decisioning API\",\"createdDate\":1579819592,\"title\":\"Verification of Income and Employment - Paystub\",\"consumerId\":\"3f7ff2cf0ffb3d0cd59875e070c9b1d4\",\"consumerSsn\":\"6789\",\"constraints\":{\"voieWithStatementData\":{\"assetIds\":[\"d50ed92f-543b-431c-8286-c8b8f6556679\"],\"extractEarnings\":true,\"extractDeductions\":false,\"extractDirectDeposit\":true},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"123456\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true}]},\"type\":\"voieTxVerify\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// The VOIE – Payroll report generates when the customer completes Connect. Lenders, who commonly use this report for pre-close verification employment check, can refresh this report by passing the consumer's SSN, DOB, and the report ID from the first VOIE – Payroll report they received.
        ///
        ///We'll refresh this report and update any new pay histories since the first report generated, including borrower's employment status as active or not.
        ///
        ///Note: lenders can only refresh this report one time in a 60-day period starting from the date of the first report. Any further report refreshes will incur additional charges.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestRefreshVOIEPayrollReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.PayrollReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.PayrollReportConstraints>("{\"payrollData\":{\"ssn\":\"999990000\",\"dob\":315576000,\"reportId\":\"abcdefghijkl-voiepayroll\"},\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true}],\"payStatementsFromDate\":1580558400,\"marketSegment\":\"Mortgage\",\"excludeEmpInfo\":true,\"purpose\":\"99\"}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.PayrollReportAck result = null;
            try
            {
                result = await this.controller.RefreshVOIEPayrollReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"123456789012-voiepayroll\",\"customerId\":1011140000,\"consumerId\":\"656cf7083c5c06e0c125a698579f0000\",\"consumerSsn\":\"6789\",\"requesterName\":\"Decisioning API\",\"requestId\":\"7a7qyps2iy\",\"type\":\"voiePayroll\",\"status\":\"inProgress\",\"createdDate\":1579819592,\"constraints\":{\"payrollData\":{\"payrollDataRetrievalId\":\"hahvhe2k0000\",\"employerNames\":[\"ACME INC\"],\"reportId\":\"abcdefghijkl-voiepayroll\"},\"payStatementsFromDate\":1580558400,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true}]},\"customerType\":\"active\",\"title\":\"Finicity Verification of Income and Employment - Payroll\",\"portfolioId\":\"9qud7dtuzbew-2-port\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}