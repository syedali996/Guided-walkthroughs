// <copyright file="AnalyticsAndAttributesControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// AnalyticsAndAttributesControllerTest.
    /// </summary>
    [TestFixture]
    public class AnalyticsAndAttributesControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private AnalyticsAndAttributesController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.AnalyticsAndAttributesController;
        }

        /// <summary>
        /// Generate a Consumer Attributes report for the given customer. The "to" and "from" date range is the last 12 months of consumer data, based on the date at which the report was generated.
        ///
        ///An analytic ID is created and associated with the customer's ID. If you generate multiple Consumer Attributes reports for the same customer, then each report will have its own analytic ID.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateConsumerAttributes()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.ConsumerAttributeAccountIDs body = null;

            // Perform API call
            Standard.Models.ConsumerAttributesAnalyticId result = null;
            try
            {
                result = await this.controller.GenerateConsumerAttributesAsync(customerId, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve a list of all analytic IDs previously created for a customer using the Generate Consumer Attributes APIs.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestListConsumerAttributes()
        {
            // Parameters for the API call
            string customerId = "1005061234";

            // Perform API call
            Standard.Models.ConsumerAttributeList result = null;
            try
            {
                result = await this.controller.ListConsumerAttributesAsync(customerId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// _Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateFCRAConsumerAttributes()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.ConsumerAttributeAccountIDs body = null;

            // Perform API call
            Standard.Models.ConsumerAttributesAnalyticId result = null;
            try
            {
                result = await this.controller.GenerateFCRAConsumerAttributesAsync(customerId, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve a Consumer Attributes report for a customer.
        ///
        ///Use the analytic and customer IDs to retrieve 12 months of data attributes according to the "to" and "from" date range of the report at the time it was created. 
        ///
        ///If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetConsumerAttributesByID()
        {
            // Parameters for the API call
            string analyticsId = "CA-5dfbaa3ac-5321";
            string customerId = "1005061234";

            // Perform API call
            Standard.Models.ConsumerAttributes result = null;
            try
            {
                result = await this.controller.GetConsumerAttributesByIDAsync(analyticsId, customerId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve a FCRA Consumer Attributes report for a customer.
        ///
        ///Use the analytic and customer IDs to retrieve 12 months of FCRA data attributes according to the `To` and `From` date range of the report at the time it was created. 
        ///
        ///If the current date is before the end of the calendar month, then the most recent month provides all available data up to the current date.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetFCRAConsumerAttributesByID()
        {
            // Parameters for the API call
            string analyticsId = "CA-5dfbaa3ac-5321";
            string customerId = "1005061234";
            string purpose = "99";

            // Perform API call
            Standard.Models.ConsumerAttributes result = null;
            try
            {
                result = await this.controller.GetFCRAConsumerAttributesByIDAsync(analyticsId, customerId, purpose);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}