// <copyright file="TransactionsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// TransactionsControllerTest.
    /// </summary>
    [TestFixture]
    public class TransactionsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private TransactionsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.TransactionsController;
        }

        /// <summary>
        /// Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.
        ///
        ///This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.)
        ///
        ///The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        ///
        ///The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.
        ///
        ///In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:
        ///
        ///* The institution's policy has changed, making more transactions available
        ///* Finicity has now added a longer transaction history support for the institution
        ///* The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team
        ///
        ///In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestLoadHistoricTransactionsForCustomerAccount()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";
            object body = null;

            // Perform API call
            try
            {
                await this.controller.LoadHistoricTransactionsForCustomerAccountAsync(customerId, accountId, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(203, HttpCallBack.Response.StatusCode, "Status should be 203");
        }

        /// <summary>
        /// Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.
        ///
        ///This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.)
        ///
        ///The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.
        ///
        ///The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.
        ///
        ///In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:
        ///
        ///* The institution's policy has changed, making more transactions available
        ///* Finicity has now added a longer transaction history support for the institution
        ///* The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team
        ///
        ///In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestLoadHistoricTransactionsForCustomerAccount1()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";
            object body = null;

            // Perform API call
            try
            {
                await this.controller.LoadHistoricTransactionsForCustomerAccountAsync(customerId, accountId, body);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(204, HttpCallBack.Response.StatusCode, "Status should be 204");
        }

        /// <summary>
        /// Get all transactions available for this customer within the given date range, across all accounts. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.
        ///
        ///Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the service Load Historic Transactions for Account.
        ///
        ///There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAllCustomerTransactions()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            long fromDate = 1607450357;
            long toDate = 1607450357;
            int? start = 1;
            int? limit = 25;
            string sort = "desc";
            bool? includePending = false;

            // Perform API call
            Standard.Models.Transactions result = null;
            try
            {
                result = await this.controller.GetAllCustomerTransactionsAsync(customerId, fromDate, toDate, start, limit, sort, includePending);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Get details for the given transaction.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetCustomerTransaction()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            long transactionId = 21284820852;

            // Perform API call
            Standard.Models.Transaction result = null;
            try
            {
                result = await this.controller.GetCustomerTransactionAsync(customerId, transactionId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Get all transactions available for this customer account within the given date range. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.
        ///
        ///Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the Cash Flow Verification service Load Historic Transactions for Account.
        ///
        ///There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetCustomerAccountTransactions()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";
            long fromDate = 1607450357;
            long toDate = 1607450357;
            int? start = 1;
            int? limit = 25;
            string sort = "desc";
            bool? includePending = false;

            // Perform API call
            Standard.Models.Transactions result = null;
            try
            {
                result = await this.controller.GetCustomerAccountTransactionsAsync(customerId, accountId, fromDate, toDate, start, limit, sort, includePending);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}