// <copyright file="PaymentsControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// PaymentsControllerTest.
    /// </summary>
    [TestFixture]
    public class PaymentsControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private PaymentsController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.PaymentsController;
        }

        /// <summary>
        /// Retrieve the names and addresses of the account owner from a financial institution.
        ///
        ///Note: this is a premium service, billable per every successful API call.
        ///
        ///This service retrieves account data from the institution. This usually returns quickly, but in some scenarios may take a few minutes to complete. In the event of a timeout condition, retry the call.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAccountOwner()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            Standard.Models.AccountOwner result = null;
            try
            {
                result = await this.controller.GetAccountOwnerAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve the names and addresses of the account owner from a financial institution.
        ///
        ///Note: this is a premium service, billable per every successful API call.
        ///
        ///This service retrieves account data from the institution. This usually returns quickly, but in some scenarios may take a few minutes to complete. In the event of a timeout condition, retry the call.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAccountOwner1()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            Standard.Models.AccountOwner result = null;
            try
            {
                result = await this.controller.GetAccountOwnerAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(203, HttpCallBack.Response.StatusCode, "Status should be 203");
        }

        /// <summary>
        /// Return the loan payment details of the customer for a loan-type account.
        ///
        ///Note: this is a premium service, billable per every successful API call.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetLoanPaymentDetails()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            Standard.Models.LoanPaymentDetails result = null;
            try
            {
                result = await this.controller.GetLoanPaymentDetailsAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Return the real account number and routing number details for an ACH payment.
        ///
        ///Note: this is a premium service, billable per every successful API call.
        ///
        ///_Supported account types_: "checking", "savings", "moneyMarket", "loan"
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAccountACHDetails()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            Standard.Models.ACHDetails result = null;
            try
            {
                result = await this.controller.GetAccountACHDetailsAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve the available and cleared account balances for a single account in real-time directly from a financial institution.
        ///
        ///Note: this is a premium service, billable per every successful API call.
        ///
        ///_Supported account types_: "checking", "savings", "moneyMarket", "cd"
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAvailableBalanceLive()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            Standard.Models.AvailableBalance result = null;
            try
            {
                result = await this.controller.GetAvailableBalanceLiveAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Retrieve the latest cached available and cleared account balances for a customer. Since we update and store balances throughout the day, this is the most accurate balance information available when a connection to a financial institution is unavailable or when a faster response is needed. Only deposit account types are supported: Checking, Savings, Money Market, and CD.
        ///
        ///Note: this is a premium service, billable per every successful API call. Enrollment is required.        
        ///
        ///_Supported account types_: "checking", "savings", "moneyMarket", "cd"
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGetAvailableBalance()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            string accountId = "5011648377";

            // Perform API call
            Standard.Models.AvailableBalance result = null;
            try
            {
                result = await this.controller.GetAvailableBalanceAsync(customerId, accountId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}