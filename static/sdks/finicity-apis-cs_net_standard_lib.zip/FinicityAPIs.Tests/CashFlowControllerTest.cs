// <copyright file="CashFlowControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace FinicityAPIs.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using FinicityAPIs.Standard;
    using FinicityAPIs.Standard.Controllers;
    using FinicityAPIs.Standard.Exceptions;
    using FinicityAPIs.Standard.Http.Client;
    using FinicityAPIs.Standard.Http.Response;
    using FinicityAPIs.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// CashFlowControllerTest.
    /// </summary>
    [TestFixture]
    public class CashFlowControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private CashFlowController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.CashFlowController;
        }

        /// <summary>
        /// Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.
        ///
        ///This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.
        ///
        ///If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateCashFlowBusinessReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.CashFlowReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.CashFlowReportConstraints>("{\"accountIds\":\"1000535275\",\"incomeStreamConfidenceMinimum\":50,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false,\"fromDate\":1580558400}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.CashFlowReportAck result = null;
            try
            {
                result = await this.controller.GenerateCashFlowBusinessReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"383z55zudewm-cfrb\",\"customerType\":\"active\",\"customerId\":1275320,\"requestId\":\"7a7qyps2iy\",\"requesterName\":\"Decisioning API\",\"createdDate\":1579819592,\"title\":\"Finicity Cash Flow Report - Business\",\"consumerId\":\"3f7ff2cf0ffb3d0cd59875e070c9b1d4\",\"consumerSsn\":\"1234\",\"constraints\":{\"accountIds\":[\"1000535275\"],\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]},\"type\":\"cfrb\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }

        /// <summary>
        /// Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.
        ///
        ///This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.
        ///
        ///Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).
        ///
        ///If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.
        ///
        ///_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png).
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestGenerateCashFlowPersonalReport()
        {
            // Parameters for the API call
            string customerId = "1005061234";
            Standard.Models.CashFlowReportConstraints body = ApiHelper.JsonDeserialize<Standard.Models.CashFlowReportConstraints>("{\"accountIds\":\"1000535275\",\"incomeStreamConfidenceMinimum\":50,\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}],\"showNsf\":false,\"fromDate\":1580558400}");
            string callbackUrl = "https://finicity-test/webhook";

            // Perform API call
            Standard.Models.CashFlowReportAck result = null;
            try
            {
                result = await this.controller.GenerateCashFlowPersonalReportAsync(customerId, body, callbackUrl);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(202, HttpCallBack.Response.StatusCode, "Status should be 202");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Content-Type", "application/json");

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");

            // Test whether the captured response is as we expected
            Assert.IsNotNull(result, "Result should exist");
            Assert.IsTrue(
                    TestHelper.IsJsonObjectProperSubsetOf(
                    "{\"id\":\"383z51zurqwo-cfrp\",\"customerType\":\"active\",\"customerId\":1275320,\"requestId\":\"7a7qyps2iy\",\"requesterName\":\"Decisioning API\",\"createdDate\":1579819592,\"title\":\"Finicity Cash Flow Report - Personal\",\"consumerId\":\"3f7ff2cf0ffb3d0cd59875e070c9b1d4\",\"consumerSsn\":\"1234\",\"constraints\":{\"accountIds\":[\"1000535275\"],\"reportCustomFields\":[{\"label\":\"loanID\",\"value\":\"12345\",\"shown\":true},{\"label\":\"trackingID\",\"value\":\"5555\",\"shown\":true},{\"label\":\"loanType\",\"value\":\"car\",\"shown\":false},{\"label\":\"vendorID\",\"value\":\"1613aa23\",\"shown\":true},{\"label\":\"vendorName\",\"value\":\"PSC Finance\",\"shown\":false}]},\"type\":\"cfrp\",\"status\":\"inProgress\"}",
                    TestHelper.ConvertStreamToString(HttpCallBack.Response.RawBody),
                    false,
                    true,
                    false),
                    "Response body should have matching keys");
        }
    }
}