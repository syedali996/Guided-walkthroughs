# Cash Flow

```csharp
CashFlowController cashFlowController = client.CashFlowController;
```

## Class Name

`CashFlowController`

## Methods

* [Generate Cash Flow Business Report](../../doc/controllers/cash-flow.md#generate-cash-flow-business-report)
* [Generate Cash Flow Personal Report](../../doc/controllers/cash-flow.md#generate-cash-flow-personal-report)


# Generate Cash Flow Business Report

Generate a Cash Flow Report (Business) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report. A consumer is not required to generate this report.

This report is not provided under FCRA rules, and this report is not available in the Finicity Consumer Portal for the borrower to view.

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GenerateCashFlowBusinessReportAsync(
    string customerId,
    Models.CashFlowReportConstraints body,
    string callbackUrl = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`Models.CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`Task<Models.CashFlowReportAck>`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```csharp
string customerId = "1005061234";
var body = new CashFlowReportConstraints();
body.AccountIds = "1000535275";
body.ReportCustomFields = new List<ReportCustomField>();

var bodyReportCustomFields0 = new ReportCustomField();
bodyReportCustomFields0.Label = "loanID";
bodyReportCustomFields0.MValue = "12345";
bodyReportCustomFields0.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields0);

var bodyReportCustomFields1 = new ReportCustomField();
bodyReportCustomFields1.Label = "trackingID";
bodyReportCustomFields1.MValue = "5555";
bodyReportCustomFields1.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields1);

var bodyReportCustomFields2 = new ReportCustomField();
bodyReportCustomFields2.Label = "loanType";
bodyReportCustomFields2.MValue = "car";
bodyReportCustomFields2.Shown = false;
body.ReportCustomFields.Add(bodyReportCustomFields2);

var bodyReportCustomFields3 = new ReportCustomField();
bodyReportCustomFields3.Label = "vendorID";
bodyReportCustomFields3.MValue = "1613aa23";
bodyReportCustomFields3.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields3);

var bodyReportCustomFields4 = new ReportCustomField();
bodyReportCustomFields4.Label = "vendorName";
bodyReportCustomFields4.MValue = "PSC Finance";
bodyReportCustomFields4.Shown = false;
body.ReportCustomFields.Add(bodyReportCustomFields4);

body.ShowNsf = false;
body.FromDate = 1580558400L;
body.IncomeStreamConfidenceMinimum = 50;
string callbackUrl = "https://finicity-test/webhook";

try
{
    CashFlowReportAck result = await cashFlowController.GenerateCashFlowBusinessReportAsync(customerId, body, callbackUrl);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "id": "383z55zudewm-cfrb",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Business",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrb",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Cash Flow Personal Report

Generate a Cash Flow Report (Personal) report for all checking and savings under the given customer. This service retrieves up to two years of transaction history for the given account. It then uses this information to generate the CFR report.

This report is provided under FCRA rules, with Finicity acting as the CRA (Consumer Reporting Agency). If an individual account is included in the report - for example, with an individual acting as an personal guarantor on the loan - then this version of the report should be used. In case of an adverse action on the loan where the decision was based on this report, then the borrower can be referred to the [Finicity Consumer Portal](https://consumer.finicityreports.com) where they can view this report and submit a dispute if they feel any information in this report is inaccurate.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

If no account type of checking or savings is found, the service will return HTTP 400 Bad Request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GenerateCashFlowPersonalReportAsync(
    string customerId,
    Models.CashFlowReportConstraints body,
    string callbackUrl = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`Models.CashFlowReportConstraints`](../../doc/models/cash-flow-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`Task<Models.CashFlowReportAck>`](../../doc/models/cash-flow-report-ack.md)

## Example Usage

```csharp
string customerId = "1005061234";
var body = new CashFlowReportConstraints();
body.AccountIds = "1000535275";
body.ReportCustomFields = new List<ReportCustomField>();

var bodyReportCustomFields0 = new ReportCustomField();
bodyReportCustomFields0.Label = "loanID";
bodyReportCustomFields0.MValue = "12345";
bodyReportCustomFields0.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields0);

var bodyReportCustomFields1 = new ReportCustomField();
bodyReportCustomFields1.Label = "trackingID";
bodyReportCustomFields1.MValue = "5555";
bodyReportCustomFields1.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields1);

var bodyReportCustomFields2 = new ReportCustomField();
bodyReportCustomFields2.Label = "loanType";
bodyReportCustomFields2.MValue = "car";
bodyReportCustomFields2.Shown = false;
body.ReportCustomFields.Add(bodyReportCustomFields2);

var bodyReportCustomFields3 = new ReportCustomField();
bodyReportCustomFields3.Label = "vendorID";
bodyReportCustomFields3.MValue = "1613aa23";
bodyReportCustomFields3.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields3);

var bodyReportCustomFields4 = new ReportCustomField();
bodyReportCustomFields4.Label = "vendorName";
bodyReportCustomFields4.MValue = "PSC Finance";
bodyReportCustomFields4.Shown = false;
body.ReportCustomFields.Add(bodyReportCustomFields4);

body.ShowNsf = false;
body.FromDate = 1580558400L;
body.IncomeStreamConfidenceMinimum = 50;
string callbackUrl = "https://finicity-test/webhook";

try
{
    CashFlowReportAck result = await cashFlowController.GenerateCashFlowPersonalReportAsync(customerId, body, callbackUrl);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "id": "383z51zurqwo-cfrp",
  "customerType": "active",
  "customerId": 1275320,
  "requestId": "7a7qyps2iy",
  "requesterName": "Decisioning API",
  "createdDate": 1579819592,
  "title": "Finicity Cash Flow Report - Personal",
  "consumerId": "3f7ff2cf0ffb3d0cd59875e070c9b1d4",
  "consumerSsn": "1234",
  "constraints": {
    "accountIds": [
      "1000535275"
    ],
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "12345",
        "shown": true
      },
      {
        "label": "trackingID",
        "value": "5555",
        "shown": true
      },
      {
        "label": "loanType",
        "value": "car",
        "shown": false
      },
      {
        "label": "vendorID",
        "value": "1613aa23",
        "shown": true
      },
      {
        "label": "vendorName",
        "value": "PSC Finance",
        "shown": false
      }
    ]
  },
  "type": "cfrp",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

