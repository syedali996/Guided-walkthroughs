# Customers

Enroll and manage customers

```csharp
CustomersController customersController = client.CustomersController;
```

## Class Name

`CustomersController`

## Methods

* [Add Testing Customer](../../doc/controllers/customers.md#add-testing-customer)
* [Add Customer](../../doc/controllers/customers.md#add-customer)
* [Get Customers](../../doc/controllers/customers.md#get-customers)
* [Get Customer With App Data](../../doc/controllers/customers.md#get-customer-with-app-data)
* [Get Customer](../../doc/controllers/customers.md#get-customer)
* [Modify Customer](../../doc/controllers/customers.md#modify-customer)
* [Delete Customer](../../doc/controllers/customers.md#delete-customer)


# Add Testing Customer

Enroll a testing customer ([Test Drive](https://signup.finicity.com/) accounts).

For using testing customers with FinBank OAuth, you must register a test application with your systems engineer or account manager. Then, use that testing `applicationId` when creating testing customers.

Testing Customers can access FinBank profiles (except "FinBank Billable" profiles), and cannot access live financial institutions.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
AddTestingCustomerAsync(
    Models.NewCustomer body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.NewCustomer`](../../doc/models/new-customer.md) | Body, Required | - |

## Response Type

[`Task<Models.CreatedCustomer>`](../../doc/models/created-customer.md)

## Example Usage

```csharp
var body = new NewCustomer();
body.Username = "customerusername1";

try
{
    CreatedCustomer result = await customersController.AddTestingCustomerAsync(body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Add Customer

Enroll an active customer, which is the actual owner of one or more real-world accounts. This is a billable customer.

Active customers must use the "FinBank Billable" profiles for testing purposes.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
AddCustomerAsync(
    Models.NewCustomer body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.NewCustomer`](../../doc/models/new-customer.md) | Body, Required | - |

## Response Type

[`Task<Models.CreatedCustomer>`](../../doc/models/created-customer.md)

## Example Usage

```csharp
var body = new NewCustomer();
body.Username = "customerusername1";

try
{
    CreatedCustomer result = await customersController.AddCustomerAsync(body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 429 | The service can't accept more requests or is not available from the [Test Drive](https://signup.finicity.com/). | `ApiException` |


# Get Customers

Find all customers enrolled by the current partner, where the search text is found in the customer's username or any combination of `firstName` and `lastName` fields. If no search text is provided, all customers will be returned.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomersAsync(
    string username = null,
    string type = null,
    string search = null,
    int? start = 1,
    int? limit = 25)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Query, Optional | Username for exact match (will return 0 or 1 record) |
| `type` | `string` | Query, Optional | "testing" or "active" to return only customers of that type, or leave empty to return all customers |
| `search` | `string` | Query, Optional | The text you wish to match. Leave this empty if you wish to return all customers. Must be URL-encoded (see: [Handling Spaces in Queries](https://docs.finicity.com/endpoint-syntax-and-format/)). |
| `start` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |

## Response Type

[`Task<Models.Customers>`](../../doc/models/customers.md)

## Example Usage

```csharp
string username = "customerusername1";
string type = "active";
string search = "searchvalue";
int? start = 1;
int? limit = 25;

try
{
    Customers result = await customersController.GetCustomersAsync(username, type, search, start, limit);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer With App Data

Retrieve a customer along with additional details about the OAuth application.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerWithAppDataAsync(
    string customerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |

## Response Type

[`Task<Models.CustomerWithAppData>`](../../doc/models/customer-with-app-data.md)

## Example Usage

```csharp
string customerId = "1005061234";

try
{
    CustomerWithAppData result = await customersController.GetCustomerWithAppDataAsync(customerId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer

Retrieve a customer by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAsync(
    string customerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |

## Response Type

[`Task<Models.Customer>`](../../doc/models/customer.md)

## Example Usage

```csharp
string customerId = "1005061234";

try
{
    Customer result = await customersController.GetCustomerAsync(customerId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify Customer

Modify an enrolled customer by ID.

You must specify either `firstName`, `lastName`, or both in the request.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
ModifyCustomerAsync(
    string customerId,
    Models.CustomerUpdate body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`Models.CustomerUpdate`](../../doc/models/customer-update.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string customerId = "1005061234";
var body = new CustomerUpdate();

try
{
    await customersController.ModifyCustomerAsync(customerId, body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Customer

Completely remove a customer from the system. This will remove the customer and all associated accounts and transactions.

⚠️ Use this service carefully! It will not pause for confirmation before performing the operation!

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
DeleteCustomerAsync(
    string customerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |

## Response Type

`Task`

## Example Usage

```csharp
string customerId = "1005061234";

try
{
    await customersController.DeleteCustomerAsync(customerId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

