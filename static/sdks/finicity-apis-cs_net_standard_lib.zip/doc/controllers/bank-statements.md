# Bank Statements

```csharp
BankStatementsController bankStatementsController = client.BankStatementsController;
```

## Class Name

`BankStatementsController`

## Methods

* [Get Customer Account Statement](../../doc/controllers/bank-statements.md#get-customer-account-statement)
* [Generate Statement Report](../../doc/controllers/bank-statements.md#generate-statement-report)


# Get Customer Account Statement

Retrieve the customer's bank statements in PDF format. Up to 24 months of history is available depending on the financial institution. Since this is a premium service, charges incur per each successful statement retrieved.

For certified financial institutions, statements are available for the following account types:

* Checking
* Savings
* Money market
* CDs
* Investments
* Mortgage
* Credit cards
* Loans
* Line of credit
* Student Loans

Note: setting the timeout to 180 seconds is recommended to allow enough time for a response.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAccountStatementAsync(
    string customerId,
    string accountId,
    int? index = 1,
    string type = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `index` | `int?` | Query, Optional | Request statements from 1-24. By default, 1 is the most recent statement. Increase the index value to count back (by month) and retrieve its most recent statement.<br>**Default**: `1`<br>**Constraints**: `<= 24` |
| `type` | `string` | Query, Optional | The type of statement to retrieve |

## Response Type

`Task<Stream>`

## Example Usage

```csharp
string customerId = "1005061234";
string accountId = "5011648377";
int? index = 1;
string type = "taxStatement";

try
{
    Stream result = await bankStatementsController.GetCustomerAccountStatementAsync(customerId, accountId, index, type);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Statement Report

Generate a Statement Report report for the given accounts under the given customer.

This is a premium service. A billable event will be created upon the successful generation of the Statement Report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GenerateStatementReportAsync(
    string customerId,
    Models.StatementReportConstraints body,
    string callbackUrl = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`Models.StatementReportConstraints`](../../doc/models/statement-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |

## Response Type

[`Task<Models.StatementReportAck>`](../../doc/models/statement-report-ack.md)

## Example Usage

```csharp
string customerId = "1005061234";
var body = new StatementReportConstraints();
body.StatementReportData = new StatementData();
body.StatementReportData.AccountId = 1000076901L;
body.StatementReportData.Index = 1;
body.ReportCustomFields = new List<ReportCustomField>();

var bodyReportCustomFields0 = new ReportCustomField();
bodyReportCustomFields0.Label = "loanID";
bodyReportCustomFields0.MValue = "123456";
bodyReportCustomFields0.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields0);

string callbackUrl = "https://finicity-test/webhook";

try
{
    StatementReportAck result = await bankStatementsController.GenerateStatementReportAsync(customerId, body, callbackUrl);
}
catch (ApiException e){};
```

## Example Response *(as JSON)*

```json
{
  "id": "38dknche83oh-statement",
  "portfolioId": "sy7aa68w2ugx-1-port",
  "customerType": "active",
  "customerId": 1010560999,
  "requestId": "ny7x32stfq",
  "requesterName": "Demo",
  "createdDate": 1596226182,
  "title": "Finicity Statement Report",
  "consumerId": "555595ec74c8ec57adf44dadddb6a35",
  "consumerSsn": "1234",
  "constraints": {
    "statementReportData": {
      "accountId": 1000076901,
      "index": 1
    },
    "reportCustomFields": [
      {
        "label": "loanID",
        "value": "123456",
        "shown": true
      }
    ]
  },
  "type": "statement",
  "status": "inProgress"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

