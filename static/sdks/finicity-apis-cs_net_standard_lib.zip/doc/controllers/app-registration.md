# App Registration

```csharp
AppRegistrationController appRegistrationController = client.AppRegistrationController;
```

## Class Name

`AppRegistrationController`

## Methods

* [Register App](../../doc/controllers/app-registration.md#register-app)
* [Modify App Registration](../../doc/controllers/app-registration.md#modify-app-registration)
* [Get App Registration Status](../../doc/controllers/app-registration.md#get-app-registration-status)
* [Set Customer App ID](../../doc/controllers/app-registration.md#set-customer-app-id)
* [Migrate Institution Login Accounts](../../doc/controllers/app-registration.md#migrate-institution-login-accounts)


# Register App

Register a new application to access financial institutions using OAuth connections.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
RegisterAppAsync(
    Models.Application body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Models.Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`Task<Models.RegisteredApplication>`](../../doc/models/registered-application.md)

## Example Usage

```csharp
var body = new Application();
body.AppDescription = "The app that makes your budgeting experience awesome";
body.AppName = "Awesome Budget App";
body.AppUrl = "https://www.finicity.com/";
body.OwnerAddressLine1 = "434 W Ascension Way";
body.OwnerAddressLine2 = "Suite #200";
body.OwnerCity = "Murray";
body.OwnerCountry = "USA";
body.OwnerName = "Finicity";
body.OwnerPostalCode = "84123";
body.OwnerState = "UT";
body.Image = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K";

try
{
    RegisteredApplication result = await appRegistrationController.RegisterAppAsync(body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify App Registration

Update a registered application.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
ModifyAppRegistrationAsync(
    string preAppId,
    Models.Application body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preAppId` | `string` | Template, Required | The application registration tracking ID |
| `body` | [`Models.Application`](../../doc/models/application.md) | Body, Required | - |

## Response Type

[`Task<Models.RegisteredApplication>`](../../doc/models/registered-application.md)

## Example Usage

```csharp
string preAppId = "2581";
var body = new Application();
body.AppDescription = "The app that makes your budgeting experience awesome";
body.AppName = "Awesome Budget App";
body.AppUrl = "https://www.finicity.com/";
body.OwnerAddressLine1 = "434 W Ascension Way";
body.OwnerAddressLine2 = "Suite #200";
body.OwnerCity = "Murray";
body.OwnerCountry = "USA";
body.OwnerName = "Finicity";
body.OwnerPostalCode = "84123";
body.OwnerState = "UT";
body.Image = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgICAKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHZpZXdCb3g9IjAgMCAwIDAiCiAgIGhlaWdodD0iMCIKICAgd2lkdGg9IjAiPgogICAgPGcvPgo8L3N2Zz4K";

try
{
    RegisteredApplication result = await appRegistrationController.ModifyAppRegistrationAsync(preAppId, body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get App Registration Status

Get the status of your application registration(s).

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetAppRegistrationStatusAsync(
    string preAppId = null,
    string applicationId = null,
    string status = null,
    string appName = null,
    long? submittedDate = null,
    long? modifiedDate = null,
    int? page = 1,
    int? pageSize = 1)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `preAppId` | `string` | Query, Optional | The application registration tracking ID |
| `applicationId` | `string` | Query, Optional | The application ID |
| `status` | `string` | Query, Optional | Look up app registration requests by status |
| `appName` | `string` | Query, Optional | Look up app registration requests by app name |
| `submittedDate` | `long?` | Query, Optional | Look up app registration requests by the date they were submitted |
| `modifiedDate` | `long?` | Query, Optional | Look up app registration requests by the date the request was updated. This can be used to determine when a request was updated to "A" or "R". |
| `page` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `pageSize` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `1` |

## Response Type

[`Task<Models.AppStatuses>`](../../doc/models/app-statuses.md)

## Example Usage

```csharp
string preAppId = "2581";
string applicationId = "123456789";
string status = "P";
string appName = "Awesome Budget App";
long? submittedDate = 1607450357L;
long? modifiedDate = 1607450357L;
int? page = 1;
int? pageSize = 20;

try
{
    AppStatuses result = await appRegistrationController.GetAppRegistrationStatusAsync(preAppId, applicationId, status, appName, submittedDate, modifiedDate, page, pageSize);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Set Customer App ID

If you have multiple applications for a single client, and you want to register their applications to access financial institutions using OAuth connections, then use this API to assign applications to an existing customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
SetCustomerAppIDAsync(
    string customerId,
    string applicationId,
    object body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `applicationId` | `string` | Template, Required | The application ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

`Task`

## Example Usage

```csharp
string customerId = "1005061234";
string applicationId = "123456789";

try
{
    await appRegistrationController.SetCustomerAppIDAsync(customerId, applicationId, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Migrate Institution Login Accounts

The `institutionLoginId` parameter uses Finicity's internal FI mapping to move accounts from the current FI legacy connection to the new OAuth FI connection.

This API returns a list of accounts for the given institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
MigrateInstitutionLoginAccountsAsync(
    string customerId,
    string institutionLoginId,
    object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `institutionLoginId` | `string` | Template, Required | The institution login ID |
| `body` | `object` | Body, Required | No payload expected |

## Response Type

[`Task<Models.CustomerAccounts>`](../../doc/models/customer-accounts.md)

## Example Usage

```csharp
string customerId = "1005061234";
string institutionLoginId = "1007302745";
object body = ApiHelper.JsonDeserialize<Object>("{\"key1\":\"val1\",\"key2\":\"val2\"}");

try
{
    CustomerAccounts result = await appRegistrationController.MigrateInstitutionLoginAccountsAsync(customerId, institutionLoginId, body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

