# Consumers

Create and manage consumers associated with customers in order to use report services

```csharp
ConsumersController consumersController = client.ConsumersController;
```

## Class Name

`ConsumersController`

## Methods

* [Create Consumer](../../doc/controllers/consumers.md#create-consumer)
* [Get Consumer for Customer](../../doc/controllers/consumers.md#get-consumer-for-customer)
* [Get Consumer](../../doc/controllers/consumers.md#get-consumer)
* [Modify Consumer](../../doc/controllers/consumers.md#modify-consumer)


# Create Consumer

Create a consumer record associated with the given customer. A consumer persists as the owner of any reports that are generated, even after the original customer is deleted from the system.

A consumer must be created for the given customer before calling any of the Generate Report services.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
CreateConsumerAsync(
    string customerId,
    Models.NewConsumer body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`Models.NewConsumer`](../../doc/models/new-consumer.md) | Body, Required | - |

## Response Type

[`Task<Models.CreatedConsumer>`](../../doc/models/created-consumer.md)

## Example Usage

```csharp
string customerId = "1005061234";
var body = new NewConsumer();
body.FirstName = "John";
body.LastName = "Smith";
body.Address = "434 W Ascension Way";
body.City = "Murray";
body.State = "UT";
body.Zip = "84123";
body.Phone = "1-800-986-3343";
body.Ssn = "999-99-9999";
body.Birthday = new Birthday();

try
{
    CreatedConsumer result = await consumersController.CreateConsumerAsync(customerId, body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 409 | The resource already exists | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer for Customer

Get the details of a consumer record by customer ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetConsumerForCustomerAsync(
    string customerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |

## Response Type

[`Task<Models.Consumer>`](../../doc/models/consumer.md)

## Example Usage

```csharp
string customerId = "1005061234";

try
{
    Consumer result = await consumersController.GetConsumerForCustomerAsync(customerId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Consumer

Get the details of a consumer record by consumer ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetConsumerAsync(
    string consumerId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumerId` | `string` | Template, Required | The consumer ID |

## Response Type

[`Task<Models.Consumer>`](../../doc/models/consumer.md)

## Example Usage

```csharp
string consumerId = "0bf46322c167b562e6cbed9d40e19a4c";

try
{
    Consumer result = await consumersController.GetConsumerAsync(consumerId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Modify Consumer

Modify an existing consumer. All fields are required for a consumer record, but individual fields for this call are optional because fields that are not specified will be left unchanged.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
ModifyConsumerAsync(
    string consumerId,
    Models.ConsumerUpdate body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumerId` | `string` | Template, Required | The consumer ID |
| `body` | [`Models.ConsumerUpdate`](../../doc/models/consumer-update.md) | Body, Required | - |

## Response Type

`Task`

## Example Usage

```csharp
string consumerId = "0bf46322c167b562e6cbed9d40e19a4c";
var body = new ConsumerUpdate();

try
{
    await consumersController.ModifyConsumerAsync(consumerId, body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

