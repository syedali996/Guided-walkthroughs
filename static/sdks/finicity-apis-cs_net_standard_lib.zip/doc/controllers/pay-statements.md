# Pay Statements

```csharp
PayStatementsController payStatementsController = client.PayStatementsController;
```

## Class Name

`PayStatementsController`


# Store Customer Pay Statement

Upload pay statements for a customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
StoreCustomerPayStatementAsync(
    string customerId,
    Models.PayStatement body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | [`Models.PayStatement`](../../doc/models/pay-statement.md) | Body, Required | - |

## Response Type

[`Task<Models.Asset>`](../../doc/models/asset.md)

## Example Usage

```csharp
string customerId = "1005061234";
var body = new PayStatement();
body.Label = "lastPayPeriod";
body.Statement = "VGhpcyBtdXN0IGJlIGFuIGltYWdl";

try
{
    Asset result = await payStatementsController.StoreCustomerPayStatementAsync(customerId, body);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

