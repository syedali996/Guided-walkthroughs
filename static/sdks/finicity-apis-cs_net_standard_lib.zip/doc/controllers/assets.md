# Assets

Download asset files

```csharp
AssetsController assetsController = client.AssetsController;
```

## Class Name

`AssetsController`


# Get Asset by Customer ID

Retrieve a binary file for the given asset ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetAssetByCustomerIDAsync(
    string customerId,
    string assetId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `assetId` | `string` | Template, Required | The asset ID |

## Response Type

`Task<Stream>`

## Example Usage

```csharp
string customerId = "1005061234";
string assetId = "097545c5-1c2a-4f20-a5ef-77f0820344c9-2018601178";

try
{
    Stream result = await assetsController.GetAssetByCustomerIDAsync(customerId, assetId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

