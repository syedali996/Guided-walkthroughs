# Transactions

Fetch customer and account transactions and generate reports asynchronously

```csharp
TransactionsController transactionsController = client.TransactionsController;
```

## Class Name

`TransactionsController`

## Methods

* [Load Historic Transactions for Customer Account](../../doc/controllers/transactions.md#load-historic-transactions-for-customer-account)
* [Get All Customer Transactions](../../doc/controllers/transactions.md#get-all-customer-transactions)
* [Get Customer Transaction](../../doc/controllers/transactions.md#get-customer-transaction)
* [Get Customer Account Transactions](../../doc/controllers/transactions.md#get-customer-account-transactions)
* [Generate Transactions Report](../../doc/controllers/transactions.md#generate-transactions-report)


# Load Historic Transactions for Customer Account

Connect to the account's financial institution and load up to 24 months of historic transactions for the account. Length of history varies by institution.

This is a premium service. The billable event is a call to this service specifying a customer ID that has not been seen before by this service. (If this service is called multiple times with the same customer ID, to load transactions from multiple accounts, only one billable event has occurred.)

The recommended timeout setting for this request is 180 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

The date range sent to the institution is calculated from the account's `createdDate`. This means that calling this service a second time for the same account normally will not add any new transactions for the account. For this reason, a second call to this service for a known account ID will usually return immediately.

In a few specific scenarios, it may be desirable to force a second connection to the institution for a known account ID. Some examples are:

* The institution's policy has changed, making more transactions available
* Finicity has now added a longer transaction history support for the institution
* The first call encountered an error, and the resulting Aggregation Ticket has now been fixed by the Finicity Support Team

In these cases, the POST request can contain the parameter `force=true` in the request body to force the second connection.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
LoadHistoricTransactionsForCustomerAccountAsync(
    string customerId,
    string accountId,
    object body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

`Task`

## Example Usage

```csharp
string customerId = "1005061234";
string accountId = "5011648377";

try
{
    await transactionsController.LoadHistoricTransactionsForCustomerAccountAsync(customerId, accountId, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get All Customer Transactions

Get all transactions available for this customer within the given date range, across all accounts. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.

Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the service Load Historic Transactions for Account.

There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetAllCustomerTransactionsAsync(
    string customerId,
    long fromDate,
    long toDate,
    int? start = 1,
    int? limit = 25,
    string sort = "desc",
    bool? includePending = false)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `fromDate` | `long` | Query, Required | A start date |
| `toDate` | `long` | Query, Required | A end date |
| `start` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `sort` | `string` | Query, Optional | Date sort order: "asc" for ascending, "desc" for descending<br>**Default**: `"desc"` |
| `includePending` | `bool?` | Query, Optional | If pending transactions must be included<br>**Default**: `false` |

## Response Type

[`Task<Models.Transactions>`](../../doc/models/transactions.md)

## Example Usage

```csharp
string customerId = "1005061234";
long fromDate = 1607450357L;
long toDate = 1607450357L;
int? start = 1;
int? limit = 25;
string sort = "desc";
bool? includePending = false;

try
{
    Transactions result = await transactionsController.GetAllCustomerTransactionsAsync(customerId, fromDate, toDate, start, limit, sort, includePending);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Transaction

Get details for the given transaction.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerTransactionAsync(
    string customerId,
    long transactionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `transactionId` | `long` | Template, Required | A transaction ID |

## Response Type

[`Task<Models.Transaction>`](../../doc/models/transaction.md)

## Example Usage

```csharp
string customerId = "1005061234";
long transactionId = 21284820852L;

try
{
    Transaction result = await transactionsController.GetCustomerTransactionAsync(customerId, transactionId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Account Transactions

Get all transactions available for this customer account within the given date range. This service supports paging and sorting by `transactionDate` (or `postedDate` if no transaction date is provided), with a maximum of 1000 transactions per request.

Standard consumer aggregation provides up to 180 days of transactions prior to the date each account was added to the Finicity system. To access older transactions, you must first call the Cash Flow Verification service Load Historic Transactions for Account.

There is no limit for the size of the window between `fromDate` and `toDate`, however, the maximum number of transactions returned on one page is 1000.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAccountTransactionsAsync(
    string customerId,
    string accountId,
    long fromDate,
    long toDate,
    int? start = 1,
    int? limit = 25,
    string sort = "desc",
    bool? includePending = false)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |
| `fromDate` | `long` | Query, Required | A start date |
| `toDate` | `long` | Query, Required | A end date |
| `start` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `sort` | `string` | Query, Optional | Date sort order: "asc" for ascending, "desc" for descending<br>**Default**: `"desc"` |
| `includePending` | `bool?` | Query, Optional | If pending transactions must be included<br>**Default**: `false` |

## Response Type

[`Task<Models.Transactions>`](../../doc/models/transactions.md)

## Example Usage

```csharp
string customerId = "1005061234";
string accountId = "5011648377";
long fromDate = 1607450357L;
long toDate = 1607450357L;
int? start = 1;
int? limit = 25;
string sort = "desc";
bool? includePending = false;

try
{
    Transactions result = await transactionsController.GetCustomerAccountTransactionsAsync(customerId, accountId, fromDate, toDate, start, limit, sort, includePending);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Generate Transactions Report

Generate a Transaction Report for the given accounts under the given customer. This service retrieves up to 24 months of transaction history for the given customer. It then uses this information to generate the Transaction Report.

This is a premium service. A billable event will be created upon the successful generation of the Transactions Report.

Before calling this API, a consumer must be created for the given customer ID (see Consumers APIs).

There cannot be more than 24 months between `fromDate` and `toDate`.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GenerateTransactionsReportAsync(
    string customerId,
    long toDate,
    Models.TransactionsReportConstraints body,
    string callbackUrl = null,
    bool? includePending = false)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `toDate` | `long` | Query, Required | A end date |
| `body` | [`Models.TransactionsReportConstraints`](../../doc/models/transactions-report-constraints.md) | Body, Required | - |
| `callbackUrl` | `string` | Query, Optional | A Report Listener URL to receive notifications. The webhook must respond to the Finicity API with a 2xx HTTP status code. |
| `includePending` | `bool?` | Query, Optional | If pending transactions must be included<br>**Default**: `false` |

## Response Type

[`Task<Models.TransactionsReportAck>`](../../doc/models/transactions-report-ack.md)

## Example Usage

```csharp
string customerId = "1005061234";
long toDate = 1607450357L;
var body = new TransactionsReportConstraints();
body.AccountIds = "1027339038 1027339039";
body.FromDate = 1580558400L;
body.ReportCustomFields = new List<ReportCustomField>();

var bodyReportCustomFields0 = new ReportCustomField();
bodyReportCustomFields0.Label = "loanID";
bodyReportCustomFields0.MValue = "12345";
bodyReportCustomFields0.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields0);

var bodyReportCustomFields1 = new ReportCustomField();
bodyReportCustomFields1.Label = "trackingID";
bodyReportCustomFields1.MValue = "5555";
bodyReportCustomFields1.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields1);

var bodyReportCustomFields2 = new ReportCustomField();
bodyReportCustomFields2.Label = "loanType";
bodyReportCustomFields2.MValue = "car";
bodyReportCustomFields2.Shown = false;
body.ReportCustomFields.Add(bodyReportCustomFields2);

var bodyReportCustomFields3 = new ReportCustomField();
bodyReportCustomFields3.Label = "vendorID";
bodyReportCustomFields3.MValue = "1613aa23";
bodyReportCustomFields3.Shown = true;
body.ReportCustomFields.Add(bodyReportCustomFields3);

var bodyReportCustomFields4 = new ReportCustomField();
bodyReportCustomFields4.Label = "vendorName";
bodyReportCustomFields4.MValue = "PSC Finance";
bodyReportCustomFields4.Shown = false;
body.ReportCustomFields.Add(bodyReportCustomFields4);

string callbackUrl = "https://finicity-test/webhook";
bool? includePending = false;

try
{
    TransactionsReportAck result = await transactionsController.GenerateTransactionsReportAsync(customerId, toDate, body, callbackUrl, includePending);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

