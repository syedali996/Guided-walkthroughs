# Institutions

Search and fetch financial institutions

```csharp
InstitutionsController institutionsController = client.InstitutionsController;
```

## Class Name

`InstitutionsController`

## Methods

* [Get Certified Institutions With RSSD](../../doc/controllers/institutions.md#get-certified-institutions-with-rssd)
* [Get Institutions](../../doc/controllers/institutions.md#get-institutions)
* [Get Certified Institutions](../../doc/controllers/institutions.md#get-certified-institutions)
* [Get Institution](../../doc/controllers/institutions.md#get-institution)
* [Get Institution Branding](../../doc/controllers/institutions.md#get-institution-branding)


# Get Certified Institutions With RSSD

Search for certified financial institutions w/RSSD.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCertifiedInstitutionsWithRSSDAsync(
    string search = null,
    int? start = 1,
    int? limit = 25,
    string type = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`Task<Models.CertifiedInstitutions>`](../../doc/models/certified-institutions.md)

## Example Usage

```csharp
string search = "finbank";
int? start = 1;
int? limit = 25;
string type = "voa";

try
{
    CertifiedInstitutions result = await institutionsController.GetCertifiedInstitutionsWithRSSDAsync(search, start, limit, type);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institutions

Search for financial institutions.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetInstitutionsAsync(
    string search = null,
    int? start = 1,
    int? limit = 25,
    string type = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`Task<Models.Institutions>`](../../doc/models/institutions.md)

## Example Usage

```csharp
string search = "finbank";
int? start = 1;
int? limit = 25;
string type = "voa";

try
{
    Institutions result = await institutionsController.GetInstitutionsAsync(search, start, limit, type);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Certified Institutions

Search for financial institutions by certified product.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCertifiedInstitutionsAsync(
    string search = null,
    int? start = 1,
    int? limit = 25,
    string type = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `search` | `string` | Query, Optional | Search term (financial institution `name` field). Leave empty for all FIs. |
| `start` | `int?` | Query, Optional | Index of the page of results to return<br>**Default**: `1` |
| `limit` | `int?` | Query, Optional | Maximum number of results per page<br>**Default**: `25`<br>**Constraints**: `<= 1000` |
| `type` | `string` | Query, Optional | A product type: "transAgg", "ach", "stateAgg", "voi", "voa", "aha", "availBalance", "accountOwner" |

## Response Type

[`Task<Models.CertifiedInstitutions>`](../../doc/models/certified-institutions.md)

## Example Usage

```csharp
string search = "finbank";
int? start = 1;
int? limit = 25;
string type = "voa";

try
{
    CertifiedInstitutions result = await institutionsController.GetCertifiedInstitutionsAsync(search, start, limit, type);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution

Get financial institution details by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetInstitutionAsync(
    long institutionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institutionId` | `long` | Template, Required | The institution ID |

## Response Type

[`Task<Models.InstitutionWrapper>`](../../doc/models/institution-wrapper.md)

## Example Usage

```csharp
long institutionId = 4222L;

try
{
    InstitutionWrapper result = await institutionsController.GetInstitutionAsync(institutionId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Institution Branding

Return the branding information for a financial institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetInstitutionBrandingAsync(
    long institutionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institutionId` | `long` | Template, Required | The institution ID |

## Response Type

[`Task<Models.BrandingWrapper>`](../../doc/models/branding-wrapper.md)

## Example Usage

```csharp
long institutionId = 4222L;

try
{
    BrandingWrapper result = await institutionsController.GetInstitutionBrandingAsync(institutionId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

