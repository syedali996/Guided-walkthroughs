# Accounts

Fetch or refresh customer accounts

```csharp
AccountsController accountsController = client.AccountsController;
```

## Class Name

`AccountsController`

## Methods

* [Get Customer Accounts by Institution Login](../../doc/controllers/accounts.md#get-customer-accounts-by-institution-login)
* [Refresh Customer Accounts by Institution Login](../../doc/controllers/accounts.md#refresh-customer-accounts-by-institution-login)
* [Delete Customer Accounts by Institution Login](../../doc/controllers/accounts.md#delete-customer-accounts-by-institution-login)
* [Get Customer Account](../../doc/controllers/accounts.md#get-customer-account)
* [Delete Customer Account](../../doc/controllers/accounts.md#delete-customer-account)
* [Get Customer Accounts](../../doc/controllers/accounts.md#get-customer-accounts)
* [Refresh Customer Accounts](../../doc/controllers/accounts.md#refresh-customer-accounts)
* [Get Customer Accounts by Institution](../../doc/controllers/accounts.md#get-customer-accounts-by-institution)


# Get Customer Accounts by Institution Login

Get all accounts associated with the given institution login. All accounts returned are accessible by a single set of credentials on a single institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAccountsByInstitutionLoginAsync(
    string customerId,
    string institutionLoginId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `institutionLoginId` | `string` | Template, Required | The institution login ID |

## Response Type

[`Task<Models.CustomerAccounts>`](../../doc/models/customer-accounts.md)

## Example Usage

```csharp
string customerId = "1005061234";
string institutionLoginId = "1007302745";

try
{
    CustomerAccounts result = await accountsController.GetCustomerAccountsByInstitutionLoginAsync(customerId, institutionLoginId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Refresh Customer Accounts by Institution Login

Refresh account and transaction data for all accounts associated with a given `institutionLoginId` with a connection to the institution.

Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.

Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.

The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
RefreshCustomerAccountsByInstitutionLoginAsync(
    string customerId,
    string institutionLoginId,
    object body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `institutionLoginId` | `string` | Template, Required | The institution login ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

[`Task<Models.CustomerAccounts>`](../../doc/models/customer-accounts.md)

## Example Usage

```csharp
string customerId = "1005061234";
string institutionLoginId = "1007302745";

try
{
    CustomerAccounts result = await accountsController.RefreshCustomerAccountsByInstitutionLoginAsync(customerId, institutionLoginId, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Customer Accounts by Institution Login

Remove from Finicity aggregation the set of accounts matching the institution login ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
DeleteCustomerAccountsByInstitutionLoginAsync(
    string customerId,
    string institutionLoginId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `institutionLoginId` | `string` | Template, Required | The institution login ID |

## Response Type

`Task`

## Example Usage

```csharp
string customerId = "1005061234";
string institutionLoginId = "1007302745";

try
{
    await accountsController.DeleteCustomerAccountsByInstitutionLoginAsync(customerId, institutionLoginId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Account

Get a customer account by ID.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAccountAsync(
    string customerId,
    string accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |

## Response Type

[`Task<Models.CustomerAccount>`](../../doc/models/customer-account.md)

## Example Usage

```csharp
string customerId = "1005061234";
string accountId = "5011648377";

try
{
    CustomerAccount result = await accountsController.GetCustomerAccountAsync(customerId, accountId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Delete Customer Account

Remove the given account from Finicity aggregation.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
DeleteCustomerAccountAsync(
    string customerId,
    string accountId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `accountId` | `string` | Template, Required | The account ID |

## Response Type

`Task`

## Example Usage

```csharp
string customerId = "1005061234";
string accountId = "5011648377";

try
{
    await accountsController.DeleteCustomerAccountAsync(customerId, accountId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Accounts

Get all accounts owned by the given customer.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAccountsAsync(
    string customerId,
    string status = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `status` | `string` | Query, Optional | A filter to fetch account in the given status |

## Response Type

[`Task<Models.CustomerAccounts>`](../../doc/models/customer-accounts.md)

## Example Usage

```csharp
string customerId = "1005061234";
string status = "pending";

try
{
    CustomerAccounts result = await accountsController.GetCustomerAccountsAsync(customerId, status);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Refresh Customer Accounts

Refresh account and transaction data for all accounts associated with the  given `customerId` with a connection to the institution.

Client apps are not permitted to automate calls to the Refresh services. Active accounts are automatically refreshed by Finicity once per day. Because many financial institutions only post transactions once per day, calling Refresh repeatedly is usually a waste of resources and is not recommended.

Apps may call Refresh services for a specific customer when there is a specific business case for the need of data that is up to date as of the moment. Please discuss with your account manager and systems engineer for further clarification.

The recommended timeout setting for this request is 120 seconds in order to receive a response. However, you can terminate the connection after making the call the operation will still complete. You will have to pull the account records to check for an updated aggregation attempt date to know when the refresh is complete.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
RefreshCustomerAccountsAsync(
    string customerId,
    object body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `body` | `object` | Body, Optional | No payload expected |

## Response Type

[`Task<Models.CustomerAccounts>`](../../doc/models/customer-accounts.md)

## Example Usage

```csharp
string customerId = "1005061234";

try
{
    CustomerAccounts result = await accountsController.RefreshCustomerAccountsAsync(customerId, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |


# Get Customer Accounts by Institution

Get all active accounts owned by the given customer at the given institution.

_Supported regions_: ![🇺🇸](https://flagcdn.com/20x15/us.png)

```csharp
GetCustomerAccountsByInstitutionAsync(
    string customerId,
    long institutionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customerId` | `string` | Template, Required | A customer ID |
| `institutionId` | `long` | Template, Required | The institution ID |

## Response Type

[`Task<Models.CustomerAccounts>`](../../doc/models/customer-accounts.md)

## Example Usage

```csharp
string customerId = "1005061234";
long institutionId = 4222L;

try
{
    CustomerAccounts result = await accountsController.GetCustomerAccountsByInstitutionAsync(customerId, institutionId);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was rejected | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 401 | The request lacks valid authentication credentials. Check "Finicity-App-Key" or "Finicity-App-Token". | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |
| 404 | The resource doesn't exist | [`ErrorMessageErrorException`](../../doc/models/error-message-error-exception.md) |

