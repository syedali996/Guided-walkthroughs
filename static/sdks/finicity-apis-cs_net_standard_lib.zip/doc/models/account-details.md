
# Account Details

## Structure

`AccountDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InterestMarginBalance` | `double?` | Optional | Only available for investment accounts. Net interest earned after deducting interest paid out. |
| `AvailableCashBalance` | `double?` | Optional | Only available for investment accounts. Amount available for cash withdrawal. |
| `VestedBalance` | `double?` | Optional | Only available for investment accounts. Vested amount in account. |
| `CurrentLoanBalance` | `double?` | Optional | Only available for investment accounts. Current loan balance. |
| `AvailableBalanceAmount` | `double?` | Optional | The available balance for the account |

## Example (as JSON)

```json
{
  "interestMarginBalance": null,
  "availableCashBalance": null,
  "vestedBalance": null,
  "currentLoanBalance": null,
  "availableBalanceAmount": null
}
```

