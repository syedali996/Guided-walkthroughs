
# Prequalification Report Asset Summary

## Structure

`PrequalificationReportAssetSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | The asset type: "checking", "savings", "moneyMarket", "cd", "investment" |
| `AvailableBalance` | `double?` | Optional | The available balance for the account |
| `CurrentBalance` | `double` | Required | The current balance of the account |
| `TwoMonthAverage` | `double` | Required | The two month average daily balance of the account |
| `SixMonthAverage` | `double` | Required | The six month average daily balance of the account |
| `BeginningBalance` | `double` | Required | The beginning balance of the account per the time period of the report |

## Example (as JSON)

```json
{
  "currentBalance": 1000,
  "twoMonthAverage": -1865.96,
  "sixMonthAverage": -7616.01,
  "beginningBalance": -17795.6
}
```

