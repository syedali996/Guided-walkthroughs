
# Cash Flow Analytics Account Result

## Structure

`CashFlowAnalyticsAccountResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountDetails` | [`Models.ObbAccountDetails`](../../doc/models/obb-account-details.md) | Required | Details of the account and financial institution |
| `AccountId` | `long` | Required | An account ID represented as a number |
| `CashflowAnalyticsMetrics` | [`Models.CashFlowAnalyticsMetrics`](../../doc/models/cash-flow-analytics-metrics.md) | Optional | Generated cashflow calculations/metrics |
| `CurrentReportRequest` | [`Models.ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Required | Describes the requested attributes of the report |
| `HistoricDataAvailability` | [`Models.ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Required | Describes the availability of data at the time the report was requested |

## Example (as JSON)

```json
{
  "accountDetails": {
    "accountOwner": {
      "address": "123 Main St, Portland, OR 12345",
      "name": "Johnny Appleseed"
    },
    "id": 5011648377,
    "institution": {
      "institutionId": 12345
    }
  },
  "accountId": 5011648377,
  "currentReportRequest": {
    "reportBeginDate": "2022-03-01",
    "reportEndDate": "2022-03-30",
    "reportRequestDate": "03/30/2022 21:47:19",
    "requestedDaysForReport": 90,
    "requestedReportBeginDate": "2022-01-01"
  },
  "historicDataAvailability": {
    "historicAvailabilityBeginDate": "2022-03-01",
    "historicAvailabilityEndDate": "2022-03-30",
    "historicAvailableDays": 30,
    "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
  }
}
```

