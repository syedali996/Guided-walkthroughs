
# Portfolio Consumer

## Structure

`PortfolioConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `FirstName` | `string` | Required | First name(s) / given name(s) |
| `LastName` | `string` | Required | Last name(s) / surname(s) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `Ssn` | `string` | Required | A full SSN with or without hyphens |
| `Birthday` | [`Models.Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `Suffix` | `string` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "ssn": "999-99-9999",
  "birthday": null
}
```

