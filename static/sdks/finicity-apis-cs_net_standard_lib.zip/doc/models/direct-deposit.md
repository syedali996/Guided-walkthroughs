
# Direct Deposit

## Structure

`DirectDeposit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AmountCurrent` | `double?` | Optional | The amount of the deposit |
| `AccountLastFour` | `string` | Optional | The last four numbers of the account the deposit went into |

## Example (as JSON)

```json
{
  "amountCurrent": null,
  "accountLastFour": null
}
```

