
# Customer Account Position

Details for investment account holdings

## Structure

`CustomerAccountPosition`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The id of the investment position |
| `Description` | `string` | Optional | The description of the holding |
| `Symbol` | `string` | Optional | The investment position's market ticker symbol |
| `Units` | `double?` | Optional | The number of units of the holding |
| `CurrentPrice` | `double?` | Optional | The current price of the investment holding |
| `SecurityName` | `string` | Optional | The security name for the investment holding |
| `TransactionType` | `string` | Optional | The transaction type of the holding, such as cash, margin, and more |
| `MarketValue` | `double?` | Optional | Market value of an investment position at the time of retrieval |
| `CostBasis` | `double?` | Optional | The total cost of acquiring the security |
| `Status` | `string` | Optional | The status of the holding |
| `CurrentPriceDate` | `long?` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `SecurityType` | `string` | Optional | Type of security for the investment position |
| `MfType` | `string` | Optional | Type of mutual fund, such as open ended |
| `PosType` | `string` | Optional | Fund type assigned by the FI (long or short) |
| `TotalGLDollar` | `double?` | Optional | Total gain and loss of the position at the time of aggregation in dollars |
| `TotalGLPercent` | `double?` | Optional | Total gain and loss of the position at the time of aggregation in percentage |
| `OptionStrikePrice` | `double?` | Optional | The strike price of the option contract |
| `OptionType` | `string` | Optional | The type of option contract (PUT or CALL) |
| `OptionSharesPerContract` | `double?` | Optional | The number of shares per option contract |
| `OptionExpireDate` | `DateTime?` | Optional | Expiration date of option |
| `FiAssetClass` | `string` | Optional | Financial Institution (FI) defined asset class (COMMON STOCK, COMNEQTY, EQUITY/STOCK, CMA-ISA, CONVERTIBLE PREFERREDS, CORPORATE BONDS, OTHER MONEY FUNDS, ALLOCATION FUNDS, CMA-TAXABLE, FOREIGNEQUITYADRS, COMMONSTOCK, PREFERRED STOCKS, STABLE VALUE, FOREIGN EQUITY ADRS) |
| `AssetClass` | `string` | Optional | An asset class is a grouping of comparable financial securities. These include equities (stocks), fixed income (bonds), and cash equivalent or money market instruments. (DOMESTICBOND, LARGESTOCK, INTLSTOCK, MONEYMRKT, OTHER) |
| `CurrencyRate` | `double?` | Optional | Currency rate, ratio of currency to original currency |
| `SecurityId` | `string` | Optional | The security ID of the transaction |
| `SecurityIdType` | `string` | Optional | The security type. This field is related to the `securityId` field. Possible values:<br><br>* "CUSIP"<br><br>* "ISIN"<br><br>* "SEDOL"<br><br>* "SICC"<br><br>* "VALOR"<br><br>* "WKN" |
| `CostBasisPerShare` | `double?` | Optional | The per share cost of acquiring the security |
| `SubAccountType` | `string` | Optional | The subaccount's type, such as cash |
| `SecurityCurrency` | `string` | Optional | Symbol for the currency that the account is being converted into |
| `TodayGLDollar` | `double?` | Optional | The current day's gain and loss of the position at the time of aggregation in dollars |
| `TodayGLPercent` | `double?` | Optional | The current day's gain and loss of the position at the time of aggregation in percentage |

## Example (as JSON)

```json
{
  "id": null,
  "description": null,
  "symbol": null,
  "units": null,
  "currentPrice": null,
  "securityName": null,
  "transactionType": null,
  "marketValue": null,
  "costBasis": null,
  "status": null,
  "currentPriceDate": null,
  "securityType": null,
  "mfType": null,
  "posType": null,
  "totalGLDollar": null,
  "totalGLPercent": null,
  "optionStrikePrice": null,
  "optionType": null,
  "optionSharesPerContract": null,
  "optionExpireDate": null,
  "fiAssetClass": null,
  "assetClass": null,
  "currencyRate": null,
  "securityId": null,
  "securityIdType": null,
  "costBasisPerShare": null,
  "subAccountType": null,
  "securityCurrency": null,
  "todayGLDollar": null,
  "todayGLPercent": null
}
```

