
# Cash Flow Monthly Cash Flow Credits

## Structure

`CashFlowMonthlyCashFlowCredits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report |
| `NumberOfCredits` | `string` | Required | Number of credits by month |
| `TotalCreditsAmount` | `double` | Required | Total amount of credits by month |
| `LargestCredit` | `double` | Required | Largest credit by month |
| `NumberOfCreditsLessTransfers` | `string` | Required | Number of credits by month (less transfers) |
| `TotalCreditsAmountLessTransfers` | `double` | Required | Total amount of credits by month (less transfers) |
| `AverageCreditAmount` | `double` | Required | The average credit amount |
| `EstimatedNumberOfLoanDeposits` | `string` | Required | The estimated number of loan deposits |
| `EstimatedLoanDepositAmount` | `double` | Required | The estimated loan deposit amount |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfCredits": "3",
  "totalCreditsAmount": 5000,
  "largestCredit": 2000,
  "numberOfCreditsLessTransfers": "2",
  "totalCreditsAmountLessTransfers": 4000,
  "averageCreditAmount": 500,
  "estimatedNumberOfLoanDeposits": "0",
  "estimatedLoanDepositAmount": 0
}
```

