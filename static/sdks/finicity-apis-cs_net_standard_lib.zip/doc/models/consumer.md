
# Consumer

A finicity consumer record

## Structure

`Consumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `FirstName` | `string` | Required | First name(s) / given name(s) |
| `LastName` | `string` | Required | Last name(s) / surname(s) |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `Address` | `string` | Required | A street address |
| `City` | `string` | Required | A city |
| `State` | `string` | Required | A state |
| `Zip` | `string` | Required | A ZIP code |
| `Phone` | `string` | Required | A phone number |
| `Ssn` | `string` | Required | Last 4 digits of a SSN |
| `Birthday` | [`Models.Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `Email` | `string` | Required | An email address |
| `CreatedDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `Suffix` | `string` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "id": "0bf46322c167b562e6cbed9d40e19a4c",
  "firstName": "John",
  "lastName": "Smith",
  "customerId": 1005061234,
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "9999",
  "birthday": null,
  "email": "finicity@test.com",
  "createdDate": 1607450357
}
```

