
# Cash Flow Monthly Cash Flow Balances

## Structure

`CashFlowMonthlyCashFlowBalances`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report |
| `MinDailyBalance` | `double` | Required | Min Daily Balance for each month |
| `MaxDailyBalance` | `double` | Required | Max Daily Balance for each month |
| `AverageDailyBalance` | `double` | Required | Average Daily Balance for each month |
| `StandardDeviationOfDailyBalance` | `string` | Required | Standard Deviation of Daily Balance for each month |
| `NumberOfDaysNegativeBalance` | `string` | Required | Number of Days Negative Balance for each month |
| `NumberOfDaysPositiveBalance` | `string` | Required | Number of Days positive balance for each month |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "minDailyBalance": 3479.39,
  "maxDailyBalance": 3479.39,
  "averageDailyBalance": 3479.39,
  "standardDeviationOfDailyBalance": "20",
  "numberOfDaysNegativeBalance": "6",
  "numberOfDaysPositiveBalance": "0"
}
```

