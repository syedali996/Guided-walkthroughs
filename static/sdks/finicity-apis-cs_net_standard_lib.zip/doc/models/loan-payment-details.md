
# Loan Payment Details

Loan payment details for a customer account

## Structure

`LoanPaymentDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LoanNumber` | `string` | Required | The number of the specific loan under the account. |
| `LoanPaymentNumber` | `string` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. |
| `LoanPaymentAddress` | `string` | Required | The payment address to send manual payments to |
| `AccountDetail` | [`Models.LoanPaymentDetailsAccount`](../../doc/models/loan-payment-details-account.md) | Optional | - |

## Example (as JSON)

```json
{
  "loanNumber": "123456789",
  "loanPaymentNumber": "5231123456789",
  "loanPaymentAddress": "Heartland ECSI       PO Box 718       Wexford PA 15090"
}
```

