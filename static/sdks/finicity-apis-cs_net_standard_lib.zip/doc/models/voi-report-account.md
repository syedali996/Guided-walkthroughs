
# VOI Report Account

## Structure

`VOIReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The ID of the account |
| `Number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `OwnerName` | `string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `OwnerAddress` | `string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `Name` | `string` | Optional | The account name from the institution |
| `Type` | `string` | Optional | One of the values from account types |
| `AggregationStatusCode` | `int?` | Optional | The status of the most recent aggregation attempt |
| `IncomeStreams` | [`List<Models.VOIReportIncomeStream>`](../../doc/models/voi-report-income-stream.md) | Optional | A list of income stream records |
| `Balance` | `double?` | Optional | The cleared balance of the account as-of `balanceDate` |
| `AverageMonthlyBalance` | `double?` | Optional | The average monthly balance of this account |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `AvailableBalance` | `double?` | Optional | The available balance for the account |
| `CurrentBalance` | `double?` | Optional | Current balance of the account |
| `BeginningBalance` | `double?` | Optional | Beginning balance of account per the time period in the report |
| `MiscDeposits` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null,
  "balance": null,
  "averageMonthlyBalance": null,
  "transactions": null,
  "availableBalance": null,
  "currentBalance": null,
  "beginningBalance": null,
  "miscDeposits": null
}
```

