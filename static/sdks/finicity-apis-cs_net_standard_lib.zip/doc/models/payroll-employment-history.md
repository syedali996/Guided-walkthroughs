
# Payroll Employment History

## Structure

`PayrollEmploymentHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AsOfDate` | `long` | Required | The last time the payroll data was updated in the payroll provider's system |
| `EmployerName` | `string` | Required | Name of the employer as stated by the employer in the payroll system |
| `PayrollSource` | `string` | Required | The name of the payroll source where the data was retrieved |
| `Employee` | [`Models.PayrollEmployeeRecord`](../../doc/models/payroll-employee-record.md) | Required | - |
| `Employment` | [`Models.PayrollEmploymentRecord`](../../doc/models/payroll-employment-record.md) | Required | - |
| `Income` | [`Models.PayrollVOEIncomeRecord`](../../doc/models/payroll-voe-income-record.md) | Required | - |

## Example (as JSON)

```json
{
  "asOfDate": 1596175200,
  "employerName": "ACME INC",
  "payrollSource": "finPayroll",
  "employee": {
    "name": "John Doe Smith",
    "givenName": "John",
    "familyName": "Smith"
  },
  "employment": {
    "employerName": "ACME INC",
    "latestPayDate": 1596175200,
    "daysSinceLastPay": 10,
    "numberPayCadenceWithoutPay": 1,
    "employmentStatusCode": "A",
    "employmentStatusName": "Active",
    "workLevelStatus": "Full Time"
  },
  "income": {
    "payFrequency": "Weekly"
  }
}
```

