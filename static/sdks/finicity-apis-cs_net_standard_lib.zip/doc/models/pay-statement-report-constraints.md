
# Pay Statement Report Constraints

## Structure

`PayStatementReportConstraints`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaystatementReport` | [`Models.PayStatementData`](../../doc/models/pay-statement-data.md) | Required | Data to be included within the pay statement report |
| `ReportCustomFields` | [`List<Models.ReportCustomField>`](../../doc/models/report-custom-field.md) | Optional | The `reportCustomFields` parameter is used when experiences are associated with a credit decisioning report.<br><br>Designate up to 5 custom fields that you'd like associated with the report when it's generated. Every custom field consists of three variables: `label`, `value`, and `shown`. The `shown` variable is "true" or "false".<br><br>* "true": (default) display the custom field in the PDF report<br>* "false": don't display the custom field in the PDF report<br><br>For an experience that generates multiple reports, the `reportCustomFields` parameter gets passed to all reports.<br><br>All custom fields display in the Reseller Billing API. |

## Example (as JSON)

```json
{
  "paystatementReport": {
    "assetIds": [
      "assetIds3",
      "assetIds4",
      "assetIds5"
    ],
    "extractEarnings": null,
    "extractDeductions": null,
    "extractDirectDeposit": null
  },
  "reportCustomFields": null
}
```

