
# Balance Analytics Business Summary

## Structure

`BalanceAnalyticsBusinessSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceAnalyticsMetrics` | [`Models.BalanceAnalyticsMetrics`](../../doc/models/balance-analytics-metrics.md) | Optional | Balance analytics metrics and calculations across all accounts in the report |
| `CurrentReportRequest` | [`Models.ObbCurrentReportRequestDetails`](../../doc/models/obb-current-report-request-details.md) | Optional | Describes the requested attributes of the report |
| `HistoricDataAvailability` | [`Models.ObbDataAvailability`](../../doc/models/obb-data-availability.md) | Optional | Describes the availability of historical data for all accounts owned by the business |

## Example (as JSON)

```json
{
  "balanceAnalyticsMetrics": null,
  "currentReportRequest": null,
  "historicDataAvailability": null
}
```

