
# Institution Address

The address of a financial institution

## Structure

`InstitutionAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `City` | `string` | Optional | A city |
| `State` | `string` | Optional | A state |
| `Country` | `string` | Optional | A country code |
| `PostalCode` | `string` | Optional | A ZIP code |
| `AddressLine1` | `string` | Optional | An address line 1 |
| `AddressLine2` | `string` | Optional | An address line 2 |

## Example (as JSON)

```json
{
  "city": null,
  "state": null,
  "country": null,
  "postalCode": null,
  "addressLine1": null,
  "addressLine2": null
}
```

