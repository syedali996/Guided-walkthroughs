
# Customer Account Detail

Additional customer account details. Not all data points will return for each account type. You can see the account type that each data point will return for in descriptions. The data point are also subject to availability by the institution.

## Structure

`CustomerAccountDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DateAsOf` | `long?` | Optional | (All Account Types) Most recent date of the following information. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `AvailableBalanceAmount` | `double` | Required | (Checking/Savings/CD/MoneyMarket) and (Mortgage/Loan) The available balance (typically the current balance with adjustments for any pending transactions) |
| `OpenDate` | `long?` | Optional | (Checking/Savings/CD/MoneyMarket) Date when account was opened. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `PeriodStartDate` | `long?` | Optional | (Checking/Savings/CD/MoneyMarket) Start date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `PeriodEndDate` | `long?` | Optional | End date of period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `PeriodInterestRate` | `double?` | Optional | (Checking/Savings/CD/MoneyMarket) The APY for the current period interest rate |
| `PeriodDepositAmount` | `double?` | Optional | (Checking/Savings/CD/MoneyMarket) Amount deposited in period |
| `PeriodInterestAmount` | `double?` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued during the current period |
| `InterestYtdAmount` | `double?` | Optional | (Checking/Savings/CD/MoneyMarket) Interest accrued year-to-date |
| `InterestPriorYtdAmount` | `double?` | Optional | (Checking/Savings/CD/MoneyMarket) Interest earned in prior year |
| `MaturityDate` | `long?` | Optional | (Checking/Savings/CD/MoneyMarket) Maturity date of account type. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `InterestRate` | `string` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The account's current interest rate |
| `CreditAvailableAmount` | `double?` | Optional | (Credit Card/Line Of Credit) The available credit (typically the credit limit minus the current balance) |
| `CreditMaxAmount` | `double?` | Optional | (Credit Card/Line Of Credit) The account's credit limit |
| `CashAdvanceAvailableAmount` | `double?` | Optional | (Credit Card/Line Of Credit) Currently available cash advance |
| `CashAdvanceMaxAmount` | `double?` | Optional | (Credit Card/Line Of Credit) Maximum cash advance amount |
| `CashAdvanceBalance` | `double?` | Optional | (Credit Card/Line Of Credit) Balance of current cash advance |
| `CashAdvanceInterestRate` | `double?` | Optional | (Credit Card/Line Of Credit) Interest rate for cash advances |
| `CurrentBalance` | `double?` | Optional | (Credit Card/Line Of Credit) and (Investment) Current balance |
| `PaymentMinAmount` | `double?` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) Minimum payment due |
| `PaymentDueDate` | `long?` | Optional | (Credit Card/Line Of Credit) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `PreviousBalance` | `double?` | Optional | (Credit Card/Line Of Credit) Prior balance in last statement |
| `StatementStartDate` | `long?` | Optional | (Credit Card/Line Of Credit) Start date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `StatementEndDate` | `long?` | Optional | (Credit Card/Line Of Credit) End date of statement period. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `StatementPurchaseAmount` | `double?` | Optional | (Credit Card/Line Of Credit) Purchase amount of statement period |
| `StatementFinanceAmount` | `double?` | Optional | (Credit Card/Line Of Credit) Finance amount of statement period |
| `StatementCreditAmount` | `double?` | Optional | (Credit Card/Line Of Credit) Credit amount applied in statement period |
| `RewardEarnedBalance` | `int?` | Optional | (Credit Card/Line Of Credit) Earned reward balance |
| `PastDueAmount` | `double?` | Optional | (Credit Card/Line Of Credit) Balance past due |
| `LastPaymentAmount` | `double?` | Optional | (Credit Card/Line Of Credit) and (Mortgage/Loan) The amount received in the last payment |
| `LastPaymentDate` | `long?` | Optional | (Credit Card/Line Of Credit) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `StatementCloseBalance` | `double?` | Optional | (Credit Card/Line Of Credit) Balance of statement at close |
| `TermOfMl` | `string` | Optional | (Mortgage/Loan) Length of loan in months |
| `MlHolderName` | `string` | Optional | (Mortgage/Loan) Holder of the mortgage or loan |
| `Description` | `string` | Optional | (Mortgage/Loan) Description of loan |
| `LateFeeAmount` | `double?` | Optional | (Mortgage/Loan) Late fee charged |
| `PayoffAmount` | `double?` | Optional | (Mortgage/Loan) The amount required to payoff the loan |
| `PayoffAmountDate` | `long?` | Optional | (Mortgage/Loan) Date of final payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `OriginalMaturityDate` | `long?` | Optional | (Mortgage/Loan) Original date of loan maturity. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `PrincipalBalance` | `double?` | Optional | (Mortgage/Loan) The principal balance |
| `EscrowBalance` | `double?` | Optional | (Mortgage/Loan) The escrow balance |
| `InterestPeriod` | `string` | Optional | (Mortgage/Loan) Period of interest |
| `InitialMlAmount` | `double?` | Optional | (Mortgage/Loan) Original loan amount |
| `InitialMlDate` | `long?` | Optional | (Mortgage/Loan) Original date of loan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `NextPaymentPrincipalAmount` | `double?` | Optional | (Mortgage/Loan) Amount towards principal in next payment |
| `NextPaymentInterestAmount` | `double?` | Optional | (Mortgage/Loan) Amount of interest in next payment |
| `NextPayment` | `double?` | Optional | (Mortgage/Loan) Minimum payment due |
| `NextPaymentDate` | `long?` | Optional | (Mortgage/Loan) Due date for the next payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `LastPaymentDueDate` | `long?` | Optional | (Mortgage/Loan) Due date of last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `LastPaymentReceiveDate` | `long?` | Optional | (Mortgage/Loan) The date of the last payment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `LastPaymentPrincipalAmount` | `double?` | Optional | (Mortgage/Loan) Amount towards principal in last payment |
| `LastPaymentInterestAmount` | `double?` | Optional | (Mortgage/Loan) Amount of interest in last payment |
| `LastPaymentEscrowAmount` | `double?` | Optional | (Mortgage/Loan) Amount towards escrow in last payment |
| `LastPaymentLastFeeAmount` | `double?` | Optional | (Mortgage/Loan) Amount of last fee in last payment |
| `LastPaymentLateCharge` | `double?` | Optional | (Mortgage/Loan) Amount of late charge in last payment |
| `YtdPrincipalPaid` | `double?` | Optional | (Mortgage/Loan) Principal paid year-to-date |
| `YtdInterestPaid` | `double?` | Optional | (Mortgage/Loan) Interest paid year-to-date |
| `YtdInsurancePaid` | `double?` | Optional | (Mortgage/Loan) Insurance paid year-to-date |
| `YtdTaxPaid` | `double?` | Optional | (Mortgage/Loan) Tax paid year-to-date |
| `AutoPayEnrolled` | `bool?` | Optional | (Mortgage/Loan) Enrolled in autopay (F/Y) |
| `Collateral` | `string` | Optional | (Mortgage/Loan) Collateral on loan |
| `CurrentSchool` | `string` | Optional | (Mortgage/Loan) Current school |
| `FirstPaymentDate` | `long?` | Optional | (Mortgage/Loan) First payment due date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `FirstMortgage` | `bool?` | Optional | (Mortgage/Loan) First mortgage (F/Y) |
| `LoanPaymentFreq` | `string` | Optional | (Mortgage/Loan) Frequency of payments (monthly, etc.) |
| `OriginalSchool` | `string` | Optional | (Mortgage/Loan) Original school |
| `RecurringPaymentAmount` | `double?` | Optional | (Mortgage/Loan) Recurring payment amount |
| `Lender` | `string` | Optional | (Mortgage/Loan) Owner of loan |
| `EndingBalanceAmount` | `double?` | Optional | (Mortgage/Loan) Ending balance |
| `LoanTermType` | `string` | Optional | (Mortgage/Loan) Type of loan term |
| `PaymentsMade` | `int?` | Optional | (Mortgage/Loan) Number of payments made |
| `BalloonAmount` | `double?` | Optional | (Mortgage/Loan) Balloon payment amount |
| `ProjectedInterest` | `double?` | Optional | (Mortgage/Loan) Projected interest on the loan |
| `InterestPaidLtd` | `double?` | Optional | (Mortgage/Loan) Interest paid since inception of loan (life to date) |
| `InterestRateType` | `string` | Optional | (Mortgage/Loan) Type of interest rate |
| `LoanPaymentType` | `string` | Optional | (Mortgage/Loan) Type of loan payment |
| `RepaymentPlan` | `string` | Optional | (Mortgage/Loan) Type of repayment plan for the student loan |
| `PaymentsRemaining` | `int?` | Optional | (Mortgage/Loan) Number of payments remaining before loan is paid off |
| `MarginBalance` | `double?` | Optional | (Investment) Net interest earned after deducting interest paid out |
| `ShortBalance` | `double?` | Optional | (Investment) Sum of short balance |
| `AvailableCashBalance` | `double?` | Optional | (Investment) Amount available for cash withdrawal |
| `MaturityValueAmount` | `double?` | Optional | (Investment) amount payable to an investor at maturity |
| `VestedBalance` | `double?` | Optional | (Investment) Vested amount in account |
| `EmpMatchAmount` | `double?` | Optional | (Investment) Employer matched contributions |
| `EmpPretaxContribAmount` | `double?` | Optional | (Investment) Employer pretax contribution amount |
| `EmpPretaxContribAmountYtd` | `double?` | Optional | (Investment) Employer pretax contribution amount year to date |
| `ContribTotalYtd` | `double?` | Optional | (Investment) Total year to date contributions |
| `CashBalanceAmount` | `double?` | Optional | (Investment) Cash balance of account |
| `PreTaxAmount` | `double?` | Optional | (Investment) Pre tax amount of total balance |
| `AfterTaxAmount` | `double?` | Optional | (Investment) Post tax amount of total balance |
| `MatchAmount` | `double?` | Optional | (Investment) Amount matched |
| `ProfitSharingAmount` | `double?` | Optional | (Investment) Amount of balance for profit sharing |
| `RolloverAmount` | `double?` | Optional | (Investment) Amount of balance rolled over from original account (401k, etc.) |
| `OtherVestAmount` | `double?` | Optional | (Investment) Other vested amount |
| `OtherNonvestAmount` | `double?` | Optional | (Investment) Other nonvested amount |
| `CurrentLoanBalance` | `double?` | Optional | (Investment) Current loan balance |
| `LoanRate` | `double?` | Optional | (Investment) Interest rate of loan |
| `BuyPower` | `double?` | Optional | (Investment) Money available to buy securities |
| `RolloverLtd` | `double?` | Optional | (Investment) Life to date of money rolled over |
| `LoanAwardId` | `string` | Optional | (Student Loan) The federal unique loan identifying number |
| `OriginalInterestRate` | `double?` | Optional | (Student Loan) The original interest rate to which the loan was disbursed, in APY |
| `Guarantor` | `string` | Optional | (Student Loan) The financial institution guarantor of the loan (who will pay the loan amount to the owner if the borrower defaults) |
| `Owner` | `string` | Optional | (Student Loan) Owner of the loan |
| `InterestSubsidyType` | `string` | Optional | (Student Loan) The indication of the presence of an interest subsidy (i.e. subsidized) |
| `InterestBalance` | `double?` | Optional | (Student Loan) The total outstanding interest balance |
| `RemainingTermOfMl` | `double?` | Optional | (Student Loan) The number of months still outstanding on a loan |
| `InitialInterestRate` | `double?` | Optional | (Student Loan) Initial interest rate of loan |
| `FeesBalance` | `double?` | Optional | (Student Loan) The total outstanding fees balance |
| `LoanYtdInterestPaid` | `double?` | Optional | (Student Loan) Loan interest paid year-to-date |
| `LoanYtdFeesPaid` | `double?` | Optional | (Student Loan) Loan fees paid year-to-date |
| `LoanYtdPrincipalPaid` | `double?` | Optional | (Student Loan) Loan principal paid year-to-date |
| `LoanStatus` | `string` | Optional | (Student Loan) The repayment status phase (i.e. In School, Grace, Repayment, Deferment, Forbearance) |
| `LoanStatusStartDate` | `long?` | Optional | (Student Loan) The start date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `LoanStatusEndDate` | `long?` | Optional | (Student Loan) The end date of the current status. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `WeightedInterestRate` | `double?` | Optional | (Student Loan) The interest rate of multiple interest rates and balances at the group level, in APY |
| `RepaymentPlanStartDate` | `long?` | Optional | (Student Loan) The start date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `RepaymentPlanEndDate` | `long?` | Optional | (Student Loan) The end date of the current repayment plan. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `ExpectedPayoffDate` | `long?` | Optional | (Student Loan) The expected date of the payoff date. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `OutOfSchoolDate` | `long?` | Optional | (Student Loan) The date the borrower graduated or dropped below half-time enrollment in school. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `ConvertToRepayment` | `long?` | Optional | (Student Loan) The date the loan enters into repayment. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `DaysDelinquent` | `int?` | Optional | (Student Loan) The number of days past a due date that a payment should have been made |
| `TotalPrincipalPaid` | `double?` | Optional | (Student Loan) The total amount paid towards the principal balance |
| `TotalInterestPaid` | `double?` | Optional | (Student Loan) The total amount paid towards interest |
| `TotalAmountPaid` | `double?` | Optional | (Student Loan) The total amount paid |

## Example (as JSON)

```json
{
  "availableBalanceAmount": 5678.78
}
```

