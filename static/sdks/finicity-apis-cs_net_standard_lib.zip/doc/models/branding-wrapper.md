
# Branding Wrapper

## Structure

`BrandingWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Branding` | [`Models.Branding`](../../doc/models/branding.md) | Required | All assets are SVGs so can be slightly resized without any issues. |

## Example (as JSON)

```json
{
  "branding": {
    "logo": null,
    "alternateLogo": null,
    "icon": null,
    "primaryColor": null,
    "tile": null
  }
}
```

