
# VOA With Income Report Account

## Structure

`VOAWithIncomeReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The ID of the account |
| `Number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `OwnerName` | `string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `OwnerAddress` | `string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `Name` | `string` | Optional | The account name from the institution |
| `Type` | `string` | Optional | One of the values from account types |
| `AvailableBalance` | `double?` | Optional | The available balance for the account |
| `AggregationStatusCode` | `int?` | Optional | The status of the most recent aggregation attempt |
| `Balance` | `double?` | Optional | The cleared balance of the account as-of balanceDate |
| `BalanceDate` | `long?` | Optional | A timestamp showing when the balance was captured |
| `AverageMonthlyBalance` | `double?` | Optional | The average monthly balance of this account |
| `TotNumberInsufficientFundsFeeDebitTxAccount` | `long?` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report. |
| `TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `long?` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. |
| `TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `long?` | Optional | The number of days since the most recent insufficient funds transaction, based on the `fromDate` of the report. |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `Details` | [`Models.AccountDetails`](../../doc/models/account-details.md) | Optional | - |
| `Asset` | [`Models.PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `IncomeStreams` | [`List<Models.VOAIReportIncomeStream>`](../../doc/models/voai-report-income-stream.md) | Optional | A list of income stream records |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "availableBalance": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver2MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "details": null,
  "asset": null,
  "incomeStreams": null
}
```

