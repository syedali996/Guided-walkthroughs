
# New Consumer

A new consumer to be created

## Structure

`NewConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Required | First name(s) / given name(s) |
| `LastName` | `string` | Required | Last name(s) / surname(s) |
| `Address` | `string` | Required | A street address |
| `City` | `string` | Required | A city |
| `State` | `string` | Required | A state |
| `Zip` | `string` | Required | A ZIP code |
| `Phone` | `string` | Required | A phone number |
| `Ssn` | `string` | Required | A full SSN with or without hyphens |
| `Birthday` | [`Models.Birthday`](../../doc/models/birthday.md) | Required | A birth date |
| `Email` | `string` | Optional | An email address |
| `Suffix` | `string` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "firstName": "John",
  "lastName": "Smith",
  "address": "434 W Ascension Way",
  "city": "Murray",
  "state": "UT",
  "zip": "84123",
  "phone": "1-800-986-3343",
  "ssn": "999-99-9999",
  "birthday": null
}
```

