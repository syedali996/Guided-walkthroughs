
# Cash Flow Negative Triggers

## Structure

`CashFlowNegativeTriggers`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `InsufficientFundFees` | [`Models.CashFlowInsufficientFundsFees`](../../doc/models/cash-flow-insufficient-funds-fees.md) | Optional | Non Sufficient Fund Fees |

## Example (as JSON)

```json
{
  "insufficientFundFees": null
}
```

