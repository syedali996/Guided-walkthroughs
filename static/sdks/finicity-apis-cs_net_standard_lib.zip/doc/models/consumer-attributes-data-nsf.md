
# Consumer Attributes Data NSF

## Structure

`ConsumerAttributesDataNSF`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MonthlyNSFOccurrences` | `object` | Required | The number of non-sufficient funds occurrences per calendar month |
| `MonthlyLateFeeOccurrences` | `object` | Required | The number of late fee occurrences |

## Example (as JSON)

```json
{
  "monthlyNSFOccurrences": {
    "2021-04-30": 1,
    "2021-07-31": 1
  },
  "monthlyLateFeeOccurrences": {}
}
```

