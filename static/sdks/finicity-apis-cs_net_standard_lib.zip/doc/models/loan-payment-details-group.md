
# Loan Payment Details Group

Group details

## Structure

`LoanPaymentDetailsGroup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `string` | Required | An account ID |
| `GroupNumber` | `string` | Required | Institution's ID of the Student Loan Group |
| `GroupPaymentNumber` | `string` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. |
| `GroupPaymentAddress` | `string` | Required | The payment address to which send manual payments should be sent |
| `GroupFuturePayoffAmount` | `double?` | Optional | The payoff amount for the group |
| `GroupFuturePayoffDate` | `DateTime?` | Optional | The date to which the "Future Payoff Amount" applies |
| `GroupLoanDetail` | [`List<Models.LoanPaymentDetailsLoan>`](../../doc/models/loan-payment-details-loan.md) | Required | - |

## Example (as JSON)

```json
{
  "accountId": "5011648377",
  "groupNumber": "3210-Group A",
  "groupPaymentNumber": "00001234895413-A",
  "groupPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054",
  "groupLoanDetail": {
    "accountId": "5011648377",
    "loanNumber": "3210-Group A-1",
    "loanPaymentNumber": "00001234895413-A-1",
    "loanPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054"
  }
}
```

