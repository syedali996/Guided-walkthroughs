
# Cash Flow Cash Flow Credit Summary

## Structure

`CashFlowCashFlowCreditSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MonthlyCashFlowCreditSummaries` | [`List<Models.CashFlowMonthlyCashFlowCreditSummaries>`](../../doc/models/cash-flow-monthly-cash-flow-credit-summaries.md) | Required | List of attributes for each month |
| `TwelveMonthCreditTotal` | `double` | Required | Sum of all credit transactions for each month for all accounts |
| `TwelveMonthCreditTotalLessTransfers` | `double` | Required | Sum of all monthly credit transactions without transfers for all accounts |
| `SixMonthCreditTotal` | `double` | Required | Six month sum of all credit transactions |
| `SixMonthCreditTotalLessTransfers` | `double` | Required | Six month sum of all monthly credit transactions without transfers for all accounts |
| `TwoMonthCreditTotal` | `double` | Required | Two month sum of all credit transactions |
| `TwoMonthCreditTotalLessTransfers` | `double` | Required | Two month sum of all monthly credit transactions without transfers for all accounts |

## Example (as JSON)

```json
{
  "monthlyCashFlowCreditSummaries": {
    "month": 1512111600,
    "numberOfCredits": "57",
    "totalCreditsAmount": 3479.39,
    "largestCredit": 3000.49,
    "numberOfCreditsLessTransfers": "5",
    "totalCreditsAmountLessTransfers": 25.46,
    "averageCreditAmount": 500,
    "estimatedNumberOfLoanDeposits": "0",
    "estimatedLoanDepositAmount": 0
  },
  "twelveMonthCreditTotal": 1200,
  "twelveMonthCreditTotalLessTransfers": 1000,
  "sixMonthCreditTotal": 750,
  "sixMonthCreditTotalLessTransfers": 500,
  "twoMonthCreditTotal": 150,
  "twoMonthCreditTotalLessTransfers": 100
}
```

