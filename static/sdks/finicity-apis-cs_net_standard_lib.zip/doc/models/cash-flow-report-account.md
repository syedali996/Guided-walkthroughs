
# Cash Flow Report Account

## Structure

`CashFlowReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | Finicity account ID |
| `OwnerName` | `string` | Optional | The name(s) of the account owner(s), retrieved from the institution. |
| `OwnerAddress` | `string` | Optional | The mailing address of the account owner, retrieved from the institution. |
| `Name` | `string` | Optional | The account name from the institution |
| `Number` | `string` | Optional | The account number from the institution (obfuscated) |
| `Type` | `string` | Optional | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) |
| `AggregationStatusCode` | `string` | Optional | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) |
| `CurrentBalance` | `double?` | Optional | The cleared balance of the account as-of `balanceDate` |
| `AvailableBalance` | `double?` | Optional | Available balance |
| `BalanceDate` | `long?` | Optional | A timestamp showing when the `balance` was captured |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `CashFlowBalance` | [`Models.CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - |
| `CashFlowCredit` | [`Models.CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - |
| `CashFlowDebit` | [`Models.CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - |
| `CashFlowCharacteristic` | [`Models.CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "number": null,
  "type": null,
  "aggregationStatusCode": null,
  "currentBalance": null,
  "availableBalance": null,
  "balanceDate": null,
  "transactions": null,
  "cashFlowBalance": null,
  "cashFlowCredit": null,
  "cashFlowDebit": null,
  "cashFlowCharacteristic": null
}
```

