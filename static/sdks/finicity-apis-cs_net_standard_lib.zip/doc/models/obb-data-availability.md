
# Obb Data Availability

## Structure

`ObbDataAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `HistoricAvailabilityBeginDate` | `string` | Required | Begin date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `HistoricAvailabilityEndDate` | `string` | Required | End date for data availability<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `HistoricAvailableDays` | `int` | Required | Days for which transaction details are available |
| `HistoricDataAvailability` | `string` | Required | Description of historic data availability<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "historicAvailabilityBeginDate": "2022-03-01",
  "historicAvailabilityEndDate": "2022-03-30",
  "historicAvailableDays": 30,
  "historicDataAvailability": "Data is available from 2022-03-01 to 2022-03-30"
}
```

