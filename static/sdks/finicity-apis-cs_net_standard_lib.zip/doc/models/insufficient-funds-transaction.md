
# Insufficient Funds Transaction

## Structure

`InsufficientFundsTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double` | Required | Amount of the NSF transaction |
| `Description` | `string` | Optional | Description of the transaction<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `Memo` | `string` | Optional | Transaction memo<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `PostedDate` | `string` | Required | Posted date of the NSF transaction<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `TransactionId` | `long` | Required | Finicity transaction ID |

## Example (as JSON)

```json
{
  "amount": -1.65,
  "postedDate": "2022-12-19",
  "transactionId": 23092384290
}
```

