
# Balance Analytics Report

Balance analytics report data as JSON

## Structure

`BalanceAnalyticsReport`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountResults` | [`List<Models.BalanceAnalyticsAccountResult>`](../../doc/models/balance-analytics-account-result.md) | Optional | Balance results per account |
| `BusinessId` | `int?` | Optional | Business ID |
| `BusinessSummary` | [`Models.BalanceAnalyticsBusinessSummary`](../../doc/models/balance-analytics-business-summary.md) | Optional | Balance analytics summarized across all accounts in the report |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `ReportHeader` | [`Models.ObbReportHeader`](../../doc/models/obb-report-header.md) | Required | Customer and report metadata |
| `RequesterName` | `string` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `Title` | `string` | Required | Title of the report |

## Example (as JSON)

```json
{
  "customerId": 1005061234,
  "reportHeader": {
    "reportDate": "03/17/2022 04:28:38",
    "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
  },
  "title": "Finicity Asset Ready Report (CRA)"
}
```

