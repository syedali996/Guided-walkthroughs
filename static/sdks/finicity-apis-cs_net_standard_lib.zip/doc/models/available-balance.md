
# Available Balance

## Structure

`AvailableBalance`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `RealAccountNumberLast4` | `string` | Required | The last 4 digits of the ACH account number |
| `AvailableBalance` | `double` | Required | The available balance of the account |
| `AvailableBalanceDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `ClearedBalance` | `double` | Required | The cleared balance of the account. Also referred as posted balance, current balance, ledger balance |
| `ClearedBalanceDate` | `long` | Required | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `AggregationStatusCode` | `int` | Required | The status of the most recent aggregation attempt (see [Aggregation Status Codes](https://docs.finicity.com/aggregation-status-codes/)). Won't be present until you have run your first aggregation for the account. |
| `Currency` | `string` | Required | A currency code |

## Example (as JSON)

```json
{
  "id": 1005061234,
  "realAccountNumberLast4": "5678",
  "availableBalance": 173.47,
  "availableBalanceDate": 1607450357,
  "clearedBalance": 222.25,
  "clearedBalanceDate": 1607450357,
  "aggregationStatusCode": null,
  "currency": "USD"
}
```

