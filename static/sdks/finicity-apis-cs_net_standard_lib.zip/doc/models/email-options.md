
# Email Options

Configuration for the Connect email's sent to customers

## Structure

`EmailOptions`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `To` | `string` | Required | The email address for the customer receiving the Connect email |
| `From` | `string` | Optional | The name of a person or business sending the Connect email |
| `SupportPhone` | `string` | Optional | The support phone number listed in the email |
| `Subject` | `string` | Optional | The subject line of the email. The default is "Verify your Financial Information". |
| `FirstName` | `string` | Optional | The first name of the customer or both names of the customers for joint borrowers. Example: "Marvin and Jenny". |
| `InstitutionName` | `string` | Optional | The name of your company |
| `InstitutionAddress` | `string` | Optional | The institution address to appear in the footer of the email |
| `Signature` | `List<string>` | Optional | A signature for the email |

## Example (as JSON)

```json
{
  "to": "alex.salido@finicity.com"
}
```

