
# Report Institution Account

An account record

## Structure

`ReportInstitutionAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | Finicity account ID |
| `OwnerName` | `string` | Required | The name(s) of the account owner(s), retrieved from the institution. |
| `OwnerAddress` | `string` | Required | The mailing address of the account owner, retrieved from the institution. |
| `Name` | `string` | Required | The account name from the institution |
| `Number` | `string` | Required | The account number from the institution (obfuscated) |
| `Type` | `string` | Required | CFR: `ALL` (`checking` / `savings` / `loan` / `mortgage` / `credit card` / `CD` / `MM` / `investment`...) |
| `AggregationStatusCode` | `string` | Required | The status of the most recent aggregation attempt for this account (non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable) |
| `CurrentBalance` | `double?` | Optional | The cleared balance of the account as-of `balanceDate` |
| `AvailableBalance` | `double` | Required | Available balance |
| `BalanceDate` | `long?` | Optional | A timestamp showing when the `balance` was captured |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Required | a list of transaction records |
| `CashFlowBalance` | [`Models.CashFlowCashFlowBalance`](../../doc/models/cash-flow-cash-flow-balance.md) | Optional | - |
| `CashFlowCredit` | [`Models.CashFlowCashFlowCredit`](../../doc/models/cash-flow-cash-flow-credit.md) | Optional | - |
| `CashFlowDebit` | [`Models.CashFlowCashFlowDebit`](../../doc/models/cash-flow-cash-flow-debit.md) | Optional | - |
| `CashFlowCharacteristic` | [`Models.CashFlowCashFlowCharacteristic`](../../doc/models/cash-flow-cash-flow-characteristic.md) | Optional | - |
| `Balance` | `double` | Required | The cleared balance of the account as-of `balanceDate` |
| `AverageMonthlyBalance` | `double` | Required | The average monthly balance of the account |
| `TotNumberInsufficientFundsFeeDebitTxAccount` | `int?` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report |
| `TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `int?` | Optional | The total number of  insufficient funds fees for the account over six months |
| `TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `long?` | Optional | The total number of days since the most recent insufficient funds fee for the account |
| `Asset` | [`Models.PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `Details` | [`Models.AccountDetails`](../../doc/models/account-details.md) | Optional | - |
| `TotNumberInsufficientFundsFeeDebitTxOver2MonthsAccount` | `long?` | Optional | The count for the total number of insufficient funds transactions for the last two months, based on the `fromDate` of the report. |
| `IncomeStreams` | [`List<Models.VOAIReportIncomeStream2>`](../../doc/models/voai-report-income-stream-2.md) | Required | A list of income stream records |
| `BeginningBalance` | `double?` | Optional | Beginning balance of account per the time period in the report |
| `MiscDeposits` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | A list of miscellaneous deposits<br>**Constraints**: *Minimum Items*: `0`, *Maximum Items*: `100` |

## Example (as JSON)

```json
{
  "id": "6681984",
  "ownerName": "PATRICK & LORRAINE PURCHASER",
  "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
  "name": "Checking",
  "number": "XX1111",
  "type": "checking",
  "aggregationStatusCode": "0",
  "availableBalance": 1000,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  },
  "balance": 501.24,
  "averageMonthlyBalance": 501.02,
  "incomeStreams": {
    "id": "dens28i3vsch-voah",
    "name": "none",
    "status": null,
    "estimateInclusion": null,
    "confidence": 70,
    "cadence": null,
    "netMonthly": [
      {
        "month": 1522562400,
        "net": 2004.77
      }
    ],
    "netAnnual": 110475.7,
    "projectedNetAnnual": 0,
    "estimatedGrossAnnual": 12321.1,
    "projectedGrossAnnual": 151609,
    "averageMonthlyIncomeNet": 9206.31,
    "incomeStreamMonths": 18,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    },
    "daysSinceLastTransaction": 15,
    "nextExpectedTransactionDate": 1572625469
  }
}
```

