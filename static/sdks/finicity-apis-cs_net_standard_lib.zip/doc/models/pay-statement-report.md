
# Pay Statement Report

A Pay Statement report

## Structure

`PayStatementReport`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | A report ID |
| `CustomerType` | `string` | Optional | The type of customer ("active" or "testing" or "" for all types) |
| `CustomerId` | `long?` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `RequestId` | `string` | Optional | Finicity indicator to track all activity associated with this report |
| `RequesterName` | `string` | Optional | Name of a Finicity partner |
| `CreatedDate` | `long?` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `Title` | `string` | Optional | Title of the report |
| `ConsumerId` | `string` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `ConsumerSsn` | `string` | Optional | Last 4 digits of a SSN |
| `Type` | `string` | Optional | A report type. Possible values:<br><br>* "voi"<br><br>* "voa"<br><br>* "voaHistory"<br><br>* "history"<br><br>* "voieTxVerify"<br><br>* "voieWithReport"<br><br>* "voieWithInterview"<br><br>* "paystatement"<br><br>* "preQualVoa"<br><br>* "assetSummary"<br><br>* "voie"<br><br>* "transactions"<br><br>* "statement"<br><br>* "voiePayroll"<br><br>* "voeTransactions"<br><br>* "voePayroll"<br><br>* "cfrp"<br><br>* "cfrb" |
| `Status` | `string` | Optional | A report generation status. Possible values: "inProgress", "success", "failure". |
| `Errors` | [`List<Models.ErrorMessage>`](../../doc/models/error-message.md) | Optional | In case errors occurred during the report generation |
| `PortfolioId` | `string` | Optional | A unique identifier that will be consistent across all reports created for the same customer |
| `StartDate` | `long?` | Optional | The `postedDate` of the earliest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `EndDate` | `long?` | Optional | The `postedDate` of the latest transaction analyzed for the report. A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `ReportStyle` | `string` | Optional | - |
| `NumberOfBillableAssets` | `int?` | Optional | Total number of billable pay statements included in the report |
| `AssetIds` | `List<string>` | Optional | - |
| `PayStatements` | [`List<Models.VOIEPayStatement>`](../../doc/models/voie-pay-statement.md) | Optional | Extracted pay statement details |

## Example (as JSON)

```json
{
  "id": null,
  "customerType": null,
  "customerId": null,
  "requestId": null,
  "requesterName": null,
  "createdDate": null,
  "title": null,
  "consumerId": null,
  "consumerSsn": null,
  "type": null,
  "status": null,
  "errors": null,
  "portfolioId": null,
  "startDate": null,
  "endDate": null,
  "reportStyle": null,
  "numberOfBillableAssets": null,
  "assetIds": null,
  "payStatements": null
}
```

