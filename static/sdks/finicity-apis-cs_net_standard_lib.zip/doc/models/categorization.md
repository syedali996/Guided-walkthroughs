
# Categorization

Categorization Record

## Structure

`Categorization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NormalizedPayeeName` | `string` | Required | A normalized payee, derived from the transaction's description and memo fields |
| `Category` | `string` | Required | The different categories for transactions.<br><br>* "ATM Fee"<br><br>* "Advertising"<br><br>* "Air Travel"<br><br>* "Alcohol & Bars"<br><br>* "Allowance"<br><br>* "Amusement"<br><br>* "Arts"<br><br>* "Auto & Transport"<br><br>* "Auto Insurance"<br><br>* "Auto Payment"<br><br>* "Baby Supplies"<br><br>* "Babysitter & Daycare"<br><br>* "Bank Fee"<br><br>* "Bills & Utilities"<br><br>* "Bonus"<br><br>* "Books"<br><br>* "Books & Supplies"<br><br>* "Business Services"<br><br>* "Buy"<br><br>* "Cash & ATM"<br><br>* "Charity"<br><br>* "Check"<br><br>* "Child Support"<br><br>* "Clothing"<br><br>* "Coffee Shops"<br><br>* "Credit Card Payment"<br><br>* "Dentist"<br><br>* "Deposit"<br><br>* "Dividend & Cap Gains"<br><br>* "Doctor"<br><br>* "Education"<br><br>* "Electronics & Software"<br><br>* "Entertainment"<br><br>* "Eyecare"<br><br>* "Fast Food"<br><br>* "Federal Tax"<br><br>* "Fees & Charges"<br><br>* "Finance Charge"<br><br>* "Financial"<br><br>* "Financial Advisor"<br><br>* "Food & Dining"<br><br>* "Furnishings"<br><br>* "Gas & Fuel"<br><br>* "Gift"<br><br>* "Gifts & Donations"<br><br>* "Groceries"<br><br>* "Gym"<br><br>* "Hair"<br><br>* "Health & Fitness"<br><br>* "Health Insurance"<br><br>* "Hobbies"<br><br>* "Home"<br><br>* "Home Improvement"<br><br>* "Home Insurance"<br><br>* "Home Phone"<br><br>* "Home Services"<br><br>* "Home Supplies"<br><br>* "Hotel"<br><br>* "Income"<br><br>* "Interest Income"<br><br>* "Internet"<br><br>* "Investments"<br><br>* "Kids"<br><br>* "Kids Activities"<br><br>* "Late Fee"<br><br>* "Laundry"<br><br>* "Lawn & Garden"<br><br>* "Legal"<br><br>* "Life Insurance"<br><br>* "Loan Fees and Charges"<br><br>* "Loan Insurance"<br><br>* "Loan Interest"<br><br>* "Loan Payment"<br><br>* "Loan Principal"<br><br>* "Loans"<br><br>* "Local Tax"<br><br>* "Low Balance"<br><br>* "Mobile Phone"<br><br>* "Mortgage & Rent"<br><br>* "Movies & DVDs"<br><br>* "Music"<br><br>* "Newspapers & Magazines"<br><br>* "Office Supplies"<br><br>* "Parking"<br><br>* "Paycheck"<br><br>* "Personal Care"<br><br>* "Pet Food & Supplies"<br><br>* "Pet Grooming"<br><br>* "Pets"<br><br>* "Pharmacy"<br><br>* "Printing"<br><br>* "Property Tax"<br><br>* "Public Transportation"<br><br>* "Reimbursement"<br><br>* "Rental Car & Taxi"<br><br>* "Restaurants"<br><br>* "Sales Tax"<br><br>* "Sell"<br><br>* "Services & Parts"<br><br>* "Service Fee"<br><br>* "Shipping"<br><br>* "Shopping"<br><br>* "Spa & Massage"<br><br>* "Sporting Goods"<br><br>* "Sports"<br><br>* "State Tax"<br><br>* "Streaming Services"<br><br>* "Student Loan"<br><br>* "Taxes"<br><br>* "Television"<br><br>* "Toys"<br><br>* "Trade Commissions"<br><br>* "Transfer"<br><br>* "Transfer for Cash Spending"<br><br>* "Travel"<br><br>* "Tuition"<br><br>* "Uncategorized"<br><br>* "Utilities"<br><br>* "Vacation"<br><br>* "Veterinary"<br><br>* "Internet / Broadband Charges" |
| `City` | `string` | Optional | A city |
| `State` | `string` | Optional | A state |
| `PostalCode` | `string` | Optional | A ZIP code |
| `Country` | `string` | Required | A country code |
| `BestRepresentation` | `string` | Optional | Combines the `description` and `memo` data together, removing duplicated information and numbers and special characters |

## Example (as JSON)

```json
{
  "normalizedPayeeName": "Mad Science Research",
  "category": "ATM Fee",
  "country": "USA"
}
```

