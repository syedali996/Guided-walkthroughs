
# Net Monthly

## Structure

`NetMonthly`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Month` | `long` | Required | Timestamp for the first day of this month |
| `Net` | `double` | Required | Total income during the given month, across all income streams |

## Example (as JSON)

```json
{
  "month": 1522562400,
  "net": 2004.77
}
```

