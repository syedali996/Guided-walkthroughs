
# Created Consumer

A consumer that was just created

## Structure

`CreatedConsumer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | A consumer ID. See Create Consumer API for how to create a consumer ID. |
| `CreatedDate` | `long?` | Optional | A date in Unix epoch time (in seconds). See: [Handling Epoch Dates and Times](https://docs.finicity.com/endpoint-syntax-and-format/). |
| `CustomerId` | `long?` | Optional | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |

## Example (as JSON)

```json
{
  "id": null,
  "createdDate": null,
  "customerId": null
}
```

