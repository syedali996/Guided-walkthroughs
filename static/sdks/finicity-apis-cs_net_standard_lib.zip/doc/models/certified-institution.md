
# Certified Institution

## Structure

`CertifiedInstitution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long` | Required | The ID of a financial institution, represented as a number |
| `Rssd` | `long?` | Optional | The RSSD ID is a unique identifier assigned to financial institutions by the Federal Reserve. While the length of the RSSD ID varies by institution, it cannot exceed 10 numerical digits. |
| `Name` | `string` | Required | The name of the institution |
| `TransAgg` | `bool` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product |
| `Ach` | `bool` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product |
| `StateAgg` | `bool` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product |
| `Voi` | `bool` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product |
| `Voa` | `bool` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product |
| `Aha` | `bool` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product |
| `AvailBalance` | `bool` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product |
| `AccountOwner` | `bool` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product |
| `StudentLoanData` | `bool` | Required | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product |
| `LoanPaymentDetails` | `bool` | Required | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product |
| `ChildInstitutions` | [`List<Models.ChildInstitution>`](../../doc/models/child-institution.md) | Optional | An array of child financial institutions<br>**Constraints**: *Minimum Items*: `0` |

## Example (as JSON)

```json
{
  "id": 4222,
  "name": "FinBank",
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "studentLoanData": true,
  "loanPaymentDetails": true
}
```

