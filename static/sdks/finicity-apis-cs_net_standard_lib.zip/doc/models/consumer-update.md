
# Consumer Update

## Structure

`ConsumerUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | First name(s) / given name(s) |
| `LastName` | `string` | Optional | Last name(s) / surname(s) |
| `Address` | `string` | Optional | A street address |
| `City` | `string` | Optional | A city |
| `State` | `string` | Optional | A state |
| `Zip` | `string` | Optional | A ZIP code |
| `Phone` | `string` | Optional | A phone number |
| `Ssn` | `string` | Optional | A full SSN with or without hyphens |
| `Birthday` | [`Models.Birthday`](../../doc/models/birthday.md) | Optional | A birth date |
| `Email` | `string` | Optional | An email address |
| `Suffix` | `string` | Optional | A person suffix |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null,
  "address": null,
  "city": null,
  "state": null,
  "zip": null,
  "phone": null,
  "ssn": null,
  "birthday": null,
  "email": null,
  "suffix": null
}
```

