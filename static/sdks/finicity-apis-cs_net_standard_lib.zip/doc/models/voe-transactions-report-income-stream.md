
# VOE Transactions Report Income Stream

## Structure

`VOETransactionsReportIncomeStream`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | Income stream ID |
| `Name` | `string` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream |
| `Status` | `string` | Required | Possible values: "ACTIVE", "INACTIVE" |
| `EstimateInclusion` | `string` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" |
| `Confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) |
| `Cadence` | [`Models.CadenceDetails`](../../doc/models/cadence-details.md) | Required | - |
| `DaysSinceLastTransaction` | `int` | Required | The number of days since the last credit transaction for the particular income stream |
| `NextExpectedTransactionDate` | `long` | Required | The next expected credit transaction date for the particular income stream, based on the cadence |
| `IncomeStreamMonths` | `int` | Required | The number of months the income transactions are observed |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Required | A list of transaction records |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voah",
  "name": "none",
  "status": null,
  "estimateInclusion": null,
  "confidence": 70,
  "cadence": null,
  "daysSinceLastTransaction": 15,
  "nextExpectedTransactionDate": 1572625469,
  "incomeStreamMonths": 18,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

