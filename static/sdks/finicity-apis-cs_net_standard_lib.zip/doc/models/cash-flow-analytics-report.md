
# Cash Flow Analytics Report

Cash Flow Analytics report data as JSON

## Structure

`CashFlowAnalyticsReport`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountResults` | [`List<Models.CashFlowAnalyticsAccountResult>`](../../doc/models/cash-flow-analytics-account-result.md) | Optional | Cash flow results per account |
| `BusinessId` | `int?` | Optional | Business ID |
| `BusinessSummary` | [`Models.CashFlowAnalyticsBusinessSummary`](../../doc/models/cash-flow-analytics-business-summary.md) | Optional | Cash flow analytics summarized across all accounts in the report |
| `CustomerId` | `long` | Required | A customer ID represented as a number. See Add Customer API for how to create a customer ID. |
| `ReportHeader` | [`Models.ObbReportHeader`](../../doc/models/obb-report-header.md) | Required | Customer and report metadata |
| `RequesterName` | `string` | Optional | Name of requester<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `Title` | `string` | Required | Title of the report |
| `TotalRevenue` | `double?` | Optional | The total revenue |

## Example (as JSON)

```json
{
  "customerId": 1005061234,
  "reportHeader": {
    "reportDate": "03/17/2022 04:28:38",
    "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
  },
  "title": "Finicity Asset Ready Report (CRA)"
}
```

