
# VOIE With Statement Data

## Structure

`VOIEWithStatementData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AssetIds` | `List<string>` | Required | A list of pay statement asset IDs |
| `ExtractEarnings` | `bool?` | Optional | Field to indicate whether to extract the earnings on all pay statements<br>**Default**: `true` |
| `ExtractDeductions` | `bool?` | Optional | Field to indicate whether to extract the deductions on all pay statements<br>**Default**: `false` |
| `ExtractDirectDeposit` | `bool?` | Optional | Field to indicate whether to extract the direct deposits on all pay statements<br>**Default**: `true` |

## Example (as JSON)

```json
{
  "assetIds": [
    "assetIds3"
  ],
  "extractEarnings": null,
  "extractDeductions": null,
  "extractDirectDeposit": null
}
```

