
# Transactions Report Account

Fields used for the Transaction History Report (CRA products)

## Structure

`TransactionsReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The Finicity account ID |
| `Name` | `string` | Optional | The account name from the financial institution. |
| `Number` | `string` | Optional | The account number from the financial institution (obfuscated) |
| `Type` | `string` | Optional | The list of supported account types.<br><br>* "checking": Standard checking<br>* "savings": Standard savings<br>* "cd": Certificates of deposit<br>* "moneyMarket": Money Market<br>* "creditCard": Standard credit cards<br>* "lineOfCredit": Home equity, line of credit<br>* "investment": Generic investment (no details)<br>* "investmentTaxDeferred": Generic tax-advantaged investment (no details)<br>* "employeeStockPurchasePlan": ESPP, Employee Stock Ownership Plans (ESOP), Stock Purchase Plans<br>* "ira": Individual Retirement Account (not Rollover or Roth)<br>* "401k": 401K Plan<br>* "roth": Roth IRA, Roth 401K<br>* "403b": 403B Plan<br>* "529plan": 529 Plan (True value is 529)<br>* "rollover": Rollover IRA<br>* "ugma": Uniform Gifts to Minors Act<br>* "utma": Uniform Transfers to Minors Act<br>* "keogh": Keogh Plan<br>* "457plan": 457 Plan (True value is 457)<br>* "401a": 401A Plan<br>* "brokerageAccount": Brokerage Account<br>* "educationSavings": Education Savings Account that is not a 529<br>* "healthSavingsAccount": HSA (Health Savings Accounts)<br>* "pension": Pension<br>* "profitSharingPlan": Profit Sharing Plan<br>* "roth401k": Roth 401K<br>* "sepIRA": Simplified Employee Pension IRA<br>* "simpleIRA": Simple IRA<br>* "thriftSavingsPlan": Thrift Savings Plan<br>* "variableAnnuity": Variable Annuity<br>* "cryptocurrency": Cryptocurrency Wallet, Cryptocurrency Account<br>* "mortgage": Standard Mortgages<br>* "loan": Auto loans, equity loans, other loans<br>* "studentLoan": Student Loan<br>* "studentLoanGroup": Student Loan Group<br>* "studentLoanAccount": Student Loan Account |
| `AggregationStatusCode` | `int?` | Optional | The status of the most recent aggregation attempt for this account. Note: non-zero means the account was not accessed successfully for this report, and additional fields for this account may not be reliable. |
| `Balance` | `double?` | Optional | The cleared balance of the account as-of `balanceDate` |
| `BalanceDate` | `long?` | Optional | A timestamp showing when the balance was captured |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "number": null,
  "type": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "transactions": null
}
```

