
# Payroll Employee Record

## Structure

`PayrollEmployeeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Required | Full name of the employee: first, middle (if stated), and last name |
| `GivenName` | `string` | Required | First name of employee |
| `MiddleName` | `string` | Optional | Middle name of employee, if stated |
| `FamilyName` | `string` | Required | Last name of employee |
| `Address` | [`List<Models.PayrollEmployeeAddress>`](../../doc/models/payroll-employee-address.md) | Optional | Array of addresses |

## Example (as JSON)

```json
{
  "name": "John Doe Smith",
  "givenName": "John",
  "familyName": "Smith"
}
```

