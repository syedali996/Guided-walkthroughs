
# Cash Flow Monthlycashflow Debits

## Structure

`CashFlowMonthlycashflowDebits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report |
| `NumberOfDebits` | `string` | Required | Number of Debits by month |
| `TotalDebitsAmount` | `double` | Required | Total Amount of Debits by month |
| `LargestDebit` | `double` | Required | Largest Debit by month |
| `NumberOfDebitsLessTransfers` | `string` | Required | Number of Debits by month (less transfers) |
| `TotalDebitsAmountLessTransfers` | `double` | Required | Total amount of debits by month (less transfers) |
| `AverageDebitAmount` | `double` | Required | The average debit amount |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "numberOfDebits": "5",
  "totalDebitsAmount": -12345,
  "largestDebit": -2000,
  "numberOfDebitsLessTransfers": "3",
  "totalDebitsAmountLessTransfers": -2000,
  "averageDebitAmount": 500
}
```

