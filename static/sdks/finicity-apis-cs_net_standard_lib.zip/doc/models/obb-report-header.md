
# Obb Report Header

Includes details about the business the report is generated for and metadata about the report

## Structure

`ObbReportHeader`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessAddress` | `string` | Optional | Business address line 1<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `BusinessCity` | `string` | Optional | Business address city<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `BusinessName` | `string` | Optional | Name of the business<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `BusinessState` | `string` | Optional | Business address state<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `BusinessZip` | `string` | Optional | Business address zip<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `ReferenceNumber` | `string` | Optional | Partner-provided reference number<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `ReportDate` | `string` | Required | Date the report was requested<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `ReportId` | `string` | Required | Generated unique report ID<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "reportDate": "03/17/2022 04:28:38",
  "reportId": "8ff8b4b2-706f-45c3-8d66-857bdb516214"
}
```

