
# Cash Flow Cash Flow Debit

## Structure

`CashFlowCashFlowDebit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MonthlyCashFlowDebits` | [`List<Models.CashFlowMonthlycashflowDebits>`](../../doc/models/cash-flow-monthlycashflow-debits.md) | Required | List of attributes for each month |
| `TwelveMonthDebitTotal` | `double` | Required | Sum of all monthly debit transactions for each month by account |
| `TwelveMonthDebitTotalLessTransfers` | `double` | Required | Sum of all monthly debit transactions without transfers for the account |
| `SixMonthDebitTotal` | `double` | Required | Six month sum of all debit transactions |
| `SixMonthDebitTotalLessTransfers` | `double` | Required | Six month sum of all debit transactions without transfers for the account |
| `TwoMonthDebitTotal` | `double` | Required | Two month sum of all debit transactions |
| `TwoMonthDebitTotalLessTransfers` | `double` | Required | Two month sum of all debit transactions without transfers for the account |

## Example (as JSON)

```json
{
  "monthlyCashFlowDebits": {
    "month": 1512111600,
    "numberOfDebits": "5",
    "totalDebitsAmount": -12345,
    "largestDebit": -2000,
    "numberOfDebitsLessTransfers": "3",
    "totalDebitsAmountLessTransfers": -2000,
    "averageDebitAmount": 500
  },
  "twelveMonthDebitTotal": 1200,
  "twelveMonthDebitTotalLessTransfers": 1000,
  "sixMonthDebitTotal": 750,
  "sixMonthDebitTotalLessTransfers": 500,
  "twoMonthDebitTotal": 150,
  "twoMonthDebitTotalLessTransfers": 100
}
```

