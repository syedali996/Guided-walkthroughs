
# Last Transaction Date

## Structure

`LastTransactionDate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Date` | `string` | Required | Date the deposit transaction was posted |
| `DepositsCredits` | `double?` | Optional | Amount of transaction if deposit, otherwise null |
| `WithdrawalsDebits` | `double?` | Optional | Amount of transaction if withdrawal, otherwise null |
| `ZeroAmountTransaction` | `double?` | Optional | Amount of transaction if zero, otherwise null |
| `TransactionDescription` | `string` | Optional | Description of transaction |

## Example (as JSON)

```json
{
  "date": "2020-03-25"
}
```

