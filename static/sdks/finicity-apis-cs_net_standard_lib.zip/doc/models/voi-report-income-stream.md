
# VOI Report Income Stream

## Structure

`VOIReportIncomeStream`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | Income stream ID |
| `Name` | `string` | Required | A human-readable name based on the `normalizedPayee` name of the transactions for this income stream |
| `Status` | `string` | Required | Possible values: "ACTIVE", "INACTIVE" |
| `EstimateInclusion` | `string` | Required | Possible values: "HIGH", "MODERATE", "LOW", "NO" |
| `Confidence` | `int` | Required | Level of confidence that the deposit stream represents income (example: 85%) |
| `Cadence` | [`Models.CadenceDetails`](../../doc/models/cadence-details.md) | Required | - |
| `NetMonthly` | [`List<Models.NetMonthly>`](../../doc/models/net-monthly.md) | Required | A list of net monthly records. One instance for each complete calendar month in the report. |
| `NetAnnual` | `double` | Required | Sum of all values in `netMonthlyIncome` over the previous 12 months |
| `ProjectedNetAnnual` | `double` | Required | Projected net income over the next 12 months, across all income streams, based on `netAnnualIncome` |
| `EstimatedGrossAnnual` | `double` | Required | Before-tax gross annual income (estimated from `netAnnual`) across all income stream in the past 12 months |
| `ProjectedGrossAnnual` | `double` | Required | Projected gross income over the next 12 months, across all active income streams, based on `projectedNetAnnual` |
| `AverageMonthlyIncomeNet` | `double` | Required | Monthly average amount over the previous 24 months |
| `IncomeStreamMonths` | `int` | Required | The number of months the income transactions are observed |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Required | A list of transaction records |

## Example (as JSON)

```json
{
  "id": "dens28i3vsch-voi1",
  "name": "none",
  "status": null,
  "estimateInclusion": null,
  "confidence": 70,
  "cadence": null,
  "netMonthly": {
    "month": 1522562400,
    "net": 2004.77
  },
  "netAnnual": 110475.7,
  "projectedNetAnnual": 0,
  "estimatedGrossAnnual": null,
  "projectedGrossAnnual": 151609,
  "averageMonthlyIncomeNet": 9206.31,
  "incomeStreamMonths": 18,
  "transactions": {
    "id": 21284820852,
    "postedDate": 1571313600,
    "description": "ATM CHECK DEPOSIT mm/dd",
    "normalizedPayee": "T-Mobile",
    "institutionTransactionId": "0000000000",
    "category": "Income"
  }
}
```

