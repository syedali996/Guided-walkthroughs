
# Obb Date Range and Amount

## Structure

`ObbDateRangeAndAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Amount` | `double?` | Optional | Metric value for the given period |
| `Period` | `string` | Required | Period represented by this metric<br>**Constraints**: *Minimum Length*: `8`, *Maximum Length*: `12` |
| `PeriodBeginDate` | `string` | Required | Begin date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |
| `PeriodEndDate` | `string` | Required | End date of the period being reported<br>**Constraints**: *Minimum Length*: `10`, *Maximum Length*: `10` |

## Example (as JSON)

```json
{
  "period": "last30to1",
  "periodBeginDate": "2022-03-01",
  "periodEndDate": "2022-03-30"
}
```

