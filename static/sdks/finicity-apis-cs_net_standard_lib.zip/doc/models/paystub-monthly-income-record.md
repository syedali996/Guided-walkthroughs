
# Paystub Monthly Income Record

## Structure

`PaystubMonthlyIncomeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EstimatedMonthlyBasePay` | `double?` | Optional | The estimated monthly base pay amount for the employment from the paystub, calculated by Finicity |
| `EstimatedMonthlyOvertimePay` | `double?` | Optional | The estimated monthly overtime pay amount for the employment from the paystub, calculated by Finicity |
| `EstimatedMonthlyBonusPay` | `double?` | Optional | The estimated monthly bonus pay amount for the employment from the paystub, calculated by Finicity |
| `EstimatedMonthlyCommissionPay` | `double?` | Optional | The estimated commission bonus pay amount for the employment from the paystub, calculated by Finicity |

## Example (as JSON)

```json
{
  "estimatedMonthlyBasePay": null,
  "estimatedMonthlyOvertimePay": null,
  "estimatedMonthlyBonusPay": null,
  "estimatedMonthlyCommissionPay": null
}
```

