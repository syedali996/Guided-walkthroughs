
# Cash Flow Outflow Attributes

## Structure

`CashFlowOutflowAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AverageWithdrawalByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of withdrawals during periods in the report |
| `CountWithdrawalsByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all withdrawals during periods in the report |
| `HistoricCountOfWithdrawalTransactions` | `int` | Required | Count of ALL withdrawals over entire known history of the account (may exceed requested length of report) |
| `HistoricSumOfWithdrawals` | `double?` | Optional | Sum of ALL withdrawals over entire known history of the account (may exceed requested length of report) |
| `MaximumWithdrawalByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum withdrawal value for different periods in the report |
| `MinimumWithdrawalByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum withdrawal value for different periods in the report |
| `SumWithdrawalsByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all withdrawals during periods in the report |

## Example (as JSON)

```json
{
  "countWithdrawalsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfWithdrawalTransactions": 20,
  "maximumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumWithdrawalByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumWithdrawalsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

