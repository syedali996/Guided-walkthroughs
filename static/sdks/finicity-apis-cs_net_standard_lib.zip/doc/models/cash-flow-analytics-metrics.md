
# Cash Flow Analytics Metrics

## Structure

`CashFlowAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Inflow` | [`Models.CashFlowInflowAttributes`](../../doc/models/cash-flow-inflow-attributes.md) | Optional | Inflow Attributes |
| `NegativeTriggers` | [`Models.CashFlowNegativeTriggers`](../../doc/models/cash-flow-negative-triggers.md) | Optional | Details of transactions that may be warning signs of bad creditworthiness |
| `Outflow` | [`Models.CashFlowOutflowAttributes`](../../doc/models/cash-flow-outflow-attributes.md) | Optional | Outflow attributes |
| `RevenueByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Sum of all transactions categorized as revenue, split by months |
| `RevenueForTheReportTimePeriod` | `double?` | Optional | Sum of all transactions categorized as revenue |
| `TransactionAnalytics` | [`Models.CashFlowTransactionAnalyticsAttributes`](../../doc/models/cash-flow-transaction-analytics-attributes.md) | Optional | Transaction Analytics Attributes |

## Example (as JSON)

```json
{
  "inflow": null,
  "negativeTriggers": null,
  "outflow": null,
  "revenueByMonthForTheReportTimePeriod": null,
  "revenueForTheReportTimePeriod": null,
  "transactionAnalytics": null
}
```

