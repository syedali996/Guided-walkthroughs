
# Loan Payment Details Account

## Structure

`LoanPaymentDetailsAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `string` | Required | An account ID |
| `AccountNumber` | `string` | Required | Institution's ID of the Student Loan Account |
| `AccountPaymentNumber` | `string` | Required | The payment number given by the institution. This number is typically for manual payments. This is not an ACH payment number. |
| `AccountPaymentAddress` | `string` | Required | The payment address to which send manual payments should be sent |
| `AccountFuturePayoffAmount` | `double?` | Optional | The payoff amount for the account |
| `AccountFuturePayoffDate` | `DateTime?` | Optional | The date to which the "Future Payoff Amount" applies |
| `GroupDetail` | [`List<Models.LoanPaymentDetailsGroup>`](../../doc/models/loan-payment-details-group.md) | Optional | Group details |
| `LoanDetail` | [`List<Models.LoanPaymentDetailsLoan>`](../../doc/models/loan-payment-details-loan.md) | Optional | Loan details |

## Example (as JSON)

```json
{
  "accountId": "5011648377",
  "accountNumber": "9876543210",
  "accountPaymentNumber": "00001234895413",
  "accountPaymentAddress": "P.O. Box 123 Sioux Falls, IA 51054"
}
```

