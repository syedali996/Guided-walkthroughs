
# VOE Transactions Report Account

## Structure

`VOETransactionsReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The ID of the account |
| `Number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `OwnerName` | `string` | Optional | The name(s) of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `OwnerAddress` | `string` | Optional | The mailing address of the account owner(s). This field is optional. If no owner information is available, this field will not appear in the report. |
| `Name` | `string` | Optional | The account name from the institution |
| `Type` | `string` | Optional | One of the values from account types |
| `AggregationStatusCode` | `int?` | Optional | The status of the most recent aggregation attempt |
| `IncomeStreams` | [`List<Models.VOETransactionsReportIncomeStream>`](../../doc/models/voe-transactions-report-income-stream.md) | Optional | A list of income stream records |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "incomeStreams": null
}
```

