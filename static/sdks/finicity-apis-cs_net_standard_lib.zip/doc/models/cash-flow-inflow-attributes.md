
# Cash Flow Inflow Attributes

## Structure

`CashFlowInflowAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AverageDepositByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average value of deposits during periods in the report |
| `CountDepositsByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Required | Count of all deposits during periods in the report |
| `HistoricCountOfDepositTransactions` | `int` | Required | Count of ALL deposits over entire known history of the account (may exceed requested length of report) |
| `HistoricSumOfDeposits` | `double?` | Optional | Sum of ALL deposits over entire known history of the account (may exceed requested length of report) |
| `MaximumDepositByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Maximum deposit value for different periods in the report |
| `MinimumDepositByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Minimum deposit value for different periods in the report |
| `SumDepositsByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Required | Sum of all deposits during periods in the report |

## Example (as JSON)

```json
{
  "countDepositsByMonthForTheReportTimePeriod": {
    "count": 5,
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "historicCountOfDepositTransactions": 20,
  "maximumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "minimumDepositByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  },
  "sumDepositsByMonthForTheReportTimePeriod": {
    "period": "last30to1",
    "periodBeginDate": "2022-03-01",
    "periodEndDate": "2022-03-30"
  }
}
```

