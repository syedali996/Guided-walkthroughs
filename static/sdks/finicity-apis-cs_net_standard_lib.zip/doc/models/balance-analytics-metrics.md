
# Balance Analytics Metrics

## Structure

`BalanceAnalyticsMetrics`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AvailableBalance` | `double?` | Optional | Available Balance |
| `AvailableBalanceDate` | `string` | Optional | Available Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `AverageDailyBalanceByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Average daily ending balance each month over the report time period |
| `AverageDailyBalanceForTheReportTimePeriod` | `double?` | Optional | Average Daily Balance |
| `AverageWeekdayBalanceForTheReportTimePeriod` | `double?` | Optional | Average Weekday Balance |
| `CountDailyNegativeBalancesByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndCount>`](../../doc/models/obb-date-range-and-count.md) | Optional | Number of negative daily ending balances each month over the report time period |
| `CurrentRunningBalance` | `double?` | Optional | Current Running Balance Date |
| `CurrentRunningBalanceDate` | `string` | Optional | Current Running Balance date<br>**Constraints**: *Minimum Length*: `25`, *Maximum Length*: `25` |
| `DailyBalancesByWeekdayForTheReportTimePeriod` | [`List<Models.ObbDailyBalance>`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account during weekdays over the length of the report |
| `DailyBalancesForTheReportTimePeriod` | [`List<Models.ObbDailyBalance>`](../../doc/models/obb-daily-balance.md) | Optional | Daily balance of the account over the length of the report |
| `HistoricNumberOfWeeksAverageBalanceIncreasing` | [`Models.ObbNumWeeksAverageBalanceIncreasing`](../../doc/models/obb-num-weeks-average-balance-increasing.md) | Optional | Report of average account balance week over week and count of weeks where the average balance increased |
| `MaximumDailyBalanceByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Maximum daily ending balance each month over the report time period |
| `MaximumRunningBalanceForTheReportTimePeriod` | `double?` | Optional | Maximum Running Balance |
| `MinimumDailyBalanceByMonthForTheReportTimePeriod` | [`List<Models.ObbDateRangeAndAmount>`](../../doc/models/obb-date-range-and-amount.md) | Optional | Minimum daily ending balance each month over the report time period |
| `MinimumRunningBalanceForTheReportTimePeriod` | `double?` | Optional | Minimum Running Balance |

## Example (as JSON)

```json
{
  "availableBalance": null,
  "availableBalanceDate": null,
  "averageDailyBalanceByMonthForTheReportTimePeriod": null,
  "averageDailyBalanceForTheReportTimePeriod": null,
  "averageWeekdayBalanceForTheReportTimePeriod": null,
  "countDailyNegativeBalancesByMonthForTheReportTimePeriod": null,
  "currentRunningBalance": null,
  "currentRunningBalanceDate": null,
  "dailyBalancesByWeekdayForTheReportTimePeriod": null,
  "dailyBalancesForTheReportTimePeriod": null,
  "historicNumberOfWeeksAverageBalanceIncreasing": null,
  "maximumDailyBalanceByMonthForTheReportTimePeriod": null,
  "maximumRunningBalanceForTheReportTimePeriod": null,
  "minimumDailyBalanceByMonthForTheReportTimePeriod": null,
  "minimumRunningBalanceForTheReportTimePeriod": null
}
```

