
# Cadence Details

## Structure

`CadenceDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StartDate` | `long?` | Optional | `postedDate` of the first deposit transaction |
| `StopDate` | `long?` | Optional | `postedDate` of the final deposit transaction (omitted if status is active) |
| `Days` | `int?` | Optional | Number of days between the recurring deposits |

## Example (as JSON)

```json
{
  "startDate": null,
  "stopDate": null,
  "days": null
}
```

