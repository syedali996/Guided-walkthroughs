
# Prequalification Report Account

## Structure

`PrequalificationReportAccount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The ID of the account |
| `Number` | `string` | Optional | The account number from the institution (all digits except the last four are obfuscated) |
| `OwnerName` | `string` | Optional | The name of the account owner. If no owner information is available, this field won't appear in the report. |
| `OwnerAddress` | `string` | Optional | The mailing address of the account owner. If no owner information is available, this field won't appear in the report. |
| `Name` | `string` | Optional | The account name from the institution |
| `Type` | `string` | Optional | One of the values from account types |
| `AggregationStatusCode` | `int?` | Optional | The status of the most recent aggregation attempt |
| `Balance` | `double?` | Optional | The cleared balance of the account as-of `balanceDate` |
| `BalanceDate` | `long?` | Optional | A timestamp of the balance |
| `AvailableBalance` | `double?` | Optional | Available balance |
| `AverageMonthlyBalance` | `double?` | Optional | The average monthly balance of the account |
| `TotNumberInsufficientFundsFeeDebitTxAccount` | `int?` | Optional | The count for the total number of insufficient funds transactions, based on the `fromDate` of the report |
| `TotNumberInsufficientFundsFeeDebitTxOver6MonthsAccount` | `int?` | Optional | The total number of  insufficient funds fees for the account over six months |
| `TotNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount` | `long?` | Optional | The total number of days since the most recent insufficient funds fee for the account |
| `Transactions` | [`List<Models.ReportTransaction>`](../../doc/models/report-transaction.md) | Optional | a list of transaction records |
| `Asset` | [`Models.PrequalificationReportAssetSummary`](../../doc/models/prequalification-report-asset-summary.md) | Optional | - |
| `Details` | [`Models.AccountDetails`](../../doc/models/account-details.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "number": null,
  "ownerName": null,
  "ownerAddress": null,
  "name": null,
  "type": null,
  "aggregationStatusCode": null,
  "balance": null,
  "balanceDate": null,
  "availableBalance": null,
  "averageMonthlyBalance": null,
  "totNumberInsufficientFundsFeeDebitTxAccount": null,
  "totNumberInsufficientFundsFeeDebitTxOver6MonthsAccount": null,
  "totNumberDaysSinceMostRecentInsufficientFundsFeeDebitTxAccount": null,
  "transactions": null,
  "asset": null,
  "details": null
}
```

