
# Report Income Estimate

## Structure

`ReportIncomeEstimate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NetAnnual` | `double` | Required | - |
| `ProjectedNetAnnual` | `double` | Required | - |
| `EstimatedGrossAnnual` | `double` | Required | - |
| `ProjectedGrossAnnual` | `double` | Required | - |

## Example (as JSON)

```json
{
  "netAnnual": 1000.12,
  "projectedNetAnnual": 1500.23,
  "estimatedGrossAnnual": 2000.12,
  "projectedGrossAnnual": 2500.23
}
```

