
# Institution

A financial institution

## Structure

`Institution`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long` | Required | The ID of a financial institution, represented as a number |
| `Name` | `string` | Optional | The name of the institution |
| `TransAgg` | `bool` | Required | "true": The institution is certified for the Transaction Aggregation product<br>"false": The institution is decertified for the Transaction Aggregation product |
| `Ach` | `bool` | Required | "true": The institution is certified for the ACH product<br>"false": The institution is decertified for the ACH product |
| `StateAgg` | `bool` | Required | "true": The institution is certified for the Statement Aggregation product<br>"false": The institution is decertified for the Statement Aggregation product |
| `Voi` | `bool` | Required | "true": The institution is certified for the VOI product<br>"false": The institution is decertified for the VOI product |
| `Voa` | `bool` | Required | "true": The institution is certified for the VOA product<br>"false": The institution is decertified for the VOA product |
| `Aha` | `bool` | Required | "true": The institution is certified for the Account History Aggregation product<br>"false": The institution is decertified for the Account History Aggregation product |
| `AvailBalance` | `bool` | Required | "true": The institution is certified for the Account Balance Check (ABC) product<br>"false": The institution is decertified for the Account Balance Check (ABC) product |
| `AccountOwner` | `bool` | Required | "true": The institution is certified for the Account Owner product<br>"false": The institution is decertified for the Account Owner product |
| `StudentLoanData` | `bool?` | Optional | "true": The institution is certified for the Student Loan Data product<br><br>"false": The institution is decertified for the Student Loan Data product |
| `LoanPaymentDetails` | `bool?` | Optional | "true": The institution is certified for the Loan Payment Detail product<br><br>"false": The institution is decertified for the Loan Payment Detail product |
| `AccountTypeDescription` | `string` | Optional | Values: Banking, Investments, Credit Cards/Accounts, Workplace Retirement, Mortgages and Loans, Insurance |
| `Phone` | `string` | Optional | A phone number |
| `UrlHomeApp` | `string` | Optional | The URL of the institution's primary home page |
| `UrlLogonApp` | `string` | Optional | The URL of the institution's login page |
| `OauthEnabled` | `bool` | Required | "true": The institution is an OAuth connection<br><br>"false": The institution isn't an OAuth connection |
| `UrlForgotPassword` | `string` | Optional | Institution's forgot password page |
| `UrlOnlineRegistration` | `string` | Optional | Institution's signup page |
| `Class` | `string` | Optional | Institution's class |
| `SpecialText` | `string` | Optional | Special instructions given to customers for login |
| `TimeZone` | `string` | Optional | The time zone of the institution. |
| `SpecialInstructions` | `List<string>` | Optional | Instructions given to the customer before they are sent to the institution website to login for OAuth institutions.<br><br>Note: this helps the customer to provide the proper permission for data needed for the application. |
| `SpecialInstutionsTitle` | `string` | Optional | The title of the special instructions, if one exists or is required. |
| `Address` | [`Models.InstitutionAddress`](../../doc/models/institution-address.md) | Optional | The address of a financial institution |
| `Currency` | `string` | Required | A currency code |
| `Email` | `string` | Optional | An email address |
| `Status` | `string` | Required | Status for the institution: "online", "offline", "maintenance", "testing" |
| `NewInstitutionId` | `long?` | Optional | The ID of a financial institution, represented as a number |
| `Branding` | [`Models.Branding`](../../doc/models/branding.md) | Optional | All assets are SVGs so can be slightly resized without any issues. |
| `OauthInstitutionId` | `long?` | Optional | The ID of a financial institution, represented as a number |

## Example (as JSON)

```json
{
  "id": 4222,
  "transAgg": true,
  "ach": true,
  "stateAgg": false,
  "voi": true,
  "voa": true,
  "aha": false,
  "availBalance": false,
  "accountOwner": true,
  "oauthEnabled": true,
  "currency": "USD",
  "status": "online"
}
```

