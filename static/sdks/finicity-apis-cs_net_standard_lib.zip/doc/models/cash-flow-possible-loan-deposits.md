
# Cash Flow Possible Loan Deposits

## Structure

`CashFlowPossibleLoanDeposits`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | Finicity institution ID |
| `Name` | `string` | Required | Finicity institution name |
| `UrlHomeApp` | `string` | Required | The URL of the Financial Institution |
| `Accounts` | [`List<Models.CashFlowPossibleLoanDepositsAccount>`](../../doc/models/cash-flow-possible-loan-deposits-account.md) | Required | A list of account records |

## Example (as JSON)

```json
{
  "id": "102105",
  "name": "FinBank Profiles",
  "urlHomeApp": "http://www.finbank.com",
  "accounts": {
    "id": "6681984",
    "ownerName": "PATRICK & LORRAINE PURCHASER",
    "ownerAddress": "7195 BELMONT ST. PARLIN, NJ 08859",
    "name": "Checking",
    "number": "XX1111",
    "type": "checking",
    "aggregationStatusCode": "0",
    "currentBalance": 100000,
    "availableBalance": 1000,
    "balanceDate": 1614880526,
    "transactions": {
      "id": 21284820852,
      "postedDate": 1571313600,
      "description": "ATM CHECK DEPOSIT mm/dd",
      "normalizedPayee": "T-Mobile",
      "institutionTransactionId": "0000000000",
      "category": "Income"
    }
  }
}
```

