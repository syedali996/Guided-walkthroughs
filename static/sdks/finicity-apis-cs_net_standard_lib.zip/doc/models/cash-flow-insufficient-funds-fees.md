
# Cash Flow Insufficient Funds Fees

## Structure

`CashFlowInsufficientFundsFees`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CountOfTransactionsForTheReportTimePeriod` | `int?` | Optional | Count of all NSF transactions during the report |
| `SumOfTransactionsForTheReportTimePeriod` | `double?` | Optional | Sum of all NSF transactions during the report |
| `Transactions` | [`List<Models.InsufficientFundsTransaction>`](../../doc/models/insufficient-funds-transaction.md) | Optional | Transactions categorized as NSF |

## Example (as JSON)

```json
{
  "countOfTransactionsForTheReportTimePeriod": null,
  "sumOfTransactionsForTheReportTimePeriod": null,
  "transactions": null
}
```

