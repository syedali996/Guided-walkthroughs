
# Cash Flow Cash Flow Characteristic

## Structure

`CashFlowCashFlowCharacteristic`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MonthlyCashFlowCharacteristics` | [`List<Models.CashFlowMonthlyCashFlowCharacteristics>`](../../doc/models/cash-flow-monthly-cash-flow-characteristics.md) | Required | List of attributes for each month |
| `AverageMonthlyNet` | `double` | Required | Average (Total Credits - Total Debits) for the account |
| `AverageMonthlyNetLessTransfers` | `double` | Required | Average (Total Credits - Total Debits) without transfers for the account |
| `TwelveMonthTotalNet` | `double` | Required | Sum of all monthly (Total Credits - Total Debits) each month for the account |
| `TwelveMonthTotalNetLessTransfers` | `double` | Required | Sum of all monthly (Total Credits - Total Debits) without transfers for the account |
| `SixMonthAverageTotalCreditsLessTotalDebits` | `double` | Required | 6 Month Average (Total Credits - Total Debits) |
| `SixMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | 6 Month Average (Total Credits - Total Debits) - (Without Transfers) |
| `TwoMonthAverageTotalCreditsLessTotalDebits` | `double` | Required | 2 Month Average (Total Credits - Total Debits) |
| `TwoMonthAverageTotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | 2 Month Average (Total Credits - Total Debits) - (Without Transfers) |

## Example (as JSON)

```json
{
  "monthlyCashFlowCharacteristics": {
    "month": 1512111600,
    "totalCreditsLessTotalDebits": 15000,
    "totalCreditsLessTotalDebitsLessTransfers": 11000,
    "averageTransactionAmount": 10
  },
  "averageMonthlyNet": 2350,
  "averageMonthlyNetLessTransfers": 1000,
  "twelveMonthTotalNet": 12500,
  "twelveMonthTotalNetLessTransfers": 12400,
  "sixMonthAverageTotalCreditsLessTotalDebits": 55555,
  "sixMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebits": 55555,
  "twoMonthAverageTotalCreditsLessTotalDebitsLessTransfers": 55555
}
```

