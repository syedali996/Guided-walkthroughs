
# VOIE Paystub With Statement Pay Statement

## Structure

`VOIEPaystubWithStatementPayStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PayPeriod` | `string` | Required | The pay period of the pay statement |
| `Billable` | `bool` | Required | This will display true if the pay statement is billable. If a pay statement has been digitized previously, this will display as false as it will not be billable. |
| `AssetId` | `string` | Required | The asset ID of the stored pay statement |
| `PayDate` | `long` | Required | The listed pay date for the pay statement |
| `StartDate` | `long` | Required | The beginning of the pay period |
| `EndDate` | `long` | Required | The end of the pay period |
| `NetPayCurrent` | `double` | Required | The total pay after deductions for the employee for the current pay period |
| `NetPayYTD` | `double` | Required | The total accumulation of pay after deductions for the employee for the current pay year |
| `GrossPayCurrent` | `double` | Required | The total pay before deductions for the employee for the current pay period |
| `GrossPayYTD` | `double` | Required | The total accumulation of pay before deductions for the employee for the current pay year |
| `PayrollProvider` | `string` | Optional | The payroll provider extracted from the pay statement |
| `Employer` | [`Models.Employer`](../../doc/models/employer.md) | Required | - |
| `Employee` | [`Models.Employee`](../../doc/models/employee.md) | Required | - |
| `PayStat` | [`List<Models.PayStat>`](../../doc/models/pay-stat.md) | Required | Information pertaining to the earnings on the pay statement |
| `DirectDeposits` | [`List<Models.DirectDeposit>`](../../doc/models/direct-deposit.md) | Required | Information pertaining to the direct deposits on the pay statement |
| `MonthlyIncome` | [`Models.PaystubMonthlyIncomeRecord`](../../doc/models/paystub-monthly-income-record.md) | Required | - |
| `Institutions` | `List<string>` | Required | Not populated for the voieWithStatement style of paystub report. For the VOIE - Paystub (with TXVerify) reports this would include details of the financial institution accounts and income streams with matching transactions to the pay statement. |
| `ErrorCode` | `int?` | Optional | Error code for the asset |
| `ErrorMessage` | `string` | Optional | Error message for the asset |

## Example (as JSON)

```json
{
  "payPeriod": "LastPayPeriod",
  "billable": true,
  "assetId": "6f8fb0a0-e882-4f57-b672-cf53f1397581",
  "payDate": 1559241000,
  "startDate": 1557513000,
  "endDate": 1558722600,
  "netPayCurrent": 1802.22,
  "netPayYTD": 36000,
  "grossPayCurrent": 24200,
  "grossPayYTD": 72600,
  "employer": null,
  "employee": null,
  "payStat": null,
  "directDeposits": null,
  "monthlyIncome": null,
  "institutions": []
}
```

