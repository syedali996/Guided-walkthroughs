
# Cash Flow Monthly Cash Flow Characteristic Summaries

## Structure

`CashFlowMonthlyCashFlowCharacteristicSummaries`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Month` | `long` | Required | One instance for each complete calendar month in the report |
| `TotalCreditsLessTotalDebits` | `double` | Required | Total Credits - Total Debits by month across all accounts |
| `TotalCreditsLessTotalDebitsLessTransfers` | `double` | Required | Total Credits - Total Debits by month (Without Transfers) across all accounts |
| `AverageTransactionAmount` | `double` | Required | Average transaction amount across all accounts |

## Example (as JSON)

```json
{
  "month": 1512111600,
  "totalCreditsLessTotalDebits": 15000,
  "totalCreditsLessTotalDebitsLessTransfers": 11000,
  "averageTransactionAmount": 10
}
```

