
# Employee

## Structure

`Employee`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | The name of the employee |

## Example (as JSON)

```json
{
  "name": null
}
```

