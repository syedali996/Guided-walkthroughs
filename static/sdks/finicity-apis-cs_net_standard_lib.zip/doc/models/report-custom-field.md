
# Report Custom Field

## Structure

`ReportCustomField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `string` | Optional | The name of the custom field |
| `MValue` | `string` | Optional | The value of the custom field |
| `Shown` | `bool?` | Optional | If the custom field will show on the PDF or not |

## Example (as JSON)

```json
{
  "label": null,
  "value": null,
  "shown": null
}
```

