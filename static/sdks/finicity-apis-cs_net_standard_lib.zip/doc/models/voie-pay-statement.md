
# VOIE Pay Statement

## Structure

`VOIEPayStatement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PayPeriod` | `string` | Optional | The pay period of the pay statement |
| `Billable` | `bool?` | Optional | Designates whether the pay statement is billable |
| `AssetId` | `string` | Optional | The asset ID of the stored pay statement |
| `PayDate` | `long?` | Optional | The listed pay date for the pay statement |
| `StartDate` | `long?` | Optional | The beginning of the pay period |
| `EndDate` | `long?` | Optional | The end of the pay period |
| `NetPayCurrent` | `double?` | Optional | The total pay after deductions for the employee for the current pay period |
| `NetPayYTD` | `double?` | Optional | The total accumulation of pay after deductions for the employee for the current pay year |
| `GrossPayCurrent` | `double?` | Optional | The total pay before deductions for the employee for the current pay period |
| `GrossPayYTD` | `double?` | Optional | The total accumulation of pay before deductions for the employee for the current pay year |
| `PayrollProvider` | `string` | Optional | The company that provides the pay stub. |
| `Employer` | [`Models.Employer`](../../doc/models/employer.md) | Optional | - |
| `Employee` | [`Models.Employee`](../../doc/models/employee.md) | Optional | - |
| `PayStat` | [`List<Models.PayStat>`](../../doc/models/pay-stat.md) | Optional | Information pertaining to the earnings on the pay statement |
| `Deductions` | [`List<Models.Deduction>`](../../doc/models/deduction.md) | Optional | Information pertaining to deductions on the pay statement |
| `DirectDeposits` | [`List<Models.DirectDeposit>`](../../doc/models/direct-deposit.md) | Optional | Information pertaining to direct deposits on the pay statement |

## Example (as JSON)

```json
{
  "payPeriod": null,
  "billable": null,
  "assetId": null,
  "payDate": null,
  "startDate": null,
  "endDate": null,
  "netPayCurrent": null,
  "netPayYTD": null,
  "grossPayCurrent": null,
  "grossPayYTD": null,
  "payrollProvider": null,
  "employer": null,
  "employee": null,
  "payStat": null,
  "deductions": null,
  "directDeposits": null
}
```

