
# Statement Data

## Structure

`StatementData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountId` | `long` | Required | An account ID represented as a number |
| `Index` | `int?` | Optional | Index of the statement to retrieve<br>**Default**: `1`<br>**Constraints**: `<= 6` |

## Example (as JSON)

```json
{
  "accountId": 5011648377
}
```

