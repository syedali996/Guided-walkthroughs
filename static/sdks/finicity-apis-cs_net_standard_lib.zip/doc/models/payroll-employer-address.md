
# Payroll Employer Address

## Structure

`PayrollEmployerAddress`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address1` | `string` | Optional | Employer address as stated by the employer in the payroll system |
| `City` | `string` | Optional | Employer city as stated by the employer in the payroll system |
| `State` | `string` | Optional | Employer state as stated by the employer in the payroll system |
| `Zip` | `string` | Optional | Employer zip code as stated by the employer in the payroll system |

## Example (as JSON)

```json
{
  "address1": null,
  "city": null,
  "state": null,
  "zip": null
}
```

