
# Pay Stat

## Structure

`PayStat`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | The normalized category of the earnings with a number appended. The number is the will be the iterating number of the type's occurrence starting at one. |
| `Type` | `string` | Optional | The categorization based on the earning line's description. Possible values:<br><br>* "bereavement"<br><br>* "bonus"<br><br>* "commission"<br><br>* "holiday"<br><br>* "jury duty"<br><br>* "overtime"<br><br>* "pension"<br><br>* "pto"<br><br>* "regular"<br><br>* "sick"<br><br>* "tips"<br><br>* "unknown"<br><br>* "vacation"<br><br>* "reimbursement"<br><br>* "stock"<br><br>* "benefit" |
| `Description` | `string` | Optional | The earnings line's pay type description |
| `AmountCurrent` | `double?` | Optional | The amount for the earning line paid out to the employee for the specified pay period. |
| `AmountYTD` | `double?` | Optional | The amount for the earning line being paid out to the employee for the current pay year. |

## Example (as JSON)

```json
{
  "name": null,
  "type": null,
  "description": null,
  "amountCurrent": null,
  "amountYTD": null
}
```

