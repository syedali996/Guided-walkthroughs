
# Customer Update

Represent an update to customer fields

## Structure

`CustomerUpdate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | First name(s) / given name(s) |
| `LastName` | `string` | Optional | Last name(s) / surname(s) |

## Example (as JSON)

```json
{
  "firstName": null,
  "lastName": null
}
```

